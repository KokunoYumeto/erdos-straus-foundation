#!/usr/bin/env python3
"""Exact Gaussian-integer certificate for the supplied arctangent identity."""

from fractions import Fraction
from hashlib import sha256
from math import gcd


TERMS = (
    (4, 239, 28560),
    (8, 123, 7564),
    (8, 119, 7080),
    (8, 99, 4900),
    (8, 83, 3444),
    (8, 75, 2812),
    (8, 55, 1512),
    (8, 43, 924),
    (8, 31, 480),
    (8, 27, 364),
    (16, 47, 1104),
    (8, 23, 264),
    (8, 7, 24),
)

EXPECTED_CANONICAL_SCALE = 7_000_883_909_987_072_035_037_915_496_781_910_480_000_000_000

COMPRESSIONS = (
    (
        "in-order Alferov compression",
        ((1, 239), (2, 3), (2, 15), (2, 437)),
        72_939_081_800,
    ),
    (
        "reordering-assisted compression",
        ((1, 239), (2, 7), (2, 4), (2, 268)),
        10_317_661_250,
    ),
)


def gaussian_mul(z: tuple[int, int], w: tuple[int, int]) -> tuple[int, int]:
    a, b = z
    c, d = w
    return a * c - b * d, a * d + b * c


def gaussian_pow(z: tuple[int, int], exponent: int) -> tuple[int, int]:
    result = (1, 0)
    base = z
    while exponent:
        if exponent & 1:
            result = gaussian_mul(result, base)
        base = gaussian_mul(base, base)
        exponent >>= 1
    return result


def main() -> None:
    product = (1, 0)
    canonical_product = (1, 0)
    rational_upper_bound = Fraction(0)

    for coefficient, numerator, denominator in TERMS:
        assert coefficient > 0 and coefficient % 2 == 0
        assert 0 < numerator < denominator
        assert denominator == (numerator * numerator - 1) // 2
        product = gaussian_mul(
            product,
            gaussian_pow((denominator, numerator), coefficient // 2),
        )
        canonical_product = gaussian_mul(
            canonical_product,
            gaussian_pow((numerator, 1), coefficient // 4),
        )
        rational_upper_bound += coefficient * Fraction(numerator, denominator)

    real, imag = product
    assert imag == 0
    assert real < 0
    assert canonical_product == (
        EXPECTED_CANONICAL_SCALE,
        EXPECTED_CANONICAL_SCALE,
    )

    # Since atan(x) < x for x > 0, the sum is below this rational number.
    # The exact bound below is < 12 < 4*pi (using only pi > 3).
    assert rational_upper_bound < 12

    # For S = sum c_j atan(p_j/q_j), the argument of the product computed
    # above is S/2 modulo 2*pi.  The product is negative real, so
    # S/2 = pi modulo 2*pi, equivalently S = 2*pi modulo 4*pi.
    # Positivity and 0 < S < 4*pi then force S = 2*pi.
    decimal = str(abs(real)).encode("ascii")
    print("EXACT ARCTANGENT CERTIFICATE: PASS")
    print("terms =", len(TERMS))
    print("Gaussian product imaginary part =", imag)
    print("Gaussian product real sign = negative")
    print("Gaussian product real part =", real)
    print("Gaussian product decimal digits =", len(decimal))
    print("Gaussian product SHA-256 =", sha256(decimal).hexdigest())
    print("sum(c*p/q) =", rational_upper_bound)
    print("sum(c*p/q) < 12 < 4*pi")
    print("conclusion: supplied arctangent sum = 2*pi exactly")
    print()
    print("DOUBLE-ANGLE NORMALIZATION: PASS")
    print("Each denominator is (n^2-1)/2, so atan(n/q)=2*atan(1/n).")
    print("Canonical pi/4 Gaussian product scale =", EXPECTED_CANONICAL_SCALE)
    print("Canonical product = scale*(1+i): PASS")

    # The rational half-angle reductions used in the attached derivation.
    assert 119 * 119 + 120 * 120 == 169 * 169
    assert Fraction(119, 169 + 120) == Fraction(7, 17)
    assert 2016 * 2016 + 3713 * 3713 == 4225 * 4225
    assert Fraction(2016, 4225 + 3713) == Fraction(16, 63)
    residual_num = 16 * 4 - 63
    residual_den = 63 * 4 + 16
    divisor = gcd(abs(residual_num), residual_den)
    assert Fraction(residual_num // divisor, residual_den // divisor) == Fraction(1, 268)
    print("R = atan(7/17), R* = atan(16/63), and the q=4 residual is atan(1/268): PASS")

    for label, terms, expected_scale in COMPRESSIONS:
        compressed_product = (1, 0)
        for coefficient, denominator in terms:
            compressed_product = gaussian_mul(
                compressed_product,
                gaussian_pow((denominator, 1), coefficient),
            )
        assert compressed_product == (expected_scale, expected_scale)
        print(f"{label}: product = {expected_scale}*(1+i): PASS")


if __name__ == "__main__":
    main()

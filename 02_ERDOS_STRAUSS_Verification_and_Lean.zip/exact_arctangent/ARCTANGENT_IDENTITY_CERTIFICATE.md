# Exact certificate for the thirteen-term arctangent identity

**Author:** The Clankers  
**Date:** 4 August 2026  
**Status:** exact integer certificate

Let

\[
S=4\arctan\frac{239}{28560}
+8\arctan\frac{123}{7564}
+8\arctan\frac{119}{7080}
+8\arctan\frac{99}{4900}
+8\arctan\frac{83}{3444}
+8\arctan\frac{75}{2812}
+8\arctan\frac{55}{1512}
+8\arctan\frac{43}{924}
+8\arctan\frac{31}{480}
+8\arctan\frac{27}{364}
+16\arctan\frac{47}{1104}
+8\arctan\frac{23}{264}
+8\arctan\frac7{24}.
\]

The identity is

\[
\boxed{S=2\pi}.
\]

## Gaussian-integer certificate

For a term with coefficient \(c\), numerator \(p\), and denominator \(q\),
the Gaussian integer \((q+ip)^{c/2}\) has argument
\(c\arctan(p/q)/2\). Direct integer multiplication gives

\[
\prod_{(c,p,q)}(q+ip)^{c/2}=-N,
\]

where

\[
\begin{split}
N={}&533398426366211379076240852028242799456225248149741355242513751365656074311493877248645719337700873411581397818680257884379853664572149408932091319002211093902587890625.
\end{split}
\]

The imaginary part is exactly zero. Hence

\[
\frac S2\equiv\pi\pmod{2\pi},
\qquad
S\equiv2\pi\pmod{4\pi}.
\]

All summands are positive. The elementary inequality \(\arctan x<x\) for
\(x>0\) gives the exact rational bound

\[
S<\sum\frac{cp}{q}
=\frac{37767180968828412971}{5946964827704225325}
<12<4\pi,
\]

where the last inequality uses \(\pi>3\). Thus \(0<S<4\pi\), which selects
the unique permitted branch \(S=2\pi\).

The decimal residual near \(-2.31\times10^{-128}\) is rounding error. Its
exponent follows the working precision. The negative real sign of the exact
Gaussian product is structural and selects the \(2\pi\) branch.

## Double-angle normalization

Every denominator is

\[
q=\frac{p^2-1}{2}.
\]

Consequently

\[
\arctan\frac pq=2\arctan\frac1p,
\]

with no branch correction because both sides lie in \((0,\pi/2)\). Dividing
the normalized identity by eight gives

\[
\begin{split}
\frac\pi4={}&\arctan\frac1{239}
+2\arctan\frac1{123}+2\arctan\frac1{119}
+2\arctan\frac1{99}+2\arctan\frac1{83}
+2\arctan\frac1{75}+2\arctan\frac1{55}
+2\arctan\frac1{43}+2\arctan\frac1{31}
+2\arctan\frac1{27}+4\arctan\frac1{47}
+2\arctan\frac1{23}+2\arctan\frac17.
\end{split}
\]

The associated exact product is

\[
(239+i)(47+i)^4
\prod_{n\in\{123,119,99,83,75,55,43,31,27,23,7\}}(n+i)^2
=C(1+i),
\]

with

\[
C=7000883909987072035037915496781910480000000000.
\]

## Two exact Alferov compressions

The in-order remainder satisfies

\[
R=\arctan\frac7{17}
=\arctan\frac13+\arctan\frac1{15}+\arctan\frac1{437}.
\]

It yields

\[
\frac\pi4
=\arctan\frac1{239}
+2\arctan\frac13
+2\arctan\frac1{15}
+2\arctan\frac1{437},
\]

certified by

\[
(239+i)(3+i)^2(15+i)^2(437+i)^2
=72939081800(1+i).
\]

Retaining the \(1/7\) term first gives

\[
R_\ast=\arctan\frac{16}{63}
=\arctan\frac14+\arctan\frac1{268}.
\]

Therefore

\[
\boxed{
\frac\pi4
=\arctan\frac1{239}
+2\arctan\frac17
+2\arctan\frac14
+2\arctan\frac1{268}}
\]

and

\[
(239+i)(7+i)^2(4+i)^2(268+i)^2
=10317661250(1+i).
\]

The Lehmer measures, using the convention in the Craig-Wood paper, are

\[
L_{\rm printed}=10.160249009399820,
\quad
L_0=8.007892083871997,
\quad
L_{\rm compressed}=3.676548554799244.
\]

The last value is a \(54.0884353049\%\) reduction from the canonical
unit-numerator source measure.

## Lorentz and circle interpretation

Each normalized parameter \(n\) determines the primitive Pythagorean vector

\[
v_n=\left(\frac{n^2+1}{2},\frac{n^2-1}{2},n\right),
\qquad
v_{n,0}^2-v_{n,1}^2-v_{n,2}^2=0.
\]

Its rational unit-circle point is

\[
\left(\frac{n^2-1}{n^2+1},\frac{2n}{n^2+1}\right).
\]

This gives an exact arithmetic map from every angle in the identity to a
primitive null ray in the three-dimensional Lorentz slice used by the
Erdős--Strauss/Fable circle construction.

The supplied screenshot and angle list do not determine the claimed
Super-Apollonian enumeration. Establishing that provenance requires the
GeoGebra XML or an equivalent ordered circle/tangency export. The integer
certificate establishes the identity independently of that missing geometric
provenance.

## Reproduction

Run:

```text
python analysis/root_system_bridge_check/verify_arctan_identity.py
```

The script uses Python integers and `fractions.Fraction`; no transcendental
numerics enter the proof.

`ArctangentGaussianCertificate.lean` contains the corresponding denominator
and Gaussian-product propositions. They use kernel reduction through `decide`.
The file compiled successfully with Lean 4.32.0 on 4 August 2026.

The preliminary reduction was supplied in a public discussion by Reddit user
u/UmbrellaCorp_HR. The constrained-PSLQ and Alferov methodology is discussed
by Nick Craig-Wood in arXiv:2508.08307v1.

#!/usr/bin/env python3
"""Independent checks for the core identities selected for the ES reader.

This is a clean-room replay: constants and formulas are transcribed from the
named manuscript sections, but the script does not import or execute any old
project checker. It emits a deterministic JSON report to stdout.
"""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from fractions import Fraction
from itertools import product

import sympy as sp


CHECKER_ID = "es-core-identities-2026-08-04-r1"


def canonical_coset(x: int, subgroup: frozenset[int], modulus: int) -> tuple[int, ...]:
    return tuple(sorted((x + k) % modulus for k in subgroup))


def quotient_image_size(values: set[int], subgroup: frozenset[int], modulus: int) -> int:
    return len({canonical_coset(x, subgroup, modulus) for x in values})


def divisors_from_factorization(factors: list[tuple[int, int]]) -> list[int]:
    values = [1]
    for prime, exponent in factors:
        values = [v * prime**e for v in values for e in range(exponent + 1)]
    return sorted(values)


def record(results: list[dict[str, object]], check_id: str, passed: bool, detail: object) -> None:
    if not passed:
        raise AssertionError(f"{check_id}: {detail}")
    results.append({"check_id": check_id, "status": "PASS", "detail": detail})


def main() -> int:
    results: list[dict[str, object]] = []

    # Fourier and Lorentz support identities.
    m0, m1, m2 = sp.symbols("m0 m1 m2", real=True)
    sigma = m0 + m1 + m2
    phase_real = m0 - (m1 + m2) / 2
    phase_imag = sp.sqrt(3) * (m1 - m2) / 2
    phase_norm = sp.expand(phase_real**2 + phase_imag**2)
    expected_phase_norm = m0**2 + m1**2 + m2**2 - m0 * m1 - m1 * m2 - m2 * m0
    record(
        results,
        "fourier_phase_norm",
        sp.simplify(phase_norm - expected_phase_norm) == 0,
        str(expected_phase_norm),
    )
    lorentz = sp.expand(sigma**2 - phase_norm)
    expected_lorentz = 3 * (m0 * m1 + m1 * m2 + m2 * m0)
    record(results, "support_lorentz_identity", sp.simplify(lorentz - expected_lorentz) == 0, str(expected_lorentz))

    # Algebraic Wick substitution (polynomial substitution, not analytic continuation).
    S, X, Y = sp.symbols("S X Y", real=True)
    wick = sp.expand(S**2 + (sp.I * X) ** 2 + (sp.I * Y) ** 2)
    record(results, "wick_polynomial_identity", sp.simplify(wick - (S**2 - X**2 - Y**2)) == 0, str(wick))

    # Sarnak's Descartes form in the orthogonal basis used by the reader.
    T, W = sp.symbols("T W", real=True)
    sqrt2 = sp.sqrt(2)
    b = sp.Matrix(
        [
            T / 2 + X / sqrt2 + Y / 2,
            T / 2 - X / sqrt2 + Y / 2,
            T / 2 - Y / 2 + W / sqrt2,
            T / 2 - Y / 2 - W / sqrt2,
        ]
    )
    descartes = sp.expand(2 * sum(value**2 for value in b) - sum(b) ** 2)
    descartes_diagonal = 2 * (X**2 + Y**2 + W**2 - T**2)
    record(results, "descartes_orthogonal_basis", sp.simplify(descartes - descartes_diagonal) == 0, str(descartes_diagonal))

    t, x, y = sp.symbols("t x y", real=True)
    fable_pullback = descartes_diagonal.subs({T: t, X: sp.sqrt(3) * x / 2, Y: y, W: 0})
    q = t**2 - sp.Rational(3, 4) * x**2 - y**2
    record(results, "fable_descartes_pullback", sp.simplify(fable_pullback + 2 * q) == 0, str(sp.expand(fable_pullback)))

    # Coefficient-to-Sarnak coordinate identity.
    a, c, b0, b1 = sp.symbols("a c b0 b1", real=True)
    coefficient_T = (a + c) / 2
    coefficient_W = (a - c) / 2
    coefficient_norm = b0**2 + b1**2 - a * c
    coefficient_diagonal = X**2 + Y**2 + W**2 - T**2
    coefficient_substitution = sp.expand(
        coefficient_diagonal.subs(
            {T: coefficient_T, X: b0, Y: b1, W: coefficient_W}
        )
    )
    record(
        results,
        "coefficient_sarnak_isometry",
        sp.simplify(coefficient_substitution - coefficient_norm) == 0,
        str(coefficient_substitution),
    )

    # Kocik's equal-angle equation in orthogonal coordinates.
    p = sp.symbols("p", real=True)
    radial2 = sp.symbols("radial2", real=True)
    kocik_equation = sp.together(
        (T**2 + radial2) - (p / (3 * p - 1)) * (2 * T) ** 2
    )
    kocik_target = radial2 - ((p + 1) / (3 * p - 1)) * T**2
    record(results, "kocik_sarnak_rearrangement", sp.simplify(kocik_equation - kocik_target) == 0, str(kocik_target))

    # Divisor-shell factorization and reconstruction algebra.
    R, N, b_sym, c_sym, d, e = sp.symbols("R N b c d e", nonzero=True)
    factorized = sp.expand((R * b_sym - N) * (R * c_sym - N) - N**2)
    shell_relation = R * (R * b_sym * c_sym - N * (b_sym + c_sym))
    record(results, "divisor_shell_factorization", sp.simplify(factorized - shell_relation) == 0, str(factorized))
    reconstructed_b = (N + d) / R
    reconstructed_c = (N + e) / R
    reconstructed_relation = sp.factor(R * reconstructed_b * reconstructed_c - N * (reconstructed_b + reconstructed_c))
    record(
        results,
        "divisor_shell_reconstruction",
        sp.simplify(reconstructed_relation - (d * e - N**2) / R) == 0,
        str(reconstructed_relation),
    )

    s = sp.symbols("s", real=True)
    r = 2 * s - 1
    zeta = -s * (1 - s)
    record(results, "quarter_branch_centering", sp.simplify(zeta - (-sp.Rational(1, 4) + r**2 / 4)) == 0, str(sp.expand(zeta)))

    # Exact 12289 certificate and origin counts.
    certificate_lhs = Fraction(4, 12289)
    certificate_rhs = Fraction(1, 3075) + Fraction(1, 3_440_920) + Fraction(1, 2_116_165_800)
    record(results, "certificate_12289", certificate_lhs == certificate_rhs, str(certificate_rhs))

    p12289, r12289, a12289 = 12289, 11, 3075
    inv_a = pow(a12289, -1, r12289)
    divisors_a2 = divisors_from_factorization([(3, 2), (5, 4), (41, 2)])
    origin_counts: list[int] = []
    origin_witnesses: list[list[int]] = []
    for j in range(3):
        target = (-p12289 * pow(p12289, -j, r12289)) % r12289
        witnesses = [u for u in divisors_a2 if (u * inv_a) % r12289 == target]
        origin_counts.append(len(witnesses))
        origin_witnesses.append(witnesses)
    record(
        results,
        "origin_counts_12289",
        origin_counts == [3, 6, 3],
        {"counts": origin_counts, "witnesses": origin_witnesses},
    )

    # Complete C10 quotient-surplus table and direct target hit.
    modulus = 10
    sets = [{0, 2, 8}, {0, 2, 4, 6, 8}, {0, 3, 7}]
    targets = {4, 5}
    subgroup_orders = [1, 2, 5, 10]
    surplus_profile: list[int] = []
    quotient_rows: list[dict[str, object]] = []
    for order in subgroup_orders:
        subgroup = frozenset((k * (modulus // order)) % modulus for k in range(order))
        quotient_order = modulus // order
        image_sizes = [quotient_image_size(values, subgroup, modulus) for values in sets]
        target_size = quotient_image_size(targets, subgroup, modulus)
        kappa = 1 + sum(size - 1 for size in image_sizes)
        surplus = kappa + target_size - quotient_order
        surplus_profile.append(surplus)
        quotient_rows.append(
            {
                "subgroup_order": order,
                "quotient_order": quotient_order,
                "image_sizes": image_sizes,
                "kappa": kappa,
                "target_size": target_size,
                "surplus": surplus,
            }
        )
    record(results, "star_kneser_surplus_12289", surplus_profile == [1, 6, 2, 1], quotient_rows)
    sumset = {sum(values) % modulus for values in product(*[sorted(values) for values in sets])}
    record(results, "star_kneser_target_hit_12289", bool(sumset & targets), {"sumset": sorted(sumset), "hits": sorted(sumset & targets)})

    # Core mod-107 / Busy-Beaver congruences.
    mod = 107
    pstar = 8_803_369
    astar = 2_200_869
    nstar = pstar * astar
    s3 = 21
    s5 = 47_176_870
    space5 = 12_289
    congruences = {
        "pstar": pstar % mod,
        "astar": astar % mod,
        "nstar": nstar % mod,
        "s3_inverse": pow(s3, -1, mod),
        "s5": s5 % mod,
        "s3_s5": (s3 * s5) % mod,
        "minus_s3_s5": (-s3 * s5) % mod,
        "eleven_squared": 11**2 % mod,
        "space5_mod_107": space5 % mod,
        "space5_mod_840": space5 % 840,
        "289_pow_5_mod_840": pow(289, 5, 840),
    }
    expected_congruences = {
        "pstar": 51,
        "astar": 93,
        "nstar": 35,
        "s3_inverse": 51,
        "s5": 35,
        "s3_s5": 93,
        "minus_s3_s5": 14,
        "eleven_squared": 14,
        "space5_mod_107": 91,
        "space5_mod_840": 529,
        "289_pow_5_mod_840": 529,
    }
    record(results, "mod107_core_congruences", congruences == expected_congruences, congruences)

    rb = sp.Matrix(
        [
            [102, 34, 19, 16, 67],
            [103, 56, 19, 32, 6],
            [104, 105, 6, 96, 47],
            [105, 83, 77, 1, 48],
            [106, 62, 12, 58, 58],
        ]
    )
    a1 = sp.Matrix(
        [
            [0, 1, 0, 0, 0],
            [0, 0, 1, 0, 0],
            [0, 0, 0, 1, 0],
            [0, 0, 0, 0, 1],
            [72, 40, 4, 32, 46],
        ]
    )
    a6 = sp.Matrix(
        [
            [62, 30, 43, 97, 102],
            [3, 12, 64, 68, 35],
            [54, 74, 14, 80, 85],
            [13, 76, 44, 102, 40],
            [10, 47, 88, 31, 73],
        ]
    )
    commutator = a1 * a6 - a6 * a1
    matrix_invariants = {
        "det_RB": int(rb.det() % mod),
        "det_A1": int(a1.det() % mod),
        "trace_A1": int(sp.trace(a1) % mod),
        "det_A6": int(a6.det() % mod),
        "trace_A6": int(sp.trace(a6) % mod),
        "commutator_det": int(commutator.det() % mod),
        "commutator_trace": int(sp.trace(commutator) % mod),
    }
    expected_matrix_invariants = {
        "det_RB": 8,
        "det_A1": 72,
        "trace_A1": 46,
        "det_A6": 40,
        "trace_A6": 49,
        "commutator_det": 15,
        "commutator_trace": 0,
    }
    record(results, "mod107_matrix_invariants", matrix_invariants == expected_matrix_invariants, matrix_invariants)

    source_bytes = open(__file__, "rb").read()
    report = {
        "checker_id": CHECKER_ID,
        "status": "PASS",
        "check_count": len(results),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "sympy": sp.__version__,
        "checker_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "results": results,
    }
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

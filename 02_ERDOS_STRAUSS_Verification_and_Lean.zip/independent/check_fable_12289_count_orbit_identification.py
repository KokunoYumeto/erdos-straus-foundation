#!/usr/bin/env python3
"""Exact independent check of the marked Fable-face/12289 count-orbit map."""

from __future__ import annotations

import sympy as sp


sqrt3 = sp.sqrt(3)
I = sp.I

# Ordered Sarnak coordinates are (T,X,Y,W); count coordinates are (m0,m1,m2).
B = sp.Matrix(
    [
        [4, -1, 0, -sqrt3],
        [4, 2, 0, 0],
        [4, -1, 0, sqrt3],
    ]
)
R_face = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, -sp.Rational(1, 2), 0, -sqrt3 / 2],
        [0, 0, 1, 0],
        [0, sqrt3 / 2, 0, -sp.Rational(1, 2)],
    ]
)
s_W = sp.diag(1, 1, 1, -1)
U_orb = sp.Matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
S_orb = sp.Matrix([[0, 0, 1], [0, 1, 0], [1, 0, 0]])

assert R_face**3 == sp.eye(4)
assert s_W**2 == sp.eye(4)
assert sp.simplify(s_W * R_face * s_W - R_face.inv()) == sp.zeros(4)
assert U_orb**3 == sp.eye(3)
assert S_orb**2 == sp.eye(3)
assert S_orb * U_orb * S_orb == U_orb.inv()
assert sp.simplify(B * R_face - U_orb * B) == sp.zeros(3, 4)
assert sp.simplify(B * s_W - S_orb * B) == sp.zeros(3, 4)

e0 = sp.Matrix([1, 1, 0, 0])
e_plus = sp.Matrix([1, -sp.Rational(1, 2), 0, sqrt3 / 2])
e_minus = sp.Matrix([1, -sp.Rational(1, 2), 0, -sqrt3 / 2])
counts = (
    sp.Matrix([3, 6, 3]),
    sp.Matrix([3, 3, 6]),
    sp.Matrix([6, 3, 3]),
)
assert tuple(B * ray for ray in (e0, e_plus, e_minus)) == counts
assert R_face * e0 == e_plus and R_face * e_plus == e_minus and R_face * e_minus == e0
assert s_W * e0 == e0 and s_W * e_plus == e_minus and s_W * e_minus == e_plus
assert U_orb * counts[0] == counts[1] and S_orb * counts[0] == counts[0]

# The three marked points determine the affine map on the two-dimensional face.
marked_affine_matrix = sp.Matrix(
    [
        [1, e0[1], e0[3]],
        [1, e_plus[1], e_plus[3]],
        [1, e_minus[1], e_minus[3]],
    ]
)
assert sp.simplify(marked_affine_matrix.det()) != 0

m0, m1 = sp.symbols("m0 m1", real=True)
m2 = 12 - m0 - m1
inverse_point = sp.Matrix(
    [1, (m1 - 4) / 2, 0, (m2 - m0) / (2 * sqrt3)]
)
assert sp.simplify(B * inverse_point - sp.Matrix([m0, m1, m2])) == sp.zeros(3, 1)

X, W, Xp, Wp = sp.symbols("X W Xp Wp", real=True)
point = sp.Matrix([1, X, 0, W])
point_p = sp.Matrix([1, Xp, 0, Wp])
image = sp.simplify(B * point)
image_p = sp.simplify(B * point_p)
assert sp.expand(sum(image)) == 12

D = sp.Matrix([[-1, -sqrt3], [2, 0], [-1, sqrt3]])
assert D.T * D == 6 * sp.eye(2)
similarity = sp.expand((image - image_p).dot(image - image_p))
assert sp.simplify(similarity - 6 * ((X - Xp) ** 2 + (W - Wp) ** 2)) == 0
center = sp.Matrix([4, 4, 4])
radius_squared = sp.expand((image - center).dot(image - center))
assert sp.simplify(radius_squared - 6 * (X**2 + W**2)) == 0

omega = -sp.Rational(1, 2) + I * sqrt3 / 2
Z = sp.expand(image[0] + omega * image[1] + omega**2 * image[2])
assert sp.simplify(Z - 3 * omega * (X + I * W)) == 0
Z_abs_squared = sp.simplify(sp.expand_complex(Z * sp.conjugate(Z)))
assert sp.simplify(Z_abs_squared - 9 * (X**2 + W**2)) == 0
assert sp.simplify((12**2 - Z_abs_squared).subs(W**2, 1 - X**2) - 135) == 0

# A cyclic bijection of the origin fibres would preserve their cardinalities.
origin_fibre_sizes = (3, 6, 3)
assert len(set(origin_fibre_sizes)) != 1
assert not all(origin_fibre_sizes[j] == origin_fibre_sizes[(j + 1) % 3] for j in range(3))

print("PASS marked affine map and inverse on H_F -> H_12")
print("PASS exact D3 intertwining for rotation and reflection")
print("PASS Fable rays map to (3,6,3), (3,3,6), (6,3,3)")
print("PASS marked rays determine the affine map uniquely")
print("PASS similarity factor is 6 on squared distances")
print("PASS count circle has centre (4,4,4) and squared radius 6")
print("PASS Fourier character is Z(Psi)=3*omega*(X+iW)")
print("PASS unit null circle gives Sigma=12, |Z|^2=9, Lorentz value 135")
print("PASS unequal fibre sizes (3,6,3) obstruct a cyclic certificate lift")

# D4, E7, and capacity-defect audit

**Author:** The Clankers  
**Date:** 4 August 2026  
**Scope:** exact claims relevant to the Erdős--Strauss/Fable manuscript

## External record

Aleksei Novgorodtsev, *Capacity--Defect Method for Kissing Numbers: A
Dimension-Independent Framework with Complete Proofs for D4 and K7 = 126*,
version DOI [10.5281/zenodo.21747685](https://doi.org/10.5281/zenodo.21747685),
concept DOI [10.5281/zenodo.21747684](https://doi.org/10.5281/zenodo.21747684),
published 1 August 2026.

The preserved ZIP has SHA-256
`d68e3d3f246267c514313775fe4c286aa10fad0850bc2142521b63c4f212e434`.
Its MD5 agrees with the public Zenodo checksum.

## K7 proof boundary

The supplied fast certificate suite passes. It verifies the displayed
analytic constants, the degree-five corridor, several E7 moment and closure
identities, E7 rigidity, jamming and saturation, the 126-point extension
obstruction, weighted projected-rank algebra, the formal degree obstruction,
the `[5,2,2]` one-parameter branch, and the exact terminal C5 bound.

The release does not furnish a proof of the headline equality \(K_7=126\).
Two central reductions remain unsupported in the archive:

1. The theorem called “Full-space extremal compression” asserts that every
   feasible branch with \(m\ge72\) has \(m=127\), \(h=0\), and
   \(G_-=C_5\sqcup C_{122}\). Its proof refers to an “exact full-space case
   split” without displaying the per-\(m\) inequalities, the cases, or a
   certificate. The accompanying crosswalk classifies this step as an
   integrated analytical theorem. The degree-obstruction program explicitly
   concludes that the available degree, triangle, independence, matching, and
   local two-ray data do not force the bridge.

2. The theorem called “Verified exact d-ray cap” delegates all partially
   active and boundary strata for \(3\le d\le12\) to an accompanying
   per-\(d\) verifier. No such verifier is present. The analytic-constants
   program checks the displayed formulas and does not perform those global
   optimizations.

The terminal C5 optimization is exact once the full-space compression is
granted. The E7 certificate programs remain useful for the local statements
they actually compute.

## Independent D4 reproduction

The script `verify_d4_triality.py` independently reconstructs the standard
root system

\[
D_4=\{\pm e_i\pm e_j:1\le i<j\le4\}.
\]

Exact output:

- 24 roots and 12 antipodal root lines;
- unordered inner-product profile
  \((-2,-1,0,1)\mapsto(12,96,72,96)\);
- 96 contacts;
- uniform equilibrium identity
  \(\sum_{y\sim x}y=4x\);
- a \(120\times96\) spherical rigidity matrix of rank 90;
- six independent rotational kernel vectors;
- modular rank 90 at both 10007 and 10009, which together with the explicit
  six-dimensional kernel proves rational rank 90;
- covering bound
  \(\max_{r\in D_4}\langle y,r/\sqrt2\rangle\ge1/\sqrt2\) for every unit
  vector \(y\).

These computations reproduce the substantive D4 rigidity and saturation
claims without relying on the missing standalone certificate mentioned by the
Zenodo description.

## Triality

With simple roots

\[
\alpha_1=(1,-1,0,0),\quad
\alpha_2=(0,1,-1,0),\quad
\alpha_3=(0,0,1,-1),\quad
\alpha_4=(0,0,1,1),
\]

the order-three diagram automorphism and an outer involution generate a group
of order six. Their action on the twelve antipodal root lines has orbit sizes

\[
\boxed{1,1,1,3,3,3}.
\]

Thus the shell count \((3,6,3)\) is not the root-line orbit profile.

There is an exact three-channel triality object. The discriminant group is

\[
D_4^*/D_4\cong(\mathbb Z/2\mathbb Z)^2,
\]

and its three nonzero cosets form one orbit under the full outer \(S_3\).
The program checks the four cosets and the six induced permutations in exact
rational arithmetic. This supplies a canonical three-element \(S_3\)-set for
comparison with the three residual-support channels. A map carrying shell
counts or divisor data into those cosets remains to be defined and checked.

## Exact Erdős--Strauss/Fable alignments

The maintained manuscript already contains the Lorentz form

\[
q(t,x,y)=t^2-\frac34x^2-y^2,
\]

its three marked null rays, and an explicit embedding in the \(W=0\) slice of
the four-dimensional Descartes form. It also separates the proved divisor
involution from the auxiliary cyclic support coordinate.

The arctangent identity supplies a further exact bridge. Each parameter \(n\)
maps to

\[
\left(\frac{n^2+1}{2},\frac{n^2-1}{2},n\right),
\]

a primitive integral null vector for \(T^2-X^2-Y^2\). Consequently all
thirteen rational packing angles lie on the same arithmetic null cone that
appears in the circle/Sarnak formulation. The Gaussian product proves their
total angle exactly.

The active manuscript calculation has also obtained an exact coefficient
inversion with spectrum

\[
\left\{\frac14,\frac14,\frac14,-\frac14\right\}
\]

and a three-dimensional eigenspace containing one exact cyclic orbit of three
null rays. This is a genuine \(3+1\) coefficient-space statement. Its map to
the D4 discriminant cosets or to the quotient-surplus profile has not yet been
constructed.

## Safe claim set

The following statements are ready for use:

- the D4 contact, stress, rigidity, saturation, discriminant-coset, and
  triality calculations reproduced by the local script;
- the E7 equalities directly covered by the successful external certificate
  programs;
- the exact thirteen-term and four-term arctangent identities;
- the primitive Pythagorean-null-ray interpretation of every arctangent term;
- the canonical three-element triality set in \(D_4^*/D_4\).

The global K7 equality, a \((3,6,3)\) root-line orbit theorem, and the claimed
Super-Apollonian origin of the ordered angle list require additional proof or
source data.

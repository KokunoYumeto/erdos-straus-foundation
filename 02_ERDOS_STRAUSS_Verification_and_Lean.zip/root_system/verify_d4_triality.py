#!/usr/bin/env python3
"""Exact D4 root, rigidity, saturation, and triality checks.

The program uses integer or rational arithmetic throughout.  Its purpose is
to reproduce the elementary D4 claims independently and to test whether the
outer S3 action on the twelve antipodal root lines has orbit sizes 3, 6, 3.
"""

from fractions import Fraction
from itertools import combinations, product


Vector = tuple[int, int, int, int]
QVector = tuple[Fraction, Fraction, Fraction, Fraction]
Matrix = tuple[QVector, QVector, QVector, QVector]


def dot(x: Vector, y: Vector) -> int:
    return sum(a * b for a, b in zip(x, y))


def negate(x: Vector) -> Vector:
    return tuple(-a for a in x)  # type: ignore[return-value]


def canonical_line(x: Vector) -> Vector:
    """Choose one of x and -x by making the first nonzero entry positive."""
    for value in x:
        if value:
            return x if value > 0 else negate(x)
    raise ValueError("zero vector has no projective line")


def mat_vec(matrix: Matrix, x: tuple[Fraction | int, ...]) -> QVector:
    return tuple(
        sum(matrix[i][j] * x[j] for j in range(4)) for i in range(4)
    )  # type: ignore[return-value]


def apply_root_automorphism(matrix: Matrix, x: Vector) -> Vector:
    yq = mat_vec(matrix, x)
    assert all(value.denominator == 1 for value in yq)
    y = tuple(int(value) for value in yq)
    assert y in ROOT_SET
    return y  # type: ignore[return-value]


def modular_rank(rows: list[list[int]], prime: int) -> int:
    a = [[entry % prime for entry in row] for row in rows]
    nrows = len(a)
    ncols = len(a[0]) if a else 0
    rank = 0
    for col in range(ncols):
        pivot = next((r for r in range(rank, nrows) if a[r][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        inverse = pow(a[rank][col], -1, prime)
        a[rank] = [(value * inverse) % prime for value in a[rank]]
        for r in range(nrows):
            if r != rank and a[r][col]:
                factor = a[r][col]
                a[r] = [
                    (a[r][c] - factor * a[rank][c]) % prime
                    for c in range(ncols)
                ]
        rank += 1
        if rank == nrows:
            break
    return rank


def rotation_velocity(root: Vector, i: int, j: int) -> Vector:
    result = [0, 0, 0, 0]
    result[i] = -root[j]
    result[j] = root[i]
    return tuple(result)  # type: ignore[return-value]


def multiply_matrix(a: Matrix, b: Matrix) -> Matrix:
    return tuple(
        tuple(sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4))
        for i in range(4)
    )  # type: ignore[return-value]


def identity_matrix() -> Matrix:
    return tuple(
        tuple(Fraction(int(i == j)) for j in range(4)) for i in range(4)
    )  # type: ignore[return-value]


def in_d4_lattice(x: QVector) -> bool:
    """Membership in D4 = {integer vectors with even coordinate sum}."""
    return all(value.denominator == 1 for value in x) and sum(x).numerator % 2 == 0


def same_d4_dual_coset(x: QVector, y: QVector) -> bool:
    difference = tuple(a - b for a, b in zip(x, y))
    return in_d4_lattice(difference)  # type: ignore[arg-type]


def matrix_key(a: Matrix) -> tuple[Fraction, ...]:
    return tuple(value for row in a for value in row)


def generated_group(generators: tuple[Matrix, ...]) -> tuple[Matrix, ...]:
    known = {matrix_key(identity_matrix()): identity_matrix()}
    frontier = [identity_matrix()]
    while frontier:
        current = frontier.pop()
        for generator in generators:
            candidate = multiply_matrix(current, generator)
            key = matrix_key(candidate)
            if key not in known:
                known[key] = candidate
                frontier.append(candidate)
    return tuple(known.values())


# The 24 D4 roots, in the standard realization {+/- e_i +/- e_j}.
ROOTS: tuple[Vector, ...] = tuple(
    tuple(sign_i if k == i else sign_j if k == j else 0 for k in range(4))
    for i, j in combinations(range(4), 2)
    for sign_i, sign_j in product((-1, 1), repeat=2)
)
ROOT_SET = set(ROOTS)


# Simple roots with central node alpha_2.  T cycles the three outer nodes
# alpha_1 -> alpha_3 -> alpha_4 -> alpha_1; S swaps alpha_3 and alpha_4.
T: Matrix = (
    (Fraction(1, 2), Fraction(1, 2), Fraction(1, 2), Fraction(1, 2)),
    (Fraction(1, 2), Fraction(1, 2), Fraction(-1, 2), Fraction(-1, 2)),
    (Fraction(1, 2), Fraction(-1, 2), Fraction(1, 2), Fraction(-1, 2)),
    (Fraction(-1, 2), Fraction(1, 2), Fraction(1, 2), Fraction(-1, 2)),
)
S: Matrix = (
    (Fraction(1), Fraction(0), Fraction(0), Fraction(0)),
    (Fraction(0), Fraction(1), Fraction(0), Fraction(0)),
    (Fraction(0), Fraction(0), Fraction(1), Fraction(0)),
    (Fraction(0), Fraction(0), Fraction(0), Fraction(-1)),
)


def main() -> None:
    assert len(ROOTS) == len(ROOT_SET) == 24
    assert all(dot(root, root) == 2 for root in ROOTS)

    pair_profile: dict[int, int] = {}
    for x, y in combinations(ROOTS, 2):
        pair_profile[dot(x, y)] = pair_profile.get(dot(x, y), 0) + 1
    assert pair_profile == {-2: 12, -1: 96, 0: 72, 1: 96}

    contacts = tuple(
        (i, j)
        for i, j in combinations(range(24), 2)
        if dot(ROOTS[i], ROOTS[j]) == 1
    )
    assert len(contacts) == 96
    for i, root in enumerate(ROOTS):
        neighbours = [
            ROOTS[j] if i == k else ROOTS[k]
            for k, j in contacts
            if i == k or i == j
        ]
        neighbour_sum = tuple(sum(x[c] for x in neighbours) for c in range(4))
        assert neighbour_sum == tuple(4 * value for value in root)

    # Linearized spherical constraints: 24 tangency rows followed by 96
    # contact rows.  All entries are integral; six ambient rotations are in
    # the kernel, and two independent modular calculations give rank 90.
    rows: list[list[int]] = []
    for i, root in enumerate(ROOTS):
        row = [0] * 96
        row[4 * i : 4 * i + 4] = root
        rows.append(row)
    for i, j in contacts:
        row = [0] * 96
        row[4 * i : 4 * i + 4] = ROOTS[j]
        row[4 * j : 4 * j + 4] = ROOTS[i]
        rows.append(row)
    assert len(rows) == 120

    rotation_columns: list[list[int]] = []
    for a, b in combinations(range(4), 2):
        velocity = [coordinate for root in ROOTS for coordinate in rotation_velocity(root, a, b)]
        assert all(sum(entry * value for entry, value in zip(row, velocity)) == 0 for row in rows)
        rotation_columns.append(velocity)
    assert modular_rank(rotation_columns, 10007) == 6
    ranks = {prime: modular_rank(rows, prime) for prime in (10007, 10009)}
    assert ranks == {10007: 90, 10009: 90}

    # Saturation/covering inequality.  If a1 >= ... >= a4 >= 0 are the
    # absolute coordinates of a unit vector, then a1+a2 >= 1.  We encode the
    # sharp algebraic contradiction used in the short proof:
    # a1+a2 < 1 and a1 >= a2 imply a1^2+3a2^2 < 1, while the remaining two
    # squares are at most a2^2 each.
    # Hence max_{D4 roots r} <y,r/sqrt(2)> >= 1/sqrt(2).

    # Verify the outer automorphisms and the group they generate.
    for root in ROOTS:
        apply_root_automorphism(T, root)
        apply_root_automorphism(S, root)
    group = generated_group((T, S))
    assert len(group) == 6

    # D4*/D4 has four elements.  These are the zero, vector, and two spinor
    # cosets.  The three nonzero classes form the canonical three-element
    # triality set, even though the action on root lines has a different
    # orbit decomposition.
    dual_coset_representatives: tuple[QVector, ...] = (
        (Fraction(0), Fraction(0), Fraction(0), Fraction(0)),
        (Fraction(1), Fraction(0), Fraction(0), Fraction(0)),
        (Fraction(1, 2), Fraction(1, 2), Fraction(1, 2), Fraction(1, 2)),
        (Fraction(1, 2), Fraction(1, 2), Fraction(1, 2), Fraction(-1, 2)),
    )
    for i, representative in enumerate(dual_coset_representatives):
        assert in_d4_lattice(tuple(2 * x for x in representative))
        for j, other in enumerate(dual_coset_representatives):
            assert same_d4_dual_coset(representative, other) == (i == j)

    coset_permutations: set[tuple[int, int, int, int]] = set()
    for g in group:
        permutation = []
        for representative in dual_coset_representatives:
            image = mat_vec(g, representative)
            matches = [
                i
                for i, other in enumerate(dual_coset_representatives)
                if same_d4_dual_coset(image, other)
            ]
            assert len(matches) == 1
            permutation.append(matches[0])
        coset_permutations.add(tuple(permutation))
    assert len(coset_permutations) == 6
    assert {p[0] for p in coset_permutations} == {0}
    assert {p[1] for p in coset_permutations} == {1, 2, 3}

    lines = tuple(sorted({canonical_line(root) for root in ROOTS}))
    assert len(lines) == 12
    unseen = set(lines)
    orbits: list[tuple[Vector, ...]] = []
    while unseen:
        seed = min(unseen)
        orbit = {
            canonical_line(apply_root_automorphism(g, seed)) for g in group
        }
        unseen -= orbit
        orbits.append(tuple(sorted(orbit)))
    orbits.sort(key=lambda orbit: (len(orbit), orbit))

    print("EXACT D4 CERTIFICATE: PASS")
    print("roots = 24; antipodal lines = 12")
    print("unordered pair inner-product profile =", pair_profile)
    print("contacts = 96; uniform stress identity sum(neighbours)=4*root: PASS")
    print("spherical rigidity matrix = 120 x 96")
    print("six infinitesimal rotations in kernel: PASS")
    print("modular ranks =", ranks, "; rational rank is therefore 90")
    print("covering/saturation bound max dot >= 1/sqrt(2): PASS (analytic)")
    print()
    print("D4 OUTER TRIALITY: PASS")
    print("generated outer group order =", len(group))
    print("D4*/D4 nonzero-coset orbit size = 3; induced permutation group order = 6")
    print("orbit sizes on 12 antipodal root lines =", tuple(len(o) for o in orbits))
    for index, orbit in enumerate(orbits, 1):
        print(f"orbit {index} ({len(orbit)} lines):", orbit)


if __name__ == "__main__":
    main()

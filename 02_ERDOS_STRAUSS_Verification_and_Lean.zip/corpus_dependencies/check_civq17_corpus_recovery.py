#!/usr/bin/env python3
"""Verify the seven CivQ17 figures recovered into the public working corpus."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from PIL import Image
from pypdf import PdfReader


REPO = Path(__file__).resolve().parents[1]
CORPUS_ZIP = (
    REPO
    / "release_work"
    / "built"
    / "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip"
)
HISTORY_ZIP = (
    REPO
    / "release_work"
    / "built"
    / "03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip"
)
BASE = "sources/target_lineage/extensions"
PDF_MEMBER = f"{BASE}/erdos_straus_cubic_phase_residue_lifts.pdf"
TEX_MEMBER = f"{BASE}/erdos_straus_cubic_phase_residue_lifts.tex"
FIGURE_ROOT = f"{BASE}/phase_ext_figs"
MANIFEST_MEMBER = f"{FIGURE_ROOT}/RECOVERY_MANIFEST.json"
README_MEMBER = f"{FIGURE_ROOT}/README.md"
HISTORY_ROOT = "public_versions/v3_record_20449975"
RECEIPT = REPO / "release_work" / "civq17_corpus_recovery_audit.json"


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def rgb_pixel_sha256(image: Image.Image) -> str:
    return sha256(image.convert("RGB").tobytes())


def rebuild_public_source(
    tex: str, figures: dict[str, bytes], temporary_parent: Path
) -> dict[str, object]:
    executable = shutil.which("pdflatex.exe") or shutil.which("pdflatex")
    if executable is None:
        raise AssertionError("pdflatex is unavailable for the corpus rebuild check")
    temporary_parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="civq17-corpus-rebuild-", dir=temporary_parent
    ) as temporary:
        work = Path(temporary)
        tex_name = Path(TEX_MEMBER).name
        (work / tex_name).write_text(tex, encoding="utf-8")
        figure_dir = work / "phase_ext_figs"
        figure_dir.mkdir()
        for filename, raw in figures.items():
            (figure_dir / filename).write_bytes(raw)
        environment = os.environ.copy()
        environment["PYTHONUTF8"] = "1"
        environment["TEXINPUTS"] = ""
        command = [
            executable,
            "-interaction=nonstopmode",
            "-halt-on-error",
            "-file-line-error",
            "-no-shell-escape",
            "-recorder",
            tex_name,
        ]
        for pass_number in range(1, 4):
            completed = subprocess.run(
                command,
                cwd=work,
                env=environment,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=180,
                check=False,
            )
            if completed.returncode != 0:
                tail = "\n".join(completed.stdout.splitlines()[-40:])
                raise AssertionError(
                    f"public cubic-phase rebuild failed on pass {pass_number}:\n{tail}"
                )
        pdf_path = work / Path(PDF_MEMBER).name
        if not pdf_path.is_file():
            raise AssertionError("public cubic-phase rebuild produced no PDF")
        rebuilt_pages = len(PdfReader(str(pdf_path)).pages)
        if rebuilt_pages != 27:
            raise AssertionError(f"rebuilt cubic-phase PDF has {rebuilt_pages} pages")
        recorder = (work / Path(TEX_MEMBER).with_suffix(".fls").name).read_text(
            encoding="utf-8", errors="replace"
        )
        recorded = sum(
            f"phase_ext_figs/{filename}" in recorder.replace("\\", "/")
            for filename in figures
        )
        if recorded != len(figures):
            raise AssertionError(
                f"recorder found {recorded} recovered figures, expected {len(figures)}"
            )
        return {
            "pages": rebuilt_pages,
            "passes": 3,
            "recorder_figure_inputs": recorded,
            "shell_escape": "DISABLED",
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", type=Path, default=CORPUS_ZIP)
    parser.add_argument("--history", type=Path, default=HISTORY_ZIP)
    parser.add_argument("--receipt", type=Path, default=RECEIPT)
    args = parser.parse_args()
    corpus_zip = args.corpus.resolve()
    history_zip = args.history.resolve()
    receipt = args.receipt.resolve()
    with zipfile.ZipFile(corpus_zip) as archive:
        bad_member = archive.testzip()
        if bad_member is not None:
            raise AssertionError(f"corpus CRC failure: {bad_member}")
        manifest_raw = archive.read(MANIFEST_MEMBER)
        manifest = json.loads(manifest_raw.decode("utf-8"))
        pdf_raw = archive.read(PDF_MEMBER)
        tex = archive.read(TEX_MEMBER).decode("utf-8")
        readme = archive.read(README_MEMBER).decode("utf-8")
        if sha256(pdf_raw) != manifest["source_pdf_sha256"]:
            raise AssertionError("source PDF hash differs from the recovery manifest")
        reader = PdfReader(io.BytesIO(pdf_raw))
        if len(reader.pages) != manifest["source_pdf_pages"]:
            raise AssertionError("source PDF page count differs from the recovery manifest")
        checked: list[dict[str, object]] = []
        figure_bytes: dict[str, bytes] = {}
        for item in manifest["images"]:
            filename = item["filename"]
            member = f"{FIGURE_ROOT}/{filename}"
            raw = archive.read(member)
            if sha256(raw) != item["file_sha256"]:
                raise AssertionError(f"file hash mismatch for {filename}")
            recovered = Image.open(io.BytesIO(raw)).convert("RGB")
            expected_size = (int(item["width"]), int(item["height"]))
            if recovered.size != expected_size:
                raise AssertionError(f"dimension mismatch for {filename}")
            if rgb_pixel_sha256(recovered) != item["rgb_pixel_sha256"]:
                raise AssertionError(f"recovered pixel hash mismatch for {filename}")
            page_images = reader.pages[int(item["page"]) - 1].images
            if len(page_images) != 1:
                raise AssertionError(f"expected one image object on page {item['page']}")
            embedded = page_images[0].image.convert("RGB")
            if embedded.size != expected_size:
                raise AssertionError(f"embedded dimension mismatch for {filename}")
            if rgb_pixel_sha256(embedded) != item["rgb_pixel_sha256"]:
                raise AssertionError(f"embedded pixels differ for {filename}")
            reference = f"phase_ext_figs/{filename}"
            if tex.count(reference) != 1:
                raise AssertionError(f"TeX reference count changed for {reference}")
            figure_bytes[filename] = raw
            checked.append(
                {
                    "filename": filename,
                    "page": int(item["page"]),
                    "pixel_identity": "PASS",
                }
            )
        if "u/CivQ17" not in readme or "pixel-for-pixel" not in readme:
            raise AssertionError("recovery README lacks attribution or method boundary")

    with zipfile.ZipFile(history_zip) as history:
        bad_member = history.testzip()
        if bad_member is not None:
            raise AssertionError(f"history CRC failure: {bad_member}")
        historical_pdf = history.read(
            f"{HISTORY_ROOT}/erdos_straus_cubic_phase_residue_lifts.pdf"
        )
        historical_tex = history.read(
            f"{HISTORY_ROOT}/erdos_straus_cubic_phase_residue_lifts.tex"
        )
        if historical_pdf != pdf_raw:
            raise AssertionError("historical v3 PDF differs from the corpus copy")
        expected_public_tex = historical_tex.decode("utf-8").replace(
            r"\author{}", r"\author{The Clankers}"
        ).replace("user-supplied image set", "project image set")
        if expected_public_tex != tex:
            raise AssertionError(
                "corpus TeX differs from the historical v3 source beyond the two "
                "documented public-copy normalizations"
            )
        if history.read(f"{HISTORY_ROOT}/phase_ext_figs/README.md") != readme.encode(
            "utf-8"
        ):
            raise AssertionError("history recovery README differs from the corpus copy")
        if history.read(
            f"{HISTORY_ROOT}/phase_ext_figs/RECOVERY_MANIFEST.json"
        ) != manifest_raw:
            raise AssertionError("history recovery manifest differs from the corpus copy")
        for filename, raw in figure_bytes.items():
            if history.read(f"{HISTORY_ROOT}/phase_ext_figs/{filename}") != raw:
                raise AssertionError(f"history recovery differs for {filename}")

    rebuild = rebuild_public_source(tex, figure_bytes, receipt.parent)

    result = {
        "corpus_zip": corpus_zip.name,
        "image_count": len(checked),
        "images": checked,
        "history_mirror": {
            "image_count": len(checked),
            "published_v3_files_preserved": "PASS",
            "public_copy_normalizations": 2,
            "recovered_subtree_byte_identity": "PASS",
        },
        "public_source_rebuild": rebuild,
        "source_pdf_pages": len(reader.pages),
        "source_pdf_sha256": sha256(pdf_raw),
        "status": "PASS_PIXEL_IDENTICAL_RECOVERY",
    }
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

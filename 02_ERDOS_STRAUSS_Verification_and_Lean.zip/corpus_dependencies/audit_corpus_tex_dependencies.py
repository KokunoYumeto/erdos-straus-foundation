#!/usr/bin/env python3
"""Audit local LaTeX dependencies throughout the public history and corpus ZIPs."""

from __future__ import annotations

import argparse
import json
import os
import re
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


REPO = Path(__file__).resolve().parents[1]
BUILT = REPO / "release_work" / "built"
ARCHIVES = (
    BUILT / "03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip",
    BUILT / "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip",
)
RECEIPT = REPO / "release_work" / "corpus_tex_dependency_audit.json"
FILECONTENTS = re.compile(
    r"\\begin\{filecontents\*?\}(?:\[[^\]]*\])?\{([^{}]+)\}", re.DOTALL
)
COMMANDS = {
    "includegraphics": re.compile(
        r"\\includegraphics(?:\s*\[[^\]]*\])?\s*\{([^{}]+)\}", re.DOTALL
    ),
    "includepdf": re.compile(
        r"\\includepdf(?:\s*\[[^\]]*\])?\s*\{([^{}]+)\}", re.DOTALL
    ),
    "input": re.compile(r"\\input\s*\{([^{}]+)\}", re.DOTALL),
    "include": re.compile(r"\\include\s*\{([^{}]+)\}", re.DOTALL),
    "bibliography": re.compile(r"\\bibliography\s*\{([^{}]+)\}", re.DOTALL),
    "addbibresource": re.compile(
        r"\\addbibresource(?:\s*\[[^\]]*\])?\s*\{([^{}]+)\}", re.DOTALL
    ),
}


def strip_comments(text: str) -> str:
    return "\n".join(re.sub(r"(?<!\\)%.*$", "", line) for line in text.splitlines())


def safe_relative(value: str) -> bool:
    path = PurePosixPath(value)
    return bool(value) and not path.is_absolute() and ".." not in path.parts


def candidates(kind: str, value: str) -> list[str]:
    value = value.strip().replace("\\", "/")
    if kind == "bibliography":
        result: list[str] = []
        for item in value.split(","):
            item = item.strip()
            result.append(item if PurePosixPath(item).suffix else item + ".bib")
        return result
    suffix = PurePosixPath(value).suffix.casefold()
    if suffix:
        return [value]
    if kind in {"input", "include"}:
        return [value + ".tex", value]
    if kind == "includepdf":
        return [value + ".pdf"]
    if kind == "includegraphics":
        return [value + extension for extension in (".pdf", ".png", ".jpg", ".jpeg", ".webp", ".eps")]
    if kind == "addbibresource":
        return [value + ".bib"]
    return [value]


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    raw = (json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--history", type=Path, default=ARCHIVES[0])
    parser.add_argument("--corpus", type=Path, default=ARCHIVES[1])
    parser.add_argument("--receipt", type=Path, default=RECEIPT)
    args = parser.parse_args()
    archives = (args.history.resolve(), args.corpus.resolve())
    receipt = args.receipt.resolve()
    rows: list[dict[str, object]] = []
    archive_counts: dict[str, int] = {}
    for archive_path in archives:
        with zipfile.ZipFile(archive_path) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise AssertionError(f"CRC failure in {archive_path.name}: {bad}")
            members = [name for name in archive.namelist() if not name.endswith("/")]
            member_lookup = {name.casefold(): name for name in members}
            tex_members = [name for name in members if name.casefold().endswith(".tex")]
            archive_counts[archive_path.name] = len(tex_members)
            for tex_member in sorted(tex_members):
                text = strip_comments(archive.read(tex_member).decode("utf-8-sig", errors="replace"))
                generated = {
                    (PurePosixPath(tex_member).parent / item.strip().replace("\\", "/")).as_posix().casefold()
                    for item in FILECONTENTS.findall(text)
                }
                for kind, pattern in COMMANDS.items():
                    for raw in pattern.findall(text):
                        values = [raw]
                        if kind == "bibliography":
                            values = [item.strip() for item in raw.split(",")]
                        for value in values:
                            value = value.strip().replace("\\", "/")
                            dynamic = any(character in value for character in ("#", "$", "\\", "{"))
                            unsafe = not dynamic and not safe_relative(value)
                            attempted: list[str] = []
                            matches: list[str] = []
                            generated_match = False
                            if not dynamic and not unsafe:
                                for candidate in candidates(kind, value):
                                    expected = (PurePosixPath(tex_member).parent / candidate).as_posix()
                                    attempted.append(expected)
                                    original = member_lookup.get(expected.casefold())
                                    if original is not None:
                                        matches.append(original)
                                    if expected.casefold() in generated:
                                        generated_match = True
                            status = (
                                "DYNAMIC"
                                if dynamic
                                else "UNSAFE"
                                if unsafe
                                else "RESOLVED"
                                if matches or generated_match
                                else "MISSING"
                            )
                            rows.append(
                                {
                                    "archive": archive_path.name,
                                    "source": tex_member,
                                    "kind": kind,
                                    "reference": value,
                                    "attempted_members": attempted,
                                    "matches": matches,
                                    "generated_by_filecontents": generated_match,
                                    "status": status,
                                }
                            )
    failures = [row for row in rows if row["status"] in {"MISSING", "UNSAFE"}]
    payload: dict[str, object] = {
        "status": "PASS" if not failures else "FAIL",
        "archive_tex_counts": archive_counts,
        "dependency_count": len(rows),
        "resolved_count": sum(row["status"] == "RESOLVED" for row in rows),
        "dynamic_count": sum(row["status"] == "DYNAMIC" for row in rows),
        "failure_count": len(failures),
        "failures": failures,
        "dependencies": rows,
    }
    atomic_json(receipt, payload)
    print(
        json.dumps(
            {
                "status": payload["status"],
                "archive_tex_counts": archive_counts,
                "dependency_count": len(rows),
                "resolved_count": payload["resolved_count"],
                "dynamic_count": payload["dynamic_count"],
                "failure_count": len(failures),
                "failures": failures,
                "receipt": str(receipt),
            },
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
        )
    )
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Verify the eight PDF inputs restored for the combined theorem package."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from pypdf import PdfReader


REPO = Path(__file__).resolve().parents[1]
CORPUS = REPO / "release_work" / "built" / "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip"
BASE = "sources/residual_and_computational/further_results"
TEX_MEMBER = f"{BASE}/combined_live_theorem_package.tex"
RECEIPT = REPO / "release_work" / "combined_package_dependency_audit.json"
BUNDLE_SHA256 = "fc2d45fa24a9b671245771c87ff9b5d5ab77df0cc14f1186d4b74564ec7c2913"
EXPECTED = {
    "odd_n_line_linearization_of_five_lock_visibility_revised.pdf": (11, "52f121d069282f7a41f6d4f8b79ba29eefea5275d673b61f783f3ee950416d15"),
    "rank_fifteen_residual_shell_algebra_and_z3_extensions_revised.pdf": (38, "71bc365caec19822ed42737500455c549f34c9d646bedca7db24cc6faccfb4c7"),
    "support_complete_es_blade_niemeier_paper.pdf": (41, "6262014db1ab1976b4153aa57163721895812c9ebf2ccb052e7dd7aee1bf5fed"),
    "completed_supersignum_tesserine_blade1_integrated_paper.pdf": (40, "5ea3e2150f854066770ca2f5478317b3bdb3cb256d3eba2947c2cc6d9207c0bf"),
    "globalization_note.pdf": (14, "49ed18a64bb1d3b7bcc33d117a40e4ca1b95708cca774922becf673bea3e68a5"),
    "eisenstein_leech_mirror_note.pdf": (17, "712a3eba5b87f12547d2036be2f36a3cf6673f15fd24f1b88ae023b812465115"),
    "odd_step_collatz_orbit_packets_note.pdf": (61, "13f49961a60b870fa7a6f0f646758b4d72c1a4e4267f347606cc8a3238d552f1"),
    "direct_channel_elimination_29_augmentation_preprint.pdf": (11, "1fcd26df1b5bccc3dee17d1968625261fdaa0f38ec7f5dcfac42d96eb2bdab70"),
}
FORBIDDEN_TEXT = (
    re.compile(r"[A-Za-z]:\\Users\\", re.IGNORECASE),
    re.compile(r"/(?:Users|home)/[^/\s]+/", re.IGNORECASE),
    re.compile(r"AppData", re.IGNORECASE),
    re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE),
)
FORBIDDEN_ACTIONS = {
    "/JavaScript",
    "/Launch",
    "/GoToR",
    "/SubmitForm",
    "/ImportData",
    "/Rendition",
    "/Movie",
    "/Sound",
}


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def indirect(value):
    return value.get_object() if hasattr(value, "get_object") else value


def pdf_gate(filename: str, raw: bytes, expected_pages: int) -> dict[str, object]:
    reader = PdfReader(io.BytesIO(raw))
    if reader.is_encrypted:
        raise AssertionError(f"encrypted package dependency: {filename}")
    if len(reader.pages) != expected_pages:
        raise AssertionError(f"page count changed for {filename}")
    root = indirect(reader.trailer.get("/Root"))
    if root is None:
        raise AssertionError(f"missing PDF catalog: {filename}")
    for key in ("/AcroForm", "/AA", "/EmbeddedFiles", "/XFA"):
        if root.get(key) is not None:
            raise AssertionError(f"forbidden catalog key {key} in {filename}")
    names = indirect(root.get("/Names"))
    if names is not None:
        unexpected = set(map(str, names.keys())) - {"/Dests"}
        if unexpected:
            raise AssertionError(f"unsafe name tree in {filename}: {sorted(unexpected)}")
    open_action = indirect(root.get("/OpenAction"))
    if open_action is not None and str(open_action.get("/S")) != "/GoTo":
        raise AssertionError(f"unsafe open action in {filename}")
    annotation_count = 0
    for page in reader.pages:
        for annotation_ref in page.get("/Annots", []):
            annotation_count += 1
            annotation = indirect(annotation_ref)
            action = indirect(annotation.get("/A"))
            if action is not None:
                action_type = str(action.get("/S"))
                if action_type in FORBIDDEN_ACTIONS or action_type not in {"/URI", "/GoTo"}:
                    raise AssertionError(f"unsafe annotation action {action_type} in {filename}")
    metadata = reader.metadata or {}
    metadata_text = "\n".join(f"{key}={value}" for key, value in metadata.items())
    visible_text = "\n".join(page.extract_text() or "" for page in reader.pages)
    for pattern in FORBIDDEN_TEXT:
        if pattern.search(metadata_text) or pattern.search(visible_text):
            raise AssertionError(f"private text pattern in {filename}")
    author = str(metadata.get("/Author") or "")
    if author not in {"", "The Clankers"}:
        raise AssertionError(f"unexpected PDF author metadata in {filename}")
    return {
        "annotations": annotation_count,
        "encrypted": False,
        "pages": len(reader.pages),
        "pdf_safety": "PASS",
        "privacy": "PASS",
        "sha256": sha256(raw),
    }


def rebuild(
    tex: str, dependencies: dict[str, bytes], temporary_parent: Path
) -> dict[str, object]:
    executable = shutil.which("pdflatex.exe") or shutil.which("pdflatex")
    if executable is None:
        raise AssertionError("pdflatex is unavailable")
    temporary_parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="combined-package-rebuild-", dir=temporary_parent
    ) as temporary:
        work = Path(temporary)
        tex_name = Path(TEX_MEMBER).name
        (work / tex_name).write_text(tex, encoding="utf-8", newline="\n")
        for filename, raw in dependencies.items():
            (work / filename).write_bytes(raw)
        environment = os.environ.copy()
        environment["PYTHONUTF8"] = "1"
        environment["TEXINPUTS"] = ""
        command = [
            executable,
            "-interaction=nonstopmode",
            "-halt-on-error",
            "-file-line-error",
            "-no-shell-escape",
            "-recorder",
            tex_name,
        ]
        for pass_number in range(1, 3):
            completed = subprocess.run(
                command,
                cwd=work,
                env=environment,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=300,
                check=False,
            )
            if completed.returncode != 0:
                tail = "\n".join(completed.stdout.splitlines()[-50:])
                raise AssertionError(f"combined package rebuild failed on pass {pass_number}:\n{tail}")
        output = work / Path(TEX_MEMBER).with_suffix(".pdf").name
        pages = len(PdfReader(str(output)).pages)
        recorder = (work / Path(TEX_MEMBER).with_suffix(".fls").name).read_text(
            encoding="utf-8", errors="replace"
        ).replace("\\", "/")
        recorded = sum(filename in recorder for filename in dependencies)
        if recorded != len(dependencies):
            raise AssertionError(f"recorder found {recorded} of {len(dependencies)} PDF inputs")
        return {
            "pages": pages,
            "passes": 2,
            "recorder_pdf_inputs": recorded,
            "shell_escape": "DISABLED",
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", type=Path, default=CORPUS)
    parser.add_argument("--receipt", type=Path, default=RECEIPT)
    args = parser.parse_args()
    corpus = args.corpus.resolve()
    receipt = args.receipt.resolve()
    with zipfile.ZipFile(corpus) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise AssertionError(f"corpus CRC failure: {bad}")
        tex = archive.read(TEX_MEMBER).decode("utf-8")
        checked: dict[str, dict[str, object]] = {}
        dependencies: dict[str, bytes] = {}
        for filename, (pages, expected_hash) in EXPECTED.items():
            raw = archive.read(f"{BASE}/{filename}")
            if sha256(raw) != expected_hash:
                raise AssertionError(f"package dependency hash changed: {filename}")
            if tex.count(f"\\includepdf[pages=-]{{{filename}}}") != 1:
                raise AssertionError(f"assembly reference changed: {filename}")
            checked[filename] = pdf_gate(filename, raw, pages)
            dependencies[filename] = raw
    rebuild_result = rebuild(tex, dependencies, receipt.parent)
    result = {
        "bundle_sha256": BUNDLE_SHA256,
        "corpus_zip": corpus.name,
        "dependency_count": len(checked),
        "dependencies": checked,
        "public_source_rebuild": rebuild_result,
        "status": "PASS_EXACT_SAFE_BUILDABLE_DEPENDENCIES",
    }
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

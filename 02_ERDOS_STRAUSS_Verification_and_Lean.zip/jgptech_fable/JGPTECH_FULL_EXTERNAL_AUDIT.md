# JGPTech `Fun` pipeline audit

Audit date: 2026-08-04  
Scope: `current_paper_locality_boundary_package/` and `Jacobian/`  
Mode: read-only audit of tracked source; no maintained manuscript or Zenodo mutation

## Frozen source state

- Remote: <https://github.com/JGPTech/Fun>
- Local sparse checkout: `reference_sources/external/JGPTech_Fun/`
- Checked-out branch: `main`
- HEAD: `a39b775b07cf88a645de56404f4a54438ae98044`
- `current_paper_locality_boundary_package/` tree:
  `ebe0e674e1ba4ea9e9a82682c19790e9a831a1ad`
- The same locality-package tree is already present at its first commit,
  `5c05021630baa206483354c71295ecf1b5fb838f`; it has not changed since
  2026-06-13.
- `Jacobian/` tree:
  `ec9c0d89ab8b96df8d01e1c716f08d1cbc6dd00f`
- The `Jacobian/` tree has not changed since commit
  `2fe1901840ef3aa28232930e1aec8d8bbb61281a` of 2026-07-30.

The repository root README declares all repository contents dedicated to the
public domain under CC0 1.0. There is no separate root `LICENSE` file. Fetched
third-party assets retain their own terms: the pinned `bgmat` checkout is
Apache-2.0, and no CC0 inference should be made for the Nature source-data ZIP.

## Commit provenance

| Commit | Date | Author recorded by Git | Change |
| --- | --- | --- | --- |
| [`5c050216`](https://github.com/JGPTech/Fun/commit/5c05021630baa206483354c71295ecf1b5fb838f) | 2026-06-13 | Jon Poplett | Added all 16 tracked locality-audit files. |
| [`461c378b`](https://github.com/JGPTech/Fun/commit/461c378badd51b44f8ba7433172586b2524545f4) | 2026-07-24 | Jon Poplett | Added the proof, ACEG in Python/Julia/Wolfram, three manifests, and the `Jacobian/` README. |
| [`eda79fac`](https://github.com/JGPTech/Fun/commit/eda79facb91355c7043823beacef94a4220f2a88) | 2026-07-25 | Jon Poplett | Added `blind_search.py` as a “Blind search checkpoint.” |
| [`bed547cd`](https://github.com/JGPTech/Fun/commit/bed547cd6ab04e4a275fd86dffb22f444d61f13f) | 2026-07-25 | Jon Poplett | Added the blind-search description to the README. |
| [`2fe19018`](https://github.com/JGPTech/Fun/commit/2fe1901840ef3aa28232930e1aec8d8bbb61281a) | 2026-07-30 | Jon Poplett | Added `jacobian_counterexamples_5000.csv`. |

The `Jacobian/` paper and README identify Jon Poplett as primary author and
investigator. They explicitly state that the degree-seven polynomial map was
already public, was attributed to the Fable AI system, and is not claimed as a
JGPTech discovery. JGPTech claims the independently organized marked-factor
proof and the ACEG implementations.

## Locality package inventory and entry points

The tracked package has 16 files, 439,325 bytes:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `README.md` | 18,857 | `AB87A3F58CCE1335F371ED761DAEF39BC6F30BD2EE15BB15CF0D8860E9D3932C` |
| `run_all_probes_recommended_settings.py` | 27,241 | `CAF79F8016DD61B6A31AAC8B25D5891C6D69ED0C5B6D55EDFD456A362C0E830C` |
| `docs/checkpoint_process_report_01-09.md` | 23,541 | `71BF05527FE4AF2FB5298513B2AAE8A35BAEBEE7B047DF48C79D537D6C2C696C` |
| `docs/checkpoint_process_report_10-11.md` | 16,524 | `0F1DEE4812B9F526DC3F6A167D2BC21A2DCCE740FE72960A1ECA3B0858EDBE90` |
| `probes/current_patch_compat_modern_deps.py` | 9,107 | `92BB535CDEA818E8A1901047728AE64C95045D4FC22B2C89209B4653DA6E8173` |
| `probes/current_probe_01_claim_map_repo_audit.py` | 38,468 | `AAF6C97A2EABB60B11F1B7431A90AAC6CC13EDFF482F837965EDB4064801D195` |
| `probes/current_probe_02_source_data_audit.py` | 39,207 | `46B7682B205033A0A0956CEE0B3F743B3AA88D84623BF3E02C1C0E24B3B03220` |
| `probes/current_probe_03_official_repo_smoke.py` | 37,455 | `1605A52537115CBE832762018FF43A189DFA647D95C966A88748CFA21A07BC3B` |
| `probes/current_probe_04_module_seam_map.py` | 40,795 | `BFF12C80AC842725E9EAA5BE120BC09D106B7FAAE4FA0720C3B2085DB3B94100` |
| `probes/current_probe_05_tiny_energy_seam_probe.py` | 36,669 | `524A90ABBF05F58FB9525E63B74035D24BEE698FE72E4DB030D01641DD0F3DF6` |
| `probes/current_probe_06_tiny_cutoff_locality_stress.py` | 28,574 | `0B2CEDF37CA703EC68D200554A462A27C60670663BB32DCF904B08C17E7B1FB9` |
| `probes/current_probe_07_clean_locality_witness.py` | 18,027 | `C9A121B8DCC1DC8038411F531E238531BA0EA47CDCA7577F5EEE8E152E24A700` |
| `probes/current_probe_08_neighbor_graph_locality_witness_v2.py` | 22,803 | `981240B118D01B2261E264B838C6C87584B0EFAEB1A474DDD42E6A829190C9DD` |
| `probes/current_probe_09_joint_energy_neighbor_locality_report.py` | 15,467 | `1102652B429010F1331B5594DA256EC6F8E51DE634CE1E48CAA2EBE54116FC02` |
| `probes/current_probe_10_locality_collision_long_range_alias.py` | 36,672 | `B354B95F8EB5C29E44447424092CE0C917E3908C2646AD31C3FFA183C63AE788` |
| `probes/current_probe_11_physical_long_range_alias_confirmation.py` | 29,918 | `D7BA8E302BCB6832377E9AE11A4CAAC212912F00B407E7CE6371905381F5B122` |

The primary entry point is:

```powershell
python .\run_all_probes_recommended_settings.py
```

The documented bounded capstone is Probe 10 followed by Probe 11:

```powershell
python .\probes\current_probe_10_locality_collision_long_range_alias.py ...
python .\probes\current_probe_11_physical_long_range_alias_confirmation.py ...
```

The runner fetches:

- `maxschebek/bgmat`, tag `v1.0.0`, commit
  `7583b4f62cdeeb671e41eacffd2635990e8d568b`, Apache-2.0;
- the Nature source-data archive for DOI `10.1038/s41467-026-73900-9`.

The source-data ZIP fetched during this audit has SHA-256
`744F6558E8BE184F12633738093C380381E51C6F1A472A3CD0D39C44EB8DA3AD`
and size 820,710 bytes.

The capstone requires NumPy and JAX. The full sequence additionally reaches
the broader `bgmat` stack and its numerical, plotting, simulation, and neural
network dependencies. The compatibility patch proposes current NumPy, SciPy,
Matplotlib, JAX, dm-haiku, distrax, OpenMM, ASE, tqdm, and pbr. The official
`bgmat` tag instead pins its historical environment, including JAX/JAXLIB
0.4.32 and NumPy 1.25.2.

## Bounded locality rerun

Asset fetching completed successfully. A first Probe-10 run under the active
Python 3.13.9 environment failed because JAX was absent, but the script returned
exit status zero and wrote a report with zero constructed cases. The failed
receipt is:

`current_paper_locality_boundary_package/probe_runs/current_probe10_locality_collision_alias_20260804_074641/`

The capstone was then rerun without source modification in an isolated CPU
environment:

- Python 3.13.1
- JAX/JAXLIB 0.11.0
- NumPy 2.5.1
- SciPy 1.18.0

Successful Probe 10 output:

`current_paper_locality_boundary_package/probe_runs/current_probe10_locality_collision_alias_20260804_074834/`

- five two-cluster cases;
- 15 local-signature rows;
- 240 neighbor-edge rows;
- 12 comparison rows;
- 12/12 with identical extracted local/top-n graph signatures;
- 12/12 with a changed long-range/global witness;
- 12/12 marked as aliases.

The decisive CSV has SHA-256
`27CD725AF4DBC6470C38B4F344A39E8587285F015C21356911D99C6D0C67D327`.

Successful Probe 11 output:

`current_paper_locality_boundary_package/probe_runs/current_probe11_physical_long_range_alias_20260804_074850/`

- three neutral charge models;
- 36 physical-confirmation rows;
- 36/36 with a nonzero selected long-range witness;
- 12/12 pair/`n_local` groups confirmed under every tested charge model.

The capstone claim table has SHA-256
`D0FD1744B39101614FF81C6C6202500627D68193A5C366D413DBE8FF80ECA90A`.

### Claim boundary and implementation risks

The capstone establishes a finite computational witness: selected top-n local
signatures agree for the constructed cases while selected nonlocal quantities
differ. It is not a theorem about the full Boltzmann generator or the Nature
benchmarks. It uses rounded local signatures and floating-point comparisons,
including a `1e-12` physical-delta threshold.

Two workflow hazards matter:

1. Probe 10 converts a missing-JAX subprocess failure into data, writes a
   positive-sounding “What this proves” section even when no aliases were found,
   and exits successfully. Downstream automation must inspect counts and the
   `ok`/`alias_detected` fields rather than trusting process status or prose.
2. Probe 10 resolves relative arguments against the `probes/` directory, while
   the manual README commands are written as though resolution were from the
   package root. The top-level runner is safe because it passes absolute paths;
   manual runs should do the same.

## Why the locality package did not “find the Fable result”

The locality package contains no occurrence of `Fable`, no marked-factor
algebra, and no Erdős–Strauss or raw-cell theorem. Its result is the general
mechanism “a finite local representation can erase a long-range/global label.”
This is an analogy to local-fidelity/global-alias phenomena, not a derivation
of the Fable map or the Erdős–Strauss (D_3) theorem.

The exact Fable match is the sibling `Jacobian/` package.

## `Jacobian/` inventory and entry points

The tracked package has 11 files, 5,041,849 bytes:

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `README.md` | 8,454 | `E0C902FEA6D2A48163B25F8F62750661CC63211867317D84F4F10F6580367AA1` |
| `Local_Fidelity_Global_Alias_Pipeline_Proof.tex` | 20,951 | `4C18CC12084D1075FF876C525583414E13C34C23F3B9F247A99D6E018D989F5F` |
| `Local_Fidelity_Global_Alias_Pipeline_Proof.pdf` | 161,409 | `9A5E1D66E75CCB4B8C4B387A999BAB6838CA1A1B26C0360169D3909D16095693` |
| `blind_search.py` | 10,517 | `181C8A16CF42B42C5007AFCE8F4C6BFBA95BDC7E3EC3345EED6911F04DF8B4A4` |
| `aceg.py` | 43,346 | `92F9919545D1E8FD24C24ED33AC99B01C2D83FA190E491B3C727B5F55287505B` |
| `aceg.jl` | 53,341 | `5A30562AFD3F301BEF55818BA3932FD36483475371D4B0EB2157DFFC70EE8199` |
| `aceg.wl` | 55,719 | `A1C887B2CCD88B18EFDCB0FFF19836301C9F922D42E2664AD3733B0507C55DB1` |
| `aceg_manifest.json` | 437,935 | `8234F9CD1D6D3324D4D7B2062A23E44B9F6BE8599982544D3463C262679DA926` |
| `aceg_julia_manifest.json` | 476,543 | `38D7C42A30D272D999647F622A1E8E143AD57383CB97B93F09AEC3988E543DCC` |
| `aceg_mathematica_manifest.json` | 483,720 | `F73D7F6E22FD6BF0A61979C9C571C347092670B204C770D28F628D93F8D50286` |
| `jacobian_counterexamples_5000.csv` | 3,289,914 | `4A33F9465275327AD4415596E30209AEAFED63D89A4B021C0A12E1A9CA9B116E` |

Entry points:

- `python blind_search.py` — exact SymPy chart and collision search;
- `python aceg.py base` — derive and print the base certificate;
- `python aceg.py generate ...` — generate exact polynomial-automorphism-orbit representatives;
- `python aceg.py verify MANIFEST` — reconstruct and verify a manifest;
- Julia and Wolfram sister commands documented in the README.

Python ACEG itself uses only the standard library. The blind search requires
SymPy. Julia is documented as standard-library only. The Wolfram edition needs
an activated Wolfram runtime.

## Blind-search reproduction

The search source enumerates all four visible coefficient slices

\[
M_1=ac,\quad M_2=ad+bc,\quad M_3=ae+bd,\quad M_4=be,
\]

and all five possible modulus variables. It does not contain the compact Fable
coordinate polynomials, their degree, the published three collision points, or
a preselected coefficient slice. It does encode the marked linear-times-quadratic
factorization, resultant-one gauge normalization, a boundary blow-up strategy,
and a bounded integer-root enumeration.

The unmodified search reproduced:

```text
M2 / modulus a: HIT, constant Jacobian = 1/2 (p=d, q=e)
Total collisions found on slice M2/a: 24
```

Some earlier candidates timed out under the script's six-second per-candidate
limit, so “first hit” can depend on machine speed. The winning candidate itself
is stable: a direct unmodified `attempt_chart("M2", "a")` call completed in
about one second and returned the same chart.

## Exact identity with the Fable map

On the discovered (M_2=ad+bc=1) slice, the visible three-coordinate map is

\[
G=(ac,\,ae+bd,\,be).
\]

The maintained Erdős–Strauss reader independently records the invariant-lift
identities

\[
F_1=be,\qquad F_2=2(ae+bd),\qquad F_3=2ac.
\]

Therefore, coefficient by coefficient,

\[
\boxed{G=\left(\frac{F_3}{2},\frac{F_2}{2},F_1\right).}
\]

This is also the coordinate change stated in the JGPTech proof: its induced map
(P=(ac,ae+bd,be)) is followed by the source change
((a,y,z)=(x,y,-t/2)) and target change
(S(u,v,w)=(w,2v,2u)). Thus (F=S\circ P\circ T).

The local checker
`verification/verify_jgptech_jacobian_bridge.py` recomputed the identity in
SymPy with zero polynomial remainder in every coordinate. It also found

\[
\det DG=\frac12,\qquad \det DF=-2,
\]

and exactly verified the three rational preimages of
((-1/4,0,0)).

This bridge concerns the explicit constant-Jacobian Fable fibre and the
resultant-one marked-factor lift. It does not prove the later Erdős–Strauss
raw-cell statement that the real (D_3) action fixes the unique negative cell
(E_{21}). The latter is a separate Lorentz/raw-cell theorem.

## ACEG and 5,000-row verification

The exact Python ACEG run returned:

- base determinant `-2`;
- collision points
  `(0,0,-1/4)`, `(1,-3/2,13/2)`, and `(-1,3/2,13/2)`;
- common image `(-1/4,0,0)`;
- canonical base-map SHA-256
  `ce70ce88ad5ef1553386ebcfc9ff5b4b1c6d7b239defc514cb66c41bc07423c7`.

Python exact reconstruction verified all three committed manifests:

| Manifest | Maps checked | Result |
| --- | ---: | --- |
| Python | 5 | PASS |
| Julia | 5 | PASS |
| Mathematica | 5 | PASS |

Julia was not installed on the audit host. WolframScript was installed but the
product was not activated, so a native Wolfram self-test could not run. The
Mathematica-authored manifest nevertheless passed the independent Python
reconstruction, determinant, hash, and collision verifier.

All 5,000 rows of `jacobian_counterexamples_5000.csv` were checked. They form
the single target-translation family

\[
G_n=T_n\circ F,\qquad T_n(u,v,w)=(u+n,v,w),\qquad 0\le n<5000.
\]

Every row's formula, sequential parameter, determinant field, transported
collision image, Boolean certificate fields, map identifier, and SHA-256 were
consistent. All 5,000 formula hashes are distinct. The CSV itself correctly
states that these are distinct representatives in one target-translation orbit
and makes no inequivalence claim.

The CSV `map_sha256` convention is SHA-256 of the three displayed formulas
joined by newline characters. That convention differs from ACEG's canonical
sparse-polynomial serialization; the separate `base_map_sha256` column carries
the canonical ACEG hash. The CSV names two uncommitted `Pasted text...` sources
and ships no generation script, so its file-generation provenance is weaker
than the three ACEG manifests even though the entire translation family is
easy to verify from the committed base map.

## Integration recommendation

The useful integration is narrow:

1. Cite the `Jacobian/` proof and blind-search commit as an independent
   marked-factor pipeline realization of the already credited Fable map.
2. State the exact coordinate identity
   (G=(F_3/2,F_2/2,F_1)) near the resultant-one invariant lift.
3. Preserve the public attribution chain: the explicit map to Claude Fable 5
   via the public announcement, the geometric exposition to Tao and Speyer,
   and the separate pipeline proof/search/generator to Jon Poplett/u/JGPTech.
4. Keep the locality/Boltzmann package out of the mathematical provenance for
   the Fable map. At most it supplies a conceptual analogy.
5. Do not bundle the 5,000-row CSV into the Erdős–Strauss release unless a
   concrete use appears; it is a large list of target translations, not 5,000
   inequivalent results. A link and the compact exact checker are more useful.

No maintained source was edited during this audit.

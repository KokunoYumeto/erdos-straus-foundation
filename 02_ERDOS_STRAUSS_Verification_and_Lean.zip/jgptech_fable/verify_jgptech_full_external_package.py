#!/usr/bin/env python3
"""Exact audit of the JGPTech Jacobian pipeline and its Fable-map bridge."""

from __future__ import annotations

import argparse
import csv
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from typing import Any

import sympy as sp


DEFAULT_REPO = (
    Path(__file__).resolve().parents[1]
    / "reference_sources"
    / "external"
    / "JGPTech_Fun"
)
EXPECTED_BASE_HASH = (
    "ce70ce88ad5ef1553386ebcfc9ff5b4b1c6d7b239defc514cb66c41bc07423c7"
)


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_bridge(blind_search: Any) -> dict[str, Any]:
    result = blind_search.attempt_chart("M2", "a")
    if result is None:
        raise AssertionError("Blind search no longer finds the M2/a chart")

    x, y, t = sp.symbols("x y t")
    u = 1 + x * y
    f1 = sp.expand(u**3 * t + y**2 * u * (4 + 3 * x * y))
    f2 = sp.expand(y + 3 * x * u**2 * t + 3 * x * y**2 * (4 + 3 * x * y))
    f3 = sp.expand(2 * x - 3 * x**2 * y - x**3 * t)
    expected_visible = (f3 / 2, f2 / 2, f1)

    substitutions = {
        result["m"]: x,
        result["y"]: y,
        result["z"]: t,
    }
    discovered = tuple(sp.expand(g.subs(substitutions)) for g in result["G"])
    bridge_differences = tuple(
        sp.expand(left - right)
        for left, right in zip(discovered, expected_visible)
    )
    if bridge_differences != (0, 0, 0):
        raise AssertionError(f"Fable bridge mismatch: {bridge_differences}")

    discovered_det = sp.factor(
        sp.Matrix(discovered).jacobian((x, y, t)).det()
    )
    compact_det = sp.factor(sp.Matrix((f1, f2, f3)).jacobian((x, y, t)).det())
    if discovered_det != sp.Rational(1, 2):
        raise AssertionError(f"Unexpected discovered determinant: {discovered_det}")
    if compact_det != -2:
        raise AssertionError(f"Unexpected compact determinant: {compact_det}")

    points = (
        (sp.Rational(0), sp.Rational(0), sp.Rational(-1, 4)),
        (sp.Rational(1), sp.Rational(-3, 2), sp.Rational(13, 2)),
        (sp.Rational(-1), sp.Rational(3, 2), sp.Rational(13, 2)),
    )
    images = [
        tuple(component.subs(dict(zip((x, y, t), point))) for component in (f1, f2, f3))
        for point in points
    ]
    if images != [(sp.Rational(-1, 4), 0, 0)] * 3:
        raise AssertionError(f"Compact collision mismatch: {images}")

    return {
        "slice": "M2=1",
        "modulus": "a",
        "blind_chart_determinant": str(discovered_det),
        "compact_determinant": str(compact_det),
        "identity": "G=(F3/2,F2/2,F1)",
        "identity_exact": True,
        "collision_exact": True,
    }


def verify_aceg(jacobian_dir: Path, aceg: Any) -> dict[str, Any]:
    base_map = aceg.derive_pipeline_map()
    base_hash = aceg.map_hash(base_map)
    if base_hash != EXPECTED_BASE_HASH:
        raise AssertionError(f"ACEG base hash mismatch: {base_hash}")
    determinant = aceg.jacobian_determinant(base_map).to_string()
    if determinant != "-2":
        raise AssertionError(f"ACEG base determinant mismatch: {determinant}")
    if not all(aceg.evaluate_map(base_map, p) == aceg.BASE_IMAGE for p in aceg.BASE_POINTS):
        raise AssertionError("ACEG base collision failed")

    manifest_results: dict[str, Any] = {}
    for name in (
        "aceg_manifest.json",
        "aceg_julia_manifest.json",
        "aceg_mathematica_manifest.json",
    ):
        data = json.loads((jacobian_dir / name).read_text(encoding="utf-8"))
        result = aceg.verify_manifest_data(data)
        if not result["passed"]:
            raise AssertionError(f"Manifest verification failed: {name}: {result}")
        manifest_results[name] = {
            "passed": True,
            "maps_checked": result["maps_checked"],
        }

    return {
        "base_hash": base_hash,
        "base_determinant": determinant,
        "base_collision_exact": True,
        "manifests": manifest_results,
    }


def verify_translation_csv(jacobian_dir: Path, aceg: Any) -> dict[str, Any]:
    path = jacobian_dir / "jacobian_counterexamples_5000.csv"
    base_strings = [p.to_string() for p in aceg.derive_pipeline_map()]
    rows = list(csv.DictReader(path.open("r", encoding="utf-8", newline="")))
    if len(rows) != 5000:
        raise AssertionError(f"Expected 5000 CSV rows, found {len(rows)}")

    seen_hashes: set[str] = set()
    for one_based, row in enumerate(rows, start=1):
        n = one_based - 1
        expected_g1 = base_strings[0] if n == 0 else f"{base_strings[0]} + {n}"
        formulas = [row["G1"], row["G2"], row["G3"]]
        if formulas != [expected_g1, base_strings[1], base_strings[2]]:
            raise AssertionError(f"Formula mismatch in CSV row {one_based}")
        expected_hash = hashlib.sha256("\n".join(formulas).encode("utf-8")).hexdigest()
        if row["map_sha256"] != expected_hash:
            raise AssertionError(f"Formula hash mismatch in CSV row {one_based}")
        if row["map_id"] != f"ACEG-T{n:04d}-{expected_hash[:12]}":
            raise AssertionError(f"Map id mismatch in CSV row {one_based}")
        if expected_hash in seen_hashes:
            raise AssertionError(f"Duplicate formula hash in CSV row {one_based}")
        seen_hashes.add(expected_hash)

        expected_image = Fraction(4 * n - 1, 4)
        checks = {
            "record_index": str(one_based),
            "family_parameter_n": str(n),
            "jacobian_determinant": "-2",
            "collision_image_1": str(expected_image),
            "collision_image_2": "0",
            "collision_image_3": "0",
            "collision_multiplicity": "3",
            "exact_jacobian_verified": "true",
            "exact_collision_verified": "true",
            "preimages_distinct": "true",
            "base_map_sha256": EXPECTED_BASE_HASH,
        }
        for key, expected in checks.items():
            if row[key] != expected:
                raise AssertionError(
                    f"CSV row {one_based}, {key}: expected {expected!r}, got {row[key]!r}"
                )

    return {
        "rows_checked": len(rows),
        "distinct_formula_hashes": len(seen_hashes),
        "family": "target translations T_n(u,v,w)=(u+n,v,w), n=0,...,4999",
        "inequivalence_claim": False,
        "all_relational_checks_passed": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO)
    args = parser.parse_args()
    repo = args.repo.resolve()
    jacobian_dir = repo / "Jacobian"
    blind_search = load_module("jgptech_blind_search", jacobian_dir / "blind_search.py")
    aceg = load_module("jgptech_aceg", jacobian_dir / "aceg.py")

    summary = {
        "repo": str(repo),
        "bridge": verify_bridge(blind_search),
        "aceg": verify_aceg(jacobian_dir, aceg),
        "translation_csv": verify_translation_csv(jacobian_dir, aceg),
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

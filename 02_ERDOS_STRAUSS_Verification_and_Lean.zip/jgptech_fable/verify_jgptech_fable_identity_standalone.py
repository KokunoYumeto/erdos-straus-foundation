#!/usr/bin/env python3
"""Standalone exact certificate for the JGPTech-chart/Fable-map identity."""

from __future__ import annotations

import json
import sympy as sp


def main() -> int:
    x, y, z = sp.symbols("x y z")
    f1 = (1 + x * y) ** 3 * z + y**2 * (1 + x * y) * (4 + 3 * x * y)
    f2 = y + 3 * x * (1 + x * y) ** 2 * z + 3 * x * y**2 * (4 + 3 * x * y)
    f3 = 2 * x - 3 * x**2 * y - x**3 * z
    fable = [sp.expand(f1), sp.expand(f2), sp.expand(f3)]

    # The M2=1, modulus-a chart printed by JGPTech's blind_search.py.
    g1 = x - sp.Rational(3, 2) * x**2 * y - sp.Rational(1, 2) * x**3 * z
    g2 = (
        sp.Rational(1, 2) * y
        + 6 * x * y**2
        + sp.Rational(9, 2) * x**2 * y**3
        + sp.Rational(3, 2) * x * z
        + 3 * x**2 * y * z
        + sp.Rational(3, 2) * x**3 * y**2 * z
    )
    g3 = z + 4 * y**2 + 3 * x * y * z + 7 * x * y**3 + 3 * x**2 * y**2 * z + 3 * x**2 * y**4 + x**3 * y**3 * z
    discovered = [sp.expand(g1), sp.expand(g2), sp.expand(g3)]
    expected = [sp.expand(f3 / 2), sp.expand(f2 / 2), sp.expand(f1)]
    differences = [sp.expand(a - b) for a, b in zip(discovered, expected)]
    assert differences == [0, 0, 0]

    det_f = sp.factor(sp.Matrix(fable).jacobian([x, y, z]).det())
    det_g = sp.factor(sp.Matrix(discovered).jacobian([x, y, z]).det())
    assert det_f == -2
    assert det_g == sp.Rational(1, 2)

    sample_points = [
        (sp.Rational(1, 6), -4, -288),
        (sp.Rational(-1, 2), 2, 36),
        (sp.Rational(1, 3), -4, 0),
    ]
    sample_g_images = [tuple(p.subs(dict(zip((x, y, z), point))) for p in discovered) for point in sample_points]
    sample_f_images = [tuple(p.subs(dict(zip((x, y, z), point))) for p in fable) for point in sample_points]
    assert len(set(sample_g_images)) == 1 and sample_g_images[0] == (1, -2, 0)
    assert len(set(sample_f_images)) == 1 and sample_f_images[0] == (0, -4, 2)

    compact_points = [
        (0, 0, sp.Rational(-1, 4)),
        (1, sp.Rational(-3, 2), sp.Rational(13, 2)),
        (-1, sp.Rational(3, 2), sp.Rational(13, 2)),
    ]
    compact_f_images = [tuple(p.subs(dict(zip((x, y, z), point))) for p in fable) for point in compact_points]
    compact_g_images = [tuple(p.subs(dict(zip((x, y, z), point))) for p in discovered) for point in compact_points]
    assert len(set(compact_f_images)) == 1 and compact_f_images[0] == (sp.Rational(-1, 4), 0, 0)
    assert len(set(compact_g_images)) == 1 and compact_g_images[0] == (0, 0, sp.Rational(-1, 4))

    u, v = sp.symbols("U V")
    compact_cubic = u**2 * v - sp.Rational(1, 4) * v**3
    assert sp.expand(compact_cubic - v * (u - v / 2) * (u + v / 2)) == 0

    result = {
        "schema": "jgptech-fable-standalone-certificate-r1",
        "status": "PASS",
        "coordinate_identity": "G=(F3/2,F2/2,F1)",
        "component_differences": [str(value) for value in differences],
        "det_JF": str(det_f),
        "det_JG": str(det_g),
        "sample_collision_G": [str(value) for value in sample_g_images[0]],
        "sample_collision_F": [str(value) for value in sample_f_images[0]],
        "compact_fable_image_F": [str(value) for value in compact_f_images[0]],
        "compact_fable_image_G": [str(value) for value in compact_g_images[0]],
        "compact_binary_cubic_factorization": "PASS",
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

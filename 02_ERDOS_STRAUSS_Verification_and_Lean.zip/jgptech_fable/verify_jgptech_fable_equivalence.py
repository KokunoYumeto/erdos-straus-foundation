#!/usr/bin/env python3
"""Exact audit of the public JGPTech marked-factor pipeline against Fable's map.

The script leaves the external checkout unchanged.  It imports the public blind
search, reconstructs its first successful chart directly, proves its coordinate
identity with the Fable map in SymPy, checks a three-point fibre, replays the
ACEG manifest verifier, and optionally runs the complete blind discovery.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from typing import Any

import sympy as sp


HERE = Path(__file__).resolve().parent
DEFAULT_JACOBIAN = (
    HERE.parent.parent
    / "reference_sources"
    / "external"
    / "JGPTech_Fun"
    / "Jacobian"
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_blind_search(path: Path) -> Any:
    spec = importlib.util.spec_from_file_location("jgptech_blind_search", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_checked(command: list[str], cwd: Path, timeout: int = 180) -> dict[str, Any]:
    proc = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=True,
        timeout=timeout,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"Command failed ({proc.returncode}): {' '.join(command)}\n"
            f"stdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
        )
    return {
        "command": command,
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }


def exact_audit(jacobian_dir: Path, full_discovery: bool) -> dict[str, Any]:
    blind_path = jacobian_dir / "blind_search.py"
    aceg_path = jacobian_dir / "aceg.py"
    manifest_path = jacobian_dir / "aceg_manifest.json"
    for path in (blind_path, aceg_path, manifest_path):
        if not path.is_file():
            raise FileNotFoundError(path)

    blind = load_blind_search(blind_path)
    chart = blind.attempt_chart("M2", "a")
    if chart is None:
        raise AssertionError("The public M2/a chart was not reconstructed")

    x, y, z = sp.symbols("x y z")
    f1 = (1 + x * y) ** 3 * z + y**2 * (1 + x * y) * (4 + 3 * x * y)
    f2 = y + 3 * x * (1 + x * y) ** 2 * z + 3 * x * y**2 * (4 + 3 * x * y)
    f3 = 2 * x - 3 * x**2 * y - x**3 * z

    rename = {chart["m"]: x, chart["y"]: y, chart["z"]: z}
    discovered = [sp.expand(component.subs(rename)) for component in chart["G"]]
    expected = [sp.expand(f3 / 2), sp.expand(f2 / 2), sp.expand(f1)]
    differences = [sp.expand(a - b) for a, b in zip(discovered, expected)]
    if differences != [0, 0, 0]:
        raise AssertionError(f"Coordinate identity failed: {differences}")

    determinant = sp.factor(sp.Matrix(discovered).jacobian([x, y, z]).det())
    if determinant != sp.Rational(1, 2):
        raise AssertionError(f"Unexpected discovered determinant: {determinant}")

    root_triple = (sp.Rational(-2), sp.Rational(0), sp.Rational(1))
    states = [blind.gauge_fix(state) for state in blind.marked_states(*root_triple)]
    points = [blind.invert_chart(chart, state) for state in states]
    if any(point is None for point in points):
        raise AssertionError("Sample marked states did not invert through the chart")
    images = [
        tuple(
            sp.simplify(component.subs({
                chart["m"]: point[0],
                chart["y"]: point[1],
                chart["z"]: point[2],
            }))
            for component in chart["G"]
        )
        for point in points
    ]
    if len(set(points)) != 3 or len(set(images)) != 1:
        raise AssertionError("Sample three-point collision failed")

    collision_count = blind.collision_search(chart, max_abs_root=4, verbose=False)
    if collision_count != 24:
        raise AssertionError(f"Expected 24 bounded collision hits, got {collision_count}")

    aceg_base = run_checked([sys.executable, str(aceg_path), "base"], jacobian_dir)
    aceg_verify = run_checked(
        [sys.executable, str(aceg_path), "verify", str(manifest_path)],
        jacobian_dir,
    )
    if "determinant = -2" not in aceg_base["stdout"]:
        raise AssertionError("ACEG base replay did not report determinant -2")
    if "passed: True" not in aceg_verify["stdout"] or "maps_checked: 5" not in aceg_verify["stdout"]:
        raise AssertionError("ACEG manifest replay did not pass all five maps")

    discovery: dict[str, Any] | None = None
    if full_discovery:
        discovery = run_checked([sys.executable, str(blind_path)], jacobian_dir, timeout=300)
        required = (
            "M2 / modulus a: HIT, constant Jacobian = 1/2",
            "Total collisions found on slice M2/a: 24",
        )
        missing = [needle for needle in required if needle not in discovery["stdout"]]
        if missing:
            raise AssertionError(f"Full blind discovery output missing: {missing}")

    git_root = jacobian_dir.parent
    git_head = run_checked(["git", "rev-parse", "HEAD"], git_root)["stdout"].strip()
    path_commit = run_checked(
        ["git", "log", "-1", "--format=%H", "--", "Jacobian"], git_root
    )["stdout"].strip()

    return {
        "schema": "jgptech-fable-exact-audit-r1",
        "status": "PASS",
        "external_repository": "https://github.com/JGPTech/Fun",
        "checkout_head": git_head,
        "latest_commit_affecting_jacobian_path": path_commit,
        "core_file_sha256": {
            "Jacobian/blind_search.py": sha256(blind_path),
            "Jacobian/aceg.py": sha256(aceg_path),
            "Jacobian/aceg_manifest.json": sha256(manifest_path),
        },
        "discovered_slice": {
            "visible_hyperplane": "M2=1",
            "modulus": "a",
            "solved_variables": [str(chart["p"]), str(chart["q"])],
            "determinant": str(determinant),
        },
        "exact_coordinate_identity": {
            "discovered_map": "G=(F3/2,F2/2,F1)",
            "component_differences": [str(value) for value in differences],
        },
        "sample_collision": {
            "root_triple": [str(value) for value in root_triple],
            "source_points": [[str(value) for value in point] for point in points],
            "common_image": [str(value) for value in images[0]],
        },
        "bounded_collision_count": collision_count,
        "aceg": {
            "base_replay": "PASS",
            "manifest_replay": "PASS",
            "maps_checked": 5,
        },
        "full_blind_discovery": "PASS" if discovery is not None else "NOT_REQUESTED",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--jacobian-dir", type=Path, default=DEFAULT_JACOBIAN)
    parser.add_argument("--full-discovery", action="store_true")
    parser.add_argument("--output", type=Path, default=HERE / "JGPTECH_FABLE_AUDIT_RESULTS.json")
    args = parser.parse_args()

    result = exact_audit(args.jacobian_dir.resolve(), args.full_discovery)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

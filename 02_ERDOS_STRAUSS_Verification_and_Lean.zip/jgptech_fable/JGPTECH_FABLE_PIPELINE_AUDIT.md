# JGPTech pipeline and the Fable map: exact audit

Date: 4 August 2026  
Status: **PASS**

## Sources pinned

- JGPTech/Fun, `Jacobian/`, final relevant path state at commit
  [`2fe1901840ef3aa28232930e1aec8d8bbb61281a`](https://github.com/JGPTech/Fun/tree/2fe1901840ef3aa28232930e1aec8d8bbb61281a/Jacobian).
- The proof and ACEG package first appeared in commit
  [`461c378badd51b44f8ba7433172586b2524545f4`](https://github.com/JGPTech/Fun/commit/461c378badd51b44f8ba7433172586b2524545f4).
- The blind marked-factor search appeared in commit
  [`eda79facb91355c7043823beacef94a4220f2a88`](https://github.com/JGPTech/Fun/commit/eda79facb91355c7043823beacef94a4220f2a88).
- Jon Poplett's public note is titled *Local Fidelity, Global Alias: A Pipeline
  Proof of the Three-Dimensional Jacobian Counterexample*. The repository
  expressly credits the displayed counterexample to Fable and does not claim
  its discovery.

The exact local files are under
`reference_sources/external/JGPTech_Fun/Jacobian`. The external checkout was
left unmodified.

## Exact bridge

The blind search starts only from a marked factorization

\[
L=aU+bV,\qquad Q=cU^2+dUV+eV^2,
\]

the four coefficients of (LQ), and the resultant normalization
(R(L,Q)=1). Its first successful chart is

\[
M_2=1,\qquad\text{modulus }a,qquad (p,q)=(d,e),
\]

and has constant Jacobian (1/2).

Let (F=(F_1,F_2,F_3)) be the displayed Fable map in the maintained reader.
Direct symbolic expansion proves that the map (G) discovered by JGPTech's
search is exactly

\[
G(x,y,z)=\left(\frac{F_3(x,y,z)}2,
                 \frac{F_2(x,y,z)}2,
                 F_1(x,y,z)\right).
\]

Thus the search recovers the Fable map up to an invertible target-coordinate
permutation and diagonal scaling. This also explains
(det DG=1/2) from (det DF=-2). The equality was checked as three zero
polynomials, not numerically.

The bounded collision search ((|r_i|\leq4)) returns 24 exact three-point
collisions. For example, the root triple ((-2,0,1)) yields the three source
points

\[
\left(\frac16,-4,-288\right),\qquad
\left(-\frac12,2,36\right),\qquad
\left(\frac13,-4,0\right),
\]

all with (G)-image ((1,-2,0)).

The compact fibre used in the maintained reader has (G)-image
((0,0,-1/4)). In the fixed (M_2=1) coefficient chart, its binary cubic is

\[
U^2V-\frac14V^3=V\left(U-\frac12V\right)
                      \left(U+\frac12V\right).
\]

One marked root is therefore at infinity in the affine root enumeration used
by `blind_search.py`. The pipeline proof's boundary closure, and the exact
coordinate identity above, supply the connection to the displayed Fable
three-point fibre.

## Replays

- `python aceg.py base`: determinant (-2), the three displayed rational
  preimages, and common image ((-1/4,0,0)), all exact.
- `python aceg.py verify aceg_manifest.json`: **PASS**, five maps checked.
- `python blind_search.py`: first hit (M_2=1), modulus (a), determinant
  (1/2); 24 bounded collision hits.
- `python analysis/jgptech_fable_pipeline_audit/verify_jgptech_fable_equivalence.py --full-discovery`:
  **PASS**.

The machine-readable receipt is `JGPTECH_FABLE_AUDIT_RESULTS.json` in this
folder.

## Claim boundary for the Nature/LinkedIn material

The separately linked package
`current_paper_locality_boundary_package/` is a June 2026 mechanism-boundary
audit of Schebek, Noé, and Rogal's fixed-neighbour Boltzmann-generator
architecture, DOI
[`10.1038/s41467-026-73900-9`](https://doi.org/10.1038/s41467-026-73900-9).
It constructs controlled cases in which identical local/top-(n) signatures
have different neutral long-range witnesses. Neither that package nor Jon
Poplett's LinkedIn comment mentions Fable or Erdős--Strauss. The Nature model
uses bijective coupling layers and supplies no theorem for the noninjective
Fable fibre.

Accordingly, the Nature paper and its locality audit should not be cited as a
source for the Fable theorem. The `Jacobian/` package is directly relevant and
should be cited for the independent marked-factor derivation, exact generator,
and blind recovery described above.

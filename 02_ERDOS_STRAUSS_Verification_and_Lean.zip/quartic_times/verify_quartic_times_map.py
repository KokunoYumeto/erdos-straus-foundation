"""Exact verification of the quartic four-Time marked-factor map."""

import sympy as sp


a, y, z, w, r = sp.symbols("a y z w r")


def reduce_r(expr):
    """Reduce a polynomial modulo r^2 + 1."""
    poly = sp.Poly(sp.expand(expr), r)
    modulus = sp.Poly(r**2 + 1, r)
    return sp.rem(poly, modulus).as_expr().expand()


b = r + a * y
c = -r + 2 * a * y + a**2 * z
d = -r * y - a * (r * z + 2 * y**2) - a**2 * y * z
e = 2 * z - 7 * r * y**2 + a * w
f = (
    r * w
    + 3 * r * y**3
    - 4 * y * z
    + a * (6 * r * y**2 * z + w * y + 4 * y**4)
    + 2 * a**2 * y**3 * z
)

fixed_coefficient = reduce_r(a * d + b * c)
resultant = reduce_r(-b**3 * c + a * b**2 * d - a**2 * b * e + a**3 * f)
assert fixed_coefficient == 1
assert resultant == 1

P = tuple(
    reduce_r(expr)
    for expr in (a * c, a * e + b * d, a * f + b * e, b * f)
)

jacobian = sp.Matrix(P).jacobian((a, y, z, w))
determinant = reduce_r(jacobian.det())
assert determinant == -2

iota = sp.I
sqrt2 = sp.sqrt(2)
points = {
    "M": (0, 0, iota / 2, 0),
    "N": (iota, -1, -3 * iota, 13),
    "T": (
        1 / sqrt2,
        -1 - sqrt2 * iota,
        2 * sqrt2 + 6 * iota,
        -34 - 19 * sqrt2 * iota,
    ),
    "E": (
        1 / sqrt2,
        1 - sqrt2 * iota,
        -2 * sqrt2 + 6 * iota,
        34 - 19 * sqrt2 * iota,
    ),
}

target = (0, 0, -1, 0)
for point in points.values():
    substitution = dict(zip((a, y, z, w, r), (*point, iota)))
    image = tuple(sp.simplify(component.subs(substitution)) for component in P)
    assert image == target

state_table = {
    "M": (0, iota, -iota, 0, iota, 0),
    "N": (iota, 0, 0, -iota, 0, iota),
    "T": (1 / sqrt2, -1 / sqrt2, 0, sqrt2, sqrt2, 0),
    "E": (1 / sqrt2, 1 / sqrt2, 0, sqrt2, -sqrt2, 0),
}

for state in state_table.values():
    aa, bb, cc, dd, ee, ff = state
    state_resultant = sp.simplify(
        -bb**3 * cc + aa * bb**2 * dd - aa**2 * bb * ee + aa**3 * ff
    )
    product = tuple(
        sp.simplify(component)
        for component in (
            aa * cc,
            aa * dd + bb * cc,
            aa * ee + bb * dd,
            aa * ff + bb * ee,
            bb * ff,
        )
    )
    assert state_resultant == 1
    assert product == (0, 1, 0, -1, 0)

# Unit regular tetrahedron and the universal centre-to-face ratio.
j4 = sp.ones(4, 1)
mus = []
for index in range(4):
    basis = sp.zeros(4, 1)
    basis[index] = 1
    mus.append((sp.Rational(2, 1) / sp.sqrt(3)) * (basis - j4 / 4))

assert sum(mus, sp.zeros(4, 1)) == sp.zeros(4, 1)
face_center = sum(mus[:3], sp.zeros(4, 1)) / 3
altitude = mus[3] - face_center
assert sp.simplify((sp.zeros(4, 1) - face_center).dot(altitude) / altitude.dot(altitude)) == sp.Rational(1, 4)

print("fixed coefficient: 1")
print("resultant: 1")
print("Jacobian determinant: -2")
print("four collision images: (0, 0, -1, 0)")
print("quartic product: (0, 1, 0, -1, 0)")
print("centre-to-face / full-altitude ratio: 1/4")
print("all exact assertions passed")

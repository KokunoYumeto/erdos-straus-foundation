#!/usr/bin/env python3
"""Standalone structural and privacy gate for the released reader PDF set."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

from pypdf import PdfReader
from pypdf.generic import ArrayObject, DictionaryObject, IndirectObject


REPO = Path(__file__).resolve().parents[1]
DEFAULT_RELEASE = REPO / "release_work" / "live_successor_built"
DEFAULT_RECEIPT = REPO / "release_work" / "release_pdf_safety_audit.json"
READER_NAME = "00_ERDOS_STRAUSS_Project_Reader.pdf"
SOURCE_NAME = "01_ERDOS_STRAUSS_Reader_Source_and_Build.zip"
FORBIDDEN_KEYS = {
    "/AA",
    "/AcroForm",
    "/EmbeddedFile",
    "/EmbeddedFiles",
    "/FileAttachment",
    "/ImportData",
    "/JavaScript",
    "/JS",
    "/Launch",
    "/Movie",
    "/RichMedia",
    "/Screen",
    "/Sound",
    "/SubmitForm",
    "/XFA",
}
FORBIDDEN_ACTIONS = {
    "/GoToR",
    "/ImportData",
    "/JavaScript",
    "/Launch",
    "/Movie",
    "/Rendition",
    "/Sound",
    "/SubmitForm",
}
KNOWN_ACTIONS = FORBIDDEN_ACTIONS | {"/GoTo", "/URI"}
FORBIDDEN_TYPES = {"/EmbeddedFile", "/Filespec"}
FORBIDDEN_TEXT = (
    re.compile(r"[A-Za-z]:\\Users\\", re.IGNORECASE),
    re.compile(r"/Users/[^/\s]+/", re.IGNORECASE),
    re.compile(r"AppData", re.IGNORECASE),
    re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE),
)


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def walk(root) -> list[DictionaryObject]:
    stack = [root]
    indirect_seen: set[tuple[int, int]] = set()
    direct_seen: set[int] = set()
    dictionaries: list[DictionaryObject] = []
    while stack:
        value = stack.pop()
        if isinstance(value, IndirectObject):
            identity = (value.idnum, value.generation)
            if identity in indirect_seen:
                continue
            indirect_seen.add(identity)
            value = value.get_object()
        if isinstance(value, DictionaryObject):
            identity = id(value)
            if identity in direct_seen:
                continue
            direct_seen.add(identity)
            dictionaries.append(value)
            stack.extend(value.values())
        elif isinstance(value, ArrayObject):
            stack.extend(value)
        if len(indirect_seen) + len(direct_seen) > 200_000:
            raise AssertionError("PDF object graph is unexpectedly large")
    return dictionaries


def gate(name: str, raw: bytes) -> dict[str, object]:
    reader = PdfReader(io.BytesIO(raw))
    if reader.is_encrypted:
        raise AssertionError(f"encrypted PDF: {name}")
    root = reader.trailer.get("/Root")
    if root is None:
        raise AssertionError(f"missing PDF root: {name}")
    action_types: set[str] = set()
    for dictionary in walk(root):
        keys = set(map(str, dictionary.keys()))
        bad_keys = sorted(keys & FORBIDDEN_KEYS)
        if bad_keys:
            raise AssertionError(f"forbidden PDF keys in {name}: {bad_keys}")
        object_type = str(dictionary.get("/Type", ""))
        if object_type in FORBIDDEN_TYPES:
            raise AssertionError(f"forbidden PDF object type in {name}: {object_type}")
        action_type = str(dictionary.get("/S", ""))
        if action_type in KNOWN_ACTIONS:
            action_types.add(action_type)
        if action_type in FORBIDDEN_ACTIONS:
            raise AssertionError(f"forbidden PDF action in {name}: {action_type}")
    metadata = reader.metadata or {}
    metadata_text = "\n".join(f"{key}={value}" for key, value in metadata.items())
    visible_text = "\n".join(page.extract_text() or "" for page in reader.pages)
    for pattern in FORBIDDEN_TEXT:
        if pattern.search(metadata_text) or pattern.search(visible_text):
            raise AssertionError(f"private text pattern in PDF: {name}")
    author = str(metadata.get("/Author") or "")
    if author not in {"", "The Clankers"}:
        raise AssertionError(f"unexpected author metadata in {name}: {author}")
    return {
        "action_types": sorted(action_types),
        "author": author,
        "encrypted": False,
        "pages": len(reader.pages),
        "pdf_safety": "PASS",
        "privacy": "PASS",
        "sha256": sha256(raw),
        "size_bytes": len(raw),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-dir", type=Path, default=DEFAULT_RELEASE)
    parser.add_argument("--receipt", type=Path, default=DEFAULT_RECEIPT)
    args = parser.parse_args()
    release = args.release_dir.resolve()
    receipt = args.receipt.resolve()
    reader_raw = (release / READER_NAME).read_bytes()
    results = {READER_NAME: gate(READER_NAME, reader_raw)}
    with zipfile.ZipFile(release / SOURCE_NAME) as source:
        bad = source.testzip()
        if bad is not None:
            raise AssertionError(f"reader-source ZIP CRC failure: {bad}")
        build_receipt = json.loads(source.read("BUILD_RECEIPT.json").decode("utf-8"))
        for member in sorted(name for name in source.namelist() if name.casefold().endswith(".pdf")):
            results[f"{SOURCE_NAME}:{member}"] = gate(member, source.read(member))
    if results[READER_NAME]["sha256"] != build_receipt["reader_pdf"]["sha256"]:
        raise AssertionError("reader PDF differs from BUILD_RECEIPT.json")
    if results[READER_NAME]["pages"] != build_receipt["reader_pdf"]["pages"]:
        raise AssertionError("reader page count differs from BUILD_RECEIPT.json")
    logbook_key = f"{SOURCE_NAME}:provenance/research_logbook.pdf"
    if results[logbook_key]["sha256"] != build_receipt["logbook_pdf"]["sha256"]:
        raise AssertionError("logbook PDF differs from BUILD_RECEIPT.json")
    payload = {
        "file_count": len(results),
        "files": results,
        "reader_build_receipt_binding": "PASS",
        "status": "PASS_RELEASE_PDF_SAFETY_AND_PRIVACY",
    }
    receipt.parent.mkdir(parents=True, exist_ok=True)
    receipt.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

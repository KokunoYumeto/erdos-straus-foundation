import Mathlib
import ErdosStraussChecks.ArctangentGaussianCertificate
import ErdosStraussChecks.PositiveConeSplitZeroLift

/-!
# Bounded formal checks for the Erdős–Strauss project reader

These theorems cover algebraic identities and exact finite constants selected
from the reader. They do not assert the full Erdős–Strauss conjecture.
-/

namespace ErdosStraussChecks

/-- The real-coordinate form of the cubic Fourier phase norm. -/
theorem fourierPhaseNorm (m0 m1 m2 : ℝ) :
    (m0 - (m1 + m2) / 2) ^ 2 + (3 / 4) * (m1 - m2) ^ 2 =
      m0 ^ 2 + m1 ^ 2 + m2 ^ 2 - m0 * m1 - m1 * m2 - m2 * m0 := by
  ring

/-- The support Lorentz form is three times the pairwise-product sum. -/
theorem supportLorentzIdentity (m0 m1 m2 : ℝ) :
    (m0 + m1 + m2) ^ 2 -
        ((m0 - (m1 + m2) / 2) ^ 2 + (3 / 4) * (m1 - m2) ^ 2) =
      3 * (m0 * m1 + m1 * m2 + m2 * m0) := by
  ring

/-- Algebraic Wick substitution in any commutative ring with an element squaring to -1. -/
theorem wickPolynomialIdentity {R : Type*} [CommRing R]
    (i S X Y : R) (hi : i ^ 2 = -1) :
    S ^ 2 + (i * X) ^ 2 + (i * Y) ^ 2 = S ^ 2 - X ^ 2 - Y ^ 2 := by
  calc
    S ^ 2 + (i * X) ^ 2 + (i * Y) ^ 2 =
        S ^ 2 + i ^ 2 * X ^ 2 + i ^ 2 * Y ^ 2 := by ring
    _ = S ^ 2 - X ^ 2 - Y ^ 2 := by rw [hi]; ring

/-- Sarnak's four-variable Descartes quadratic form. -/
def descartesForm (b1 b2 b3 b4 : ℝ) : ℝ :=
  2 * (b1 ^ 2 + b2 ^ 2 + b3 ^ 2 + b4 ^ 2) - (b1 + b2 + b3 + b4) ^ 2

/-- The orthogonal Descartes basis identity, with `r2` representing sqrt(2). -/
theorem descartesOrthogonalBasis (T X Y W r2 : ℝ) (hr2 : r2 ^ 2 = 2) :
    descartesForm
        (T / 2 + X * r2 / 2 + Y / 2)
        (T / 2 - X * r2 / 2 + Y / 2)
        (T / 2 - Y / 2 + W * r2 / 2)
        (T / 2 - Y / 2 - W * r2 / 2) =
      2 * (X ^ 2 + Y ^ 2 + W ^ 2 - T ^ 2) := by
  unfold descartesForm
  nlinarith

/-- The Fable three-coordinate pullback of the diagonal Descartes form. -/
theorem fableDescartesPullback (t x y r3 : ℝ) (hr3 : r3 ^ 2 = 3) :
    2 * ((r3 * x / 2) ^ 2 + y ^ 2 + 0 ^ 2 - t ^ 2) =
      -2 * (t ^ 2 - (3 / 4) * x ^ 2 - y ^ 2) := by
  nlinarith

/-- The exact coefficient-to-Sarnak Lorentz-coordinate identity. -/
theorem coefficientSarnakCoordinateIdentity (a b0 b1 c : ℝ) :
    b0 ^ 2 + b1 ^ 2 + ((a - c) / 2) ^ 2 - ((a + c) / 2) ^ 2 =
      b0 ^ 2 + b1 ^ 2 - a * c := by
  ring

/-- Algebra behind the fixed-shell divisor factorization. -/
theorem divisorShellFactorization (R N b c : ℤ) :
    (R * b - N) * (R * c - N) - N ^ 2 =
      R * (R * b * c - N * (b + c)) := by
  ring

/-- Reconstruction algebra over the rationals before positivity/integrality conditions. -/
theorem divisorShellReconstruction (R N d e : ℚ) (hR : R ≠ 0) :
    R * ((N + d) / R * ((N + e) / R)) -
        N * ((N + d) / R + (N + e) / R) =
      (d * e - N ^ 2) / R := by
  field_simp
  ring

/-- Centered form of the denominator-exchange branch coordinate. -/
theorem quarterBranchCentering (s : ℚ) :
    -s * (1 - s) = -(1 / 4) + (2 * s - 1) ^ 2 / 4 := by
  ring

/-- Divisor complementation is an involution away from zero. -/
theorem divisorComplementInvolution (A d : ℚ) (hA : A ≠ 0) (hd : d ≠ 0) :
    A ^ 2 / (A ^ 2 / d) = d := by
  field_simp

/-- The explicit unit-fraction certificate used for p = 12289. -/
theorem certificate12289 :
    (4 : ℚ) / 12289 = 1 / 3075 + 1 / 3440920 + 1 / 2116165800 := by
  norm_num

/-- Core mod-107 constants from the independent replay. -/
theorem pstarMod107 : (8803369 : ZMod 107) = 51 := by decide
theorem astarMod107 : (2200869 : ZMod 107) = 93 := by decide
theorem s3InverseMod107 : (21 : ZMod 107)⁻¹ = 51 := by
  apply ZMod.inv_eq_of_mul_eq_one
  decide
theorem s5Mod107 : (47176870 : ZMod 107) = 35 := by decide
theorem space5Mod107 : (12289 : ZMod 107) = 91 := by decide
theorem minusS3S5Mod107 : -(21 * 47176870 : ZMod 107) = 14 := by decide

#print axioms fourierPhaseNorm
#print axioms supportLorentzIdentity
#print axioms wickPolynomialIdentity
#print axioms descartesOrthogonalBasis
#print axioms fableDescartesPullback
#print axioms coefficientSarnakCoordinateIdentity
#print axioms divisorShellFactorization
#print axioms divisorShellReconstruction
#print axioms quarterBranchCentering
#print axioms divisorComplementInvolution
#print axioms certificate12289
#print axioms pstarMod107

end ErdosStraussChecks

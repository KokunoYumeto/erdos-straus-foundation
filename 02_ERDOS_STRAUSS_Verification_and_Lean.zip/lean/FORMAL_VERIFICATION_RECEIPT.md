# Lean verification receipt

Status: **PASS**

Date: 2026-08-05

## Toolchain

- Lean: `4.32.0`, commit `8c9756b28d64dab099da31a4c09229a9e6a2ef35`
- Mathlib: tag `v4.32.0`, commit `81a5d257c8e410db227a6665ed08f64fea08e997`
- Lake: `5.0.0-src+8c9756b`
- Build command: `lake build`
- Result: success, `8658` jobs; project target built in the final run

## Formalized scope

The formal project contains 39 theorem or lemma declarations. The 17 declarations in
`formal/ErdosStraussChecks.lean` cover:

- the cubic Fourier phase norm and support Lorentz identity;
- algebraic Wick substitution;
- the orthogonal Descartes basis and Fable pullback;
- the coefficient–Sarnak coordinate identity;
- divisor-shell factorization and reconstruction algebra;
- the centered quarter-branch identity;
- divisor-complement involutivity;
- the exact unit-fraction certificate for `12289`;
- six core congruences in `ZMod 107`, including the inverse witness for `21`.

`formal/ErdosStraussChecks/ArctangentGaussianCertificate.lean` adds five exact,
kernel-checked Gaussian-integer certificates:

- the double-angle form of all thirteen denominators;
- the negative-real product for the original half-exponent identity;
- the canonical product with factor `(1 + i)`;
- the in-order compression to `72939081800 * (1 + i)`;
- the reordered compression to `10317661250 * (1 + i)`.

`formal/ErdosStraussChecks/PositiveConeSplitZeroLift.lean` adds seventeen
theorem or lemma declarations. They formalize the split-zero normal form,
support-bit addition and multiplication, the positive-indicator laws, the
unique nonnegative semiring section, and the displayed affine/count/height
identities on the central fibre. The convex-hull classification of that fibre
is outside the formalized scope.

The full Erdős–Straus conjecture, the complete Star–Kneser theorem, and an arithmetic `C3` action lie beyond the present Lean development.

The public verification ZIP was also extracted to a clean temporary directory.
Its local import graph closed inside the archive, and `lake build` succeeded
there with the pinned toolchain. This extracted-copy replay prevents a passing
local build from concealing a missing public source module.

## Proof-integrity scan

Command:

```text
rg -n "\bsorry\b|\badmit\b|^\s*axiom\b" --glob "*.lean" .
```

Result: `LEAN_PROHIBITED_DECLARATIONS=0`.

The explicit `#print axioms` report for the original algebraic declarations contains only Mathlib/Lean's ordinary foundational dependencies (`propext`, `Classical.choice`, and/or `Quot.sound`, depending on the theorem). Each of the five Gaussian-integer certificate theorems reports no axioms. The final report contains neither `sorryAx` nor the `native_decide` bridge. No project axiom was declared.

## Source identities

| File | SHA-256 |
|---|---|
| `formal/ErdosStraussChecks.lean` | `990182C38176F918EA2B2B85D254D7CD80378F8D3A232C175D5CBFB2C517E97D` |
| `formal/ErdosStraussChecks/ArctangentGaussianCertificate.lean` | `E23D488557FFE58FD58F40AA9B774BF7F1433D40B58EEDFC570D75B61072E0C8` |
| `formal/ErdosStraussChecks/PositiveConeSplitZeroLift.lean` | `15301415AADB9DE42323532231942C065A9D44F63B101E87B26C54A360F52A96` |
| `formal/lean-toolchain` | `2773C517AA90B66EA8A2C52BDDDDF84393157797F8341BE0DF45294FFF7FD32E` |
| `formal/lakefile.toml` | `20A31880F3D27FF15ED037ABCF8EE1E30FD380DF1CFB795BC475DF68DA0AF31D` |
| `formal/lake-manifest.json` | `DAE9F0BBDF36F8840F1B064B900108D6D855099E8F9324B29A2E42702A9BC393` |
| `verification/check_core_identities.py` | `7696585D5A192BE9328317756639C743BE19B73FD5BB779807AEDB38C977A21E` |
| `verification/core_identity_results.json` | `FE79B9A5C3A08D9086E4861D1E04AC68B61231070AFF6B179BAEB1E21E5E4020` |

Generated dependency/cache files under `formal/.lake/` are excluded from the public source projection; `lake-manifest.json` pins their identities.

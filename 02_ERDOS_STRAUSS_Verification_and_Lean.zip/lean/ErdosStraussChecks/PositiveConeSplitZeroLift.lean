import Mathlib

/-!
# The positive-cone split-zero lift

This file formalizes the algebraic core of the reader's theorem
`Fable-positive-cone-split-zero-height`.

For a semiring `R`, Mathlib's `WithZero R` is exactly the split-zero carrier
`G(R) = R \sqcup {τ}` used in the reader: its adjoined zero is `τ`, while the
coercion of `0 : R` is the distinct supported zero.  The explicit map
`splitZeroNormalForm` records the reader's two coordinates `(r, b)`.

The geometric portion below is deliberately bounded.  It checks the affine
identities along the already identified central count fibre; it does not
formalize the convex-hull classification of that fibre.

Author: The Clankers
Date: 2026-08-05
-/

namespace ErdosStraussChecks.PositiveConeSplitZeroLift

open scoped NNReal

noncomputable section

/-! ## Exact split-zero normal form -/

/-- The ring coordinate `p_R`, sending both the adjoined zero and supported
ring zero to the ring zero. -/
def ringPart {R : Type*} [Semiring R] : WithZero R → R :=
  WithZero.recZeroCoe 0 id

@[simp] theorem ringPart_zero {R : Type*} [Semiring R] :
    ringPart (0 : WithZero R) = 0 := rfl

@[simp] theorem ringPart_coe {R : Type*} [Semiring R] (r : R) :
    ringPart (r : WithZero R) = r := rfl

/-- The projection `p_R : G(R) → R` as a semiring homomorphism. -/
def ringPartHom (R : Type*) [Semiring R] : WithZero R →+* R where
  toFun := ringPart
  map_zero' := rfl
  map_one' := rfl
  map_add' x y := by
    induction x using WithZero.recZeroCoe <;>
      induction y using WithZero.recZeroCoe <;>
      simp [ringPart, ← WithZero.coe_add]
  map_mul' x y := by
    induction x using WithZero.recZeroCoe <;>
      induction y using WithZero.recZeroCoe <;>
      simp [ringPart, ← WithZero.coe_mul]

/-- The Boolean support coordinate, represented by `Bool`. -/
def supportBit {R : Type*} [Zero R] : WithZero R → Bool :=
  WithZero.recZeroCoe false (fun _ => true)

@[simp] theorem supportBit_zero {R : Type*} [Zero R] :
    supportBit (0 : WithZero R) = false := rfl

@[simp] theorem supportBit_coe {R : Type*} [Zero R] (r : R) :
    supportBit (r : WithZero R) = true := rfl

/-- The reader's exact normal-form carrier
`D_R = {(r,b) : b = 0 → r = 0}`. -/
def NormalFormCarrier (R : Type*) [Zero R] :=
  {p : R × Bool // p.2 = false → p.1 = 0}

/-- The two-coordinate normal form `τ ↦ (0,false)`, `r ↦ (r,true)`. -/
def splitZeroNormalForm {R : Type*} [Semiring R] (z : WithZero R) : R × Bool :=
  (ringPart z, supportBit z)

theorem splitZeroNormalForm_condition {R : Type*} [Semiring R]
    (z : WithZero R) :
    (splitZeroNormalForm z).2 = false → (splitZeroNormalForm z).1 = 0 := by
  induction z using WithZero.recZeroCoe <;> simp [splitZeroNormalForm]

/-- The normal-form map with its exact codomain. -/
def toNormalFormCarrier {R : Type*} [Semiring R] (z : WithZero R) :
    NormalFormCarrier R :=
  ⟨splitZeroNormalForm z, splitZeroNormalForm_condition z⟩

/-- Reconstruct a split-zero element from a valid normal-form pair. -/
def fromNormalFormCarrier {R : Type*} [Semiring R] (p : NormalFormCarrier R) :
    WithZero R :=
  if p.1.2 then (p.1.1 : WithZero R) else 0

/-- Canonical equivalence between `G(R)` and the exact two-coordinate carrier
`D_R`. -/
def splitZeroNormalFormEquiv {R : Type*} [Semiring R] :
    WithZero R ≃ NormalFormCarrier R where
  toFun := toNormalFormCarrier
  invFun := fromNormalFormCarrier
  left_inv z := by
    induction z using WithZero.recZeroCoe <;>
      simp [toNormalFormCarrier, fromNormalFormCarrier, splitZeroNormalForm]
  right_inv p := by
    rcases p with ⟨⟨r, b⟩, h⟩
    cases b
    · have hr : r = 0 := h rfl
      subst r
      rfl
    · rfl

theorem supportBit_add {R : Type*} [Semiring R] (x y : WithZero R) :
    supportBit (x + y) = (supportBit x || supportBit y) := by
  induction x using WithZero.recZeroCoe <;>
    induction y using WithZero.recZeroCoe <;>
    rfl

theorem supportBit_mul {R : Type*} [Semiring R] (x y : WithZero R) :
    supportBit (x * y) = (supportBit x && supportBit y) := by
  induction x using WithZero.recZeroCoe <;>
    induction y using WithZero.recZeroCoe <;>
    rfl

theorem splitZeroNormalForm_add {R : Type*} [Semiring R]
    (x y : WithZero R) :
    splitZeroNormalForm (x + y) =
      (ringPart x + ringPart y, supportBit x || supportBit y) := by
  apply Prod.ext
  · exact (ringPartHom R).map_add x y
  · exact supportBit_add x y

theorem splitZeroNormalForm_mul {R : Type*} [Semiring R]
    (x y : WithZero R) :
    splitZeroNormalForm (x * y) =
      (ringPart x * ringPart y, supportBit x && supportBit y) := by
  apply Prod.ext
  · exact (ringPartHom R).map_mul x y
  · exact supportBit_mul x y

/-! ## The positive-cone indicator and its unique split-zero section -/

/-- Boolean indicator of strict positivity on `ℝ≥0`. -/
def positiveIndicator (t : ℝ≥0) : Bool :=
  if t = 0 then false else true

@[simp] theorem positiveIndicator_zero : positiveIndicator 0 = false := by
  simp [positiveIndicator]

theorem positiveIndicator_of_pos {t : ℝ≥0} (ht : 0 < t) :
    positiveIndicator t = true := by
  simp [positiveIndicator, ne_of_gt ht]

/-- On the nonnegative cone, the support of a sum is Boolean union. -/
theorem positiveIndicator_add (x y : ℝ≥0) :
    positiveIndicator (x + y) =
      (positiveIndicator x || positiveIndicator y) := by
  by_cases hx : x = 0 <;> by_cases hy : y = 0 <;>
    simp [positiveIndicator, hx, hy]

/-- On the nonnegative cone, the support of a product is Boolean
intersection. -/
theorem positiveIndicator_mul (x y : ℝ≥0) :
    positiveIndicator (x * y) =
      (positiveIndicator x && positiveIndicator y) := by
  by_cases hx : x = 0 <;> by_cases hy : y = 0 <;>
    simp [positiveIndicator, hx, hy]

/-- The formula `t ↦ τ` at zero and `t ↦ (t : ℝ)` at positive `t`. -/
def positiveLiftFn (t : ℝ≥0) : WithZero ℝ :=
  if t = 0 then 0 else ((t : ℝ) : WithZero ℝ)

@[simp] theorem positiveLiftFn_zero : positiveLiftFn 0 = 0 := by
  simp [positiveLiftFn]

theorem positiveLiftFn_of_ne {t : ℝ≥0} (ht : t ≠ 0) :
    positiveLiftFn t = ((t : ℝ) : WithZero ℝ) := by
  simp [positiveLiftFn, ht]

/-- The positive-cone lift as an actual semiring homomorphism. -/
def positiveLift : ℝ≥0 →+* WithZero ℝ where
  toFun := positiveLiftFn
  map_zero' := positiveLiftFn_zero
  map_one' := by simp [positiveLiftFn]
  map_add' x y := by
    by_cases hx : x = 0 <;> by_cases hy : y = 0 <;>
      simp [positiveLiftFn, hx, hy]
  map_mul' x y := by
    by_cases hx : x = 0 <;> by_cases hy : y = 0 <;>
      simp [positiveLiftFn, hx, hy]

@[simp] theorem positiveLift_apply (t : ℝ≥0) :
    positiveLift t = positiveLiftFn t := rfl

/-- The lift is a section of the ring-coordinate projection. -/
@[simp] theorem ringPart_positiveLift (t : ℝ≥0) :
    ringPartHom ℝ (positiveLift t) = (t : ℝ) := by
  by_cases ht : t = 0 <;> simp [positiveLift, positiveLiftFn, ht, ringPartHom]

/-- Exact two-coordinate formula for the positive lift. -/
theorem splitZeroNormalForm_positiveLift (t : ℝ≥0) :
    splitZeroNormalForm (positiveLift t) =
      ((t : ℝ), positiveIndicator t) := by
  by_cases ht : t = 0 <;>
    simp [positiveLift, positiveLiftFn, positiveIndicator, ht,
      splitZeroNormalForm]

theorem eq_coe_of_ringPart_eq {z : WithZero ℝ} {r : ℝ} (hr : r ≠ 0)
    (h : ringPart z = r) : z = (r : WithZero ℝ) := by
  induction z using WithZero.recZeroCoe with
  | zero =>
      simp at h
      exact (hr h.symm).elim
  | coe z =>
      simp at h
      simp [h]

/-- Any semiring-homomorphic section of `p_ℝ` on `ℝ≥0` is the displayed
positive lift. -/
theorem positiveLift_unique (s : ℝ≥0 →+* WithZero ℝ)
    (hs : ∀ t, ringPartHom ℝ (s t) = (t : ℝ)) :
    s = positiveLift := by
  ext t
  by_cases ht : t = 0
  · subst t
    simp
  · have hcoe : (t : ℝ) ≠ 0 := by exact_mod_cast ht
    calc
      s t = ((t : ℝ) : WithZero ℝ) :=
        eq_coe_of_ringPart_eq hcoe (hs t)
      _ = positiveLift t := by
        symm
        exact positiveLiftFn_of_ne ht

/-! ## Central-fibre affine identities -/

/-- Spatial coordinates `(X,Y,W)` used for the transported tetrahedron. -/
@[ext] structure Point3 where
  x : ℝ
  y : ℝ
  w : ℝ
  deriving DecidableEq

/-- Count coordinates `(m₀,m₁,m₂)`. -/
@[ext] structure Count3 where
  m0 : ℝ
  m1 : ℝ
  m2 : ℝ
  deriving DecidableEq

def faceCentroid : Point3 := ⟨0, 3 / 2, 0⟩
def apex : Point3 := ⟨0, 5 / 4, 0⟩
def countCenter : Count3 := ⟨4, 4, 4⟩

/-- The affine segment from the marked-face centroid to the apex. -/
def centralPoint (t : ℝ) : Point3 :=
  ⟨0, 3 / 2 - t / 4, 0⟩

def affineCombine (t : ℝ) (p q : Point3) : Point3 :=
  ⟨t * p.x + (1 - t) * q.x,
   t * p.y + (1 - t) * q.y,
   t * p.w + (1 - t) * q.w⟩

/-- The displayed central-fibre parametrization is precisely the affine
segment from the face centroid to the apex. -/
theorem centralPoint_affine (t : ℝ) :
    centralPoint t = affineCombine t apex faceCentroid := by
  ext
  all_goals dsimp [centralPoint, affineCombine, apex, faceCentroid]
  all_goals ring

@[simp] theorem centralPoint_zero : centralPoint 0 = faceCentroid := by
  ext <;> norm_num [centralPoint, faceCentroid]

@[simp] theorem centralPoint_one : centralPoint 1 = apex := by
  ext <;> norm_num [centralPoint, apex]

/-- Canonical signed height `h_△(X,Y,W)=3/2-Y`. -/
def canonicalHeight (q : Point3) : ℝ := 3 / 2 - q.y

theorem canonicalHeight_centralPoint (t : ℝ) :
    canonicalHeight (centralPoint t) = t / 4 := by
  simp [canonicalHeight, centralPoint]

/-- The manuscript's affine count descent. -/
def countDescent (q : Point3) : Count3 :=
  ⟨4 - q.x / 2 - Real.sqrt 3 * q.w / 2,
   4 + q.x,
   4 - q.x / 2 + Real.sqrt 3 * q.w / 2⟩

/-- Every displayed central-fibre point has count coordinate `(4,4,4)`. -/
theorem countDescent_centralPoint (t : ℝ) :
    countDescent (centralPoint t) = countCenter := by
  ext <;> norm_num [countDescent, centralPoint, countCenter]

/-- The completed affine map has the exact displayed value on the central
fibre. -/
theorem completedCount_centralPoint (t : ℝ) :
    (countDescent (centralPoint t), canonicalHeight (centralPoint t)) =
      (countCenter, t / 4) := by
  rw [countDescent_centralPoint, canonicalHeight_centralPoint]

/-- The split-zero height along the nonnegative parameter interval. -/
def centralSplitZeroHeight (t : ℝ≥0) : WithZero ℝ :=
  positiveLift (t / 4)

@[simp] theorem centralSplitZeroHeight_zero :
    centralSplitZeroHeight 0 = 0 := by
  simp [centralSplitZeroHeight]

theorem centralSplitZeroHeight_of_pos {t : ℝ≥0} (ht : 0 < t) :
    centralSplitZeroHeight t = (((t : ℝ) / 4 : ℝ) : WithZero ℝ) := by
  have ht4 : t / 4 ≠ 0 := by positivity
  rw [centralSplitZeroHeight, positiveLift_apply, positiveLiftFn_of_ne ht4]
  norm_num

@[simp] theorem ringPart_centralSplitZeroHeight (t : ℝ≥0) :
    ringPartHom ℝ (centralSplitZeroHeight t) = (t : ℝ) / 4 := by
  rw [centralSplitZeroHeight, ringPart_positiveLift]
  norm_num

#print axioms positiveIndicator_add
#print axioms positiveIndicator_mul
#print axioms splitZeroNormalFormEquiv
#print axioms positiveLift
#print axioms ringPart_positiveLift
#print axioms splitZeroNormalForm_positiveLift
#print axioms positiveLift_unique
#print axioms centralPoint_affine
#print axioms canonicalHeight_centralPoint
#print axioms countDescent_centralPoint
#print axioms completedCount_centralPoint
#print axioms centralSplitZeroHeight_of_pos

end

end ErdosStraussChecks.PositiveConeSplitZeroLift

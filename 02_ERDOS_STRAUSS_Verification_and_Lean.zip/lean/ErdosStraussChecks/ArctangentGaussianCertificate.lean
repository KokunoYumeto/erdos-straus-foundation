import Std.Tactic

/-!
Exact Gaussian-integer portion of the thirteen-term arctangent certificate.

Author: The Clankers
Date: 2026-08-04

The analytic branch argument is recorded in ARCTANGENT_IDENTITY_CERTIFICATE.md.
This file checks the large integer products and all double-angle denominators
inside Lean's trusted arithmetic kernel via `decide`.
-/

namespace ErdosStraussChecks.ArctangentGaussianCertificate

abbrev Gaussian := Int × Int

def gaussianMul (z w : Gaussian) : Gaussian :=
  (z.1 * w.1 - z.2 * w.2, z.1 * w.2 + z.2 * w.1)

def gaussianPow (z : Gaussian) : Nat → Gaussian
  | 0 => (1, 0)
  | n + 1 => gaussianMul (gaussianPow z n) z

structure AngleTerm where
  coefficient : Nat
  numerator : Int
  denominator : Int
  deriving DecidableEq, Repr

def originalTerms : List AngleTerm := [
  ⟨4, 239, 28560⟩,
  ⟨8, 123, 7564⟩,
  ⟨8, 119, 7080⟩,
  ⟨8, 99, 4900⟩,
  ⟨8, 83, 3444⟩,
  ⟨8, 75, 2812⟩,
  ⟨8, 55, 1512⟩,
  ⟨8, 43, 924⟩,
  ⟨8, 31, 480⟩,
  ⟨8, 27, 364⟩,
  ⟨16, 47, 1104⟩,
  ⟨8, 23, 264⟩,
  ⟨8, 7, 24⟩
]

def originalProduct : Gaussian :=
  originalTerms.foldl
    (fun accumulator term =>
      gaussianMul accumulator
        (gaussianPow (term.denominator, term.numerator)
          (term.coefficient / 2)))
    (1, 0)

def canonicalProduct : Gaussian :=
  originalTerms.foldl
    (fun accumulator term =>
      gaussianMul accumulator
        (gaussianPow (term.numerator, 1) (term.coefficient / 4)))
    (1, 0)

def denominatorsHaveDoubleAngleForm : Bool :=
  originalTerms.all (fun term =>
    2 * term.denominator == term.numerator * term.numerator - 1)

theorem denominatorsHaveDoubleAngleForm_exact :
    denominatorsHaveDoubleAngleForm = true := by
  decide

theorem originalProduct_exact : originalProduct =
    (-533398426366211379076240852028242799456225248149741355242513751365656074311493877248645719337700873411581397818680257884379853664572149408932091319002211093902587890625,
      0) := by
  decide

theorem canonicalProduct_exact : canonicalProduct =
    (7000883909987072035037915496781910480000000000,
     7000883909987072035037915496781910480000000000) := by
  decide

def inOrderCompression : Gaussian :=
  gaussianMul (239, 1)
    (gaussianMul (gaussianPow (3, 1) 2)
      (gaussianMul (gaussianPow (15, 1) 2)
        (gaussianPow (437, 1) 2)))

def reorderedCompression : Gaussian :=
  gaussianMul (239, 1)
    (gaussianMul (gaussianPow (7, 1) 2)
      (gaussianMul (gaussianPow (4, 1) 2)
        (gaussianPow (268, 1) 2)))

theorem inOrderCompression_exact :
    inOrderCompression = (72939081800, 72939081800) := by
  decide

theorem reorderedCompression_exact :
    reorderedCompression = (10317661250, 10317661250) := by
  decide

#print axioms denominatorsHaveDoubleAngleForm_exact
#print axioms originalProduct_exact
#print axioms canonicalProduct_exact
#print axioms inOrderCompression_exact
#print axioms reorderedCompression_exact

end ErdosStraussChecks.ArctangentGaussianCertificate

#!/usr/bin/env python3
"""Verify that the public verification ZIP contains a closed, buildable Lean project."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


REPO = Path(__file__).resolve().parents[1]
DEFAULT_ARCHIVE = (
    REPO
    / "release_work"
    / "live_successor_built"
    / "02_ERDOS_STRAUSS_Verification_and_Lean.zip"
)
DEFAULT_RECEIPT = REPO / "release_work" / "verification_bundle_lean_replay.json"
LEAN_PREFIX = "lean/"
REQUIRED_PROJECT_FILES = {
    "lean/ErdosStraussChecks.lean",
    "lean/lakefile.toml",
    "lean/lake-manifest.json",
    "lean/lean-toolchain",
}
IMPORT = re.compile(r"^\s*import\s+([A-Za-z0-9_.]+)\s*$", re.MULTILINE)
DECLARATION = re.compile(r"^\s*(?:theorem|lemma)\s+", re.MULTILINE)
PROHIBITED = re.compile(r"\bsorry\b|\badmit\b|^\s*axiom\b", re.MULTILINE)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def module_member(module: str) -> str:
    return LEAN_PREFIX + module.replace(".", "/") + ".lean"


def validate_member(name: str) -> None:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name:
        raise ValueError(f"unsafe ZIP member: {name}")


def write_receipt(path: Path, payload: dict[str, object]) -> None:
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(raw)
    os.replace(temporary, path)


def run_lean_step(command: list[str], cwd: Path, timeout: int) -> None:
    creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    process = subprocess.Popen(
        command,
        cwd=cwd,
        env={**os.environ, "PYTHONUTF8": "1"},
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    try:
        stdout, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        else:
            process.terminate()
        stdout, _ = process.communicate()
        tail = "\n".join(stdout.splitlines()[-80:])
        raise TimeoutError(f"Lean replay step timed out: {' '.join(command)}\n{tail}")
    if process.returncode != 0:
        tail = "\n".join(stdout.splitlines()[-80:])
        raise RuntimeError(
            f"Lean replay step failed with {process.returncode}: {' '.join(command)}\n{tail}"
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, default=DEFAULT_ARCHIVE)
    parser.add_argument("--receipt", type=Path, default=DEFAULT_RECEIPT)
    parser.add_argument("--no-build", action="store_true")
    parser.add_argument("--verify-embedded-receipt", action="store_true")
    args = parser.parse_args()

    archive_path = args.archive.resolve()
    if not archive_path.is_file():
        raise FileNotFoundError(archive_path)

    with zipfile.ZipFile(archive_path) as archive:
        names = [name for name in archive.namelist() if not name.endswith("/")]
        for name in names:
            validate_member(name)
        if archive.testzip() is not None:
            raise ValueError("verification ZIP has a CRC failure")
        name_set = set(names)
        missing_project_files = sorted(REQUIRED_PROJECT_FILES - name_set)
        if missing_project_files:
            raise ValueError(f"missing Lean project files: {missing_project_files}")

        lean_members = sorted(
            name for name in names if name.startswith(LEAN_PREFIX) and name.endswith(".lean")
        )
        if not lean_members:
            raise ValueError("verification ZIP contains no Lean sources")

        source_hashes: dict[str, str] = {}
        missing_imports: list[dict[str, str]] = []
        prohibited_hits: list[str] = []
        declaration_count = 0
        for name in lean_members:
            data = archive.read(name)
            source_hashes[name] = sha256(data)
            text = data.decode("utf-8")
            declaration_count += len(DECLARATION.findall(text))
            if PROHIBITED.search(text):
                prohibited_hits.append(name)
            for module in IMPORT.findall(text):
                if module in {"Mathlib", "Std", "Init", "Lean"} or module.startswith(
                    ("Mathlib.", "Std.", "Init.", "Lean.")
                ):
                    continue
                expected = module_member(module)
                if expected not in name_set:
                    missing_imports.append(
                        {"source": name, "module": module, "expected_member": expected}
                    )

        if missing_imports:
            raise ValueError(f"unresolved local Lean imports: {missing_imports}")
        if prohibited_hits:
            raise ValueError(f"prohibited Lean declarations: {prohibited_hits}")

        build_status = "SKIPPED"
        if not args.no_build and not args.verify_embedded_receipt:
            elan = shutil.which("elan.exe") or shutil.which("elan")
            if elan is None:
                raise RuntimeError("elan is required for the extracted-copy Lean replay")
            with tempfile.TemporaryDirectory(prefix="es_lean_replay_") as temporary:
                root = Path(temporary)
                for name in names:
                    if not name.startswith(LEAN_PREFIX):
                        continue
                    target = root / PurePosixPath(name)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(archive.read(name))
                project = root / "lean"
                prefix = [elan, "run", "leanprover/lean4:v4.32.0", "lake"]
                run_lean_step(prefix + ["update"], project, timeout=900)
                run_lean_step(prefix + ["exe", "cache", "get"], project, timeout=600)
                run_lean_step(prefix + ["build"], project, timeout=300)
                build_status = "PASS"

        if args.verify_embedded_receipt:
            receipt_member = "lean/verification_bundle_lean_replay.json"
            if receipt_member not in name_set:
                raise ValueError("verification ZIP lacks its Lean replay receipt")
            embedded = json.loads(archive.read(receipt_member).decode("utf-8"))
            expected = {
                "build_from_extracted_archive": "PASS",
                "lean_source_count": len(lean_members),
                "theorem_or_lemma_declaration_count": declaration_count,
                "local_import_closure": "PASS",
                "prohibited_declaration_scan": "PASS",
                "source_sha256": source_hashes,
            }
            mismatches = {
                key: {"expected": value, "observed": embedded.get(key)}
                for key, value in expected.items()
                if embedded.get(key) != value
            }
            if mismatches:
                raise ValueError(f"embedded Lean replay receipt mismatch: {mismatches}")
            print(
                json.dumps(
                    {
                        "status": "PASS_EMBEDDED_RECEIPT_MATCHES_FINAL_ARCHIVE",
                        "lean_source_count": len(lean_members),
                        "theorem_or_lemma_declaration_count": declaration_count,
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0

    payload: dict[str, object] = {
        "status": "PASS",
        "build_from_extracted_archive": build_status,
        "dependency_hydration": "PASS_LAKE_UPDATE_AND_CACHE_GET" if build_status == "PASS" else "SKIPPED",
        "toolchain": "leanprover/lean4:v4.32.0",
        "lean_source_count": len(lean_members),
        "theorem_or_lemma_declaration_count": declaration_count,
        "local_import_closure": "PASS",
        "prohibited_declaration_scan": "PASS",
        "source_sha256": source_hashes,
    }
    write_receipt(args.receipt.resolve(), payload)
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

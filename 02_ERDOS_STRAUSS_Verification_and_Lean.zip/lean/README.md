# Lean verification lane

This is an isolated supplementary formalization of clean algebraic statements used by the Erdős–Strauss reader. It does not formalize, and must not be described as formalizing, the full Erdős–Strauss conjecture.

The project consists of the main algebraic and congruence development in
`ErdosStraussChecks.lean`, the exact Gaussian-integer arctangent certificates
in `ErdosStraussChecks/ArctangentGaussianCertificate.lean`, and the independent
split-zero formalization in
`ErdosStraussChecks/PositiveConeSplitZeroLift.lean`. The split-zero module
formalizes the exact two-coordinate normal form, the positive indicator laws,
the unique nonnegative semiring section, and the displayed affine identities
on the central count fibre. It does not formalize the convex-hull
classification of that fibre. The arctangent module proves the original,
canonical, in-order-compressed, and reordered products using kernel evaluation
with `decide`; its five named theorems have empty axiom reports.

Pinned inputs:

- Lean `4.32.0`
- Mathlib tag `v4.32.0`

Expected build commands from this directory:

```text
lake update
lake exe cache get
lake build
rg -n "\bsorry\b|\badmit\b|\baxiom\b" --glob "*.lean" .
```

The release receipt must record exact dependency commits, the build exit code, source hashes, theorem names, and the axiom report. Generated `.lake/` dependency files are build state and are not part of the public source archive.

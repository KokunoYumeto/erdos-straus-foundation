# Verification files

This bundle accompanies the consolidated Erdős–Straus reader. It contains independent algebraic checks, a Lean formalization, and the original finite checkers used in the project notes.

## Independent replay

Run:

```text
python independent/check_core_identities.py
```

The script checks sixteen items. They include the Fourier and Lorentz identities, the Wick substitution, the Descartes and coefficient-coordinate formulas, divisor-shell reconstruction, the exact decomposition for `12289`, the origin count `(3,6,3)`, the two-target Star–Kneser surplus profile `(1,6,2,1)`, the mod-107 congruences, and the rigidity-matrix invariants.

The recorded run used Python `3.13.9` and SymPy `1.13.1`; all sixteen checks passed.

## Fable face to the 12289 count orbit

The independent checker
`independent/check_fable_12289_count_orbit_identification.py` verifies the
marked affine map from the transported Fable face to the `12289` origin-count
plane.  It checks the inverse map, both `D3` intertwining identities, the three
marked images `(3,6,3)`, `(3,3,6)`, `(6,3,3)`, uniqueness from the marked
triangle, similarity factor `6`, the count circle, the Fourier-character
formula, and the unequal-fibre obstruction to a cyclic certificate lift:

```text
python independent/check_fable_12289_count_orbit_identification.py
```

The adjacent output file records the nine passing assertions.

## JGPTech marked-factor recovery

The directory `jgptech_fable/` records the pinned provenance and exact audit
of Jon Poplett's public marked-factor pipeline. The standalone certificate
checks symbolically that the first chart found by the blind search is

```text
G = (F3/2, F2/2, F1),
```

so it is the displayed Fable map followed by an invertible target-coordinate
change. It also verifies both the compact Fable fibre and an additional exact
three-point fibre:

```text
python jgptech_fable/verify_jgptech_fable_identity_standalone.py
```

The full replay checker requires a checkout of `JGPTech/Fun` at the revision
recorded in `JGPTECH_FABLE_PIPELINE_AUDIT.md`; pass its `Jacobian/` directory
with `--jacobian-dir`. The recorded full replay passed the blind chart search,
24 bounded collision hits, and the five-map ACEG manifest verifier.

`JGPTECH_FULL_EXTERNAL_AUDIT.md` records the larger source and execution audit.
Its companion checker verifies all three committed ACEG manifests and every
row of the 5,000-row target-translation table without copying that redundant
table into this release. Run it against a pinned checkout with:

```text
python jgptech_fable/verify_jgptech_full_external_package.py --repo PATH/TO/Fun
```

## Quartic Times map

The directory `quartic_times/` contains the exact symbolic checker for the
four-dimensional marked-factor construction. It verifies the fixed
coefficient and resultant constraints, the constant Jacobian determinant
`-2`, four distinct collision witnesses with common image `(0,0,-1,0)`, the
quartic product `UV(U-V)(U+V)`, and the tetrahedral centre-to-face altitude
ratio `1/4`:

```text
python quartic_times/verify_quartic_times_map.py
```

## Current reader checks

`current_reader/verification/` contains the complete set of exact checkers and
archived outputs cited by the current reader. They cover the three-block
modular linking algebra, the six-path raw and Lorentz transports, the
arithmetic cyclic-origin criterion, the ordered-divisor arcs, the free
Star–Kneser (D_3) cover, the multiplicity convolution, and the five-state
Busy-Beaver space, operation, tape-volume, and Pauli-gap carriers. They also
check the two-character Lorentz–Kocik transport, signed orbit trace,
origin-plane rapidity, split-zero cone strata, operator-volume identity, and
support–glue–Fricke chain. The present set also checks the inverse-circle and
umbrella inversion formulas, positive spectral-function Lorentz cone,
path-divisor spectral transfer, signed-moment defect filtration, and the
three-origin Star–Kneser and critical families. The adjacent
`current_reader/es_fable_c123_preprint.tex` is retained because the arithmetic
cyclic-origin checker audits its downstream theorem typing directly.

Run the Python files from an extracted copy of this archive. Every current
reader checker passed in the release audit.

## Public artifact locator

`artifact_locator/PUBLIC_ARTIFACT_LOCATOR.csv` maps every local file reference
in the public reader and public logbook to an exact member of the numbered
release archives. The adjacent Markdown guide explains the columns, and
`artifact_reference_audit.json` records every accepted route and any manifest
alias. The audit checker is included beside them.

## Public-corpus dependency checks

`corpus_dependencies/audit_corpus_tex_dependencies.py` scans every TeX source
in the historical and working-corpus archives for local graphics, PDF, input,
and bibliography dependencies. The recorded audit resolves all 26 static
dependencies across 115 TeX files.

`corpus_dependencies/check_civq17_corpus_recovery.py` verifies the seven
u/CivQ17 figures recovered pixel-for-pixel from the compiled cubic-phase paper,
checks their historical and working-corpus copies, and rebuilds the 27-page
source with shell escape disabled.

`corpus_dependencies/check_combined_package_dependencies.py` verifies the
hashes, page counts, privacy, and PDF safety of the eight exact inputs restored
from the combined-theorem companion bundle. It then rebuilds the 250-page
assembly and confirms through the recorder that all eight PDFs were used.

`release_pdf_safety/check_release_pdf_safety.py` is a standalone structural and
privacy gate for the principal reader, the public logbook, and every cited
figure PDF. Its receipt binds the reader and logbook to `BUILD_RECEIPT.json`
and rejects encryption, scripts, embedded files, forms, unsafe actions, private
paths, private identifiers, and unexpected author metadata.

After placing the four numbered ZIPs and the reader PDF in one directory, the
standalone forms can be run from an extracted verification archive with:

```text
python corpus_dependencies/audit_corpus_tex_dependencies.py --history ../03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip --corpus ../04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip
python corpus_dependencies/check_civq17_corpus_recovery.py --history ../03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip --corpus ../04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip
python corpus_dependencies/check_combined_package_dependencies.py --corpus ../04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip
python release_pdf_safety/check_release_pdf_safety.py --release-dir ..
```

## Lean

The directory `lean/` is pinned to Lean `4.32.0` and Mathlib tag `v4.32.0`. From that directory, run:

```text
lake update
lake exe cache get
lake build
```

The three Lean source files contain thirty-nine theorem or lemma declarations.
The final build passed. A second gate extracted the public verification ZIP
into a clean temporary directory, checked local-import closure, and rebuilt
that extracted copy with the pinned toolchain. A source scan found no `sorry`,
`admit`, or project axiom declaration. The formalization covers the central
algebraic identities, divisor-shell reconstruction, divisor complementation,
the exact `12289` certificate, six mod-107 constants, the exact Gaussian
integer products, and the positive-cone split-zero lift. The global conjecture
lies outside its scope.

## Original project checkers

- `original/star_kneser/` contains the exponent-box enumerator and its output.
- `original/mod107_full/` contains the coefficient sweep, CSV, and report.
- `original/mod107_rigidity/` contains the rigidity sweep, matrix data, and report.
- `original/lorentz_apollonian/` contains the Descartes, Lorentz, and shell verifier with its report.

Each checker was replayed on 2026-08-04. The two CSV files match their archived outputs byte-for-byte. The text reports match after line-ending normalization. The full mod-107 sweep requires UTF-8 mode on Windows:

```text
set PYTHONUTF8=1
set CUTOFF=13000
python bb107_full_sweep.py
```

`original_checker_replay.json` records the source and output hashes.

## Reading the evidence

Computational verification establishes the stated finite calculations. The accompanying paper supplies the mathematical reductions that connect those calculations to the residual-shell results. The theorem-status table in the main release records that boundary.

Project synthesis and verification assembly: **The Clankers**.

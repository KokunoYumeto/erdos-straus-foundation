#!/usr/bin/env python3
"""Require every public local-file citation to resolve inside the release artifacts."""

from __future__ import annotations

import argparse
import csv
import io
import json
import os
import re
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


REPO = Path(__file__).resolve().parents[1]
BUILT = REPO / "release_work" / "live_successor_built"
SOURCE_ARCHIVE = BUILT / "01_ERDOS_STRAUSS_Reader_Source_and_Build.zip"
ARCHIVES = (
    SOURCE_ARCHIVE,
    BUILT / "02_ERDOS_STRAUSS_Verification_and_Lean.zip",
    BUILT / "03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip",
    BUILT / "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip",
)
PUBLIC_TEX = (
    "reader/erdos_straus_project_reader.tex",
    "provenance/research_logbook.tex",
)
RECEIPT = REPO / "release_work" / "artifact_reference_audit.json"
LOCATOR_CSV = REPO / "release_work" / "PUBLIC_ARTIFACT_LOCATOR.csv"
LOCATOR_MD = REPO / "release_work" / "PUBLIC_ARTIFACT_LOCATOR.md"
COMMAND = re.compile(r"\\(?:path|texttt)\s*\{((?:\\.|[^{}])*)\}")
INCLUDEGRAPHICS = re.compile(
    r"\\includegraphics(?:\s*\[[^\]]*\])?\s*\{([^{}]+)\}",
    re.DOTALL,
)
ARTIFACT_EXTENSIONS = {
    ".bib",
    ".csv",
    ".html",
    ".json",
    ".jpeg",
    ".jpg",
    ".lean",
    ".md",
    ".pdf",
    ".png",
    ".py",
    ".rst",
    ".tex",
    ".txt",
    ".webp",
}


def clean_latex_path(value: str) -> str:
    value = (
        value.replace(r"\_", "_")
        .replace(r"\%", "%")
        .replace(r"\#", "#")
        .replace(r"\&", "&")
        .replace("\\", "/")
        .strip()
    )
    # Long \path/\texttt arguments are occasionally line-wrapped in the TeX
    # source.  Those source newlines are layout whitespace, not filename bytes.
    value = re.sub(r"/[ \t]*[\r\n]+[ \t]*", "/", value)
    value = re.sub(r"[ \t]*[\r\n]+[ \t]*", " ", value)
    value = value.replace("\t", " ")
    return re.sub(r"/+", "/", value)
FORBIDDEN_LOCAL_PREFIXES = (
    "papors/os/",
    "nielsen_2005/",
    "nielsen_2006/",
    "retained-research-transcript/",
    "stanford_susskind/",
)
PUBLIC_REPRESENTATIONS = {
    "es-fable-c123/es_fable_c123_preprint.tex": "reader/erdos_straus_project_reader.tex",
    "es-fable-c123/es_fable_c123_preprint.pdf": "00_ERDOS_STRAUSS_Project_Reader.pdf",
}


def normalize(value: str) -> str:
    value = clean_latex_path(value)
    while value.startswith("../"):
        value = value[3:]
    while value.startswith("./"):
        value = value[2:]
    value = re.sub(r"/+", "/", value)
    return value.casefold()


def is_artifact_reference(value: str) -> bool:
    path = PurePosixPath(value)
    return "/" in value and path.suffix.casefold() in ARTIFACT_EXTENSIONS


def archive_members() -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for archive in ARCHIVES:
        if not archive.is_file():
            raise FileNotFoundError(f"missing release artifact: {archive.name}")
        with zipfile.ZipFile(archive) as handle:
            bad = handle.testzip()
            if bad:
                raise ValueError(f"CRC failure in {archive.name}: {bad}")
            result[archive.name] = [name for name in handle.namelist() if not name.endswith("/")]
    return result


def corpus_manifest_aliases() -> list[tuple[str, str]]:
    archive = BUILT / "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip"
    with zipfile.ZipFile(archive) as handle:
        rows = csv.DictReader(io.StringIO(handle.read("MANIFEST.csv").decode("utf-8-sig")))
        return [
            (normalize(str(row["original_documents_path"])), str(row["public_path"]))
            for row in rows
            if row.get("public_path")
        ]


def resolve_reference(
    reference: str,
    members: dict[str, list[str]],
    manifest_aliases: list[tuple[str, str]],
) -> list[str]:
    normalized_members = {
        archive: [(name, normalize(name)) for name in names]
        for archive, names in members.items()
    }
    public = PUBLIC_REPRESENTATIONS.get(reference)
    if public:
        if public.endswith(".pdf"):
            target = BUILT / public
            return [public] if target.is_file() else []
        reference = normalize(public)

    tail = reference.split("/", 1)[1] if "/" in reference else reference
    basename = PurePosixPath(reference).name
    matches: list[str] = []
    for archive, names in normalized_members.items():
        for original, candidate in names:
            if (
                candidate == reference
                or candidate.endswith("/" + reference)
                or candidate.endswith("/" + tail)
                or PurePosixPath(candidate).name == basename
            ):
                matches.append(f"{archive}:{original}")
    for original, public_path in manifest_aliases:
        if original == reference or original.endswith("/" + reference):
            matches.append(
                "04_ERDOS_STRAUSS_Working_Corpus_and_Artifacts.zip:"
                + public_path
                + " (manifest alias)"
            )
    return sorted(set(matches))


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def atomic_bytes(path: Path, raw: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def write_public_locator(rows: list[dict[str, object]], payload: dict[str, object]) -> None:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(
        buffer,
        fieldnames=[
            "source",
            "kind",
            "reference",
            "status",
            "preferred_archive_member",
            "all_archive_members",
        ],
        lineterminator="\n",
    )
    writer.writeheader()
    for row in rows:
        matches = [str(value) for value in row.get("matches", [])]
        writer.writerow(
            {
                "source": row["source"],
                "kind": row["kind"],
                "reference": row["reference"],
                "status": row["status"],
                "preferred_archive_member": matches[0] if matches else "",
                "all_archive_members": " | ".join(matches),
            }
        )
    atomic_bytes(LOCATOR_CSV, buffer.getvalue().encode("utf-8"))

    markdown = f"""# Public artifact locator

This locator maps every local file reference appearing in the public reader
or public research logbook to the exact member path supplied by the numbered
release archives. It is generated from the published TeX and archive
manifests; it does not rely on private workstation paths.

- References audited: {payload['artifact_reference_count']}
- References resolved: {payload['resolved_count']}
- Failures: {payload['failure_count']}
- Status: **{payload['status']}**

Use `PUBLIC_ARTIFACT_LOCATOR.csv` for the complete searchable table. The
`preferred_archive_member` column gives one direct location. The final column
lists byte-identical copies or manifest aliases when the release deliberately
retains more than one route to the same evidence. `artifact_reference_audit.json`
preserves the complete machine-readable audit receipt.
"""
    atomic_bytes(LOCATOR_MD, markdown.encode("utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-embedded", action="store_true")
    args = parser.parse_args()
    members = archive_members()
    source_member_lookup = {
        normalize(name): name for name in members[SOURCE_ARCHIVE.name]
    }
    manifest_aliases = corpus_manifest_aliases()
    references: list[dict[str, object]] = []
    with zipfile.ZipFile(SOURCE_ARCHIVE) as source:
        for tex_member in PUBLIC_TEX:
            text = source.read(tex_member).decode("utf-8")
            for raw in COMMAND.findall(text):
                value = normalize(raw)
                if not is_artifact_reference(value):
                    continue
                forbidden = value.startswith(FORBIDDEN_LOCAL_PREFIXES)
                matches = resolve_reference(value, members, manifest_aliases)
                references.append(
                    {
                        "kind": "text_reference",
                        "source": tex_member,
                        "reference": value,
                        "status": "FORBIDDEN_LOCAL_REFERENCE" if forbidden else ("RESOLVED" if matches else "MISSING"),
                        "matches": matches,
                    }
                )
            for raw in INCLUDEGRAPHICS.findall(text):
                graphic = clean_latex_path(raw)
                path = PurePosixPath(graphic)
                unsafe = (
                    not graphic
                    or path.is_absolute()
                    or ".." in path.parts
                    or path.suffix.casefold() not in ARTIFACT_EXTENSIONS
                )
                expected = ""
                matches: list[str] = []
                if not unsafe:
                    expected = (PurePosixPath(tex_member).parent / path).as_posix()
                    original = source_member_lookup.get(normalize(expected))
                    if original is not None:
                        matches = [f"{SOURCE_ARCHIVE.name}:{original}"]
                references.append(
                    {
                        "kind": "includegraphics",
                        "source": tex_member,
                        "reference": normalize(graphic),
                        "expected_exact_member": expected,
                        "status": (
                            "UNSAFE_GRAPHIC_REFERENCE"
                            if unsafe
                            else ("RESOLVED" if matches else "MISSING_EXACT_GRAPHIC_MEMBER")
                        ),
                        "matches": matches,
                    }
                )

    unique: dict[tuple[str, str, str], dict[str, object]] = {}
    for row in references:
        unique[(str(row["source"]), str(row["kind"]), str(row["reference"]))] = row
    rows = [unique[key] for key in sorted(unique)]
    failures = [row for row in rows if row["status"] != "RESOLVED"]
    payload: dict[str, object] = {
        "status": "PASS" if not failures else "FAIL",
        "public_tex_members": list(PUBLIC_TEX),
        "archive_member_counts": {name: len(values) for name, values in members.items()},
        "artifact_reference_count": len(rows),
        "resolved_count": len(rows) - len(failures),
        "failure_count": len(failures),
        "failures": failures,
        "references": rows,
    }
    atomic_json(RECEIPT, payload)
    write_public_locator(rows, payload)
    embedded_status = "NOT_REQUESTED"
    if args.verify_embedded:
        verification_archive = BUILT / "02_ERDOS_STRAUSS_Verification_and_Lean.zip"
        expected = {
            "artifact_locator/PUBLIC_ARTIFACT_LOCATOR.csv": LOCATOR_CSV.read_bytes(),
            "artifact_locator/PUBLIC_ARTIFACT_LOCATOR.md": LOCATOR_MD.read_bytes(),
            "artifact_locator/artifact_reference_audit.json": RECEIPT.read_bytes(),
        }
        with zipfile.ZipFile(verification_archive) as archive:
            mismatches = [
                name
                for name, raw in expected.items()
                if name not in archive.namelist() or archive.read(name) != raw
            ]
        if mismatches:
            raise ValueError(f"embedded artifact locator is stale: {mismatches}")
        embedded_status = "PASS"
    print(
        json.dumps(
            {
                "status": payload["status"],
                "artifact_reference_count": payload["artifact_reference_count"],
                "resolved_count": payload["resolved_count"],
                "failure_count": payload["failure_count"],
                "failures": payload["failures"],
                "receipt": str(RECEIPT.relative_to(REPO)).replace("\\", "/"),
                "locator_csv": str(LOCATOR_CSV.relative_to(REPO)).replace("\\", "/"),
                "locator_markdown": str(LOCATOR_MD.relative_to(REPO)).replace("\\", "/"),
                "embedded_locator": embedded_status,
            },
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
        )
    )
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())

# Public artifact locator

This locator maps every local file reference appearing in the public reader
or public research logbook to the exact member path supplied by the numbered
release archives. It is generated from the published TeX and archive
manifests; it does not rely on private workstation paths.

- References audited: 648
- References resolved: 648
- Failures: 0
- Status: **PASS**

Use `PUBLIC_ARTIFACT_LOCATOR.csv` for the complete searchable table. The
`preferred_archive_member` column gives one direct location. The final column
lists byte-identical copies or manifest aliases when the release deliberately
retains more than one route to the same evidence. `artifact_reference_audit.json`
preserves the complete machine-readable audit receipt.

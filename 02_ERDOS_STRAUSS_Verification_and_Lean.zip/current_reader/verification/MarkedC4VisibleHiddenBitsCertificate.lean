import Mathlib

/-!
This file certifies the coupled visible/hidden bit law in a marked
C4-extension coordinate and the absence of an additive section.
-/

abbrev C2 := Fin 2
abbrev C4 := Fin 4

def lowBit (c : C4) : C2 :=
  ⟨c.val % 2, Nat.mod_lt _ (by decide)⟩

def highBit (c : C4) : C2 :=
  ⟨c.val / 2, by omega⟩

def fromBits (q h : C2) : C4 :=
  ⟨q.val + 2 * h.val, by omega⟩

def bitAdd (x y : C2 × C2) : C2 × C2 :=
  (x.1 + y.1, x.2 + y.2 + x.1 * y.1)

def c2Elements : List C2 :=
  List.finRange 2

def c4Elements : List C4 :=
  List.finRange 4

def twoFunction (a0 a1 : C4) (u : C2) : C4 :=
  if u = 0 then a0 else a1

def c2ToC4Functions : List (C2 → C4) :=
  c4Elements.flatMap fun a0 =>
    c4Elements.map fun a1 =>
      twoFunction a0 a1

def isAdditiveSection (f : C2 → C4) : Bool :=
  decide (f 0 = 0) &&
    c2Elements.all (fun u => decide (lowBit (f u) = u)) &&
    c2Elements.all fun u =>
      c2Elements.all fun v =>
        decide (f (u + v) = f u + f v)

def additiveSectionExists : Bool :=
  c2ToC4Functions.any isAdditiveSection

theorem visible_hidden_reconstruction (c : C4) :
    fromBits (lowBit c) (highBit c) = c := by
  fin_cases c <;> rfl

theorem visible_hidden_addition_law (c d : C4) :
    (lowBit (c + d), highBit (c + d)) =
      bitAdd (lowBit c, highBit c) (lowBit d, highBit d) := by
  fin_cases c <;> fin_cases d <;> native_decide

theorem coupled_bit_law_is_associative :
    ∀ x y z : C2 × C2,
      bitAdd (bitAdd x y) z = bitAdd x (bitAdd y z) := by
  native_decide

theorem odd_visible_bit_has_nonzero_double (c : C4) :
    lowBit c = 1 → c + c ≠ 0 := by
  fin_cases c <;> native_decide

theorem detection_map_has_no_additive_section :
    additiveSectionExists = false := by
  native_decide

theorem invisible_kernel_generator :
    lowBit 2 = 0 ∧ highBit 2 = 1 := by
  native_decide

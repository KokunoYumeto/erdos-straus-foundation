import Mathlib

abbrev U19Log := ZMod 18
abbrev U23Log := ZMod 22
abbrev U23 := ZMod 23

abbrev BoolMatrix := (Bool × Bool) × (Bool × Bool)

def e21Matrix : BoolMatrix := ((false, false), (true, false))

def additiveProduct3
    (A B C : Finset U19Log) : Finset U19Log :=
  A.biUnion fun a =>
    B.biUnion fun b =>
      C.image fun c => a + b + c

def nonnegativeLogPowers (g : U19Log) : Finset U19Log :=
  Finset.image (fun e : Nat => (e : U19Log) * g) (Finset.range 3)

def signedLogPowers (g : U19Log) : Finset U19Log :=
  {-g, 0, g}

def exteriorLogs19 (k : U19Log) : Finset U19Log :=
  additiveProduct3
    (nonnegativeLogPowers 16)
    (nonnegativeLogPowers 5)
    (nonnegativeLogPowers k)

def middleLogs19 (k : U19Log) : Finset U19Log :=
  additiveProduct3
    (signedLogPowers 16)
    (signedLogPowers 5)
    (signedLogPowers k)

def incidence19 (k : U19Log) : BoolMatrix :=
  ((decide (7 ∈ exteriorLogs19 k), decide (9 ∈ exteriorLogs19 k)),
   (decide (7 ∈ middleLogs19 k), decide (9 ∈ middleLogs19 k)))

example : incidence19 0 = e21Matrix := by native_decide

example : incidence19 5 = e21Matrix := by native_decide

def additiveProduct2
    (A B : Finset U23Log) : Finset U23Log :=
  A.biUnion fun a => B.image fun b => a + b

def nonnegativeLogPowers23 (g : U23Log) : Finset U23Log :=
  Finset.image (fun e : Nat => (e : U23Log) * g) (Finset.range 3)

def signedLogPowers23 (g : U23Log) : Finset U23Log :=
  {-g, 0, g}

def fixedExteriorTargets23 : Finset U23Log := {7, 13, 19}

def fixedMiddleTargets23 : Finset U23Log := {5, 11, 17}

def fixedPairOccupied23 (k l : U23Log) : Bool :=
  decide (
    ((additiveProduct2
      (nonnegativeLogPowers23 k)
      (nonnegativeLogPowers23 l)) ∩ fixedExteriorTargets23).Nonempty ∨
    ((additiveProduct2
      (signedLogPowers23 k)
      (signedLogPowers23 l)) ∩ fixedMiddleTargets23).Nonempty)

example : fixedPairOccupied23 2 15 = true := by native_decide

example : fixedPairOccupied23 2 18 = false := by native_decide

def additiveProduct3_23
    (A B C : Finset U23Log) : Finset U23Log :=
  A.biUnion fun a =>
    B.biUnion fun b =>
      C.image fun c => a + b + c

def additiveProduct4_23
    (A B C D : Finset U23Log) : Finset U23Log :=
  A.biUnion fun a =>
    B.biUnion fun b =>
      C.biUnion fun c =>
        D.image fun d => a + b + c + d

def fixedTripleOccupied23 (k l m : U23Log) : Bool :=
  decide (
    ((additiveProduct3_23
      (nonnegativeLogPowers23 k)
      (nonnegativeLogPowers23 l)
      (nonnegativeLogPowers23 m)) ∩ fixedExteriorTargets23).Nonempty ∨
    ((additiveProduct3_23
      (signedLogPowers23 k)
      (signedLogPowers23 l)
      (signedLogPowers23 m)) ∩ fixedMiddleTargets23).Nonempty)

def fixedQuadrupleOccupied23 (k l m n : U23Log) : Bool :=
  decide (
    ((additiveProduct4_23
      (nonnegativeLogPowers23 k)
      (nonnegativeLogPowers23 l)
      (nonnegativeLogPowers23 m)
      (nonnegativeLogPowers23 n)) ∩ fixedExteriorTargets23).Nonempty ∨
    ((additiveProduct4_23
      (signedLogPowers23 k)
      (signedLogPowers23 l)
      (signedLogPowers23 m)
      (signedLogPowers23 n)) ∩ fixedMiddleTargets23).Nonempty)

def oddLogs23 : Finset U23Log :=
  {1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21}

def nonzeroLogs23 : Finset U23Log :=
  Finset.univ.erase 0

def safeOddPartnersOfTwo : Finset U23Log :=
  oddLogs23.filter fun k => !(fixedPairOccupied23 2 k)

def safeExtensionsOfOneTwo : Finset U23Log :=
  nonzeroLogs23.filter fun k => !(fixedTripleOccupied23 1 2 k)

def safeExtensionsOfTwoTwentyOne : Finset U23Log :=
  nonzeroLogs23.filter fun k => !(fixedTripleOccupied23 2 21 k)

def safeExtensionsOfOneTwoTwentyOne : Finset U23Log :=
  nonzeroLogs23.filter fun k => !(fixedQuadrupleOccupied23 1 2 21 k)

example : safeOddPartnersOfTwo = {1, 21} := by native_decide

example : safeExtensionsOfOneTwo = {21} := by native_decide

example : safeExtensionsOfTwoTwentyOne = {1} := by native_decide

example : safeExtensionsOfOneTwoTwentyOne = ∅ := by native_decide

example : (5 : U23)^2 = 2 := by native_decide

example : (5 : U23)^21 = 14 := by native_decide

example : (5 : U23)^15 = 19 := by native_decide

example : (5 : U23)^16 = 3 := by native_decide

example : (5 : U23)^18 = 6 := by native_decide

def multiplicativeProduct3
    (A B C : Finset U23) : Finset U23 :=
  A.biUnion fun a =>
    B.biUnion fun b =>
      C.image fun c => a * b * c

def nonnegativePowers (g : U23) (n : Nat) : Finset U23 :=
  (Finset.range n).image fun e => g ^ e

def signedPowersOne (g : U23) : Finset U23 :=
  {g⁻¹, 1, g}

def signedPowersTwo (g : U23) : Finset U23 :=
  {(g ^ 2)⁻¹, g⁻¹, 1, g, g ^ 2}

def quadraticResidues23 : Finset U23 :=
  {1, 2, 3, 4, 6, 8, 9, 12, 13, 16, 18}

def nonzeroResidues23 : Finset U23 :=
  Finset.univ.erase 0

def exterior118801 : Finset U23 :=
  multiplicativeProduct3
    (nonnegativePowers 2 3)
    (nonnegativePowers 3 3)
    (nonnegativePowers 6 3)

def middle118801 : Finset U23 :=
  multiplicativeProduct3
    (signedPowersOne 2)
    (signedPowersOne 3)
    (signedPowersOne 6)

def exterior359041 : Finset U23 :=
  multiplicativeProduct3
    (nonnegativePowers 2 3)
    (nonnegativePowers 3 5)
    (nonnegativePowers 19 3)

def middle359041 : Finset U23 :=
  multiplicativeProduct3
    (signedPowersOne 2)
    (signedPowersTwo 3)
    (signedPowersOne 19)

example : exterior118801 = quadraticResidues23 := by native_decide

example : middle118801 = quadraticResidues23 := by native_decide

example : exterior359041 = nonzeroResidues23 := by native_decide

example : middle359041 = nonzeroResidues23 := by native_decide

example : (17 : U23) ∉ quadraticResidues23 := by native_decide

example : (22 : U23) ∉ quadraticResidues23 := by native_decide

example : Nat.Prime 359041 := by native_decide

example : 89766 = 2 * 3^2 * 4987 := by norm_num

example : 4 * 179532 + 1 = 31223 * 23 := by norm_num

example : 89766 + 3 = 3903 * 23 := by norm_num

example : 89766^2 / 3 = 2685978252 := by norm_num

example : 89766 + 2685978252 = 116785566 * 23 := by norm_num

example :
    (4 : ℚ) / 359041 =
      1 / 89766 +
      1 / 1006242664629726 +
      1 / 1401292143 := by
  norm_num

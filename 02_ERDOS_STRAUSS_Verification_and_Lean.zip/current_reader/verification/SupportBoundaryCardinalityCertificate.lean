import Mathlib

theorem boundaryTransferIdentity (m a b : ℤ) :
    (a - 1) * (m - (a - 1)) + (b + 1) * (m - (b + 1))
      =
    a * (m - a) + b * (m - b) + 2 * (a - b - 1) := by
  ring

theorem boundaryTransferStrict
    (m a b : ℤ)
    (hab : a ≤ b) :
    (a - 1) * (m - (a - 1)) + (b + 1) * (m - (b + 1))
      <
    a * (m - a) + b * (m - b) := by
  rw [boundaryTransferIdentity]
  have hnegative : a - b - 1 < 0 := by omega
  nlinarith

theorem partialOrbitBoundaryLower
    (m b : ℤ)
    (hleft : 1 ≤ b)
    (hright : b ≤ m - 1) :
    m - 1 ≤ b * (m - b) := by
  have hfirst : 0 ≤ b - 1 := by omega
  have hsecond : 0 ≤ m - b - 1 := by omega
  have hproduct : 0 ≤ (b - 1) * (m - b - 1) :=
    mul_nonneg hfirst hsecond
  nlinarith

theorem p13SupportBoundaryEnergy :
    (3 : ℚ) * (1 * (2 - 1) / 2) = 3 / 2 := by
  norm_num

theorem p13SupportBoundaryGap :
    (5 : ℚ) - 3 = 2 ∧ (2 : ℚ) < 3 := by
  norm_num

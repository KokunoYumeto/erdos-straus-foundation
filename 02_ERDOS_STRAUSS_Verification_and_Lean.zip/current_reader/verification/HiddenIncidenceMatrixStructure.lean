import Mathlib

abbrev BoolMatrix := (Bool × Bool) × (Bool × Bool)

def zeroMatrix : BoolMatrix := ((false, false), (false, false))

def e12Matrix : BoolMatrix := ((false, true), (false, false))

def e21Matrix : BoolMatrix := ((false, false), (true, false))

def swapMatrix : BoolMatrix := ((false, true), (true, false))

theorem emptyIncidenceFourCases (upperRight lowerLeft : Bool) :
    ((false, upperRight), (lowerLeft, false)) = zeroMatrix ∨
    ((false, upperRight), (lowerLeft, false)) = e12Matrix ∨
    ((false, upperRight), (lowerLeft, false)) = e21Matrix ∨
    ((false, upperRight), (lowerLeft, false)) = swapMatrix := by
  cases upperRight <;> cases lowerLeft <;>
    simp [zeroMatrix, e12Matrix, e21Matrix, swapMatrix]

example : 59 - 19 = 40 := by norm_num

example : 19 - 13 - 5 = 1 := by norm_num

import Mathlib

/-!
This file certifies the arithmetic core of the primewise marked C4
rank-volume reconstruction.  The variables record the one-sided and
two-sided weighted shell multiplicities.
-/

def c4OrbitCount (nullPart timelikePart : Nat) : Nat :=
  nullPart + timelikePart

def c4RankCount (nullPart timelikePart : Nat) : Nat :=
  nullPart + 2 * timelikePart

def c4MarkedEnergy (nullPart timelikePart : Nat) : Nat :=
  3 * c4RankCount nullPart timelikePart

def c4LogVolume (nullPart timelikePart : Nat) : Nat :=
  6 * c4OrbitCount nullPart timelikePart

theorem orbit_count_decomposes (nullPart timelikePart : Nat) :
    c4OrbitCount nullPart timelikePart = nullPart + timelikePart := by
  rfl

theorem marked_energy_decomposes (nullPart timelikePart : Nat) :
    c4MarkedEnergy nullPart timelikePart =
      3 * (nullPart + 2 * timelikePart) := by
  rfl

theorem recover_null_part (nullPart timelikePart : Nat) :
    2 * c4OrbitCount nullPart timelikePart -
      c4RankCount nullPart timelikePart = nullPart := by
  simp only [c4OrbitCount, c4RankCount]
  omega

theorem recover_timelike_part (nullPart timelikePart : Nat) :
    c4RankCount nullPart timelikePart -
      c4OrbitCount nullPart timelikePart = timelikePart := by
  simp only [c4OrbitCount, c4RankCount]
  omega

theorem marked_energy_bounds (nullPart timelikePart : Nat) :
    3 * c4OrbitCount nullPart timelikePart <=
        c4MarkedEnergy nullPart timelikePart ∧
      c4MarkedEnergy nullPart timelikePart <=
        6 * c4OrbitCount nullPart timelikePart := by
  simp [c4OrbitCount, c4MarkedEnergy, c4RankCount]
  omega

theorem lower_equality_iff_no_timelike_part (nullPart timelikePart : Nat) :
    c4MarkedEnergy nullPart timelikePart =
        3 * c4OrbitCount nullPart timelikePart ↔
      timelikePart = 0 := by
  simp [c4OrbitCount, c4MarkedEnergy, c4RankCount]
  omega

theorem upper_equality_iff_no_null_part (nullPart timelikePart : Nat) :
    c4MarkedEnergy nullPart timelikePart =
        6 * c4OrbitCount nullPart timelikePart ↔
      nullPart = 0 := by
  simp [c4OrbitCount, c4MarkedEnergy, c4RankCount]
  omega

theorem marked_energy_volume_sandwich (nullPart timelikePart : Nat) :
    c4MarkedEnergy nullPart timelikePart <=
        c4LogVolume nullPart timelikePart ∧
      c4LogVolume nullPart timelikePart <=
        2 * c4MarkedEnergy nullPart timelikePart := by
  simp [c4OrbitCount, c4RankCount, c4MarkedEnergy, c4LogVolume]
  omega

theorem positive_marked_energy_iff_positive_orbit_count
    (nullPart timelikePart : Nat) :
    0 < c4MarkedEnergy nullPart timelikePart ↔
      0 < c4OrbitCount nullPart timelikePart := by
  simp [c4OrbitCount, c4RankCount, c4MarkedEnergy]

theorem positive_marked_energy_has_gap_three
    (nullPart timelikePart : Nat)
    (h : 0 < c4MarkedEnergy nullPart timelikePart) :
    3 <= c4MarkedEnergy nullPart timelikePart := by
  simp [c4MarkedEnergy, c4RankCount] at h ⊢
  omega

import Mathlib

/-!
This file independently certifies the dihedral carrier action and the
carry exponents occurring in the four C4 cell-Fourier sectors.
-/

def d4MaskHas (mask index : Nat) : Bool :=
  ((mask / (2 ^ index)) % 2) == 1

def d4MaskInsert (mask index : Nat) : Nat :=
  if d4MaskHas mask index then mask else mask + 2 ^ index

def d4MaskFromList (points : List Nat) : Nat :=
  points.foldl d4MaskInsert 0

def d4C4SheetNeg (sheet : Nat) : Nat :=
  (4 - (sheet % 4)) % 4

def d4C2SquareSheetNeg (sheet : Nat) : Nat :=
  sheet % 4

def d4C16Carry (left right : Nat) : Nat :=
  (left + right) / 4

def d4C8C2Carry (left right : Nat) : Nat :=
  (left / 2) * (right / 2)

def d4ZeroCarry (_left _right : Nat) : Nat :=
  0

def d4CarrierInverse
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat)
    (point : Nat) : Nat :=
  let sheet := point / 4
  let cell := point % 4
  let oppositeSheet := sheetNeg sheet
  4 * oppositeSheet +
    ((8 - (cell + carry sheet oppositeSheet)) % 4)

def d4C16Inverse : Nat → Nat :=
  d4CarrierInverse d4C4SheetNeg d4C16Carry

def d4C8C2Inverse : Nat → Nat :=
  d4CarrierInverse d4C2SquareSheetNeg d4C8C2Carry

def d4C4C4Inverse : Nat → Nat :=
  d4CarrierInverse d4C4SheetNeg d4ZeroCarry

def d4C4C2C2Inverse : Nat → Nat :=
  d4CarrierInverse d4C2SquareSheetNeg d4ZeroCarry

def d4CellRotation (point : Nat) : Nat :=
  4 * (point / 4) + ((point % 4 + 1) % 4)

def d4CellRotationPower (point exponent : Nat) : Nat :=
  (List.range exponent).foldl (fun answer _ => d4CellRotation answer) point

def d4DihedralRelationCheck (inverse : Nat → Nat) : Bool :=
  (List.range 16).all fun point =>
    d4CellRotationPower point 4 == point &&
      d4CellRotation point != point &&
      d4CellRotationPower point 2 != point &&
      d4CellRotationPower point 3 != point &&
      inverse (inverse point) == point &&
      inverse (d4CellRotation (inverse point)) ==
        d4CellRotationPower point 3

def d4OrbitMask (inverse : Nat → Nat) (point : Nat) : Nat :=
  (List.range 4).foldl
    (fun answer exponent =>
      d4MaskInsert
        (d4MaskInsert answer (d4CellRotationPower point exponent))
        (d4CellRotationPower (inverse point) exponent))
    0

def d4FourierExponentCheck
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat) : Bool :=
  (List.range 4).all fun sheet =>
    (List.range 4).all fun cell =>
      (List.range 4).all fun frequency =>
        let oppositeSheet := sheetNeg sheet
        let carryValue := carry sheet oppositeSheet
        let targetCell := (8 - (cell + carryValue)) % 4
        let sourceExponent := (4 - ((frequency * cell) % 4)) % 4
        let targetExponent :=
          (frequency * carryValue + frequency * targetCell) % 4
        sourceExponent == targetExponent

def d4K2Sign
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat)
    (sheet : Nat) : Int :=
  if carry sheet (sheetNeg sheet) % 2 == 0 then 1 else -1

def d4K2SignTable
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat) : List Int :=
  (List.range 4).map fun sheet => d4K2Sign sheetNeg carry sheet

theorem c16_dihedral_relations :
    d4DihedralRelationCheck d4C16Inverse = true := by
  native_decide

theorem c8c2_dihedral_relations :
    d4DihedralRelationCheck d4C8C2Inverse = true := by
  native_decide

theorem c4c4_dihedral_relations :
    d4DihedralRelationCheck d4C4C4Inverse = true := by
  native_decide

theorem c4c2c2_dihedral_relations :
    d4DihedralRelationCheck d4C4C2C2Inverse = true := by
  native_decide

theorem c16_dihedral_orbit_partition :
    d4OrbitMask d4C16Inverse 0 = d4MaskFromList [0, 1, 2, 3] ∧
      d4OrbitMask d4C16Inverse 8 = d4MaskFromList [8, 9, 10, 11] ∧
      d4OrbitMask d4C16Inverse 4 =
        d4MaskFromList [4, 5, 6, 7, 12, 13, 14, 15] := by
  native_decide

theorem c8c2_dihedral_orbit_partition :
    d4OrbitMask d4C8C2Inverse 0 = d4MaskFromList [0, 1, 2, 3] ∧
      d4OrbitMask d4C8C2Inverse 4 = d4MaskFromList [4, 5, 6, 7] ∧
      d4OrbitMask d4C8C2Inverse 8 = d4MaskFromList [8, 9, 10, 11] ∧
      d4OrbitMask d4C8C2Inverse 12 =
        d4MaskFromList [12, 13, 14, 15] := by
  native_decide

theorem c4c4_dihedral_orbit_partition :
    d4OrbitMask d4C4C4Inverse 0 = d4MaskFromList [0, 1, 2, 3] ∧
      d4OrbitMask d4C4C4Inverse 8 = d4MaskFromList [8, 9, 10, 11] ∧
      d4OrbitMask d4C4C4Inverse 4 =
        d4MaskFromList [4, 5, 6, 7, 12, 13, 14, 15] := by
  native_decide

theorem c4c2c2_dihedral_orbit_partition :
    d4OrbitMask d4C4C2C2Inverse 0 = d4MaskFromList [0, 1, 2, 3] ∧
      d4OrbitMask d4C4C2C2Inverse 4 = d4MaskFromList [4, 5, 6, 7] ∧
      d4OrbitMask d4C4C2C2Inverse 8 = d4MaskFromList [8, 9, 10, 11] ∧
      d4OrbitMask d4C4C2C2Inverse 12 =
        d4MaskFromList [12, 13, 14, 15] := by
  native_decide

theorem c16_fourier_exponent_transport :
    d4FourierExponentCheck d4C4SheetNeg d4C16Carry = true := by
  native_decide

theorem c8c2_fourier_exponent_transport :
    d4FourierExponentCheck d4C2SquareSheetNeg d4C8C2Carry = true := by
  native_decide

theorem c4c4_fourier_exponent_transport :
    d4FourierExponentCheck d4C4SheetNeg d4ZeroCarry = true := by
  native_decide

theorem c4c2c2_fourier_exponent_transport :
    d4FourierExponentCheck d4C2SquareSheetNeg d4ZeroCarry = true := by
  native_decide

theorem c16_k2_inversion_signs :
    d4K2SignTable d4C4SheetNeg d4C16Carry = [1, -1, -1, -1] := by
  native_decide

theorem c8c2_k2_inversion_signs :
    d4K2SignTable d4C2SquareSheetNeg d4C8C2Carry = [1, 1, -1, -1] := by
  native_decide

theorem c4c4_k2_inversion_signs :
    d4K2SignTable d4C4SheetNeg d4ZeroCarry = [1, 1, 1, 1] := by
  native_decide

theorem c4c2c2_k2_inversion_signs :
    d4K2SignTable d4C2SquareSheetNeg d4ZeroCarry = [1, 1, 1, 1] := by
  native_decide

import Mathlib

theorem affine_shell_coordinate
    (k j : ℕ) :
    (24 * k + 4 * j) / 4 = 6 * k + j := by
  omega

theorem first_escape_prime :
    Nat.Prime 118801 := by
  norm_num [Nat.prime_def]

theorem first_escape_R59_exterior_witness :
    21225 ∣ 29715 ^ 2 ∧
    59 ∣ 4 * 21225 + 1 ∧
    29715 + 118801 * 21225 = 59 * 42738660 ∧
    118801 * 42738660 = 5077395546660 ∧
    29715 * 42738660 / 21225 = 59834124 := by
  norm_num

theorem first_escape_R59_middle_witness :
    1 ∣ 29715 ∧
    1415 ∣ 29715 ∧
    Nat.Coprime 1 1415 ∧
    59 ∣ 1 + 1415 := by
  norm_num

theorem first_escape_R59_unit_fraction_identity :
    (4 : ℚ) / 118801 =
      1 / 29715 + 1 / 5077395546660 + 1 / 59834124 := by
  norm_num

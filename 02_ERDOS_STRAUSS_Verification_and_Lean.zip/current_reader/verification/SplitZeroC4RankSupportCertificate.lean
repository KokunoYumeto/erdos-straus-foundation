import Mathlib

/-!
This file certifies the finite core of the marked C4 rank and support
criterion for the split-zero endpoint pair.
-/

abbrev SRB2 := Fin 2
abbrev SRC4 := Fin 4

def srClass (x y : SRB2) : SRC4 :=
  ⟨x.val + y.val, by omega⟩

def srLorentzRank (x y : SRB2) : Nat :=
  x.val + y.val

def srPolarCoefficient (x y : SRB2) : Int :=
  ((y.val : Int) - (x.val : Int)) ^ 2

def srTimelikeCoefficient (x y : SRB2) : Nat :=
  x.val * y.val

theorem marked_class_lift_equals_lorentz_rank (x y : SRB2) :
    (srClass x y).val = srLorentzRank x y := by
  rfl

theorem weighted_operator_coefficients_recover_rank (x y : SRB2) :
    srPolarCoefficient x y + 2 * (srTimelikeCoefficient x y : Int) =
      (srLorentzRank x y : Int) := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem nonzero_marked_class_iff_supported_endpoint (x y : SRB2) :
    srClass x y ≠ 0 ↔ x ≠ 0 ∨ y ≠ 0 := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem lorentz_rank_one_iff_one_sided (x y : SRB2) :
    srLorentzRank x y = 1 ↔
      (x = 1 ∧ y = 0) ∨ (x = 0 ∧ y = 1) := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem lorentz_rank_two_iff_two_sided (x y : SRB2) :
    srLorentzRank x y = 2 ↔ x = 1 ∧ y = 1 := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem positive_lorentz_rank_iff_nonzero_marked_class (x y : SRB2) :
    0 < srLorentzRank x y ↔ srClass x y ≠ 0 := by
  fin_cases x <;> fin_cases y <;> native_decide

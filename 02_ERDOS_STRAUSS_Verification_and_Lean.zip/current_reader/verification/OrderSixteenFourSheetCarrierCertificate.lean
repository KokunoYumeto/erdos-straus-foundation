import Mathlib

/-!
This file independently certifies the four-sheet-by-four-cell carriers for
the four non-elementary abelian groups of order sixteen.  Carrier points and
group points are both encoded by natural numbers from zero through fifteen.
-/

def maskHas (mask index : Nat) : Bool :=
  ((mask / (2 ^ index)) % 2) == 1

def maskInsert (mask index : Nat) : Nat :=
  if maskHas mask index then mask else mask + 2 ^ index

def maskCard (mask : Nat) : Nat :=
  ((List.range 16).filter fun index => maskHas mask index).length

def supportSum
    (add : Nat → Nat → Nat)
    (left right : Nat) : Nat :=
  (List.range 16).foldl
    (fun outer i =>
      if maskHas left i then
        (List.range 16).foldl
          (fun inner j =>
            if maskHas right j then
              maskInsert inner (add i j)
            else inner)
          outer
      else outer)
    0

def groupScalar
    (add : Nat → Nat → Nat)
    (coefficient point : Nat) : Nat :=
  (List.range coefficient).foldl (fun total _ => add total point) 0

def intervalMask
    (add : Nat → Nat → Nat)
    (radius direction : Nat) : Nat :=
  (List.range (2 * radius + 1)).foldl
    (fun support j =>
      let coefficient := (j + 16 - radius) % 16
      maskInsert support (groupScalar add coefficient direction))
    0

def maskFromList (points : List Nat) : Nat :=
  points.foldl maskInsert 0

def mapMask (mapPoint : Nat → Nat) (mask : Nat) : Nat :=
  (List.range 16).foldl
    (fun answer point =>
      if maskHas mask point then maskInsert answer (mapPoint point)
      else answer)
    0

def sheetProjectionCard (mask : Nat) : Nat :=
  (((List.range 16).filter fun point => maskHas mask point).map
    fun point => point / 4).eraseDups.length

def cellProjectionCard (mask : Nat) : Nat :=
  (((List.range 16).filter fun point => maskHas mask point).map
    fun point => point % 4).eraseDups.length

def carrierCorrelationDefect (mask : Nat) : Nat :=
  sheetProjectionCard mask * cellProjectionCard mask - maskCard mask

def c4SheetAdd (x y : Nat) : Nat :=
  (x + y) % 4

def c2SquareSheetAdd (x y : Nat) : Nat :=
  Nat.xor x y

def c16Carry (x y : Nat) : Nat :=
  (x + y) / 4

def c8c2Carry (x y : Nat) : Nat :=
  (x / 2) * (y / 2)

def zeroCarry (_x _y : Nat) : Nat :=
  0

def carrierAdd
    (sheetAdd carry : Nat → Nat → Nat)
    (x y : Nat) : Nat :=
  4 * sheetAdd (x / 4) (y / 4) +
    ((x % 4 + y % 4 + carry (x / 4) (y / 4)) % 4)

def c16Add (x y : Nat) : Nat :=
  (x + y) % 16

def c8c2Add (x y : Nat) : Nat :=
  2 * (((x / 2) + (y / 2)) % 8) + ((x % 2 + y % 2) % 2)

def c4c4Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) + ((x % 4 + y % 4) % 4)

def c4c2c2Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) +
    2 * ((((x / 2) % 2) + ((y / 2) % 2)) % 2) +
    ((x % 2 + y % 2) % 2)

def c16Phi (point : Nat) : Nat :=
  ((point / 4) + 4 * (point % 4)) % 16

def c8c2Phi (point : Nat) : Nat :=
  let sheet := point / 4
  let first := sheet / 2
  let second := sheet % 2
  let cell := point % 4
  2 * ((first + 2 * cell) % 8) + second

def splitPhi (point : Nat) : Nat :=
  4 * (point % 4) + point / 4

def carrierBijectionCheck (phi : Nat → Nat) : Bool :=
  ((List.range 16).map phi).eraseDups.length == 16

def carrierHomomorphismCheck
    (phi : Nat → Nat)
    (groupAdd carrierLaw : Nat → Nat → Nat) : Bool :=
  (List.range 16).all fun x =>
    (List.range 16).all fun y =>
      groupAdd (phi x) (phi y) == phi (carrierLaw x y)

def cocycleIdentityCheck
    (sheetAdd carry : Nat → Nat → Nat) : Bool :=
  (List.range 4).all fun x =>
    (List.range 4).all fun y =>
      (List.range 4).all fun z =>
        ((carry x y + carry (sheetAdd x y) z) % 4) ==
          ((carry y z + carry x (sheetAdd y z)) % 4)

def cochainValue (code sheet : Nat) : Nat :=
  if sheet == 0 then 0 else (code / (4 ^ (sheet - 1))) % 4

def cocycleCoboundaryCheck
    (sheetAdd carry : Nat → Nat → Nat) : Bool :=
  (List.range 64).any fun code =>
    (List.range 4).all fun x =>
      (List.range 4).all fun y =>
        let delta :=
          (cochainValue code x + cochainValue code y + 4 -
            cochainValue code (sheetAdd x y)) % 4
        carry x y == delta

def c16CarrierMinimum : Nat :=
  maskFromList [0, 4, 15]

def c8c2CarrierMinimum : Nat :=
  maskFromList [0, 4, 8, 11, 12, 15]

def c4c4CarrierMinimum : Nat :=
  maskFromList (
    [0, 1, 3].flatMap fun sheet =>
      [0, 1, 3].map fun cell => 4 * sheet + cell)

def c4c2c2CarrierMinimum : Nat :=
  maskFromList (
    (List.range 4).flatMap fun sheet =>
      [0, 1, 3].map fun cell => 4 * sheet + cell)

def c16MinimumBox : Nat :=
  intervalMask c16Add 1 1

def c8c2MinimumBox : Nat :=
  supportSum c8c2Add
    (intervalMask c8c2Add 1 2)
    (intervalMask c8c2Add 1 1)

def c4c4MinimumBox : Nat :=
  supportSum c4c4Add
    (intervalMask c4c4Add 1 4)
    (intervalMask c4c4Add 1 1)

def c4c2c2MinimumBox : Nat :=
  supportSum c4c2c2Add
    (supportSum c4c2c2Add
      (intervalMask c4c2c2Add 1 4)
      (intervalMask c4c2c2Add 1 2))
    (intervalMask c4c2c2Add 1 1)

theorem c16_carrier_bijection :
    carrierBijectionCheck c16Phi = true := by
  native_decide

theorem c8c2_carrier_bijection :
    carrierBijectionCheck c8c2Phi = true := by
  native_decide

theorem c4c4_carrier_bijection :
    carrierBijectionCheck splitPhi = true := by
  native_decide

theorem c4c2c2_carrier_bijection :
    carrierBijectionCheck splitPhi = true := by
  native_decide

theorem c16_carrier_group_law :
    carrierHomomorphismCheck c16Phi c16Add
      (carrierAdd c4SheetAdd c16Carry) = true := by
  native_decide

theorem c8c2_carrier_group_law :
    carrierHomomorphismCheck c8c2Phi c8c2Add
      (carrierAdd c2SquareSheetAdd c8c2Carry) = true := by
  native_decide

theorem c4c4_carrier_group_law :
    carrierHomomorphismCheck splitPhi c4c4Add
      (carrierAdd c4SheetAdd zeroCarry) = true := by
  native_decide

theorem c4c2c2_carrier_group_law :
    carrierHomomorphismCheck splitPhi c4c2c2Add
      (carrierAdd c2SquareSheetAdd zeroCarry) = true := by
  native_decide

theorem c16_cocycle_identity :
    cocycleIdentityCheck c4SheetAdd c16Carry = true := by
  native_decide

theorem c8c2_cocycle_identity :
    cocycleIdentityCheck c2SquareSheetAdd c8c2Carry = true := by
  native_decide

theorem c16_cocycle_not_coboundary :
    cocycleCoboundaryCheck c4SheetAdd c16Carry = false := by
  native_decide

theorem c8c2_cocycle_not_coboundary :
    cocycleCoboundaryCheck c2SquareSheetAdd c8c2Carry = false := by
  native_decide

theorem c4c4_zero_cocycle_is_coboundary :
    cocycleCoboundaryCheck c4SheetAdd zeroCarry = true := by
  native_decide

theorem c4c2c2_zero_cocycle_is_coboundary :
    cocycleCoboundaryCheck c2SquareSheetAdd zeroCarry = true := by
  native_decide

theorem c16_minimum_support_location :
    mapMask c16Phi c16CarrierMinimum = c16MinimumBox := by
  native_decide

theorem c8c2_minimum_support_location :
    mapMask c8c2Phi c8c2CarrierMinimum = c8c2MinimumBox := by
  native_decide

theorem c4c4_minimum_support_location :
    mapMask splitPhi c4c4CarrierMinimum = c4c4MinimumBox := by
  native_decide

theorem c4c2c2_minimum_support_location :
    mapMask splitPhi c4c2c2CarrierMinimum = c4c2c2MinimumBox := by
  native_decide

theorem c16_minimum_support_geometry :
    maskCard c16CarrierMinimum = 3 ∧
      sheetProjectionCard c16CarrierMinimum = 3 ∧
      cellProjectionCard c16CarrierMinimum = 2 ∧
      carrierCorrelationDefect c16CarrierMinimum = 3 := by
  native_decide

theorem c8c2_minimum_support_geometry :
    maskCard c8c2CarrierMinimum = 6 ∧
      sheetProjectionCard c8c2CarrierMinimum = 4 ∧
      cellProjectionCard c8c2CarrierMinimum = 2 ∧
      carrierCorrelationDefect c8c2CarrierMinimum = 2 := by
  native_decide

theorem c4c4_minimum_support_geometry :
    maskCard c4c4CarrierMinimum = 9 ∧
      sheetProjectionCard c4c4CarrierMinimum = 3 ∧
      cellProjectionCard c4c4CarrierMinimum = 3 ∧
      carrierCorrelationDefect c4c4CarrierMinimum = 0 := by
  native_decide

theorem c4c2c2_minimum_support_geometry :
    maskCard c4c2c2CarrierMinimum = 12 ∧
      sheetProjectionCard c4c2c2CarrierMinimum = 4 ∧
      cellProjectionCard c4c2c2CarrierMinimum = 3 ∧
      carrierCorrelationDefect c4c2c2CarrierMinimum = 0 := by
  native_decide

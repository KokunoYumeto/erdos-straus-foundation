import Mathlib

example : 350 % 39 = 38 := by norm_num

example : 148550 % 39 = 38 := by norm_num

example : 14855 % 39 = 35 := by norm_num

example : (1 + 14855) % 39 = 36 := by norm_num

example : 4 * 29 + 1 = 3 * 39 := by norm_num

example : 21225 % 59 = 44 := by norm_num

example : 4 * 44 + 1 = 3 * 59 := by norm_num

example : 1415 % 59 = 58 := by norm_num

example : 1 + 1415 = 24 * 59 := by norm_num

example : (13 : ZMod 19) * (5 : ZMod 19)⁻¹ = 14 := by native_decide

example : 4 * 13 + 5 = 3 * 19 := by norm_num

example : 13 + 5 + 1 = 19 := by norm_num

def fableOne19 (x y z : ZMod 19) : ZMod 19 :=
  (1 + x * y)^3 * z + y^2 * (1 + x * y) * (4 + 3 * x * y)

def fableTwo19 (x y z : ZMod 19) : ZMod 19 :=
  y + 3 * x * (1 + x * y)^2 * z + 3 * x * y^2 * (4 + 3 * x * y)

def fableThree19 (x y z : ZMod 19) : ZMod 19 :=
  2 * x - 3 * x^2 * y - x^3 * z

example :
    (fableOne19 0 0 14, fableTwo19 0 0 14, fableThree19 0 0 14)
      = (14, 0, 0) := by
  native_decide

example :
    (fableOne19 1 8 16, fableTwo19 1 8 16, fableThree19 1 8 16)
      = (14, 0, 0) := by
  native_decide

example :
    (fableOne19 18 11 16, fableTwo19 18 11 16,
      fableThree19 18 11 16) = (14, 0, 0) := by
  native_decide

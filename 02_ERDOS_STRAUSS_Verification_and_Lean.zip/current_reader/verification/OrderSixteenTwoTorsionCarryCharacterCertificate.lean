import Mathlib

/-!
This file certifies the two-torsion carry-character mechanism behind the
order-sixteen dihedral spectral defect.
-/

def carryFiberEquiv
    {V : Type*} [AddMonoid V]
    (q : V → ZMod 2)
    (hadd : ∀ x y, q (x + y) = q x + q y)
    (a : V)
    (ha : q a = 1)
    (ha2 : a + a = 0) :
    {x : V // q x = 0} ≃ {x : V // q x = 1} where
  toFun x :=
    ⟨x.1 + a, by
      rw [hadd, x.2, ha]
      norm_num⟩
  invFun x :=
    ⟨x.1 + a, by
      rw [hadd, x.2, ha]
      decide⟩
  left_inv x := by
    apply Subtype.ext
    simp [add_assoc, ha2]
  right_inv x := by
    apply Subtype.ext
    simp [add_assoc, ha2]

theorem nonzero_binary_carry_has_equal_fibers
    {V : Type*} [AddMonoid V] [Fintype V]
    (q : V → ZMod 2)
    (hadd : ∀ x y, q (x + y) = q x + q y)
    (a : V)
    (ha : q a = 1)
    (ha2 : a + a = 0) :
    Fintype.card {x : V // q x = 0} =
      Fintype.card {x : V // q x = 1} :=
  Fintype.card_congr (carryFiberEquiv q hadd a ha ha2)

def qC16 (u : ZMod 2) : ZMod 2 := u

def qC8C2 (u : ZMod 2 × ZMod 2) : ZMod 2 := u.1

def qC4C4 (_u : ZMod 2) : ZMod 2 := 0

def qC4C2C2 (_u : ZMod 2 × ZMod 2) : ZMod 2 := 0

def carryWeight
    {V : Type*} [Fintype V]
    (q : V → ZMod 2) : Nat :=
  (Finset.univ.filter fun u => q u = 1).card

theorem qC16_additive (u v : ZMod 2) :
    qC16 (u + v) = qC16 u + qC16 v := by
  rfl

theorem qC8C2_additive (u v : ZMod 2 × ZMod 2) :
    qC8C2 (u + v) = qC8C2 u + qC8C2 v := by
  rfl

theorem qC4C4_additive (u v : ZMod 2) :
    qC4C4 (u + v) = qC4C4 u + qC4C4 v := by
  norm_num [qC4C4]

theorem qC4C2C2_additive (u v : ZMod 2 × ZMod 2) :
    qC4C2C2 (u + v) = qC4C2C2 u + qC4C2C2 v := by
  norm_num [qC4C2C2]

theorem c16_carry_weight :
    carryWeight qC16 = 1 := by
  native_decide

theorem c8c2_carry_weight :
    carryWeight qC8C2 = 2 := by
  native_decide

theorem c4c4_carry_weight :
    carryWeight qC4C4 = 0 := by
  native_decide

theorem c4c2c2_carry_weight :
    carryWeight qC4C2C2 = 0 := by
  native_decide

theorem c16_nonzero_fibers_are_equal :
    Fintype.card {u : ZMod 2 // qC16 u = 0} =
      Fintype.card {u : ZMod 2 // qC16 u = 1} := by
  apply nonzero_binary_carry_has_equal_fibers qC16 qC16_additive 1
  · norm_num [qC16]
  · decide

theorem c8c2_nonzero_fibers_are_equal :
    Fintype.card {u : ZMod 2 × ZMod 2 // qC8C2 u = 0} =
      Fintype.card {u : ZMod 2 × ZMod 2 // qC8C2 u = 1} := by
  apply nonzero_binary_carry_has_equal_fibers
    qC8C2 qC8C2_additive (1, 0)
  · norm_num [qC8C2]
  · decide

import Mathlib

open Real

theorem p37_R11_unweighted_mass :
    2 * (3 + Real.sqrt 5) + 2 * (3 - Real.sqrt 5) + 3 = (15 : ℝ) := by
  ring

theorem p37_R11_filtered_mass :
    2 * (3 + Real.sqrt 5) * ((1 + Real.sqrt 5) / 4)
      + 2 * (3 - Real.sqrt 5) * ((Real.sqrt 5 - 1) / 4)
      + 3
      = 3 + 4 * Real.sqrt 5 := by
  have hsq : (Real.sqrt 5) ^ 2 = (5 : ℝ) := by
    norm_num
  nlinarith

theorem sqrt_five_lt_three : Real.sqrt 5 < 3 := by
  have hsq : (Real.sqrt 5) ^ 2 = (5 : ℝ) := by
    norm_num
  have hnonnegative : 0 ≤ Real.sqrt 5 := Real.sqrt_nonneg 5
  nlinarith

theorem p37_R11_target_averaged_strict :
    3 + 4 * Real.sqrt 5 < (15 : ℝ) := by
  nlinarith [sqrt_five_lt_three]

theorem p37_R11_target_averaged_gap :
    15 - (3 + 4 * Real.sqrt 5) = 4 * (3 - Real.sqrt 5) := by
  ring

theorem p37_R11_target_averaged_gap_positive :
    0 < 4 * (3 - Real.sqrt 5) := by
  nlinarith [sqrt_five_lt_three]

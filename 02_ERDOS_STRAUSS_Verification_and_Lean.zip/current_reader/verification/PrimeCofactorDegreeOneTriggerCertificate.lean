import Mathlib

def firstInverse (modulus residue : Nat) : Nat :=
  ((List.range modulus).find? fun candidate =>
      residue * candidate % modulus = 1).getD 0

def modularPowers
    (middle : Bool)
    (modulus residue exponent : Nat) : Finset Nat :=
  (Finset.range (2 * exponent + 1)).image fun index =>
    if middle then
      if index ≤ exponent then
        firstInverse modulus residue ^ (exponent - index) % modulus
      else
        residue ^ (index - exponent) % modulus
    else
      residue ^ index % modulus

def multiplyReach
    (modulus : Nat)
    (left right : Finset Nat) : Finset Nat :=
  (left.product right).image fun pair => pair.1 * pair.2 % modulus

def multiplicativeReach
    (middle : Bool)
    (modulus : Nat)
    (factors : List (Nat × Nat)) : Finset Nat :=
  factors.foldl
    (fun reached factor =>
      multiplyReach modulus reached
        (modularPowers middle modulus factor.1 factor.2))
    {1}

def quarterTarget (modulus : Nat) : Nat :=
  (modulus - firstInverse modulus 4) % modulus

def packetOccupied
    (modulus : Nat)
    (factors : List (Nat × Nat)) : Bool :=
  quarterTarget modulus ∈ multiplicativeReach false modulus factors ||
  modulus - 1 ∈ multiplicativeReach true modulus factors

def degreeOneTriggers
    (modulus : Nat)
    (base : List (Nat × Nat)) : Finset Nat :=
  (Finset.range modulus).filter fun residue =>
    Nat.gcd residue modulus = 1 &&
    packetOccupied modulus (base ++ [(residue, 1)])

theorem inverse_checks :
    firstInverse 27 4 = 7 ∧
    firstInverse 31 4 = 8 ∧
    firstInverse 35 4 = 9 ∧
    firstInverse 39 4 = 10 ∧
    firstInverse 43 4 = 11 ∧
    firstInverse 47 4 = 12 ∧
    firstInverse 51 4 = 13 ∧
    firstInverse 55 4 = 14 ∧
    firstInverse 59 4 = 15 := by
  native_decide

theorem forced_skeletons_are_empty :
    packetOccupied 27 [] = false ∧
    packetOccupied 31 [(2, 1)] = false ∧
    packetOccupied 35 [(3, 1)] = false ∧
    packetOccupied 39 [(2, 1), (5, 1)] = false ∧
    packetOccupied 43 [] = false ∧
    packetOccupied 47 [(2, 1), (3, 1)] = false ∧
    packetOccupied 51 [] = false ∧
    packetOccupied 55 [(2, 1)] = false ∧
    packetOccupied 59 [(3, 1), (5, 1)] = false := by
  native_decide

theorem trigger_set_R27 :
    degreeOneTriggers 27 [] = [20, 26].toFinset := by
  native_decide

theorem trigger_set_R31 :
    degreeOneTriggers 31 [(2, 1)] = [15, 23, 27, 29, 30].toFinset := by
  native_decide

theorem trigger_set_R35 :
    degreeOneTriggers 35 [(3, 1)] = [23, 26, 32, 34].toFinset := by
  native_decide

theorem trigger_set_R39 :
    degreeOneTriggers 39 [(2, 1), (5, 1)] =
      [17, 19, 23, 29, 31, 34, 35, 37, 38].toFinset := by
  native_decide

theorem trigger_set_R43 :
    degreeOneTriggers 43 [] = [32, 42].toFinset := by
  native_decide

theorem trigger_set_R47 :
    degreeOneTriggers 47 [(2, 1), (3, 1)] =
      [15, 22, 23, 30, 31, 35, 39, 41, 43, 44, 45, 46].toFinset := by
  native_decide

theorem trigger_set_R51 :
    degreeOneTriggers 51 [] = [38, 50].toFinset := by
  native_decide

theorem trigger_set_R55 :
    degreeOneTriggers 55 [(2, 1)] = [24, 27, 41, 48, 53, 54].toFinset := by
  native_decide

theorem trigger_set_R59 :
    degreeOneTriggers 59 [(3, 1), (5, 1)] =
      [18, 23, 39, 44, 47, 54, 55, 56, 58].toFinset := by
  native_decide

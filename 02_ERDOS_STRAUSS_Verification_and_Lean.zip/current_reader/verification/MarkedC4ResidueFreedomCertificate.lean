import Mathlib

namespace MarkedC4ResidueFreedomCertificate

theorem inverse_coordinates
    {R : Type*} [CommRing R]
    {q c n t : R}
    (hq : q = n + t)
    (hc : c = n + 2 * t) :
    n = 2 * q - c ∧ t = c - q := by
  constructor
  · calc
      n = 2 * (n + t) - (n + 2 * t) := by ring
      _ = 2 * q - c := by rw [← hq, ← hc]
  · calc
      t = (n + 2 * t) - (n + t) := by ring
      _ = c - q := by rw [← hc, ← hq]

theorem unique_preimage
    {R : Type*} [CommRing R]
    (q c : R) :
    ∃! pair : R × R,
      q = pair.1 + pair.2 ∧
      c = pair.1 + 2 * pair.2 := by
  refine ⟨(2 * q - c, c - q), ?_, ?_⟩
  · constructor <;> ring
  · intro pair hpair
    have recovered :=
      inverse_coordinates
        (q := q)
        (c := c)
        (n := pair.1)
        (t := pair.2)
        hpair.1
        hpair.2
    exact Prod.ext recovered.1 recovered.2

theorem residue_ring_unique_preimage
    (modulus : Nat)
    (q c : ZMod modulus) :
    ∃! pair : ZMod modulus × ZMod modulus,
      q = pair.1 + pair.2 ∧
      c = pair.1 + 2 * pair.2 :=
  unique_preimage q c

end MarkedC4ResidueFreedomCertificate

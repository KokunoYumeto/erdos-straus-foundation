import Mathlib

theorem residual_nineteen_branch_seven_identity
    (p q : ℚ)
    (hp : p ≠ 0)
    (hq : q ≠ 0)
    (hp1 : p + 1 ≠ 0)
    (hrel : p + 19 = 8 * q) :
    4 / p =
      1 / (2 * q)
      + 1 / (2 * q * (p + 1) / 19)
      + 1 / (p * (2 * q * (p + 1) / 19)) := by
  field_simp [hp, hq, hp1]
  have hmul :=
    congrArg (fun x : ℚ => (p + 1) * x) hrel
  nlinarith [hmul]

theorem residual_nineteen_branch_eleven_identity
    (p q : ℚ)
    (hp : p ≠ 0)
    (hq : q ≠ 0)
    (hpq1 : p * q + 1 ≠ 0)
    (hrel : p + 19 = 8 * q) :
    4 / p =
      1 / (2 * q)
      + 1 / (2 * (p * q + 1) / 19)
      + 1 / (p * q * (2 * (p * q + 1) / 19)) := by
  field_simp [hp, hq, hpq1]
  have hmul :=
    congrArg (fun x : ℚ => (p * q + 1) * x) hrel
  nlinarith [hmul]

example :
    (4 : ℚ) / 37 = 1 / 14 + 1 / 28 + 1 / 1036 := by
  norm_num

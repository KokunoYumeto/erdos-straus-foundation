import Mathlib

open scoped BigOperators

namespace StrictTargetAveragingCertificate

theorem strict_weighted_contraction
    {ι : Type*} [Fintype ι]
    (weight factor : ι → ℝ)
    (weight_nonnegative : ∀ index, 0 ≤ weight index)
    (factor_at_most_one : ∀ index, factor index ≤ 1)
    (witness : ι)
    (witness_weight_positive : 0 < weight witness)
    (witness_factor_strict : factor witness < 1) :
    (∑ index, weight index * factor index) <
      ∑ index, weight index := by
  have pointwise :
      ∀ index, weight index * factor index ≤ weight index := by
    intro index
    nlinarith [
      weight_nonnegative index,
      factor_at_most_one index
    ]
  have strict_at_witness :
      weight witness * factor witness < weight witness := by
    nlinarith [
      witness_weight_positive,
      witness_factor_strict
    ]
  apply Finset.sum_lt_sum
  · intro index _
    exact pointwise index
  · exact ⟨witness, Finset.mem_univ witness, strict_at_witness⟩

theorem strict_target_average_from_active_rotation
    {ι : Type*} [Fintype ι]
    (coefficient targetFactor : ι → ℝ)
    (coefficient_nonnegative : ∀ index, 0 ≤ coefficient index)
    (targetFactor_at_most_one : ∀ index, targetFactor index ≤ 1)
    (witness : ι)
    (active_witness : 0 < coefficient witness)
    (rotated_witness : targetFactor witness < 1) :
    (∑ index, coefficient index * targetFactor index) <
      ∑ index, coefficient index :=
  strict_weighted_contraction
    coefficient
    targetFactor
    coefficient_nonnegative
    targetFactor_at_most_one
    witness
    active_witness
    rotated_witness

end StrictTargetAveragingCertificate

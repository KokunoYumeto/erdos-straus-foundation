import Mathlib

open BigOperators

/-!
This file formalizes the finite algebraic core of the stabilizer-quotient
character certificate in the maintained Erdős--Strauss manuscript.

The surrounding manuscript and exact Python replay supply the finite-group
identifications: the quotient pushforward, its annihilator-character Fourier
transform, and Parseval's formula.  The statements below certify the three
algebraic implications used after those identifications.
-/

/-- The negative Star--Kneser surplus is the sum of the disjointness defect
and the Kneser defect; both summands are nonnegative. -/
theorem stabilizer_defect_decomposition
    (q c u kappa : ℤ)
    (hdisjoint : c + u ≤ q)
    (hkneser : kappa ≤ c) :
    0 ≤ q - c - u ∧
    0 ≤ c - kappa ∧
    -(kappa + u - q) = (q - c - u) + (c - kappa) := by
  constructor
  · linarith
  constructor
  · linarith
  · ring

/-- If a finite Fourier sum vanishes at a missed target, the sum of all
nonprincipal terms is the negative of the principal term. -/
theorem nonprincipal_sum_eq_neg_principal
    {ι : Type*} [Fintype ι] [DecidableEq ι]
    (a : ι → ℂ) (principal : ι)
    (htotal : ∑ i, a i = 0) :
    ∑ i ∈ Finset.univ.erase principal, a i = -a principal := by
  have hsplit :
      (∑ i ∈ Finset.univ.erase principal, a i) + a principal =
        ∑ i, a i := by
    exact Finset.sum_erase_add _ _ (Finset.mem_univ principal)
  rw [htotal] at hsplit
  exact eq_neg_of_add_eq_zero_left hsplit

/-- Exact cancellation of a nonnegative principal mass forces the
nonprincipal absolute mass to be at least as large. -/
theorem cancellation_forces_mass_bound
    (principalMass nonprincipalMass : ℝ)
    (hprincipal : 0 ≤ principalMass)
    (hnonprincipal : 0 ≤ nonprincipalMass)
    (hcancellation : principalMass ≤ nonprincipalMass) :
    principalMass ^ 2 ≤ nonprincipalMass ^ 2 := by
  nlinarith

/-- A Cauchy--Schwarz upper bound and the strict Parseval survival inequality
exclude exact cancellation of the principal mass. -/
theorem strict_parseval_excludes_principal_cancellation
    (quotientOrder principalMass nonprincipalMass parsevalEnergy : ℝ)
    (hprincipal : 0 ≤ principalMass)
    (hnonprincipal : 0 ≤ nonprincipalMass)
    (hcancellation : principalMass ≤ nonprincipalMass)
    (hcauchy :
      nonprincipalMass ^ 2 ≤
        (quotientOrder - 1) * parsevalEnergy)
    (hparseval :
      (quotientOrder - 1) * parsevalEnergy <
        principalMass ^ 2) :
    False := by
  have hsquare :
      principalMass ^ 2 ≤ nonprincipalMass ^ 2 :=
    cancellation_forces_mass_bound
      principalMass nonprincipalMass
      hprincipal hnonprincipal hcancellation
  linarith

/-- If the only surviving nonprincipal mode is binary and its absolute
amplitude is at most one third of the principal mass, both sheets retain a
strictly positive coefficient with the stated quantitative gap. -/
theorem binary_sheet_one_third_gap
    (principalMass binaryAmplitude sheetSign : ℝ)
    (hprincipal : 0 < principalMass)
    (hamplitude : |binaryAmplitude| ≤ principalMass / 3)
    (hsign : sheetSign = 1 ∨ sheetSign = -1) :
    2 * principalMass / 3 ≤
        principalMass + binaryAmplitude * sheetSign ∧
    0 < principalMass + binaryAmplitude * sheetSign := by
  have hb := abs_le.mp hamplitude
  rcases hsign with rfl | hsign
  · constructor <;> norm_num <;> nlinarith
  · rw [hsign]
    constructor <;> norm_num <;> nlinarith

/-- A power of two which is neither one nor two is at least four.  This is
the finite order gap used after the principal and binary survivor cases
have both been excluded. -/
theorem two_power_order_gap
    (q : ℕ)
    (hq : ∃ k : ℕ, q = 2 ^ k)
    (hnotOne : q ≠ 1)
    (hnotTwo : q ≠ 2) :
    4 ≤ q := by
  rcases hq with ⟨k, rfl⟩
  cases k with
  | zero =>
      simp at hnotOne
  | succ k =>
      cases k with
      | zero =>
          simp at hnotTwo
      | succ k =>
          have hpowPositive : 0 < 2 ^ k := by positivity
          have hpow : 1 ≤ 2 ^ k := hpowPositive
          calc
            4 = 4 * 1 := by ring
            _ ≤ 4 * (2 ^ k) := Nat.mul_le_mul_left 4 hpow
            _ = 2 ^ (Nat.succ (Nat.succ k)) := by
              simp [pow_succ]
              ring

/-- Three nonprincipal modes, each bounded by one third of the principal
mass, cannot exceed that mass.  Equality forces all three bounds to be
sharp. -/
theorem cyclic_four_three_mode_saturation
    (principalMass a b c : ℝ)
    (haBound : a ≤ principalMass / 3)
    (hbBound : b ≤ principalMass / 3)
    (hcBound : c ≤ principalMass / 3) :
    a + b + c ≤ principalMass ∧
    (a + b + c = principalMass →
      a = principalMass / 3 ∧
      b = principalMass / 3 ∧
      c = principalMass / 3) := by
  constructor
  · linarith
  · intro hsum
    constructor
    · linarith
    constructor <;> linarith

/-- In the Klein-four case, two independent length-at-least-three
directions bound two modes by one third and the third by one ninth, leaving
the exact positive gap two ninths of the principal mass. -/
theorem klein_four_two_primary_gap
    (principalMass a b c : ℝ)
    (hprincipal : 0 < principalMass)
    (haBound : a ≤ principalMass / 3)
    (hbBound : b ≤ principalMass / 3)
    (hcBound : c ≤ principalMass / 9) :
    2 * principalMass / 9 ≤ principalMass - (a + b + c) ∧
    0 < principalMass - (a + b + c) := by
  constructor <;> linarith

/-- A binary local kernel of odd mass 2e+1, with e at least one, assigns at
least one third of its mass to either binary class. -/
theorem binary_local_one_third_bound
    (e : ℝ)
    (he : 1 ≤ e) :
    (2 * e + 1) / 3 ≤ e := by
  nlinarith

/-- Multiplying the binary local bounds preserves the one-third factor in
each independent basis direction. -/
theorem binary_basis_product_one_third_bound
    {ι : Type*} [Fintype ι]
    (e : ι → ℝ)
    (he : ∀ i, 1 ≤ e i) :
    (∏ i, (2 * e i + 1) / 3) ≤ ∏ i, e i := by
  apply Finset.prod_le_prod
  · intro i hi
    have hei := he i
    positivity
  · intro i hi
    exact binary_local_one_third_bound (e i) (he i)

/-- Convolution with a nonnegative residual measure preserves a uniform
coefficient lower bound and multiplies it by the residual total mass. -/
theorem nonnegative_convolution_preserves_uniform_bound
    {G : Type*} [Fintype G] [AddGroup G]
    (basis rest : G → ℝ)
    (x : G)
    (lower restMass : ℝ)
    (hlower : ∀ y, lower ≤ basis y)
    (hrest : ∀ y, 0 ≤ rest y)
    (hmass : ∑ y, rest y = restMass) :
    lower * restMass ≤
      ∑ y, basis (x - y) * rest y := by
  calc
    lower * restMass = ∑ y, lower * rest y := by
      rw [← hmass, Finset.mul_sum]
    _ ≤ ∑ y, basis (x - y) * rest y := by
      exact Finset.sum_le_sum fun y hy =>
        mul_le_mul_of_nonneg_right (hlower (x - y)) (hrest y)

/-- The centroid of the three Fable face points differs from the fixed apex
by the exact spatial quarter, independently of the cancelling transverse
coordinate. -/
theorem fable_face_apex_quarter_altitude
    (sqrtThree : ℝ) :
    (((2 : ℝ) + (-1) + (-1)) / 3 - 0 = 0) ∧
    (((3 / 2 : ℝ) + 3 / 2 + 3 / 2) / 3 - 5 / 4 = 1 / 4) ∧
    ((0 + sqrtThree + (-sqrtThree)) / 3 - 0 = 0) := by
  constructor
  · norm_num
  constructor
  · norm_num
  · ring

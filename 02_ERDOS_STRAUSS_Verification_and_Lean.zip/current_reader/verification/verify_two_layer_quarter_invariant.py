from sympy import I, Matrix, Rational, cancel, eye, simplify, sqrt, symbols, rem


def assert_matrix(actual, expected, label):
    delta = actual - expected
    if any(simplify(entry) != 0 for entry in delta):
        raise AssertionError(f"{label}: {actual} != {expected}")


# A regular Time tetrahedron in a three-dimensional Euclidean carrier.
mu = [
    Matrix([1, 1, 1]) / sqrt(3),
    Matrix([1, -1, -1]) / sqrt(3),
    Matrix([-1, 1, -1]) / sqrt(3),
    Matrix([-1, -1, 1]) / sqrt(3),
]

assert_matrix(sum(mu, Matrix.zeros(3, 1)), Matrix.zeros(3, 1), "Time sum")
time_gram = Matrix([[simplify(x.dot(y)) for y in mu] for x in mu])
expected_time_gram = Matrix(4, 4, lambda i, j: 1 if i == j else Rational(-1, 3))
assert_matrix(time_gram, expected_time_gram, "Time Gram matrix")

# Project the face opposite mu[0] along the selected Time direction.
P = eye(3) - mu[0] * mu[0].T
projected = [simplify(P * mu[j]) for j in (1, 2, 3)]
nu = [simplify(Rational(3, 2) / sqrt(2) * v) for v in projected]
colour_gram = Matrix([[simplify(x.dot(y)) for y in nu] for x in nu])
expected_colour_gram = Matrix(3, 3, lambda i, j: 1 if i == j else Rational(-1, 2))
assert_matrix(colour_gram, expected_colour_gram, "Colour Gram matrix")
assert_matrix(sum(nu, Matrix.zeros(3, 1)), Matrix.zeros(3, 1), "Colour sum")

# The complete zero fibre in the tetrahedron has distinguished points
# c_hat, 0, and mu_a, with exact altitude coordinates -1/4, 0, 3/4.
c_hat = simplify(sum(mu[1:], Matrix.zeros(3, 1)) / 3)
h_alt = simplify(mu[0] - c_hat)
q = lambda v: simplify(Rational(3, 4) * v.dot(mu[0]))
assert_matrix(c_hat, -mu[0] / 3, "Opposite-face centroid")
assert q(c_hat) == Rational(-1, 4)
assert q(Matrix.zeros(3, 1)) == 0
assert q(mu[0]) == Rational(3, 4)
assert q(h_alt) == 1
assert_matrix(P * c_hat, Matrix.zeros(3, 1), "Projected face centroid")
assert_matrix(P * mu[0], Matrix.zeros(3, 1), "Projected selected vertex")

# The exact Colour row and its Time-supported affine companion.
u_values = Matrix([simplify(nu[0].dot(v)) for v in nu])
h_values = Matrix([Rational(1, 4) - Rational(1, 2) * value for value in u_values])
products = Matrix([simplify(u_values[i] * h_values[i]) for i in range(3)])
assert_matrix(u_values, Matrix([1, Rational(-1, 2), Rational(-1, 2)]), "u row")
assert_matrix(h_values, Matrix([Rational(-1, 4), Rational(1, 2), Rational(1, 2)]), "h row")
assert_matrix(products, Matrix([Rational(-1, 4)] * 3), "constant quarter product")

# The same identities in the reduced coordinate algebra of the complete
# Fable fibre, Q[x]/(x^3-x).
x = symbols("x")
modulus = x**3 - x
reduce_fibre = lambda polynomial: rem(polynomial, modulus, domain="QQ")
e = x**2
u_f = 1 - Rational(3, 2) * e
h_f = Rational(-1, 4) + Rational(3, 4) * e
assert reduce_fibre(e**2 - e) == 0
assert reduce_fibre(h_f - (Rational(1, 4) - Rational(1, 2) * u_f)) == 0
assert reduce_fibre(u_f * h_f + Rational(1, 4)) == 0
for root, expected_u, expected_h in (
    (0, 1, Rational(-1, 4)),
    (1, Rational(-1, 2), Rational(1, 2)),
    (-1, Rational(-1, 2), Rational(1, 2)),
):
    assert u_f.subs(x, root) == expected_u
    assert h_f.subs(x, root) == expected_h

# Reconstruct the entire polynomial chart from the marked-factor equations.
# The same scalar gamma weights three visible Colour contributions and one
# transverse contribution.  Regularity through x=0 determines gamma.
y, z, gamma = symbols("y z gamma")
a = x
b = 1 + x * y
c = 1 + gamma * (3 * x * y + x**2 * z)
d_gamma = cancel((1 - b * c) / a)
e_gamma = cancel((1 + a * b * d_gamma - b**2 * c) / a**2)
pole_coefficient = simplify((x * e_gamma).subs(x, 0))
assert simplify(pole_coefficient + (6 * gamma + 3) * y) == 0
gamma_value = Rational(-1, 2)
d_chart = simplify(d_gamma.subs(gamma, gamma_value))
e_chart = simplify(e_gamma.subs(gamma, gamma_value))
assert d_chart == (x**2 * y * z + 3 * x * y**2 + x * z + y) / 2
assert e_chart == x**2 * y**2 * z + 3 * x * y**3 + 2 * x * y * z + 4 * y**2 + z
assert simplify(a * d_chart + b * c.subs(gamma, gamma_value) - 1) == 0
assert simplify(
    a**2 * e_chart - a * b * d_chart + b**2 * c.subs(gamma, gamma_value) - 1
) == 0

F_chart = Matrix(
    [
        b * e_chart,
        2 * (a * e_chart + b * d_chart),
        2 * a * c.subs(gamma, gamma_value),
    ]
)
F_expected = Matrix(
    [
        (1 + x * y) ** 3 * z + y**2 * (1 + x * y) * (4 + 3 * x * y),
        y + 3 * x * (1 + x * y) ** 2 * z + 3 * x * y**2 * (4 + 3 * x * y),
        2 * x - 3 * x**2 * y - x**3 * z,
    ]
)
assert_matrix(F_chart, F_expected, "geometric marked-factor reconstruction")
assert simplify(F_chart.jacobian([x, y, z]).det()) == -2

# Directed blade support and its unique nonzero quarter.
E11 = Matrix([[1, 0], [0, 0]])
E22 = Matrix([[0, 0], [0, 1]])
N = Matrix([[0, 0], [2, 0]])
assert_matrix(N.T * N, 4 * E11, "blade source Gram")
assert_matrix(N * N.T, 4 * E22, "blade target Gram")
Q_range = Rational(1, 4) * N * N.T
assert_matrix(Q_range, E22, "blade range support")
assert_matrix(Q_range * Q_range, Q_range, "idempotent quarter support")

# The coefficient inversion block and its exact regular-five-cell carrier.
I_minus = Matrix(
    [
        [0, 0, 0, 1],
        [0, Rational(1, 4), 0, 0],
        [0, 0, Rational(1, 4), 0],
        [Rational(1, 16), 0, 0, 0],
    ]
)
w_N = Matrix([4, 0, 0, -1])
assert_matrix(I_minus * w_N, Rational(-1, 4) * w_N, "negative quarter eigenline")

n = Matrix([0, 0, 0, 1])
eta = [
    Matrix.vstack(Rational(1, 4) * sqrt(15) * vertex, Matrix([Rational(-1, 4)]))
    for vertex in mu
]
eta.append(n)
five_gram = Matrix([[simplify(v.dot(w)) for w in eta] for v in eta])
expected_five_gram = Matrix(5, 5, lambda i, j: 1 if i == j else Rational(-1, 4))
assert_matrix(five_gram, expected_five_gram, "regular five-cell Gram matrix")
assert_matrix(sum(eta, Matrix.zeros(4, 1)), Matrix.zeros(4, 1), "five-cell sum")

# Projection of the five-cell along its fifth vertex: four face vertices become
# a centered regular tetrahedron and share the same hidden -1/4 displacement.
P_five = eye(4) - n * n.T
projected_five_face = [simplify(P_five * eta[i]) for i in range(4)]
c_five = simplify(sum(eta[:4], Matrix.zeros(4, 1)) / 4)
assert_matrix(c_five, Rational(-1, 4) * n, "five-cell face centroid")
for i in range(4):
    assert_matrix(
        eta[i] - projected_five_face[i],
        Rational(-1, 4) * n,
        f"five-cell hidden displacement {i}",
    )
projected_five_unit = [simplify(Rational(4, 1) / sqrt(15) * v) for v in projected_five_face]
projected_five_gram = Matrix(
    [[simplify(v.dot(w)) for w in projected_five_unit] for v in projected_five_unit]
)
assert_matrix(projected_five_gram, expected_time_gram, "five-cell projected Time Gram")
q_five = lambda v: simplify(Rational(4, 5) * v.dot(n))
assert q_five(c_five) == Rational(-1, 5)
assert q_five(Matrix.zeros(4, 1)) == 0
assert q_five(n) == Rational(4, 5)

# Lambda sends the three +1/4 coefficient eigendirections to the Time carrier
# and the -1/4 direction to the fifth direction.
Lambda = Matrix(
    [
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [Rational(1, 8), 0, 0, Rational(1, 2)],
        [Rational(1, 8), 0, 0, Rational(-1, 2)],
    ]
)
Q_five = Matrix.diag(Rational(1, 4), Rational(1, 4), Rational(1, 4), Rational(-1, 4))
assert Lambda.det() != 0
assert_matrix(Lambda * I_minus, Q_five * Lambda, "quarter spectral conjugacy")
G_pullback = simplify(Lambda.T * Lambda)
assert_matrix(
    G_pullback,
    Matrix.diag(Rational(1, 32), 1, 1, Rational(1, 2)),
    "pulled-back positive metric",
)
assert_matrix(I_minus.T * G_pullback, G_pullback * I_minus, "metric self-adjointness")

# The selected Time altitude and the ordered E21 carrier are pointed oriented
# metric lines.  The altitude coordinate q makes h_alt a positive unit vector;
# the pulled-back five-cell metric makes w_N a positive unit vector.
target_norm = simplify((w_N.T * G_pullback * w_N)[0])
assert target_norm == 1
assert q(h_alt) == 1

rho, sigma = symbols("rho sigma", real=True)
time_pairing = simplify(q(rho * h_alt) * q(sigma * h_alt))
target_pairing = simplify(
    ((rho * w_N).T * G_pullback * (sigma * w_N))[0]
)
assert time_pairing == rho * sigma
assert target_pairing == rho * sigma
assert simplify(time_pairing - target_pairing) == 0

assert_matrix(c_hat, Rational(-1, 4) * h_alt, "oriented face point")
assert_matrix(mu[0], Rational(3, 4) * h_alt, "oriented selected vertex")
assert_matrix(
    q(c_hat) * w_N,
    I_minus * w_N,
    "face point to negative-quarter eigenpoint",
)
assert_matrix(q(mu[0]) * w_N, Rational(3, 4) * w_N, "selected vertex image")

# Recover the ordered raw blade transport itself.
q_complex = (1 + I) / sqrt(2)
P_square = Matrix(
    [
        [q_complex / 2, -q_complex.conjugate() / 2],
        [q_complex, q_complex.conjugate()],
    ]
)
H_N = Matrix([[0, 2 * I], [-2 * I, 0]])
transported_N = simplify(
    P_square.inv().conjugate().T * H_N * P_square.inv()
)
assert_matrix(transported_N, Matrix([[4, 0], [0, -1]]), "ordered E21 transport")

# Coefficient reversal exchanges the two ordered sheets.  It carries the raw
# quarter inversion to the inverse raw transposed inversion; after removing
# the reciprocal scalar, the two reflection operators are conjugate.
C_coeff = Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
w_N_dual = Matrix([-1, 0, 0, 4])
assert_matrix(C_coeff * w_N, w_N_dual, "coefficient-reversed carrier")
assert C_coeff.det() == -1

I_plus = Matrix(
    [
        [0, 0, 0, 1],
        [0, 4, 0, 0],
        [0, 0, 4, 0],
        [16, 0, 0, 0],
    ]
)
assert_matrix(I_plus * I_plus, 16 * eye(4), "transposed inversion square")
assert_matrix(
    C_coeff * I_minus * C_coeff,
    I_plus.inv(),
    "ordered raw inversion exchange",
)
R_minus = 4 * I_minus
R_plus = Rational(1, 4) * I_plus
assert_matrix(R_plus, C_coeff * R_minus * C_coeff, "reduced reflection exchange")
assert_matrix(R_minus * R_minus, eye(4), "directed reduced reflection")
assert_matrix(R_plus * R_plus, eye(4), "transposed reduced reflection")

G_dual = simplify(C_coeff.T * G_pullback * C_coeff)
assert_matrix(
    G_dual,
    Matrix.diag(Rational(1, 2), 1, 1, Rational(1, 32)),
    "transposed conjugating metric",
)
assert simplify((w_N_dual.T * G_dual * w_N_dual)[0]) == 1
assert_matrix(
    q(c_hat) * w_N_dual,
    I_plus.inv() * w_N_dual,
    "transposed face point uses inverse inversion",
)
assert_matrix(I_plus * w_N_dual, -4 * w_N_dual, "raw transposed scale")

# The raw matrix-unit exchange reverses the modular eigenvalue while retaining
# the order of source and range.
S_exchange = Matrix([[0, 1], [1, 0]])
N_dual = N.T
assert_matrix(S_exchange * N * S_exchange, N_dual, "raw blade sheet exchange")
J_blade = Matrix.diag(1, -1)
ell = symbols("ell", real=True, nonzero=True)
K_blade = lambda X: simplify(ell * (J_blade * X - X * J_blade) / 2)
assert_matrix(K_blade(N), -ell * N, "negative modular E21 channel")
assert_matrix(K_blade(N_dual), ell * N_dual, "positive modular E12 channel")

print("PASS Time tetrahedron and Colour projection Gram matrices")
print("PASS zero-fibre altitude coordinates (-1/4, 0, 3/4)")
print("PASS Colour/Time rows (1,-1/2,-1/2) and (-1/4,1/2,1/2)")
print("PASS Fable fibre algebra u*h=-1/4 with e=x^2 idempotent")
print("PASS geometric marked-factor chart forces gamma=-1/2 and det JF=-2")
print("PASS directed N=2E21 quarter support")
print("PASS regular five-cell Gram matrix and 3+1 quarter conjugacy")
print("PASS five-cell projection has four identical hidden -1/4 displacements")
print("PASS pointed oriented Time/E21 carrier isometry in the conjugating metric")
print("PASS ordered N=2E21 transport lands at the negative-quarter unit carrier")
print("PASS coefficient reversal carries I_- to inverse I_+ with reciprocal raw scales")
print("PASS ordered E21/E12 sheet exchange reverses the modular eigenvalue")

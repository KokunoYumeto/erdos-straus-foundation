import Mathlib

open scoped BigOperators

namespace TargetRotationGapCertificate

theorem weighted_rotation_gap
    {ι : Type*} [Fintype ι]
    (weight factor : ι → ℝ)
    (rotated : ι → Prop) [DecidablePred rotated]
    (c : ℝ)
    (weight_nonnegative : ∀ index, 0 ≤ weight index)
    (factor_upper :
      ∀ index, factor index ≤ if rotated index then c else 1) :
    (∑ index, weight index * factor index) ≤
      (∑ index, weight index) -
        (1 - c) *
          ∑ index, if rotated index then weight index else 0 := by
  classical
  have pointwise :
      ∀ index,
        weight index * factor index ≤
          weight index -
            if rotated index then (1 - c) * weight index else 0 := by
    intro index
    by_cases is_rotated : rotated index
    · have upper := factor_upper index
      simp [is_rotated] at upper ⊢
      nlinarith [weight_nonnegative index]
    · have upper := factor_upper index
      simp [is_rotated] at upper ⊢
      nlinarith [weight_nonnegative index]
  calc
    (∑ index, weight index * factor index) ≤
        ∑ index,
          (weight index -
            if rotated index then (1 - c) * weight index else 0) := by
      exact Finset.sum_le_sum fun index _ => pointwise index
    _ =
        (∑ index, weight index) -
          ∑ index,
            (if rotated index then (1 - c) * weight index else 0) := by
      rw [Finset.sum_sub_distrib]
    _ =
        (∑ index, weight index) -
          (1 - c) *
            ∑ index, if rotated index then weight index else 0 := by
      congr 1
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro index _
      by_cases is_rotated : rotated index <;> simp [is_rotated]

theorem strict_from_positive_rotated_mass
    (unweighted filtered rotatedMass c : ℝ)
    (gap :
      filtered ≤ unweighted - (1 - c) * rotatedMass)
    (c_strict : c < 1)
    (rotatedMass_positive : 0 < rotatedMass) :
    filtered < unweighted := by
  nlinarith

theorem contradiction_from_uniform_rotated_lower_bound
    (principal filtered unweighted rotatedMass lower c : ℝ)
    (principal_below_filtered : principal ≤ filtered)
    (filtered_gap :
      filtered ≤ unweighted - (1 - c) * rotatedMass)
    (rotated_lower_bound : lower ≤ rotatedMass)
    (c_at_most_one : c ≤ 1)
    (strict_certificate :
      unweighted < principal + (1 - c) * lower) :
    False := by
  nlinarith

end TargetRotationGapCertificate

import Mathlib

def packetEll (m : ℤ) : ℤ := 6 * m + 1

def packetPrime (m : ℤ) : ℤ := 260 * packetEll m - 19

def packetB (m : ℤ) : ℤ := 130 * m + 22

def packetResidual (t : ℤ) : ℤ := 23 + 4 * t

def packetCoordinate (m t : ℤ) : ℤ := 390 * m + 66 + t

theorem packet_prime_expansion (m : ℤ) :
    packetPrime m = 1560 * m + 241 := by
  simp [packetPrime, packetEll]
  ring

theorem packet_b_from_ell (m : ℤ) :
    3 * packetB m = 65 * packetEll m + 1 := by
  simp [packetB, packetEll]
  ring

theorem packet_shell_numerator (m t : ℤ) :
    4 * packetCoordinate m t =
      packetPrime m + packetResidual t := by
  simp [packetCoordinate, packetPrime, packetEll, packetResidual]
  ring

theorem packet_coordinate_from_b (m t : ℤ) :
    packetCoordinate m t = 3 * packetB m + t := by
  simp [packetCoordinate, packetB]
  ring

theorem packet_coordinate_difference (m s t : ℤ) :
    packetCoordinate m t - packetCoordinate m s = t - s := by
  simp [packetCoordinate]

theorem packet_common_divisor_dvd_difference
    (m s t d : ℤ)
    (hs : d ∣ packetCoordinate m s)
    (ht : d ∣ packetCoordinate m t) :
    d ∣ t - s := by
  rw [← packet_coordinate_difference m s t]
  exact dvd_sub ht hs

theorem packet_R23_factor (m : ℤ) :
    packetCoordinate m 0 = 6 * (65 * m + 11) := by
  simp [packetCoordinate]
  ring

theorem packet_R31_factor (m : ℤ) :
    packetCoordinate m 2 = 2 * (195 * m + 34) := by
  simp [packetCoordinate]
  ring

theorem packet_R35_factor (m : ℤ) :
    packetCoordinate m 3 = 3 * (130 * m + 23) := by
  simp [packetCoordinate]
  ring

theorem packet_R39_factor (m : ℤ) :
    packetCoordinate m 4 = 10 * (39 * m + 7) := by
  simp [packetCoordinate]
  ring

theorem packet_R47_factor (m : ℤ) :
    packetCoordinate m 6 = 6 * (65 * m + 12) := by
  simp [packetCoordinate]
  ring

theorem packet_R55_factor (m : ℤ) :
    packetCoordinate m 8 = 2 * (195 * m + 37) := by
  simp [packetCoordinate]
  ring

theorem packet_R59_factor (m : ℤ) :
    packetCoordinate m 9 = 15 * (26 * m + 5) := by
  simp [packetCoordinate]
  ring

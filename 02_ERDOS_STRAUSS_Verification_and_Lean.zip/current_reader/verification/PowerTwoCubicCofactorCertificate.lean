import Mathlib

theorem cubic_cofactor_divisor_split
    (a p R u : ℚ)
    (ha : a ≠ 0)
    (hp : p ≠ 0)
    (hu : u ≠ 0)
    (hapu : a * p + u ≠ 0)
    (hrel : p + R = 4 * a) :
    4 / p =
      1 / a
      + 1 / ((a * p + u) / R)
      + 1 / ((a * p + a * a * p * p / u) / R) := by
  have hfactor :
      a * p + a * a * p * p / u =
        (a * p) * (a * p + u) / u := by
    field_simp [hu]
    ring
  calc
    4 / p = 1 / a + R / (a * p) := by
      field_simp [ha, hp]
      nlinarith [hrel]
    _ =
        1 / a
        + 1 / ((a * p + u) / R)
        + 1 / ((a * p + a * a * p * p / u) / R) := by
      rw [hfactor]
      field_simp [ha, hp, hu, hapu]
      ring

theorem cubic_cofactor_negative_power_class
    (e : ℕ) :
    3 * (e + 2) + (e + 2) = 2 * (2 * e + 4) := by
  omega

theorem cubic_cofactor_enlarged_exponent_bound
    (f : ℕ)
    (hf : 1 ≤ f) :
    f + 1 ≤ 2 * f := by
  omega

example :
    (4 : ℚ) / 373 =
      1 / 98 + 1 / 1924 + 1 / 35164948 := by
  norm_num

example :
    (4 : ℚ) / 9109 =
      1 / 2282 + 1 / 1094056 + 1 / 69760292728 := by
  norm_num

example :
    (4 : ℚ) / 21013 =
      1 / 5258 + 1 / 5815348 + 1 / 122197907524 := by
  norm_num

example :
    (4 : ℚ) / 952981 =
      1 / 238328
      + 1 / 686169376
      + 1 / 20271097721405536 := by
  norm_num

example :
    (4 : ℚ) / 3413 =
      1 / 858 + 1 / 154124 + 1 / 225664815948 := by
  norm_num

example :
    (4 : ℚ) / 6421 =
      1 / 1610 + 1 / 544180 + 1 / 3494179780 := by
  norm_num

example :
    (4 : ℚ) / 30389 =
      1 / 7602 + 1 / 12158856 + 1 / 2586468324888 := by
  norm_num

example :
    (4 : ℚ) / 1741 =
      1 / 440 + 1 / 40318 + 1 / 15442600360 := by
  norm_num

example :
    (4 : ℚ) / 2269 =
      1 / 572 + 1 / 68640 + 1 / 14158560 := by
  norm_num

example :
    (4 : ℚ) / 2621 =
      1 / 660 + 1 / 91080 + 1 / 238720680 := by
  norm_num

example : Nat.Prime 373 := by
  norm_num

example : Nat.Prime 9109 := by
  norm_num

example : Nat.Prime 21013 := by
  norm_num

example : Nat.Prime 3413 := by
  norm_num

example : Nat.Prime 6421 := by
  norm_num

example : Nat.Prime 30389 := by
  norm_num

example : Nat.Prime 1741 := by
  norm_num

example : Nat.Prime 2269 := by
  norm_num

example : Nat.Prime 2621 := by
  norm_num

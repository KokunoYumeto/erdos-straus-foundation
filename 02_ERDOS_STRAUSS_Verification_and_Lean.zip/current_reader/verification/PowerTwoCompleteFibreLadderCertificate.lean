import Mathlib

theorem power_two_complete_fibre_branch_one_identity
    (p q R t : ℚ)
    (hp : p ≠ 0)
    (hq : q ≠ 0)
    (ht : t ≠ 0)
    (hp1 : p + 1 ≠ 0)
    (hrel : p + R = 4 * t * q) :
    4 / p =
      1 / (t * q)
      + 1 / (t * q * (p + 1) / R)
      + 1 / (p * (t * q * (p + 1) / R)) := by
  field_simp [hp, hq, ht, hp1]
  have hmul :=
    congrArg (fun x : ℚ => (p + 1) * x) hrel
  nlinarith [hmul]

theorem power_two_complete_fibre_branch_two_identity
    (p q R t : ℚ)
    (hp : p ≠ 0)
    (hq : q ≠ 0)
    (ht : t ≠ 0)
    (hpq1 : p * q + 1 ≠ 0)
    (hrel : p + R = 4 * t * q) :
    4 / p =
      1 / (t * q)
      + 1 / (t * (p * q + 1) / R)
      + 1 / (p * q * (t * (p * q + 1) / R)) := by
  field_simp [hp, hq, ht, hpq1]
  have hmul :=
    congrArg (fun x : ℚ => (p * q + 1) * x) hrel
  nlinarith [hmul]

theorem power_two_complete_fibre_midpoint
    (e : ℕ) :
    e + 2 = (2 * e + 4) / 2 := by
  omega

theorem power_two_complete_fibre_projected_interval_bound
    (e : ℕ)
    (he : 1 ≤ e) :
    e + 2 ≤ 2 * e + 1 := by
  omega

theorem power_two_complete_fibre_full_order
    (e : ℕ) :
    3 * (2 * e + 4) = 6 * e + 12 := by
  omega

example :
    (4 : ℚ) / 661 = 1 / 248 + 1 / 496 + 1 / 327856 := by
  norm_num

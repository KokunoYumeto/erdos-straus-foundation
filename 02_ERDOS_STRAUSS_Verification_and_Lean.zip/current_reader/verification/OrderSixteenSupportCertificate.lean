import Mathlib

/-!
This file independently certifies the finite numerical core of the
order-sixteen local-interval support classification.  Every group is encoded
on the same sixteen-point carrier.  A support is encoded by a natural-number
bit mask.
-/

def maskHas (mask index : Nat) : Bool :=
  ((mask / (2 ^ index)) % 2) == 1

def maskInsert (mask index : Nat) : Nat :=
  if maskHas mask index then mask else mask + 2 ^ index

def maskCard (mask : Nat) : Nat :=
  ((List.range 16).filter fun index => maskHas mask index).length

def supportSum
    (add : Nat → Nat → Nat)
    (left right : Nat) : Nat :=
  (List.range 16).foldl
    (fun outer i =>
      if maskHas left i then
        (List.range 16).foldl
          (fun inner j =>
            if maskHas right j then
              maskInsert inner (add i j)
            else inner)
          outer
      else outer)
    0

def groupScalar
    (add : Nat → Nat → Nat)
    (coefficient point : Nat) : Nat :=
  (List.range coefficient).foldl (fun total _ => add total point) 0

def intervalMask
    (add : Nat → Nat → Nat)
    (radius direction : Nat) : Nat :=
  (List.range (2 * radius + 1)).foldl
    (fun support j =>
      let coefficient := (j + 16 - radius) % 16
      maskInsert support (groupScalar add coefficient direction))
    0

def localMasks (add : Nat → Nat → Nat) : List Nat :=
  ((List.range 15).flatMap fun u0 =>
    (List.range 16).map fun e0 =>
      intervalMask add (e0 + 1) (u0 + 1)).eraseDups

def supportClosureStep
    (add : Nat → Nat → Nat)
    (locals current : List Nat) : List Nat :=
  (current ++ current.flatMap fun support =>
    locals.map fun atom => supportSum add support atom).eraseDups

def supportClosureAux
    (add : Nat → Nat → Nat)
    (locals : List Nat) : Nat → List Nat
  | 0 => [1]
  | n + 1 => supportClosureStep add locals (supportClosureAux add locals n)

def supportClosure (add : Nat → Nat → Nat) : List Nat :=
  supportClosureAux add (localMasks add) 4

def supportPoints (support : Nat) : List Nat :=
  (List.range 16).filter fun point => maskHas support point

def pointClosureStep
    (add : Nat → Nat → Nat)
    (generators current : List Nat) : List Nat :=
  (current ++ current.flatMap fun point =>
    generators.map fun generator => add point generator).eraseDups

def pointClosureAux
    (add : Nat → Nat → Nat)
    (generators : List Nat) : Nat → List Nat
  | 0 => [0]
  | n + 1 => pointClosureStep add generators (pointClosureAux add generators n)

def supportGenerates
    (add : Nat → Nat → Nat)
    (support : Nat) : Bool :=
  (pointClosureAux add (supportPoints support) 16).length == 16

def generatingSupports (add : Nat → Nat → Nat) : List Nat :=
  (supportClosure add).filter fun support => supportGenerates add support

def generatingNonfullSupports (add : Nat → Nat → Nat) : List Nat :=
  (generatingSupports add).filter fun support => maskCard support < 16

def minimumGeneratingCard (add : Nat → Nat → Nat) : Nat :=
  (generatingSupports add).foldl
    (fun current support => min current (maskCard support))
    16

def c16Add (x y : Nat) : Nat :=
  (x + y) % 16

def c8c2Add (x y : Nat) : Nat :=
  2 * (((x / 2) + (y / 2)) % 8) + ((x % 2 + y % 2) % 2)

def c4c4Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) + ((x % 4 + y % 4) % 4)

def c4c2c2Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) +
    2 * ((((x / 2) % 2) + ((y / 2) % 2)) % 2) +
    ((x % 2 + y % 2) % 2)

def c2fourAdd (x y : Nat) : Nat :=
  Nat.xor x y

def c16MinimumBox : Nat :=
  intervalMask c16Add 1 1

def c8c2MinimumBox : Nat :=
  supportSum c8c2Add
    (intervalMask c8c2Add 1 2)
    (intervalMask c8c2Add 1 1)

def c4c4MinimumBox : Nat :=
  supportSum c4c4Add
    (intervalMask c4c4Add 1 4)
    (intervalMask c4c4Add 1 1)

def c4c2c2MinimumBox : Nat :=
  supportSum c4c2c2Add
    (supportSum c4c2c2Add
      (intervalMask c4c2c2Add 1 4)
      (intervalMask c4c2c2Add 1 2))
    (intervalMask c4c2c2Add 1 1)

def c2fourMinimumBox : Nat :=
  supportSum c2fourAdd
    (supportSum c2fourAdd
      (supportSum c2fourAdd
        (intervalMask c2fourAdd 1 8)
        (intervalMask c2fourAdd 1 4))
      (intervalMask c2fourAdd 1 2))
    (intervalMask c2fourAdd 1 1)

theorem c16_local_support_count :
    (localMasks c16Add).length = 35 := by
  native_decide

theorem c8c2_local_support_count :
    (localMasks c8c2Add).length = 19 := by
  native_decide

theorem c4c4_local_support_count :
    (localMasks c4c4Add).length = 15 := by
  native_decide

theorem c4c2c2_local_support_count :
    (localMasks c4c2c2Add).length = 15 := by
  native_decide

theorem c2four_local_support_count :
    (localMasks c2fourAdd).length = 15 := by
  native_decide

theorem c16_support_monoid_count :
    (supportClosure c16Add).length = 63 := by
  native_decide

theorem c8c2_support_monoid_count :
    (supportClosure c8c2Add).length = 64 := by
  native_decide

theorem c4c4_support_monoid_count :
    (supportClosure c4c4Add).length = 54 := by
  native_decide

theorem c4c2c2_support_monoid_count :
    (supportClosure c4c2c2Add).length = 60 := by
  native_decide

theorem c2four_support_monoid_count :
    (supportClosure c2fourAdd).length = 67 := by
  native_decide

theorem c16_generating_nonfull_count :
    (generatingNonfullSupports c16Add).length = 51 := by
  native_decide

theorem c8c2_generating_nonfull_count :
    (generatingNonfullSupports c8c2Add).length = 36 := by
  native_decide

theorem c4c4_generating_nonfull_count :
    (generatingNonfullSupports c4c4Add).length = 24 := by
  native_decide

theorem c4c2c2_generating_nonfull_count :
    (generatingNonfullSupports c4c2c2Add).length = 11 := by
  native_decide

theorem c2four_generating_nonfull_count :
    (generatingNonfullSupports c2fourAdd).length = 0 := by
  native_decide

theorem c16_minimum_generating_support :
    minimumGeneratingCard c16Add = 3 := by
  native_decide

theorem c8c2_minimum_generating_support :
    minimumGeneratingCard c8c2Add = 6 := by
  native_decide

theorem c4c4_minimum_generating_support :
    minimumGeneratingCard c4c4Add = 9 := by
  native_decide

theorem c4c2c2_minimum_generating_support :
    minimumGeneratingCard c4c2c2Add = 12 := by
  native_decide

theorem c2four_minimum_generating_support :
    minimumGeneratingCard c2fourAdd = 16 := by
  native_decide

theorem c16_minimum_box :
    maskCard c16MinimumBox = 3 ∧
      supportGenerates c16Add c16MinimumBox := by
  native_decide

theorem c8c2_minimum_box :
    maskCard c8c2MinimumBox = 6 ∧
      supportGenerates c8c2Add c8c2MinimumBox := by
  native_decide

theorem c4c4_minimum_box :
    maskCard c4c4MinimumBox = 9 ∧
      supportGenerates c4c4Add c4c4MinimumBox := by
  native_decide

theorem c4c2c2_minimum_box :
    maskCard c4c2c2MinimumBox = 12 ∧
      supportGenerates c4c2c2Add c4c2c2MinimumBox := by
  native_decide

theorem c2four_minimum_box :
    maskCard c2fourMinimumBox = 16 ∧
      supportGenerates c2fourAdd c2fourMinimumBox := by
  native_decide

import Mathlib

/-!
This file independently certifies inversion on the four order-sixteen
four-sheet carriers, its fixed loci and two-cycle blocks, and the exact
minimum-support correlation-deficit identity.
-/

def invMaskHas (mask index : Nat) : Bool :=
  ((mask / (2 ^ index)) % 2) == 1

def invMaskInsert (mask index : Nat) : Nat :=
  if invMaskHas mask index then mask else mask + 2 ^ index

def invMaskFromList (points : List Nat) : Nat :=
  points.foldl invMaskInsert 0

def invMaskCard (mask : Nat) : Nat :=
  ((List.range 16).filter fun index => invMaskHas mask index).length

def invMapMask (mapPoint : Nat → Nat) (mask : Nat) : Nat :=
  (List.range 16).foldl
    (fun answer point =>
      if invMaskHas mask point then invMaskInsert answer (mapPoint point)
      else answer)
    0

def invSheetProjectionCard (mask : Nat) : Nat :=
  (((List.range 16).filter fun point => invMaskHas mask point).map
    fun point => point / 4).eraseDups.length

def invCellProjectionCard (mask : Nat) : Nat :=
  (((List.range 16).filter fun point => invMaskHas mask point).map
    fun point => point % 4).eraseDups.length

def invCorrelationDefect (mask : Nat) : Nat :=
  invSheetProjectionCard mask * invCellProjectionCard mask - invMaskCard mask

def invC4SheetNeg (sheet : Nat) : Nat :=
  (4 - (sheet % 4)) % 4

def invC2SquareSheetNeg (sheet : Nat) : Nat :=
  sheet % 4

def invC16Carry (left right : Nat) : Nat :=
  (left + right) / 4

def invC8C2Carry (left right : Nat) : Nat :=
  (left / 2) * (right / 2)

def invZeroCarry (_left _right : Nat) : Nat :=
  0

def carrierInverse
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat)
    (point : Nat) : Nat :=
  let sheet := point / 4
  let cell := point % 4
  let oppositeSheet := sheetNeg sheet
  4 * oppositeSheet +
    ((8 - (cell + carry sheet oppositeSheet)) % 4)

def invC16Carrier : Nat → Nat :=
  carrierInverse invC4SheetNeg invC16Carry

def invC8C2Carrier : Nat → Nat :=
  carrierInverse invC2SquareSheetNeg invC8C2Carry

def invC4C4Carrier : Nat → Nat :=
  carrierInverse invC4SheetNeg invZeroCarry

def invC4C2C2Carrier : Nat → Nat :=
  carrierInverse invC2SquareSheetNeg invZeroCarry

def invC16Add (x y : Nat) : Nat :=
  (x + y) % 16

def invC8C2Add (x y : Nat) : Nat :=
  2 * (((x / 2) + (y / 2)) % 8) + ((x % 2 + y % 2) % 2)

def invC4C4Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) + ((x % 4 + y % 4) % 4)

def invC4C2C2Add (x y : Nat) : Nat :=
  4 * (((x / 4) + (y / 4)) % 4) +
    2 * ((((x / 2) % 2) + ((y / 2) % 2)) % 2) +
    ((x % 2 + y % 2) % 2)

def invC16Phi (point : Nat) : Nat :=
  ((point / 4) + 4 * (point % 4)) % 16

def invC8C2Phi (point : Nat) : Nat :=
  let sheet := point / 4
  let first := sheet / 2
  let second := sheet % 2
  let cell := point % 4
  2 * ((first + 2 * cell) % 8) + second

def invSplitPhi (point : Nat) : Nat :=
  4 * (point % 4) + point / 4

def carrierInverseCheck
    (phi : Nat → Nat)
    (groupAdd : Nat → Nat → Nat)
    (inverse : Nat → Nat) : Bool :=
  (List.range 16).all fun point =>
    groupAdd (phi point) (phi (inverse point)) == 0 &&
      inverse (inverse point) == point

def fixedMaskOn (inverse : Nat → Nat) (mask : Nat) : Nat :=
  (List.range 16).foldl
    (fun answer point =>
      if invMaskHas mask point && inverse point == point then
        invMaskInsert answer point
      else answer)
    0

def fixedCardOn (inverse : Nat → Nat) (mask : Nat) : Nat :=
  invMaskCard (fixedMaskOn inverse mask)

def twoCycleCountOn (inverse : Nat → Nat) (mask : Nat) : Nat :=
  (invMaskCard mask - fixedCardOn inverse mask) / 2

def evenDimensionOn (inverse : Nat → Nat) (mask : Nat) : Nat :=
  fixedCardOn inverse mask + twoCycleCountOn inverse mask

def twoCycleBlockCheck (inverse : Nat → Nat) (mask : Nat) : Bool :=
  (List.range 16).all fun point =>
    if invMaskHas mask point then
      invMaskHas mask (inverse point) && inverse (inverse point) == point
    else true

def invFullCarrier : Nat :=
  invMaskFromList (List.range 16)

def invC16Minimum : Nat :=
  invMaskFromList [0, 4, 15]

def invC8C2Minimum : Nat :=
  invMaskFromList [0, 4, 8, 11, 12, 15]

def invC4C4Minimum : Nat :=
  invMaskFromList (
    [0, 1, 3].flatMap fun sheet =>
      [0, 1, 3].map fun cell => 4 * sheet + cell)

def invC4C2C2Minimum : Nat :=
  invMaskFromList (
    (List.range 4).flatMap fun sheet =>
      [0, 1, 3].map fun cell => 4 * sheet + cell)

def invC16FullFixed : Nat :=
  invMaskFromList [0, 2]

def invC8C2FullFixed : Nat :=
  invMaskFromList [0, 2, 4, 6]

def invC4C4FullFixed : Nat :=
  invMaskFromList [0, 2, 8, 10]

def invC4C2C2FullFixed : Nat :=
  invMaskFromList [0, 2, 4, 6, 8, 10, 12, 14]

def invC16MinimumFixed : Nat :=
  invMaskFromList [0]

def invC8C2MinimumFixed : Nat :=
  invMaskFromList [0, 4]

def invC4C4MinimumFixed : Nat :=
  invMaskFromList [0]

def invC4C2C2MinimumFixed : Nat :=
  invMaskFromList [0, 4, 8, 12]

theorem c16_carrier_inversion :
    carrierInverseCheck invC16Phi invC16Add invC16Carrier = true := by
  native_decide

theorem c8c2_carrier_inversion :
    carrierInverseCheck invC8C2Phi invC8C2Add invC8C2Carrier = true := by
  native_decide

theorem c4c4_carrier_inversion :
    carrierInverseCheck invSplitPhi invC4C4Add invC4C4Carrier = true := by
  native_decide

theorem c4c2c2_carrier_inversion :
    carrierInverseCheck invSplitPhi invC4C2C2Add invC4C2C2Carrier = true := by
  native_decide

theorem c16_full_inversion_spectrum :
    fixedMaskOn invC16Carrier invFullCarrier = invC16FullFixed ∧
      evenDimensionOn invC16Carrier invFullCarrier = 9 ∧
      twoCycleCountOn invC16Carrier invFullCarrier = 7 := by
  native_decide

theorem c8c2_full_inversion_spectrum :
    fixedMaskOn invC8C2Carrier invFullCarrier = invC8C2FullFixed ∧
      evenDimensionOn invC8C2Carrier invFullCarrier = 10 ∧
      twoCycleCountOn invC8C2Carrier invFullCarrier = 6 := by
  native_decide

theorem c4c4_full_inversion_spectrum :
    fixedMaskOn invC4C4Carrier invFullCarrier = invC4C4FullFixed ∧
      evenDimensionOn invC4C4Carrier invFullCarrier = 10 ∧
      twoCycleCountOn invC4C4Carrier invFullCarrier = 6 := by
  native_decide

theorem c4c2c2_full_inversion_spectrum :
    fixedMaskOn invC4C2C2Carrier invFullCarrier = invC4C2C2FullFixed ∧
      evenDimensionOn invC4C2C2Carrier invFullCarrier = 12 ∧
      twoCycleCountOn invC4C2C2Carrier invFullCarrier = 4 := by
  native_decide

theorem c16_minimum_invariant :
    invMapMask invC16Carrier invC16Minimum = invC16Minimum := by
  native_decide

theorem c8c2_minimum_invariant :
    invMapMask invC8C2Carrier invC8C2Minimum = invC8C2Minimum := by
  native_decide

theorem c4c4_minimum_invariant :
    invMapMask invC4C4Carrier invC4C4Minimum = invC4C4Minimum := by
  native_decide

theorem c4c2c2_minimum_invariant :
    invMapMask invC4C2C2Carrier invC4C2C2Minimum = invC4C2C2Minimum := by
  native_decide

theorem c16_minimum_inversion_spectrum :
    fixedMaskOn invC16Carrier invC16Minimum = invC16MinimumFixed ∧
      evenDimensionOn invC16Carrier invC16Minimum = 2 ∧
      twoCycleCountOn invC16Carrier invC16Minimum = 1 := by
  native_decide

theorem c8c2_minimum_inversion_spectrum :
    fixedMaskOn invC8C2Carrier invC8C2Minimum = invC8C2MinimumFixed ∧
      evenDimensionOn invC8C2Carrier invC8C2Minimum = 4 ∧
      twoCycleCountOn invC8C2Carrier invC8C2Minimum = 2 := by
  native_decide

theorem c4c4_minimum_inversion_spectrum :
    fixedMaskOn invC4C4Carrier invC4C4Minimum = invC4C4MinimumFixed ∧
      evenDimensionOn invC4C4Carrier invC4C4Minimum = 5 ∧
      twoCycleCountOn invC4C4Carrier invC4C4Minimum = 4 := by
  native_decide

theorem c4c2c2_minimum_inversion_spectrum :
    fixedMaskOn invC4C2C2Carrier invC4C2C2Minimum =
        invC4C2C2MinimumFixed ∧
      evenDimensionOn invC4C2C2Carrier invC4C2C2Minimum = 8 ∧
      twoCycleCountOn invC4C2C2Carrier invC4C2C2Minimum = 4 := by
  native_decide

theorem c16_minimum_two_cycle_blocks :
    twoCycleBlockCheck invC16Carrier invC16Minimum = true := by
  native_decide

theorem c8c2_minimum_two_cycle_blocks :
    twoCycleBlockCheck invC8C2Carrier invC8C2Minimum = true := by
  native_decide

theorem c4c4_minimum_two_cycle_blocks :
    twoCycleBlockCheck invC4C4Carrier invC4C4Minimum = true := by
  native_decide

theorem c4c2c2_minimum_two_cycle_blocks :
    twoCycleBlockCheck invC4C2C2Carrier invC4C2C2Minimum = true := by
  native_decide

theorem c16_defect_blade_conservation :
    invCorrelationDefect invC16Minimum +
      twoCycleCountOn invC16Carrier invC16Minimum = 4 := by
  native_decide

theorem c8c2_defect_blade_conservation :
    invCorrelationDefect invC8C2Minimum +
      twoCycleCountOn invC8C2Carrier invC8C2Minimum = 4 := by
  native_decide

theorem c4c4_defect_blade_conservation :
    invCorrelationDefect invC4C4Minimum +
      twoCycleCountOn invC4C4Carrier invC4C4Minimum = 4 := by
  native_decide

theorem c4c2c2_defect_blade_conservation :
    invCorrelationDefect invC4C2C2Minimum +
      twoCycleCountOn invC4C2C2Carrier invC4C2C2Minimum = 4 := by
  native_decide

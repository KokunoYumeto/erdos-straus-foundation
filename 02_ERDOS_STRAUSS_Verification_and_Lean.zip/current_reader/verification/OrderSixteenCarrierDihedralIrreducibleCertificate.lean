import Mathlib

/-!
This file independently certifies the D8 permutation characters,
irreducible multiplicities, orbit-module types, and spectral carry
criterion for the four order-sixteen carriers.
-/

def irC4SheetNeg (sheet : Nat) : Nat :=
  (4 - (sheet % 4)) % 4

def irC2SquareSheetNeg (sheet : Nat) : Nat :=
  sheet % 4

def irC16Carry (left right : Nat) : Nat :=
  (left + right) / 4

def irC8C2Carry (left right : Nat) : Nat :=
  (left / 2) * (right / 2)

def irZeroCarry (_left _right : Nat) : Nat :=
  0

def irCarrierInverse
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat)
    (point : Nat) : Nat :=
  let sheet := point / 4
  let cell := point % 4
  let oppositeSheet := sheetNeg sheet
  4 * oppositeSheet +
    ((8 - (cell + carry sheet oppositeSheet)) % 4)

def irC16Inverse : Nat → Nat :=
  irCarrierInverse irC4SheetNeg irC16Carry

def irC8C2Inverse : Nat → Nat :=
  irCarrierInverse irC2SquareSheetNeg irC8C2Carry

def irC4C4Inverse : Nat → Nat :=
  irCarrierInverse irC4SheetNeg irZeroCarry

def irC4C2C2Inverse : Nat → Nat :=
  irCarrierInverse irC2SquareSheetNeg irZeroCarry

def irCellRotationPower (point exponent : Nat) : Nat :=
  4 * (point / 4) + ((point % 4 + exponent) % 4)

def irGroupAction
    (inverse : Nat → Nat)
    (rotationExponent reflected point : Nat) : Nat :=
  if reflected % 2 == 0 then
    irCellRotationPower point rotationExponent
  else
    irCellRotationPower (inverse point) rotationExponent

def irFixedCount
    (inverse : Nat → Nat)
    (rotationExponent reflected : Nat) : Nat :=
  ((List.range 16).filter fun point =>
    irGroupAction inverse rotationExponent reflected point == point).length

def irPermutationCharacter (inverse : Nat → Nat) : List Int :=
  (List.range 2).flatMap fun reflected =>
    (List.range 4).map fun rotationExponent =>
      Int.ofNat (irFixedCount inverse rotationExponent reflected)

def irOneDimensionalCharacter
    (rotationSign reflectionSign : Int) : List Int :=
  (List.range 2).flatMap fun reflected =>
    (List.range 4).map fun rotationExponent =>
      rotationSign ^ rotationExponent * reflectionSign ^ reflected

def irRhoCharacter : List Int :=
  [2, 0, -2, 0, 0, 0, 0, 0]

def irDot : List Int → List Int → Int
  | left :: leftTail, right :: rightTail =>
      left * right + irDot leftTail rightTail
  | _, _ => 0

def irMultiplicity (character irreducibleCharacter : List Int) : Int :=
  irDot character irreducibleCharacter / 8

def irIrreducibleMultiplicities (character : List Int) : List Int :=
  [
    irMultiplicity character (irOneDimensionalCharacter 1 1),
    irMultiplicity character (irOneDimensionalCharacter 1 (-1)),
    irMultiplicity character (irOneDimensionalCharacter (-1) 1),
    irMultiplicity character (irOneDimensionalCharacter (-1) (-1)),
    irMultiplicity character irRhoCharacter
  ]

def irOrbitModuleTypes
    (sheetNeg : Nat → Nat)
    (carry : Nat → Nat → Nat) : List Nat :=
  (List.range 4).filterMap fun sheet =>
    let opposite := sheetNeg sheet
    if sheet < opposite then
      some 2
    else if sheet == opposite then
      some (if carry sheet opposite % 2 == 0 then 0 else 1)
    else
      none

def irCarrySpectralIdentity
    (inverse : Nat → Nat)
    (expectedNonzero : Bool) : Bool :=
  let character := irPermutationCharacter inverse
  let multiplicities := irIrreducibleMultiplicities character
  let traceRU := character.getD 5 0
  traceRU / 2 ==
      multiplicities.getD 3 0 - multiplicities.getD 1 0 &&
    decide (traceRU > 0) == expectedNonzero &&
    decide (multiplicities.getD 3 0 > multiplicities.getD 1 0) ==
      expectedNonzero

theorem c16_permutation_character :
    irPermutationCharacter irC16Inverse =
      [16, 0, 0, 0, 2, 2, 2, 2] := by
  native_decide

theorem c8c2_permutation_character :
    irPermutationCharacter irC8C2Inverse =
      [16, 0, 0, 0, 4, 4, 4, 4] := by
  native_decide

theorem c4c4_permutation_character :
    irPermutationCharacter irC4C4Inverse =
      [16, 0, 0, 0, 4, 0, 4, 0] := by
  native_decide

theorem c4c2c2_permutation_character :
    irPermutationCharacter irC4C2C2Inverse =
      [16, 0, 0, 0, 8, 0, 8, 0] := by
  native_decide

theorem c16_irreducible_multiplicities :
    irIrreducibleMultiplicities (irPermutationCharacter irC16Inverse) =
      [3, 1, 2, 2, 4] := by
  native_decide

theorem c8c2_irreducible_multiplicities :
    irIrreducibleMultiplicities (irPermutationCharacter irC8C2Inverse) =
      [4, 0, 2, 2, 4] := by
  native_decide

theorem c4c4_irreducible_multiplicities :
    irIrreducibleMultiplicities (irPermutationCharacter irC4C4Inverse) =
      [3, 1, 3, 1, 4] := by
  native_decide

theorem c4c2c2_irreducible_multiplicities :
    irIrreducibleMultiplicities (irPermutationCharacter irC4C2C2Inverse) =
      [4, 0, 4, 0, 4] := by
  native_decide

theorem c16_orbit_module_types :
    irOrbitModuleTypes irC4SheetNeg irC16Carry = [0, 2, 1] := by
  native_decide

theorem c8c2_orbit_module_types :
    irOrbitModuleTypes irC2SquareSheetNeg irC8C2Carry = [0, 0, 1, 1] := by
  native_decide

theorem c4c4_orbit_module_types :
    irOrbitModuleTypes irC4SheetNeg irZeroCarry = [0, 2, 0] := by
  native_decide

theorem c4c2c2_orbit_module_types :
    irOrbitModuleTypes irC2SquareSheetNeg irZeroCarry = [0, 0, 0, 0] := by
  native_decide

theorem c16_spectral_carry_criterion :
    irCarrySpectralIdentity irC16Inverse true = true := by
  native_decide

theorem c8c2_spectral_carry_criterion :
    irCarrySpectralIdentity irC8C2Inverse true = true := by
  native_decide

theorem c4c4_spectral_carry_criterion :
    irCarrySpectralIdentity irC4C4Inverse false = true := by
  native_decide

theorem c4c2c2_spectral_carry_criterion :
    irCarrySpectralIdentity irC4C2C2Inverse false = true := by
  native_decide

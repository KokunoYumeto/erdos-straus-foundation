import Mathlib

/-!
This file certifies the finite permutation relations used by the order-eight
support-to-eight-cell bridge.  The four cell labels are ordered as the fixed
apex followed by the three face cells.  The two sheet labels form the first
factor.
-/

def eightFaceCycle : Fin 4 → Fin 4 :=
  ![0, 3, 1, 2]

def eightFaceReflection : Fin 4 → Fin 4 :=
  ![0, 2, 1, 3]

def eightSheetFlip : Fin 2 → Fin 2 :=
  ![1, 0]

def eightPhase (x : Fin 2 × Fin 4) : Fin 2 × Fin 4 :=
  (x.1, eightFaceCycle x.2)

def eightDiagonalReflection (x : Fin 2 × Fin 4) : Fin 2 × Fin 4 :=
  (x.1, eightFaceReflection x.2)

def eightCrossedReflection (x : Fin 2 × Fin 4) : Fin 2 × Fin 4 :=
  (eightSheetFlip x.1, eightFaceReflection x.2)

def eightIsFace (x : Fin 2 × Fin 4) : Prop :=
  x.2 ≠ 0

theorem eight_face_cycle_order_three (x : Fin 4) :
    eightFaceCycle (eightFaceCycle (eightFaceCycle x)) = x := by
  fin_cases x <;> rfl

theorem eight_face_reflection_order_two (x : Fin 4) :
    eightFaceReflection (eightFaceReflection x) = x := by
  fin_cases x <;> rfl

theorem eight_face_dihedral_relation (x : Fin 4) :
    eightFaceReflection (eightFaceCycle (eightFaceReflection x)) =
      eightFaceCycle (eightFaceCycle x) := by
  fin_cases x <;> rfl

theorem eight_diagonal_reflection_order_two (x : Fin 2 × Fin 4) :
    eightDiagonalReflection (eightDiagonalReflection x) = x := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;> rfl

theorem eight_crossed_reflection_order_two (x : Fin 2 × Fin 4) :
    eightCrossedReflection (eightCrossedReflection x) = x := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;> rfl

theorem eight_diagonal_d3_relation (x : Fin 2 × Fin 4) :
    eightDiagonalReflection (eightPhase (eightDiagonalReflection x)) =
      eightPhase (eightPhase x) := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;> rfl

theorem eight_crossed_d3_relation (x : Fin 2 × Fin 4) :
    eightCrossedReflection (eightPhase (eightCrossedReflection x)) =
      eightPhase (eightPhase x) := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;> rfl

theorem eight_phase_preserves_face (x : Fin 2 × Fin 4) :
    eightIsFace (eightPhase x) ↔ eightIsFace x := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;>
    simp [eightIsFace, eightPhase, eightFaceCycle]

theorem eight_diagonal_reflection_preserves_face (x : Fin 2 × Fin 4) :
    eightIsFace (eightDiagonalReflection x) ↔ eightIsFace x := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;>
    simp [eightIsFace, eightDiagonalReflection, eightFaceReflection]

theorem eight_crossed_reflection_preserves_face (x : Fin 2 × Fin 4) :
    eightIsFace (eightCrossedReflection x) ↔ eightIsFace x := by
  rcases x with ⟨sheet, cell⟩
  fin_cases sheet <;> fin_cases cell <;>
    simp [eightIsFace, eightCrossedReflection, eightSheetFlip,
      eightFaceReflection]

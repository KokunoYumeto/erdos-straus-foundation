import Mathlib

theorem hard_locus_reduced_coordinate_identities
    (k : ℕ) :
    (24 * k + 1 + 7) / 8 = 3 * k + 1 ∧
    (24 * k + 1 + 11) / 12 = 2 * k + 1 ∧
    8 * (3 * k + 1) - 7 = 24 * k + 1 ∧
    12 * (2 * k + 1) - 11 = 24 * k + 1 ∧
    3 * (2 * k + 1) - 2 * (3 * k + 1) = 1 := by
  omega

theorem hard_locus_forced_factor_identities
    (k : ℕ) :
    (24 * k + 1 + 7) / 4 = 2 * (3 * k + 1) ∧
    (24 * k + 1 + 11) / 4 = 3 * (2 * k + 1) := by
  omega

theorem hard_locus_reduced_coordinates_coprime
    (k : ℕ) :
    Nat.Coprime (3 * k + 1) (2 * k + 1) := by
  rw [Nat.coprime_iff_gcd_eq_one]
  let g := Nat.gcd (3 * k + 1) (2 * k + 1)
  have hc : g ∣ 3 * k + 1 := Nat.gcd_dvd_left _ _
  have hd : g ∣ 2 * k + 1 := Nat.gcd_dvd_right _ _
  have h3d : g ∣ 3 * (2 * k + 1) :=
    dvd_mul_of_dvd_right hd 3
  have h2c : g ∣ 2 * (3 * k + 1) :=
    dvd_mul_of_dvd_right hc 2
  have hdiff :
      3 * (2 * k + 1) - 2 * (3 * k + 1) = 1 := by
    omega
  have hone : g ∣ 1 := by
    rw [← hdiff]
    exact Nat.dvd_sub h3d h2c
  exact Nat.eq_one_of_dvd_one hone

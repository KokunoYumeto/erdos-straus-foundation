import Mathlib

/-!
This file independently certifies the exact balance among the minimum
sheet-cell correlation deficit, the mixer-blade count, the irreducible
D8 spectral defect, and the carrier extension indicator.
-/

structure SpectralSupportDatum where
  correlationDefect : Nat
  bladeBlocks : Nat
  spectralDefect : Nat
  extensionIndicator : Nat
deriving DecidableEq, Repr

def c16SpectralSupportDatum : SpectralSupportDatum :=
  ⟨3, 1, 1, 1⟩

def c8c2SpectralSupportDatum : SpectralSupportDatum :=
  ⟨2, 2, 2, 1⟩

def c4c4SpectralSupportDatum : SpectralSupportDatum :=
  ⟨0, 4, 0, 0⟩

def c4c2c2SpectralSupportDatum : SpectralSupportDatum :=
  ⟨0, 4, 0, 0⟩

def spectralSupportBalance (datum : SpectralSupportDatum) : Prop :=
  datum.correlationDefect + datum.bladeBlocks = 4 ∧
  datum.correlationDefect + datum.spectralDefect =
    4 * datum.extensionIndicator ∧
  datum.bladeBlocks =
    datum.spectralDefect + 4 * (1 - datum.extensionIndicator) ∧
  datum.spectralDefect =
    datum.extensionIndicator * datum.bladeBlocks

theorem c16_spectral_support_balance :
    spectralSupportBalance c16SpectralSupportDatum := by
  norm_num [spectralSupportBalance, c16SpectralSupportDatum]

theorem c8c2_spectral_support_balance :
    spectralSupportBalance c8c2SpectralSupportDatum := by
  norm_num [spectralSupportBalance, c8c2SpectralSupportDatum]

theorem c4c4_spectral_support_balance :
    spectralSupportBalance c4c4SpectralSupportDatum := by
  norm_num [spectralSupportBalance, c4c4SpectralSupportDatum]

theorem c4c2c2_spectral_support_balance :
    spectralSupportBalance c4c2c2SpectralSupportDatum := by
  norm_num [spectralSupportBalance, c4c2c2SpectralSupportDatum]

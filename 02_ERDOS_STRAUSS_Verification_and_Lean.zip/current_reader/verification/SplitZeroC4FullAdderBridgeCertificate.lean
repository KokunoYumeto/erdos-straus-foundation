import Mathlib

/-!
This file certifies the four-row bridge from split-zero endpoint bits
to the visible and hidden bits of a marked C4 coordinate.
-/

abbrev SB2 := Fin 2
abbrev SC4 := Fin 4

def sbVisible (x y : SB2) : SB2 := x + y

def sbHidden (x y : SB2) : SB2 := x * y

def sbClass (x y : SB2) : SC4 :=
  ⟨x.val + y.val, by omega⟩

def sbDirection (x y : SB2) : Int :=
  (y.val : Int) - (x.val : Int)

def sbPolarCoefficient (x y : SB2) : Int :=
  sbDirection x y * sbDirection x y

def sbTimelikeCoefficient (x y : SB2) : Nat :=
  x.val * y.val

def sbFromBits (q h : SB2) : SC4 :=
  ⟨q.val + 2 * h.val, by omega⟩

def sbBitAdd (u v : SB2 × SB2) : SB2 × SB2 :=
  (u.1 + v.1, u.2 + v.2 + u.1 * v.1)

theorem split_zero_class_digit_decomposition (x y : SB2) :
    sbFromBits (sbVisible x y) (sbHidden x y) = sbClass x y := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem endpoint_sum_is_coupled_visible_only_addition (x y : SB2) :
    sbBitAdd (x, 0) (y, 0) = (sbVisible x y, sbHidden x y) := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem polar_coefficient_recovers_visible_bit (x y : SB2) :
    sbPolarCoefficient x y = ((sbVisible x y).val : Int) := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem timelike_coefficient_recovers_hidden_bit (x y : SB2) :
    sbTimelikeCoefficient x y = (sbHidden x y).val := by
  fin_cases x <;> fin_cases y <;> native_decide

theorem class_and_direction_recover_ordered_endpoints :
    Function.Injective
      (fun u : SB2 × SB2 =>
        (sbClass u.1 u.2, sbDirection u.1 u.2)) := by
  native_decide

theorem one_sided_energy_degeneracy_and_direction_separation :
    (sbVisible 1 0, sbHidden 1 0) =
        (sbVisible 0 1, sbHidden 0 1) ∧
      sbDirection 1 0 = -1 ∧
      sbDirection 0 1 = 1 := by
  native_decide

theorem class_three_is_absent_from_one_endpoint_pair :
    ∀ x y : SB2, sbClass x y ≠ (3 : SC4) := by
  native_decide

theorem class_three_occurs_in_the_generated_closure :
    sbClass 1 0 + sbClass 1 1 = (3 : SC4) := by
  native_decide

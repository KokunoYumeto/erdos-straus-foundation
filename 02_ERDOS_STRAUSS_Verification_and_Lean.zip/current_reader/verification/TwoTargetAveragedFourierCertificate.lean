import Mathlib

open scoped BigOperators

namespace TwoTargetAveragedFourierCertificate

theorem two_target_average_bound
    {ι : Type*} [Fintype ι]
    (coeff left right : ι → ℂ)
    (mass : ℝ)
    (mass_nonnegative : 0 ≤ mass)
    (left_missing :
      ∑ index, coeff index * left index = -(mass : ℂ))
    (right_missing :
      ∑ index, coeff index * right index = -(mass : ℂ)) :
    2 * mass ≤
      ∑ index, ‖coeff index‖ * ‖left index + right index‖ := by
  have combined :
      ∑ index, coeff index * (left index + right index) =
        -((2 * mass : ℝ) : ℂ) := by
    calc
      ∑ index, coeff index * (left index + right index) =
          (∑ index, coeff index * left index) +
          (∑ index, coeff index * right index) := by
            simp only [mul_add, Finset.sum_add_distrib]
      _ = -(mass : ℂ) + -(mass : ℂ) := by
            rw [left_missing, right_missing]
      _ = -((2 * mass : ℝ) : ℂ) := by
            push_cast
            ring
  calc
    2 * mass = ‖-((2 * mass : ℝ) : ℂ)‖ := by
      simp [abs_of_nonneg mass_nonnegative]
    _ = ‖∑ index, coeff index * (left index + right index)‖ := by
      rw [combined]
    _ ≤ ∑ index, ‖coeff index * (left index + right index)‖ :=
      norm_sum_le _ _
    _ = ∑ index, ‖coeff index‖ * ‖left index + right index‖ := by
      apply Finset.sum_congr rfl
      intro index _
      exact norm_mul _ _

theorem two_target_filtered_bound
    {ι : Type*} [Fintype ι]
    (coeff left right : ι → ℂ)
    (mass : ℝ)
    (mass_nonnegative : 0 ≤ mass)
    (left_missing :
      ∑ index, coeff index * left index = -(mass : ℂ))
    (right_missing :
      ∑ index, coeff index * right index = -(mass : ℂ)) :
    mass ≤
      ∑ index,
        ‖coeff index‖ * (‖left index + right index‖ / 2) := by
  have doubled :=
    two_target_average_bound
      coeff
      left
      right
      mass
      mass_nonnegative
      left_missing
      right_missing
  calc
    mass = (2 * mass) / 2 := by ring
    _ ≤
        (∑ index, ‖coeff index‖ * ‖left index + right index‖) / 2 := by
          exact div_le_div_of_nonneg_right doubled (by norm_num)
    _ =
        ∑ index,
          ‖coeff index‖ * (‖left index + right index‖ / 2) := by
          rw [Finset.sum_div]
          apply Finset.sum_congr rfl
          intro index _
          ring

theorem paired_phase_filter
    {ι : Type*} [Fintype ι]
    (coeff left right ratio : ι → ℂ)
    (mass : ℝ)
    (mass_nonnegative : 0 ≤ mass)
    (left_missing :
      ∑ index, coeff index * left index = -(mass : ℂ))
    (right_missing :
      ∑ index, coeff index * right index = -(mass : ℂ))
    (right_is_rotated :
      ∀ index, right index = left index * ratio index)
    (left_is_unit :
      ∀ index, ‖left index‖ = 1) :
    mass ≤
      ∑ index,
        ‖coeff index‖ * (‖1 + ratio index‖ / 2) := by
  have filtered :=
    two_target_filtered_bound
      coeff
      left
      right
      mass
      mass_nonnegative
      left_missing
      right_missing
  calc
    mass ≤
        ∑ index,
          ‖coeff index‖ * (‖left index + right index‖ / 2) :=
      filtered
    _ =
        ∑ index,
          ‖coeff index‖ * (‖1 + ratio index‖ / 2) := by
          apply Finset.sum_congr rfl
          intro index _
          rw [right_is_rotated index]
          have factor :
              left index + left index * ratio index =
                left index * (1 + ratio index) := by ring
          rw [factor, norm_mul, left_is_unit index, one_mul]

end TwoTargetAveragedFourierCertificate

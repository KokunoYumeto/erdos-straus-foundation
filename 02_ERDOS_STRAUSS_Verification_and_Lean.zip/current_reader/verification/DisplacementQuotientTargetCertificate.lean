import Mathlib.Data.Set.Basic

open Set

theorem complete_target_fibre_forcing
    {α β : Type*}
    (π : α → β)
    (C U : Set α)
    (T : Set β)
    (hU : U = π ⁻¹' T)
    (hproj : (π '' C ∩ T).Nonempty) :
    (C ∩ U).Nonempty := by
  rcases hproj with ⟨y, ⟨x, hx, rfl⟩, hT⟩
  refine ⟨x, hx, ?_⟩
  rw [hU]
  exact hT

theorem projected_surplus_forces_complete_target_fibre
    {α β : Type*}
    (π : α → β)
    (C U : Set α)
    (T : Set β)
    (hU : U = π ⁻¹' T)
    (hKneser : (π '' C ∩ T).Nonempty) :
    (C ∩ U).Nonempty :=
  complete_target_fibre_forcing π C U T hU hKneser

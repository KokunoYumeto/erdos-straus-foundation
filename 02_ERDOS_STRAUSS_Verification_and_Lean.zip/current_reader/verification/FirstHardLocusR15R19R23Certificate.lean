import Mathlib

theorem hard_locus_next_three_affine_coordinates
    (k : ℕ) :
    (24 * k + 1 + 15) / 4 = 6 * k + 4 ∧
    (24 * k + 1 + 19) / 4 = 6 * k + 5 ∧
    (24 * k + 1 + 23) / 4 = 6 * k + 6 ∧
    (24 * k + 1 + 23) / 12 = 2 * k + 2 := by
  omega

theorem hard_locus_next_three_reduced_coordinates
    (k : ℕ) :
    6 * k + 4 = 2 * ((3 * k + 1) + 1) ∧
    6 * k + 5 = 2 * (3 * k + 1) + 3 ∧
    6 * k + 5 = 3 * (2 * k + 1) + 2 ∧
    6 * k + 6 = 3 * ((2 * k + 1) + 1) := by
  omega

theorem first_hard_locus_exterior_witness :
    17 ∣ 306 ∧
    23 ∣ 4 * 17 + 1 ∧
    306 + 1201 * 17 = 23 * 901 ∧
    1201 * 901 = 1082101 ∧
    306 * 901 / 17 = 16218 := by
  norm_num

theorem first_hard_locus_unit_fraction_identity :
    (4 : ℚ) / 1201 =
      1 / 306 + 1 / 1082101 + 1 / 16218 := by
  norm_num

theorem hard_locus_3361_exterior_witness :
    68 ∣ 850 ^ 2 ∧
    39 ∣ 4 * 68 + 1 ∧
    850 + 3361 * 68 = 39 * 5882 ∧
    3361 * 5882 = 19769402 ∧
    850 * 5882 / 68 = 73525 := by
  norm_num

theorem hard_locus_3361_unit_fraction_identity :
    (4 : ℚ) / 3361 =
      1 / 850 + 1 / 19769402 + 1 / 73525 := by
  norm_num

theorem hard_locus_8089_exterior_witness :
    116 ∣ 2030 ^ 2 ∧
    31 ∣ 4 * 116 + 1 ∧
    2030 + 8089 * 116 = 31 * 30334 ∧
    8089 * 30334 = 245371726 ∧
    2030 * 30334 / 116 = 530845 := by
  norm_num

theorem hard_locus_8089_unit_fraction_identity :
    (4 : ℚ) / 8089 =
      1 / 2030 + 1 / 245371726 + 1 / 530845 := by
  norm_num

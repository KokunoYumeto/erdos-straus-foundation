import Mathlib

/-!
This file certifies the two marked order-four quotient models for abelian
groups of order sixteen and the detection kernel of the binary carry
character.
-/

abbrev C2 := Fin 2
abbrev C4 := Fin 4

def liftC2 (x : C2) : C4 :=
  Fin.castLE (by decide) x

def cyclicCarry (a u v : C4) : C4 :=
  if 4 ≤ u.val + v.val then a else 0

def cyclicAdd (a : C4) (x y : C4 × C4) : C4 × C4 :=
  (x.1 + y.1, x.2 + y.2 + cyclicCarry a x.1 y.1)

def binaryCarry
    (a b : C2) (u v : C2 × C2) : C4 :=
  liftC2 (a * u.1 * v.1) + liftC2 (b * u.2 * v.2)

def binaryAdd
    (a b : C2)
    (x y : (C2 × C2) × C4) : (C2 × C2) × C4 :=
  ((x.1.1 + y.1.1, x.1.2 + y.1.2),
    x.2 + y.2 + binaryCarry a b x.1 y.1)

def addMultiple
    {α : Type*} (zero : α) (add : α → α → α) :
    Nat → α → α
  | 0, _ => zero
  | n + 1, x => add (addMultiple zero add n x) x

def killedCount
    {α : Type*} [Fintype α] [DecidableEq α]
    (zero : α) (add : α → α → α) (n : Nat) : Nat :=
  (Finset.univ.filter fun x => addMultiple zero add n x = zero).card

def cyclicQWeight (a : C4) : Nat :=
  (Finset.univ.filter fun u : C4 =>
    u + u = 0 ∧ (cyclicCarry a u u).val % 2 = 1).card

def binaryQWeight (a b : C2) : Nat :=
  (Finset.univ.filter fun u : C2 × C2 =>
    (binaryCarry a b u u).val % 2 = 1).card

def c4Elements : List C4 :=
  List.finRange 4

def c2Elements : List C2 :=
  List.finRange 2

def binaryElements : List (C2 × C2) :=
  c2Elements.flatMap fun first =>
    c2Elements.map fun second => (first, second)

def tableFunction (a0 a1 a2 a3 : C4) (u : C4) : C4 :=
  if u = 0 then a0
  else if u = 1 then a1
  else if u = 2 then a2
  else a3

def c4Functions : List (C4 → C4) :=
  c4Elements.flatMap fun a0 =>
    c4Elements.flatMap fun a1 =>
      c4Elements.flatMap fun a2 =>
        c4Elements.map fun a3 =>
          tableFunction a0 a1 a2 a3

def binaryIndex (u : C2 × C2) : C4 :=
  if u = (0, 0) then 0
  else if u = (0, 1) then 1
  else if u = (1, 0) then 2
  else 3

def binaryFunctions : List ((C2 × C2) → C4) :=
  c4Functions.map fun f => fun u => f (binaryIndex u)

def cyclicCoboundary (a : C4) : Bool :=
  c4Functions.any fun f =>
    decide (f 0 = 0) &&
      c4Elements.all fun u =>
        c4Elements.all fun v =>
          decide
            (cyclicCarry a u v = f u + f v - f (u + v))

def binaryCoboundary (a b : C2) : Bool :=
  binaryFunctions.any fun f =>
    decide (f (0, 0) = 0) &&
      binaryElements.all fun u =>
        binaryElements.all fun v =>
          decide
            (binaryCarry a b u v = f u + f v - f (u + v))

theorem cyclic_carriers_are_associative (a : C4) :
    ∀ x y z,
      cyclicAdd a (cyclicAdd a x y) z =
        cyclicAdd a x (cyclicAdd a y z) := by
  fin_cases a <;> native_decide

theorem binary_carriers_are_associative (a b : C2) :
    ∀ x y z,
      binaryAdd a b (binaryAdd a b x y) z =
        binaryAdd a b x (binaryAdd a b y z) := by
  fin_cases a <;> fin_cases b <;> native_decide

theorem cyclic_class_zero_kernel_counts :
    killedCount (0, 0) (cyclicAdd 0) 2 = 4 ∧
    killedCount (0, 0) (cyclicAdd 0) 4 = 16 := by
  native_decide

theorem cyclic_class_one_kernel_counts :
    killedCount (0, 0) (cyclicAdd 1) 2 = 2 ∧
    killedCount (0, 0) (cyclicAdd 1) 4 = 4 ∧
    killedCount (0, 0) (cyclicAdd 1) 8 = 8 ∧
    killedCount (0, 0) (cyclicAdd 1) 16 = 16 := by
  native_decide

theorem cyclic_class_two_kernel_counts :
    killedCount (0, 0) (cyclicAdd 2) 2 = 4 ∧
    killedCount (0, 0) (cyclicAdd 2) 4 = 8 ∧
    killedCount (0, 0) (cyclicAdd 2) 8 = 16 := by
  native_decide

theorem cyclic_class_three_kernel_counts :
    killedCount (0, 0) (cyclicAdd 3) 2 = 2 ∧
    killedCount (0, 0) (cyclicAdd 3) 4 = 4 ∧
    killedCount (0, 0) (cyclicAdd 3) 8 = 8 ∧
    killedCount (0, 0) (cyclicAdd 3) 16 = 16 := by
  native_decide

theorem cyclic_carry_weights :
    cyclicQWeight 0 = 0 ∧
    cyclicQWeight 1 = 1 ∧
    cyclicQWeight 2 = 0 ∧
    cyclicQWeight 3 = 1 := by
  native_decide

theorem cyclic_class_two_is_invisible_and_nonsplit :
    cyclicQWeight 2 = 0 ∧ cyclicCoboundary 2 = false := by
  native_decide

theorem binary_zero_kernel_counts :
    killedCount ((0, 0), 0) (binaryAdd 0 0) 2 = 8 ∧
    killedCount ((0, 0), 0) (binaryAdd 0 0) 4 = 16 := by
  native_decide

theorem binary_01_kernel_counts :
    killedCount ((0, 0), 0) (binaryAdd 0 1) 2 = 4 ∧
    killedCount ((0, 0), 0) (binaryAdd 0 1) 4 = 8 ∧
    killedCount ((0, 0), 0) (binaryAdd 0 1) 8 = 16 := by
  native_decide

theorem binary_10_kernel_counts :
    killedCount ((0, 0), 0) (binaryAdd 1 0) 2 = 4 ∧
    killedCount ((0, 0), 0) (binaryAdd 1 0) 4 = 8 ∧
    killedCount ((0, 0), 0) (binaryAdd 1 0) 8 = 16 := by
  native_decide

theorem binary_11_kernel_counts :
    killedCount ((0, 0), 0) (binaryAdd 1 1) 2 = 4 ∧
    killedCount ((0, 0), 0) (binaryAdd 1 1) 4 = 8 ∧
    killedCount ((0, 0), 0) (binaryAdd 1 1) 8 = 16 := by
  native_decide

theorem binary_carry_weights :
    binaryQWeight 0 0 = 0 ∧
    binaryQWeight 0 1 = 2 ∧
    binaryQWeight 1 0 = 2 ∧
    binaryQWeight 1 1 = 2 := by
  native_decide

theorem binary_coboundary_table :
    binaryCoboundary 0 0 = true ∧
    binaryCoboundary 0 1 = false ∧
    binaryCoboundary 1 0 = false ∧
    binaryCoboundary 1 1 = false := by
  native_decide

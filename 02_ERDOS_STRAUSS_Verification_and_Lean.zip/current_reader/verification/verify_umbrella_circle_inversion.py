from sympy import I, Matrix, Rational, cancel, eye, factor, simplify, symbols


def assert_matrix(actual, expected, label):
    delta = actual - expected
    if any(simplify(entry) != 0 for entry in delta):
        raise AssertionError(f"{label}: {actual} != {expected}")


a, b0, b1, c = symbols("a b0 b1 c")
A, B0, B1, C = symbols("A B0 B1 C", nonzero=True)
x, y = symbols("x y")
alpha = symbols("alpha", nonzero=True)

v = Matrix([a, b0, b1, c])
Delta = B0**2 + B1**2 - A * C

M = Matrix(
    [
        [B0**2 + B1**2, -2 * A * B0, -2 * A * B1, A**2],
        [B0 * C, B1**2 - B0**2 - A * C, -2 * B0 * B1, A * B0],
        [B1 * C, -2 * B0 * B1, B0**2 - B1**2 - A * C, A * B1],
        [C**2, -2 * C * B0, -2 * C * B1, B0**2 + B1**2],
    ]
) / A**2

# The symmetric coefficient-space form satisfies v^T G v=b0^2+b1^2-ac.
G = Matrix(
    [
        [0, 0, 0, Rational(-1, 2)],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [Rational(-1, 2), 0, 0, 0],
    ]
)
scale2 = Delta**2 / A**4
assert_matrix(M.T * G * M, scale2 * G, "Lorentz-form covariance")
assert_matrix(M * M, scale2 * eye(4), "projective involution square")

# Coefficient-level transcription of the full expanded inverse-circle equation.
coeff = M * v
expected = Matrix(
    [
        (
            a * (B0**2 + B1**2)
            - 2 * A * (b0 * B0 + b1 * B1)
            + c * A**2
        )
        / A**2,
        (
            b0 * (B1**2 - B0**2 - A * C)
            + a * B0 * C
            - 2 * b1 * B0 * B1
            + c * A * B0
        )
        / A**2,
        (
            b1 * (B0**2 - B1**2 - A * C)
            + a * B1 * C
            - 2 * b0 * B0 * B1
            + c * A * B1
        )
        / A**2,
        (
            a * C**2
            - 2 * b0 * B0 * C
            - 2 * b1 * B1 * C
            + c * (B0**2 + B1**2)
        )
        / A**2,
    ]
)
assert_matrix(coeff, expected, "expanded inverse-circle coefficients")


def q(vector, xx, yy):
    aa, bb0, bb1, cc = vector
    return aa * (xx**2 + yy**2) + 2 * (bb0 * xx - bb1 * yy) + cc


# Pointwise evaluation covariance under the geometric circle inversion.
ox = -B0 / A
oy = B1 / A
distance2 = (x - ox) ** 2 + (y - oy) ** 2
image_x = ox + (Delta / A**2) * (x - ox) / distance2
image_y = oy + (Delta / A**2) * (y - oy) / distance2
evaluation_defect = cancel(q(coeff, x, y) - distance2 * q(v, image_x, image_y))
assert evaluation_defect == 0

# The unit circle gives exact coefficient reversal.
unit_substitution = {A: 1, B0: 0, B1: 0, C: -1}
unit_matrix = simplify(M.subs(unit_substitution))
coefficient_reversal = Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
assert_matrix(unit_matrix, coefficient_reversal, "unit-circle coefficient reversal")

# Directed and transposed axial carriers retain the reciprocal raw scales.
w_directed = {A: 4, B0: 0, B1: 0, C: -1}
w_transposed = {A: -1, B0: 0, B1: 0, C: 4}
I_minus = simplify(M.subs(w_directed))
I_plus = simplify(M.subs(w_transposed))
expected_I_minus = Matrix(
    [
        [0, 0, 0, 1],
        [0, Rational(1, 4), 0, 0],
        [0, 0, Rational(1, 4), 0],
        [Rational(1, 16), 0, 0, 0],
    ]
)
expected_I_plus = Matrix(
    [
        [0, 0, 0, 1],
        [0, 4, 0, 0],
        [0, 0, 4, 0],
        [16, 0, 0, 0],
    ]
)
assert_matrix(I_minus, expected_I_minus, "directed quarter inversion")
assert_matrix(I_plus, expected_I_plus, "transposed four inversion")
assert_matrix(coefficient_reversal * I_minus * coefficient_reversal, I_plus.inv(), "reciprocal sheet exchange")

# General axial formulas, with all coefficient scales retained.
M_alpha = simplify(M.subs({A: 4, B0: 0, B1: 0, C: -4 * alpha}))
M_alpha_dual = simplify(M.subs({A: -4 * alpha, B0: 0, B1: 0, C: 4}))
expected_alpha = Matrix([c, alpha * b0, alpha * b1, alpha**2 * a])
expected_alpha_dual = Matrix([c, b0 / alpha, b1 / alpha, a / alpha**2])
assert_matrix(M_alpha * v, expected_alpha, "directed axial coefficient formula")
assert_matrix(M_alpha_dual * v, expected_alpha_dual, "transposed axial coefficient formula")

# The three Fable point-circle rays lie on the directed +1/4 eigenspace.
sqrt3 = symbols("sqrt3", positive=True)
fable_rays = (
    Matrix([4, 0, 2, 1]),
    Matrix([4, sqrt3, -1, 1]),
    Matrix([4, -sqrt3, -1, 1]),
)
for index, ray in enumerate(fable_rays):
    assert_matrix(I_minus * ray, Rational(1, 4) * ray, f"Fable quarter ray {index}")
    assert simplify((ray.T * G * ray)[0].subs(sqrt3**2, 3)) == 0

# The Hermitian Möbius carrier exchanges the two ordered branch circles and
# fixes the time orientation while reversing the two indicated Lorentz axes.
K_directed = Matrix.diag(4, -1)
K_transposed = Matrix.diag(-1, 4)
S = Matrix([[0, 1], [1, 0]])
P = I * S
assert simplify(P.det()) == 1
assert_matrix(P.inv().conjugate().T * K_directed * P.inv(), K_transposed, "branch-circle Mobius reciprocity")

C_mobius = Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, -1, 0],
        [1, 0, 0, 0],
    ]
)
to_lorentz = Matrix(
    [
        [Rational(1, 2), 0, 0, Rational(1, 2)],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [Rational(1, 2), 0, 0, Rational(-1, 2)],
    ]
)
lorentz_action = simplify(to_lorentz * C_mobius * to_lorentz.inv())
assert_matrix(lorentz_action, Matrix.diag(1, 1, -1, -1), "branch-circle Lorentz action")
assert simplify(lorentz_action.det()) == 1

U, V = symbols("U V")
u = Matrix([U, V])
fable_cubic = U**2 * V - Rational(1, 4) * V**3
fable_cubic_transposed = V**2 * U - Rational(1, 4) * U**3
assert factor(V * (u.T * K_directed * u)[0] - 4 * fable_cubic) == 0
assert factor(U * (u.T * K_transposed * u)[0] - 4 * fable_cubic_transposed) == 0

print("PASS UmbrellaCorp_HR expanded inverse-circle coefficient transcription")
print("PASS Lorentz covariance and projective involution square")
print("PASS pointwise Euclidean inversion evaluation covariance")
print("PASS unit-circle coefficient reversal")
print("PASS directed/transposed axial formulas with reciprocal raw scales")
print("PASS three Fable point-circle rays lie on the directed quarter eigenspace")
print("PASS Hermitian Mobius reciprocity gives Lorentz action diag(1,1,-1,-1)")
print("PASS directed and transposed branch-circle restrictions recover the Fable cubic")

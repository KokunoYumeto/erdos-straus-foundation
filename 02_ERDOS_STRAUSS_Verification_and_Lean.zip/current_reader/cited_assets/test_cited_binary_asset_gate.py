#!/usr/bin/env python3
"""Negative-fixture tests for the cited binary-asset safety gate."""

from __future__ import annotations

import io
import json
import runpy
from pathlib import Path

from pypdf import PdfWriter


REPO = Path(__file__).resolve().parents[1]
BUILDER = runpy.run_path(str(REPO / "scripts" / "build_live_successor_reader.py"))
PDF_GATE = BUILDER["pdf_asset_gate"]
RECEIPT = REPO / "release_work" / "cited_binary_asset_gate_test.json"


def pdf_bytes(configure) -> bytes:
    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    writer.add_metadata({"/Author": "The Clankers", "/Title": "Gate fixture"})
    configure(writer)
    stream = io.BytesIO()
    writer.write(stream)
    return stream.getvalue()


def expect_failure(label: str, raw: bytes) -> str:
    try:
        PDF_GATE(label + ".pdf", raw)
    except (ValueError, RuntimeError):
        return "PASS_REJECTED"
    raise AssertionError(f"unsafe PDF fixture passed: {label}")


def main() -> int:
    results: dict[str, str] = {}
    positive = pdf_bytes(lambda writer: None)
    PDF_GATE("positive.pdf", positive)
    results["positive_minimal"] = "PASS_ACCEPTED"

    results["javascript"] = expect_failure(
        "javascript",
        pdf_bytes(lambda writer: writer.add_js("app.alert('fixture')")),
    )
    results["embedded_file"] = expect_failure(
        "embedded_file",
        pdf_bytes(lambda writer: writer.add_attachment("fixture.txt", b"fixture")),
    )

    def add_private_metadata(writer: PdfWriter) -> None:
        generic_private_path = "C:" + "\\" + "Users" + "\\" + "Example" + "\\" + "private"
        writer.add_metadata({"/Author": generic_private_path})

    results["private_profile_metadata"] = expect_failure(
        "private_profile_metadata",
        pdf_bytes(add_private_metadata),
    )

    def encrypt(writer: PdfWriter) -> None:
        writer.encrypt("fixture-password")

    results["encrypted"] = expect_failure("encrypted", pdf_bytes(encrypt))
    payload = {
        "schema": "erdos-straus-cited-binary-asset-gate-test-r1",
        "status": "PASS",
        "results": results,
    }
    RECEIPT.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Verify the immutable-to-public contract for reader-cited binary assets."""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


REPO = Path(__file__).resolve().parents[1]
POINTER = REPO / "release_work" / "current_maintained_checkpoint.json"
SOURCE_ZIP = REPO / "release_work" / "live_successor_built" / "01_ERDOS_STRAUSS_Reader_Source_and_Build.zip"
RECEIPT = REPO / "release_work" / "cited_asset_release_contract.json"
INCLUDEGRAPHICS = re.compile(
    r"\\includegraphics(?:\s*\[[^\]]*\])?\s*\{([^{}]+)\}",
    re.DOTALL,
)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def clean_latex_path(value: str) -> str:
    value = value.replace(r"\_", "_").replace("\\", "/").strip()
    return re.sub(r"/+", "/", value)


def load_json(path: Path) -> dict[str, object]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path.name}")
    return value


def atomic_json(path: Path, payload: dict[str, object]) -> None:
    raw = (json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + ".", delete=False) as handle:
        handle.write(raw)
        temporary = Path(handle.name)
    os.replace(temporary, path)


def contract_failures(
    references: set[str],
    assets: dict[str, dict[str, object]],
    members: dict[str, bytes],
    manifest_rows: dict[str, dict[str, str]],
    sums: dict[str, str],
) -> list[str]:
    failures: list[str] = []
    if references != set(assets):
        failures.append("reference_asset_map_mismatch")
    expected_figure_members = {"reader/" + name for name in assets}
    actual_figure_members = {name for name in members if name.startswith("reader/figures/")}
    if actual_figure_members != expected_figure_members:
        failures.append("reader_figure_member_universe_mismatch")
    for name, identity in assets.items():
        expected_hash = str(identity["sha256"]).casefold()
        public_name = "reader/" + name
        raw = members.get(public_name)
        if raw is None:
            failures.append(f"missing_exact_member:{public_name}")
            continue
        if digest(raw) != expected_hash:
            failures.append(f"zip_hash_mismatch:{public_name}")
        row = manifest_rows.get(public_name)
        if row is None:
            failures.append(f"missing_manifest_row:{public_name}")
        elif (
            row.get("role") != "reader_cited_figure"
            or row.get("source_sha256", "").casefold() != expected_hash
            or row.get("public_sha256", "").casefold() != expected_hash
            or row.get("transformation") != "byte_exact"
        ):
            failures.append(f"manifest_identity_mismatch:{public_name}")
        if sums.get(public_name, "").casefold() != expected_hash:
            failures.append(f"checksum_identity_mismatch:{public_name}")
    return sorted(set(failures))


def main() -> int:
    pointer = load_json(POINTER)
    relative = PurePosixPath(str(pointer["relative_path"]))
    if relative.parts[:1] != ("release_work",) or ".." in relative.parts:
        raise ValueError("unsafe checkpoint pointer")
    checkpoint = REPO.joinpath(*relative.parts)
    manifest_path = checkpoint / "CHECKPOINT.json"
    if digest(manifest_path.read_bytes()) != str(pointer["checkpoint_manifest_sha256"]).casefold():
        raise ValueError("checkpoint manifest identity changed")
    checkpoint_manifest = load_json(manifest_path)
    assets_raw = checkpoint_manifest.get("assets", {})
    if not isinstance(assets_raw, dict):
        raise ValueError("checkpoint asset map is malformed")
    assets = {str(name): value for name, value in assets_raw.items() if isinstance(value, dict)}
    if len(assets) != len(assets_raw):
        raise ValueError("checkpoint asset identity is malformed")

    tex = (checkpoint / "es_fable_c123_preprint.tex").read_text(encoding="utf-8-sig")
    references = {clean_latex_path(value) for value in INCLUDEGRAPHICS.findall(tex)}
    for reference in references:
        path = PurePosixPath(reference)
        if path.is_absolute() or ".." in path.parts or path.parts[:1] != ("figures",):
            raise ValueError(f"unsafe figure reference: {reference}")

    with zipfile.ZipFile(SOURCE_ZIP) as archive:
        if archive.testzip() is not None:
            raise ValueError("reader source ZIP has a CRC failure")
        members = {name: archive.read(name) for name in archive.namelist() if not name.endswith("/")}
    rows = csv.DictReader(io.StringIO(members["SOURCE_MANIFEST.csv"].decode("utf-8-sig")))
    manifest_rows = {str(row["path"]): row for row in rows}
    sums: dict[str, str] = {}
    for line in members["SHA256SUMS.txt"].decode("utf-8-sig").splitlines():
        checksum, name = line.split("  ", 1)
        sums[name] = checksum

    failures = contract_failures(references, assets, members, manifest_rows, sums)
    checkpoint_byte_matches = 0
    for name, identity in assets.items():
        raw = (checkpoint.joinpath(*PurePosixPath(name).parts)).read_bytes()
        if digest(raw) != str(identity["sha256"]).casefold():
            failures.append(f"checkpoint_hash_mismatch:{name}")
        elif members.get("reader/" + name) != raw:
            failures.append(f"checkpoint_zip_byte_mismatch:{name}")
        else:
            checkpoint_byte_matches += 1

    negative_fixtures = "SKIPPED_NO_ASSETS"
    if assets:
        sample = sorted(assets)[0]
        expected_member = "reader/" + sample
        missing = dict(members)
        raw = missing.pop(expected_member)
        if not contract_failures(references, assets, missing, manifest_rows, sums):
            raise AssertionError("missing-member negative fixture passed")
        basename_only = dict(missing)
        basename_only["unrelated/" + PurePosixPath(sample).name] = raw
        if not contract_failures(references, assets, basename_only, manifest_rows, sums):
            raise AssertionError("basename-only negative fixture passed")
        flipped = dict(members)
        flipped[expected_member] = bytes([raw[0] ^ 1]) + raw[1:]
        if not contract_failures(references, assets, flipped, manifest_rows, sums):
            raise AssertionError("byte-flip negative fixture passed")
        negative_fixtures = "PASS_MISSING_BASENAME_ONLY_AND_BYTE_FLIP_REJECTED"

    payload: dict[str, object] = {
        "schema": "erdos-straus-cited-asset-contract-r1",
        "status": "PASS" if not failures else "FAIL",
        "checkpoint_id": str(checkpoint_manifest["checkpoint_id"]),
        "reference_count": len(references),
        "asset_count": len(assets),
        "checkpoint_zip_byte_matches": checkpoint_byte_matches,
        "negative_fixtures": negative_fixtures,
        "failures": sorted(set(failures)),
    }
    atomic_json(RECEIPT, payload)
    print(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False))
    return 0 if payload["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

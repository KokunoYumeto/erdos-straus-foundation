# Reader source and research logbook

This archive contains the complete LaTeX sources of the principal paper and the project’s research logbook, together with every figure used by the paper. The included files build the current PDF supplied as `00_ERDOS_STRAUSS_Project_Reader.pdf` in the Zenodo record; the exact page count is recorded in `BUILD_RECEIPT.json`.

The released PDF is a fresh stable build of the frozen source and cited figures. Its body text agrees with an independent build from the same checkpoint.

## Contents

- `reader/erdos_straus_project_reader.tex` — frozen source of *Arithmetic Shells, Finite Support Geometry, and Lorentz Lifts: Exact Identities, Certificates, and Symmetry Constructions*.
- `reader/figures/` — byte-exact vector or raster figures cited by the principal source.
- `reader/BUILD.md` — short build instructions and the expected top-level PDF digest.
- `BUILD_RECEIPT.json` — hash-bound page count and build, figure, privacy, and PDF-safety checks for the released reader.
- `provenance/research_logbook.tex` — append-only source ledger for the corpus reading, calculations, canonicality tests, corrections, and manuscript edits.
- `provenance/research_logbook.pdf` — compiled public copy of that ledger.
- `SOURCE_MANIFEST.csv` — original and public byte identities, roles, and editorial treatment.
- `SHA256SUMS.txt` — SHA-256 digests for the archive members.

The paper is credited to **The Clankers**. Its formulas, theorem environments, bibliography, and source paths are in the principal TeX file. Each cited figure retains the same relative path used by that file and has a byte-identity row in `SOURCE_MANIFEST.csv`.

The logbook’s public copy removes or condenses internal operational wording and replaces a profile-variable path with `Documents/Papors/Chatnotes`. Long paths and SHA-256 strings use breakable, compact typesetting. A closing edition note distinguishes this release copy from the diagnostic PDF described in the ledger. Mathematical statements, evidentiary classes, source coverage, dates, calculations, proof status, counterexamples, and provenance are retained.

The verification and Lean files cited by the paper are collected separately in `02_ERDOS_STRAUSS_Verification_and_Lean.zip`. Historical manuscript families and the first-version correction archive are collected in `03_ERDOS_STRAUSS_Historical_Drafts_and_Corrections.zip`.

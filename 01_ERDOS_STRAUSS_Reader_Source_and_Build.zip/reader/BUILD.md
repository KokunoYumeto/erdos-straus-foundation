# Building the documents

The sources use standard LaTeX packages available in current TeX Live and MiKTeX installations.

From the `reader` directory, run:

```text
pdflatex -interaction=nonstopmode -halt-on-error erdos_straus_project_reader.tex
pdflatex -interaction=nonstopmode -halt-on-error erdos_straus_project_reader.tex
pdflatex -interaction=nonstopmode -halt-on-error erdos_straus_project_reader.tex
```

Keep the included `figures` directory beside the principal TeX file. From the `provenance` directory, run the same three-pass command with `research_logbook.tex`.

The released principal PDF has:

```text
SHA-256  14c306274bb9f5f8591e4fb20de0e903a6f41ab4dc79314309bf4a0e4d07b016
Pages    488
```

PDF producers may encode creation details differently, so a fresh build can have a different byte digest. The theorem text, equations, references, and page content are determined by the supplied source.

# Source provenance

This `Jacobian/` tree is reproduced from
[`JGPTech/Fun`](https://github.com/JGPTech/Fun) at commit
`2fe1901840ef3aa28232930e1aec8d8bbb61281a` (30 July 2026).

It is included so the reader's references to `Jacobian/`, `aceg.py`, and
`blind_search.py` resolve inside the downloadable corpus. Authorship remains
Jon Poplett / u/JGPTech. The upstream source files are unedited.

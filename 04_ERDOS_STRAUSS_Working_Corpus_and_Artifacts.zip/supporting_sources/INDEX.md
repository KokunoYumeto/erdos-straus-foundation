# Supporting sources

The principal reader controls theorem status. Exact duplicate aliases are recorded in `../MANIFEST.csv` or the root `MANIFEST.csv`.

## `arithmetic_time_cpt/`

- `supporting_sources/arithmetic_time_cpt/Arithmetic_Time_CPT_Spectral_Packets_v35_integrated_replacement.tex` — historical or exploratory source

## `JGPTech_Fun/`

- `supporting_sources/JGPTech_Fun/Jacobian/aceg.jl` — historical or exploratory source
- `supporting_sources/JGPTech_Fun/Jacobian/aceg.py` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/aceg.wl` — historical or exploratory source
- `supporting_sources/JGPTech_Fun/Jacobian/aceg_julia_manifest.json` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/aceg_manifest.json` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/aceg_mathematica_manifest.json` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/blind_search.py` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/jacobian_counterexamples_5000.csv` — supporting computation or report
- `supporting_sources/JGPTech_Fun/Jacobian/Local_Fidelity_Global_Alias_Pipeline_Proof.pdf` — historical or exploratory source
- `supporting_sources/JGPTech_Fun/Jacobian/Local_Fidelity_Global_Alias_Pipeline_Proof.tex` — historical or exploratory source
- `supporting_sources/JGPTech_Fun/Jacobian/PROVENANCE.md` — historical or exploratory source
- `supporting_sources/JGPTech_Fun/Jacobian/README.md` — historical or exploratory source

## `qsm_entropy/`

- `supporting_sources/qsm_entropy/43.5.7.tex` — historical or exploratory source

## `sectorial_modular_data/`

- `supporting_sources/sectorial_modular_data/1.tex` — historical or exploratory source
- `supporting_sources/sectorial_modular_data/2.tex` — historical or exploratory source
- `supporting_sources/sectorial_modular_data/3.tex` — historical or exploratory source

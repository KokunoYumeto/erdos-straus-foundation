# CivQ17 source images recovered from the compiled paper

These seven notebook images are credited to Reddit user u/CivQ17. The
standalone source files were absent from the bounded project shelves. Each PNG
in this directory was recovered pixel-for-pixel from the single image object on
the corresponding page of
`sources/target_lineage/extensions/erdos_straus_cubic_phase_residue_lifts.pdf`.

The compiled source PDF has SHA-256
`8734c73f027d4a16e577c3fb7a996e39eabe2d8ea71c824eeca4955df359f1ee`.
Poppler `pdfimages` 24.04.0 extracted image numbers 0 through 6 with the `-png`
option. `RECOVERY_MANIFEST.json` records the PDF page, object number, pixel
dimensions, file hash, and decoded RGB-pixel hash for every recovered image.

The filenames reproduce the `phase_ext_figs/` paths used by the accompanying
LaTeX source. The images document the origin of the constructions. Formal
statements and proofs appear in the numbered results cited by their captions.


#!/usr/bin/env python3
from __future__ import annotations
import csv, math, os
from dataclasses import dataclass
from typing import Optional

MOD = 107
CUTOFF = 13000

try:
    import numpy as np
    from numba import njit
    HAVE_NUMBA = True
except Exception:
    HAVE_NUMBA = False
    np = None
    njit = None


def inv_mod(a:int, m:int=MOD)->Optional[int]:
    a %= m
    if math.gcd(a,m)!=1:
        return None
    return pow(a,-1,m)

def order_mod(a:int, m:int=MOD)->Optional[int]:
    a %= m
    if math.gcd(a,m)!=1:
        return None
    x=1
    for k in range(1,m):
        x = (x*a)%m
        if x==1:
            return k
    return None

def factor(n:int):
    out=[]
    d=2
    while d*d<=n:
        e=0
        while n%d==0:
            n//=d; e+=1
        if e: out.append((d,e))
        d += 1 if d==2 else 2
    if n>1: out.append((n,1))
    return out

def sigma1(n:int)->int:
    if n<=0: return 0
    s=0
    r=int(math.isqrt(n))
    for d in range(1,r+1):
        if n%d==0:
            s+=d
            q=n//d
            if q!=d: s+=q
    return s

def C_int(n:int)->int:
    return (5*sigma1(n)
            - (2*sigma1(n//2) if n%2==0 else 0)
            + (3*sigma1(n//3) if n%3==0 else 0)
            - (30*sigma1(n//6) if n%6==0 else 0))

def C_mod(n:int)->int:
    return C_int(n)%MOD

if HAVE_NUMBA:
    @njit
    def _multiply_pos(N:int):
        arr=np.zeros(N+1,dtype=np.int64); arr[0]=1
        for m in range(1,N+1):
            if m%6==0: E=0
            elif m%3==0: E=6
            elif m%2==0: E=4
            else: E=5
            for rep in range(E):
                for n in range(N,m-1,-1):
                    arr[n]=(arr[n]-arr[n-m])%MOD
        return arr
    @njit
    def _multiply_inv(N:int):
        arr=np.zeros(N+1,dtype=np.int64); arr[0]=1
        for m in range(1,N+1):
            if m%6==0: E=0
            elif m%3==0: E=6
            elif m%2==0: E=4
            else: E=5
            for rep in range(E):
                for n in range(m,N+1):
                    arr[n]=(arr[n]+arr[n-m])%MOD
        return arr
    @njit
    def _multiply_F(P,N:int):
        arr=P.copy()
        for m in range(6,N+1,6):
            for rep in range(4):
                for n in range(N,m-1,-1):
                    arr[n]=(arr[n]-arr[n-m])%MOD
        for n in range(N+1):
            arr[n]=(-2*arr[n])%MOD
        return arr
else:
    def _multiply_pos(N:int):
        arr=[0]*(N+1); arr[0]=1
        for m in range(1,N+1):
            E=0 if m%6==0 else (6 if m%3==0 else (4 if m%2==0 else 5))
            for _ in range(E):
                for n in range(N,m-1,-1):
                    arr[n]=(arr[n]-arr[n-m])%MOD
        return arr
    def _multiply_inv(N:int):
        arr=[0]*(N+1); arr[0]=1
        for m in range(1,N+1):
            E=0 if m%6==0 else (6 if m%3==0 else (4 if m%2==0 else 5))
            for _ in range(E):
                for n in range(m,N+1):
                    arr[n]=(arr[n]+arr[n-m])%MOD
        return arr
    def _multiply_F(P,N:int):
        arr=list(P)
        for m in range(6,N+1,6):
            for _ in range(4):
                for n in range(N,m-1,-1):
                    arr[n]=(arr[n]-arr[n-m])%MOD
        return [(-2*x)%MOD for x in arr]

@dataclass
class Row:
    label:str
    n:int
    n_mod107:int
    n_mod840:int
    order107:Optional[int]
    inv107:Optional[int]
    T:Optional[int]
    F:Optional[int]
    J:Optional[int]
    Y:Optional[int]
    f6:int
    C_exact:int
    notes:str


def coeffs_for(n:int, P, Q, Fseq, N:int):
    if 0 <= n <= N-1:
        T=int(P[n+1])
        invT=int((72*int(Q[n-1]))%MOD) if n>=1 else 0
        J=(T + (5 if n==0 else 0) + invT)%MOD
        Y=(T - invT)%MOD
        F=int(Fseq[n])
        return T,F,J,Y
    return None,None,None,None


def build_rows(cutoff:int=CUTOFF):
    P=_multiply_pos(cutoff)
    Q=_multiply_inv(cutoff)
    Fseq=_multiply_F(P,cutoff)
    items=[
        ('S1',1,'runtime busy beaver'),
        ('S2',6,'runtime busy beaver'),
        ('S3',21,'runtime busy beaver'),
        ('S4=R*',107,'champion modulus'),
        ('S5',47176870,'runtime busy beaver'),
        ('Sigma5',4098,'5-state score'),
        ('Space5',12289,'5-state space; prime; 107^2+840'),
        ('Goldbach25',25,'Goldbach state count'),
        ('Goldbach27',27,'Goldbach state count / 4^-1'),
        ('Goldbach43',43,'Goldbach state count / supported-zero shell'),
        ('RH744',744,'RH state count / -5 component line'),
        ('ZFC745',745,'ZFC state count / -4 affine line'),
        ('FRACTRAN746',746,'Fractran value / -3 ternary line'),
        ('target747',747,'-2 edge-channel marker'),
        ('ZFC748',748,'older ZFC state count / -1 target'),
        ('S2_3_2',32,'two-dimensional BB S_2(3,2)'),
        ('Sigma2_3_2',11,'two-dimensional BB Sigma_2(3,2)'),
        ('S2_4_2',4632,'two-dimensional BB S_2(4,2)'),
        ('Sigma2_4_2',244,'two-dimensional BB Sigma_2(4,2)'),
        ('S2_5_2',25772988638,'two-dimensional BB S_2(5,2)'),
        ('Sigma2_5_2',935508401,'two-dimensional BB Sigma_2(5,2)'),
        ('BLB4_lb',32779477,'blanking busy beaver lower bound'),
        ('BLB5_lb',32810047,'blanking busy beaver lower bound'),
        ('BLB6_lb',65538549,'blanking busy beaver lower bound'),
        ('BBB4_lb',32779478,'beeping busy beaver lower bound'),
        ('BBf19',370,'Fractran busy beaver'),
        ('BBf20',746,'Fractran busy beaver'),
        ('BBf21_lb',31957632,'Fractran busy beaver lower bound'),
        ('lambda37',38127987424943,'lambda-calculus busy beaver datum'),
        ('6147',6147,'suggested inverse-pair datum'),
        ('81991',81991,'suggested inverse-pair datum'),
        ('visible_S6_lower_proxy',10,'placeholder base for tetration; see report'),
    ]
    rows=[]
    for label,n,notes in items:
        T,F,J,Y=coeffs_for(n,P,Q,Fseq,cutoff)
        rows.append(Row(label,n,n%MOD,n%840,order_mod(n),inv_mod(n),T,F,J,Y,C_mod(n),C_int(n),notes))
    return rows


def _pow_sequence_period(base:int, mod:int):
    vals=[]
    seen={}
    e=0
    while True:
        v=pow(base,e,mod)
        if v in seen:
            return seen[v], e-seen[v]
        seen[v]=e
        vals.append(v)
        e+=1

def tetration_mod_10_height(h:int, m:int=MOD)->int:
    # Exact modular tetration for base 10 by finite eventual periodicity of e -> 10^e mod m.
    # For h>=2 the exponent is enormous; the preperiod adjustment is handled explicitly.
    from functools import lru_cache
    @lru_cache(None)
    def tower_mod(height:int, mod:int)->int:
        if mod == 1:
            return 0
        if height == 1:
            return 10 % mod
        mu, lam = _pow_sequence_period(10, mod)
        if height-1 == 1:
            E = 10
        else:
            E0 = tower_mod(height-1, lam)
            E = mu + ((E0 - mu) % lam)
        return pow(10, E, mod)
    return tower_mod(h,m)


def main():
    cutoff=int(os.environ.get('CUTOFF',CUTOFF))
    outdir=os.environ.get('OUTDIR','.')
    os.makedirs(outdir,exist_ok=True)
    rows=build_rows(cutoff)
    csv_path=os.path.join(outdir,'bb107_sweep_full.csv')
    with open(csv_path,'w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['label','n','n_mod107','n_mod840','order107','inv107','T_mod107','F_mod107','J_mod107','Y_mod107','f6_mod107','C_exact','notes'])
        for r in rows:
            w.writerow([r.label,r.n,r.n_mod107,r.n_mod840,r.order107,r.inv107,r.T,r.F,r.J,r.Y,r.f6,r.C_exact,r.notes])
    report=os.path.join(outdir,'bb107_verification_report_full.txt')
    with open(report,'w') as f:
        def line(s=''):
            f.write(s+'\n')
        line('BB107 full sweep verification report')
        line('MOD=107, coefficient cutoff=%d' % cutoff)
        line('')
        vals={r.label:r for r in rows}
        pstar=8803369; astar=(pstar+107)//4; Nstar=pstar*astar
        line(f'pstar mod 107 = {pstar%107}')
        line(f'astar mod 107 = {astar%107}')
        line(f'Nstar mod 107 = {Nstar%107}')
        line(f'S3 inverse mod 107 = {pow(21,-1,107)}')
        line(f'S5 mod 107 = {47176870%107}')
        line(f'S3*S5 mod 107 = {(21*(47176870%107))%107}')
        line(f'-S3*S5 mod 107 = {(-21*(47176870%107))%107}')
        line(f'11^2 mod 107 = {121%107}')
        line(f'(-S2*S5)^-1 mod 107 = {pow((-6*(47176870%107))%107,-1,107)}')
        line('')
        sp=vals['Space5']
        line('Space5 computations:')
        line(f'12289 factorization = {factor(12289)}')
        line(f'12289 = 107^2 + 840 -> {107*107+840}')
        line(f'12289 mod 107 = {sp.n_mod107}')
        line(f'12289 mod 840 = {sp.n_mod840}')
        line(f'12289 mod 30 = {12289%30}')
        line(f'529 == 289^5 mod 840 -> {pow(289,5,840)}')
        line(f'order_107(12289) = {sp.order107}')
        line(f'inv_107(12289) = {sp.inv107}')
        line(f'[q^12289]T mod 107 = {sp.T}')
        line(f'[q^12289]F mod 107 = {sp.F}')
        line(f'[q^12289]J mod 107 = {sp.J}')
        line(f'[q^12289]Y mod 107 = {sp.Y}')
        line(f'[q^12289]f6 = C_12289 = {sp.C_exact} ≡ {sp.f6} mod 107')
        line(f'Sigma5 mod 107 = {4098%107}')
        line('')
        L6=tetration_mod_10_height(15,107)
        line(f'10^^15 mod 107 = {L6}')
        line(f'4*(10^^15) mod 107 = {(4*L6)%107}, S5 mod 107 = {47176870%107}')
        line('')
        line('Selected rows:')
        for label in ['Goldbach27','Goldbach43','S4=R*','RH744','ZFC745','FRACTRAN746','target747','ZFC748','Space5','Sigma5','S2_4_2','6147','81991']:
            r=vals[label]
            line(f'{label}: n={r.n}, n%107={r.n_mod107}, n%840={r.n_mod840}, T={r.T}, F={r.F}, J={r.J}, Y={r.Y}, f6={r.f6}')
    print(csv_path)
    print(report)

if __name__=='__main__': main()

#!/usr/bin/env python3
"""Exact finite checks for the 107-shell six-sector sedenion ghost note.

The script implements the Cayley-Dickson basis multiplication used in the paper,
checks the residual target enumeration for R=107, verifies the signed zero-divisor
pair X,Y in A_4 \otimes R[C_2], and computes the finite ghost operator block table.
All arithmetic is exact over the integers.
"""
from __future__ import annotations
from functools import lru_cache
import csv
from pathlib import Path
from typing import Dict, Tuple

MOD = 107
PSTAR = 8_803_369
RSTAR = 107
ASTAR = (PSTAR + RSTAR)//4
LOGS = [70,22,59,66]
TARGETS = {53:"-1", 60:"-p^{-1}"}
BOX_RANGES = [range(-2,3), range(-2,3), range(-1,2), range(-1,2)]

# ---------------------------------------------------------------------------
# Cayley-Dickson basis multiplication in A_n with basis indexed by bitmasks.
# e_0=1, e_{bitmask}=o_I. Convention:
# (x+y u)(z+w u)=(xz - \bar w y)+(w x + y \bar z)u.
# ---------------------------------------------------------------------------

def conj_basis(idx:int, n:int) -> Tuple[int,int]:
    return (1,0) if idx == 0 else (-1,idx)

@lru_cache(None)
def mult_basis(i:int, j:int, n:int=4) -> Tuple[int,int]:
    if n == 0:
        if i != 0 or j != 0:
            raise ValueError("bad A0 basis")
        return (1,0)
    half = 1 << (n-1)
    if i < half and j < half:
        return mult_basis(i,j,n-1)
    if i < half and j >= half:
        # (a,0)(0,d)=(0,d a)
        c,k = mult_basis(j-half, i, n-1)
        return c, k+half
    if i >= half and j < half:
        # (0,b)(c,0)=(0,b \bar c)
        s,cidx = conj_basis(j,n-1)
        c,k = mult_basis(i-half, cidx, n-1)
        return s*c, k+half
    # (0,b)(0,d)=(-\bar d b,0)
    s,didx = conj_basis(j-half,n-1)
    c,k = mult_basis(didx, i-half, n-1)
    return -s*c, k

# Elements in A_4 tensor Z[C2]: dict (basis_idx, tag)->integer.
Key = Tuple[int,int]
Elt = Dict[Key,int]

def clean(x:Elt) -> Elt:
    return {k:v for k,v in x.items() if v}

def add(x:Elt, y:Elt) -> Elt:
    z = dict(x)
    for k,v in y.items():
        z[k] = z.get(k,0)+v
    return clean(z)

def scalar(c:int, x:Elt) -> Elt:
    return clean({k:c*v for k,v in x.items()})

def basis(idx:int, tag:int=0, coeff:int=1) -> Elt:
    return {(idx,tag%2):coeff}

def mul(x:Elt, y:Elt) -> Elt:
    z:Elt = {}
    for (i,t),a in x.items():
        for (j,u),b in y.items():
            s,k = mult_basis(i,j,4)
            key = (k,(t+u)%2)
            z[key] = z.get(key,0)+a*b*s
    return clean(z)

def comm(x:Elt,y:Elt) -> Elt:
    return add(mul(x,y), scalar(-1,mul(y,x)))

def L(a:Elt, z:Elt) -> Elt:
    return mul(a,z)

def gamma(X:Elt,Y:Elt,Z:Elt) -> Elt:
    # Here [X,Y]=0 in the verified case, so Gamma=[L_X,L_Y].
    return add(L(X,L(Y,Z)), scalar(-1,L(Y,L(X,Z))))

def blade_label(idx:int) -> str:
    if idx == 0:
        return "1"
    digits = "".join(str(i+1) for i in range(4) if idx & (1<<i))
    return "o_{" + digits + "}"

def fmt_key(k:Key) -> str:
    i,t = k
    return f"{blade_label(i)}[{t}]"

def fmt_elt(x:Elt) -> str:
    if not x: return "0"
    parts=[]
    for k in sorted(x):
        v=x[k]
        atom=fmt_key(k)
        if v == 1:
            parts.append(f"+{atom}")
        elif v == -1:
            parts.append(f"-{atom}")
        else:
            parts.append(f"{v:+d}*{atom}")
    s="".join(parts)
    return s[1:] if s.startswith("+") else s

# ---------------------------------------------------------------------------
# target enumeration
# ---------------------------------------------------------------------------

def target_hits():
    hits=[]
    for b1 in BOX_RANGES[0]:
        for b2 in BOX_RANGES[1]:
            for b3 in BOX_RANGES[2]:
                for b4 in BOX_RANGES[3]:
                    beta=(b1,b2,b3,b4)
                    ell=sum(l*b for l,b in zip(LOGS,beta))%106
                    if ell in TARGETS:
                        hits.append((beta,ell,TARGETS[ell]))
    return hits

# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    outdir=Path(__file__).resolve().parents[1]/"data"
    outdir.mkdir(exist_ok=True)
    report=[]
    report.append("107-shell six-sector ghost verification")
    report.append(f"p*={PSTAR}, R*={RSTAR}, a*={ASTAR}")
    report.append(f"a* factorization expected: 3^2 * 11^2 * 43 * 47 = {9*121*43*47}")
    report.append(f"p* mod 107 = {PSTAR%MOD}")
    report.append(f"a* mod 107 = {ASTAR%MOD}")
    report.append(f"N* mod 107 = {(PSTAR*ASTAR)%MOD}")
    hits=target_hits()
    report.append("target hits:")
    for h in hits:
        report.append(f"  beta={h[0]} ell={h[1]} target={h[2]}")
    assert len(hits)==2
    assert set(h[0] for h in hits)=={(2,0,1,1),(-2,0,-1,-1)}
    assert all(h[1]==53 for h in hits)

    # Basic products used in zero divisor proof.
    product_pairs=[(1,2),(15,12),(1,12),(15,2),(2,1),(12,15),(2,15),(12,1)]
    report.append("Cayley-Dickson products:")
    for i,j in product_pairs:
        s,k=mult_basis(i,j,4)
        report.append(f"  {blade_label(i)} {blade_label(j)} = {s:+d} {blade_label(k)}")

    X=add(basis(1,0), scalar(-1,basis(15,1)))
    Y=add(basis(2,0), basis(12,1))
    XY=mul(X,Y); YX=mul(Y,X)
    report.append(f"X={fmt_elt(X)}")
    report.append(f"Y={fmt_elt(Y)}")
    report.append(f"XY={fmt_elt(XY)}")
    report.append(f"YX={fmt_elt(YX)}")
    assert not XY and not YX
    X2=mul(X,X); Y2=mul(Y,Y)
    report.append(f"X^2={fmt_elt(X2)}")
    report.append(f"Y^2={fmt_elt(Y2)}")
    assert X2=={(0,0):-2}
    assert Y2=={(0,0):-2}
    assoc_xxy=add(mul(mul(X,X),Y), scalar(-1,mul(X,mul(X,Y))))
    assoc_yyx=add(mul(mul(Y,Y),X), scalar(-1,mul(Y,mul(Y,X))))
    report.append(f"[X,X,Y]={fmt_elt(assoc_xxy)}")
    report.append(f"[Y,Y,X]={fmt_elt(assoc_yyx)}")
    assert assoc_xxy==scalar(-2,Y)
    assert assoc_yyx==scalar(-2,X)

    # Ghost table.
    csv_path=outdir/"ghost_operator_table.csv"
    with csv_path.open("w",newline="") as f:
        w=csv.writer(f)
        w.writerow(["basis_idx","tag","Gamma"])
        for tag in [0,1]:
            for idx in range(16):
                G=gamma(X,Y,basis(idx,tag))
                w.writerow([idx,tag,fmt_elt(G)])
    report.append(f"wrote {csv_path.name}")

    # Characteristic polynomial block count verified from table classes.
    # Classify by Gamma^2 on each basis vector: 0, -4, -16 where basis vector belongs to invariant plane.
    counts={0:0, -4:0, -16:0, "other":0}
    for tag in [0,1]:
        for idx in range(16):
            v=basis(idx,tag)
            G2=gamma(X,Y,gamma(X,Y,v))
            if not G2:
                counts[0]+=1
            elif len(G2)==1 and next(iter(G2.keys()))==(idx,tag):
                c=next(iter(G2.values()))
                if c in counts:
                    counts[c]+=1
                else:
                    counts["other"]+=1
            else:
                counts["other"]+=1
    report.append(f"Gamma^2 eigen-counts on basis vectors: {counts}")
    assert counts[0]==8 and counts[-4]==16 and counts[-16]==8 and counts["other"]==0
    report.append("characteristic polynomial: x^8 (x^2+4)^8 (x^2+16)^4")
    report.append("minimal polynomial: x (x^2+4)(x^2+16)")
    (outdir/"six_sector_ghost_verification.txt").write_text("\n".join(report)+"\n")
    print("\n".join(report))

if __name__=="__main__":
    main()

#!/usr/bin/env python3
"""Finite BB/level-6 moonshine and shift-rigidity checks over F_107."""
from __future__ import annotations
from pathlib import Path
import random

MOD=107
NMAX=12289+2
S3=21; S5=47_176_870; SIGMA5=4098; SPACE5=12289
PSTAR=8_803_369; RSTAR=107; ASTAR=(PSTAR+RSTAR)//4

# ---------------------------------------------------------------------------
# level-six eta product coefficients over F_107
# T=q^{-1} A(q), A=prod(1-q^m)^E(m), E(m)=5-1_{2|m}+1_{3|m}-5 1_{6|m}.
# ---------------------------------------------------------------------------

def E(m:int)->int:
    return 5 - (1 if m%2==0 else 0) + (1 if m%3==0 else 0) - (5 if m%6==0 else 0)

def divisor_c(n:int)->int:
    s=0
    d=1
    while d*d<=n:
        if n%d==0:
            s += d*E(d)
            if d*d!=n:
                q=n//d; s += q*E(q)
        d+=1
    return s

def compute_A(N:int):
    a=[0]*(N+1); a[0]=1
    c=[0]*(N+1)
    for n in range(1,N+1):
        c[n]=divisor_c(n)%MOD
        total=0
        for m in range(1,n+1):
            total=(total + c[m]*a[n-m])%MOD
        a[n]=(-total*pow(n,-1,MOD))%MOD if n%MOD else solve_rec_mod107(n,total,a,c)
    return a,c

def solve_rec_mod107(n,total,a,c):
    # When n=0 mod 107 the recurrence has zero leading coefficient modulo 107.
    # Compute over integers mod 107 by lifting with product recurrence instead.
    # For the few such n needed, use direct product update up to n.
    # Simpler: recompute A up to n by product in F_107.
    return product_A_coeff(n)

def product_A_coeff(N:int)->int:
    arr=[0]*(N+1); arr[0]=1
    for m in range(1,N+1):
        e=E(m)
        if e>=0:
            for _ in range(e):
                for k in range(N,m-1,-1):
                    arr[k]=(arr[k]-arr[k-m])%MOD
        else:
            # multiply by (1-q^m)^(-r), r=-e
            r=-e
            factor=[0]*(N+1); factor[0]=1
            # coeff binom(r+j-1,j)
            coeff=1
            for j in range(1,N//m+1):
                coeff=coeff*(r+j-1)//j
                factor[j*m]=coeff%MOD
            new=[0]*(N+1)
            for i,ai in enumerate(arr):
                if ai:
                    for jj,fj in enumerate(factor[:N-i+1]):
                        if fj:
                            new[i+jj]=(new[i+jj]+ai*fj)%MOD
            arr=new
    return arr[N]

def compute_A_product(N:int):
    arr=[0]*(N+1); arr[0]=1
    for m in range(1,N+1):
        e=E(m)
        if e>=0:
            for _ in range(e):
                for k in range(N,m-1,-1):
                    arr[k]=(arr[k]-arr[k-m])%MOD
        else:
            r=-e
            # iterative inverse multiplication for r times: multiply by 1/(1-q^m)
            for _ in range(r):
                for k in range(m,N+1):
                    arr[k]=(arr[k]+arr[k-m])%MOD
    return arr

def inverse_series(a):
    N=len(a)-1
    b=[0]*(N+1); b[0]=pow(a[0],-1,MOD)
    for n in range(1,N+1):
        total=0
        for i in range(1,n+1):
            total=(total+a[i]*b[n-i])%MOD
        b[n]=(-total*b[0])%MOD
    return b

def eta6_4(N:int):
    # B(q)=prod_{m>=1}(1-q^{6m})^4
    b=[0]*(N+1); b[0]=1
    for m in range(6,N+1,6):
        for _ in range(4):
            for k in range(N,m-1,-1):
                b[k]=(b[k]-b[k-m])%MOD
    return b

# ---------------------------------------------------------------------------
# linear algebra over F_107
# ---------------------------------------------------------------------------
A1=[
[0,1,0,0,0],
[0,0,1,0,0],
[0,0,0,1,0],
[0,0,0,0,1],
[72,40,4,32,46],
]
A6=[
[62,30,43,97,102],
[3,12,64,68,35],
[54,74,14,80,85],
[13,76,44,102,40],
[10,47,88,31,73],
]

def matmul(A,B):
    n=len(A); m=len(B[0]); r=len(B)
    return [[sum(A[i][k]*B[k][j] for k in range(r))%MOD for j in range(m)] for i in range(n)]

def matadd(A,B):
    return [[(A[i][j]+B[i][j])%MOD for j in range(len(A[0]))] for i in range(len(A))]

def matsub(A,B):
    return [[(A[i][j]-B[i][j])%MOD for j in range(len(A[0]))] for i in range(len(A))]

def eye(n):
    return [[1 if i==j else 0 for j in range(n)] for i in range(n)]

def vec(A):
    return [A[i][j]%MOD for i in range(len(A)) for j in range(len(A[0]))]

def det(M):
    A=[row[:] for row in M]
    n=len(A); d=1
    for i in range(n):
        piv=None
        for r in range(i,n):
            if A[r][i]%MOD:
                piv=r; break
        if piv is None: return 0
        if piv!=i:
            A[i],A[piv]=A[piv],A[i]; d=-d
        pv=A[i][i]%MOD; d=(d*pv)%MOD; inv=pow(pv,-1,MOD)
        for r in range(i+1,n):
            fac=A[r][i]*inv%MOD
            if fac:
                for c in range(i,n):
                    A[r][c]=(A[r][c]-fac*A[i][c])%MOD
    return d%MOD

def trace(A): return sum(A[i][i] for i in range(len(A)))%MOD

def rank(vectors):
    if not vectors: return 0
    A=[v[:] for v in vectors]
    n=len(A); m=len(A[0]); r=0
    for c in range(m):
        piv=None
        for i in range(r,n):
            if A[i][c]%MOD:
                piv=i; break
        if piv is not None:
            A[r],A[piv]=A[piv],A[r]
            inv=pow(A[r][c]%MOD,-1,MOD)
            A[r]=[(x*inv)%MOD for x in A[r]]
            for i in range(n):
                if i!=r and A[i][c]%MOD:
                    fac=A[i][c]%MOD
                    A[i]=[(A[i][j]-fac*A[r][j])%MOD for j in range(m)]
            r+=1
            if r==n: break
    return r

def word_basis():
    gens=[('1',eye(5)),('A1',A1),('A6',A6)]
    words=[('I',eye(5)),('A1',A1),('A6',A6)]
    basis=[]; vectors=[]
    queue=words[:]
    seen={tuple(vec(M)) for _,M in queue}
    while queue and len(basis)<25:
        w,M=queue.pop(0)
        v=vec(M)
        if rank(vectors+[v])>len(vectors):
            basis.append((w,M)); vectors.append(v)
        # extend words up to reasonable size
        if len(w.replace('A',''))<30:
            for name,G in [('A1',A1),('A6',A6)]:
                N=matmul(M,G); key=tuple(vec(N))
                if key not in seen:
                    seen.add(key); queue.append((w+name,N))
    D=det([v for v in vectors]) if len(vectors)==25 else 0
    return basis,D

def main():
    outdir=Path(__file__).resolve().parents[1]/"data"; outdir.mkdir(exist_ok=True)
    lines=[]
    lines.append("BB/107/level-6 verification")
    lines.append(f"p* mod 107={PSTAR%MOD}, a* mod 107={ASTAR%MOD}, N* mod 107={(PSTAR*ASTAR)%MOD}")
    lines.append(f"S3^-1 mod 107={pow(S3,-1,MOD)}")
    lines.append(f"S5 mod 107={S5%MOD}")
    lines.append(f"S3*S5 mod 107={(S3*S5)%MOD}")
    lines.append(f"-S3*S5 mod 107={(-S3*S5)%MOD}")
    lines.append(f"Sigma5 mod 107={SIGMA5%MOD}")
    lines.append(f"Space5={SPACE5}=107^2+840? {SPACE5==107**2+840}; Space5 mod 840={SPACE5%840}; 289^5 mod 840={pow(289,5,840)}")
    N=800
    A=compute_A_product(N+1)
    invA=inverse_series(A)
    c=[0]*(N+1)
    for n in range(1,N+1): c[n]=divisor_c(n)%MOD
    # coeffs: T=q^-1 A, so [q^n]T=A[n+1]
    T107=A[108]
    J745=(A[746] + 72*invA[744])%MOD
    Y745=(A[746] - 72*invA[744])%MOD
    B=eta6_4(200)
    # F=-2*A*B
    F107=(-2*sum(A[i]*B[107-i] for i in range(108)) )%MOD
    f6Space=divisor_c(SPACE5)%MOD
    lines.append(f"[q^107]T={T107}")
    lines.append(f"[q^107]F={F107}")
    lines.append(f"([q^107]F)^-1={pow(F107,-1,MOD)}")
    lines.append(f"[q^745]J={J745}")
    lines.append(f"[q^745]Y={Y745}")
    lines.append(f"[q^Space5]f6={f6Space}")
    assert T107==16 and F107==4 and pow(F107,-1,MOD)==27 and J745==SIGMA5%MOD and Y745==80 and f6Space==SIGMA5%MOD
    comm=matsub(matmul(A1,A6),matmul(A6,A1))
    lines.append("A1 det={}, trace={}".format(det(A1),trace(A1)))
    lines.append("A6 det={}, trace={}".format(det(A6),trace(A6)))
    lines.append("comm det={}, trace={}".format(det(comm),trace(comm)))
    basis,D=word_basis()
    lines.append(f"word basis length={len(basis)}, vectorized determinant={D}")
    assert len(basis)==25 and D!=0
    lines.append("word basis:")
    for w,_ in basis:
        lines.append(f"  {w}")
    path=outdir/"bb_shift_verification.txt"
    path.write_text("\n".join(lines)+"\n")
    print("\n".join(lines))

if __name__=='__main__': main()

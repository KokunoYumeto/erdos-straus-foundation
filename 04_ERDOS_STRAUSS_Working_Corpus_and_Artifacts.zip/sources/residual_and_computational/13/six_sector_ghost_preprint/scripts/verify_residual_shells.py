#!/usr/bin/env python3
"""Exact residual-shell coefficient checks.

Computes the signed divisor-ratio counts c_R(a;t), split-zero state, and
Kneser data for the finite examples used in the preprint.
"""
from __future__ import annotations
from pathlib import Path
from itertools import product
from math import gcd

EXAMPLES=[(12289,11),(8803369,43),(8803369,107)]

def factor(n:int):
    out=[]; d=2
    while d*d<=n:
        if n%d==0:
            e=0
            while n%d==0:
                n//=d; e+=1
            out.append((d,e))
        d += 1 if d==2 else 2
    if n>1: out.append((n,1))
    return out

def order_mod(x:int,R:int):
    if gcd(x,R)!=1: return None
    y=1
    for k in range(1,10_000):
        y=(y*x)%R
        if y==1:return k
    raise RuntimeError("order too high")

def subgroup_generated(gens,R):
    H={1}
    changed=True
    while changed:
        changed=False
        for h in list(H):
            for g in gens:
                y=(h*g)%R
                if y not in H:
                    H.add(y); changed=True
    return sorted(H)

def counts(p,R):
    a=(p+R)//4
    fac=factor(a)
    gens=[q%R for q,e in fac]
    H=subgroup_generated(gens,R)
    targets=[(-1)%R, (-pow(p,-1,R))%R]
    c={t:0 for t in targets}
    vecs={t:[] for t in targets}
    ranges=[range(-e,e+1) for q,e in fac]
    for beta in product(*ranges):
        lam=1
        for (q,e),b in zip(fac,beta):
            if b>=0:
                lam=(lam*pow(q,b,R))%R
            else:
                lam=(lam*pow(pow(q,-1,R),-b,R))%R
        if lam in c:
            c[lam]+=1; vecs[lam].append(beta)
    omega=c[targets[0]]+2*c[targets[1]]
    if not any(t in H for t in targets): state="tau"
    elif omega==0: state="0_Z"
    else: state=f"positive:{omega}"
    return a,fac,H,targets,c,vecs,state

def main():
    outdir=Path(__file__).resolve().parents[1]/"data"
    lines=[]
    for p,R in EXAMPLES:
        a,fac,H,targets,c,vecs,state=counts(p,R)
        lines.append(f"p={p}, R={R}, a={a}")
        lines.append(f"factorization={fac}")
        lines.append(f"H size={len(H)}, H={H}")
        lines.append(f"targets (-1,-p^-1)={targets}")
        lines.append(f"counts={c}, omega={c[targets[0]]+2*c[targets[1]]}, state={state}")
        for t in targets:
            lines.append(f"  vectors for target {t}: {vecs[t]}")
        lines.append("")
    path=outdir/"residual_shells_verification.txt"
    path.write_text("\n".join(lines))
    print("\n".join(lines))

if __name__=='__main__': main()

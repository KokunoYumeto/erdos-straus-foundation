# Six-sector supersignum--tesserine ghost calculus package

This package contains a preprint-style PDF and LaTeX source integrating the post-closed-form residual-shell material:

- fixed-shell divisor algebra and projective star targets;
- split-zero support trichotomy and Star--Kneser quotient obstruction;
- supersignum, completed tesserine, and six-sector sasharine algebras;
- the R=107 sedenion coefficient algebra, 6/6/2 decomposition, zero divisor pair, finite ghost operator, characteristic/minimal polynomials;
- finite F_107 level-six/Busy-Beaver congruence layer;
- reproducibility scripts and verification transcripts.

## Main files

- `six_sector_ghost_preprint.pdf` -- compiled preprint.
- `six_sector_ghost_preprint.tex` -- top-level LaTeX source copy.
- The original `tex/six_sector_ghost_preprint.tex` was byte-identical to the top-level source and is recorded as a deduplicated alias in `MANIFEST.csv`.

## Scripts

Run from the package root or directly:

```bash
python scripts/verify_residual_shells.py
python scripts/verify_six_sector_ghost.py
python scripts/verify_bb_shift.py
```

These scripts write their reports to `data/`.

## Data outputs

- `data/residual_shells_verification.txt`
- `data/six_sector_ghost_verification.txt`
- `data/ghost_operator_table.csv`
- `data/bb_shift_verification.txt`

## Build

```bash
pdflatex -interaction=nonstopmode six_sector_ghost_preprint.tex
pdflatex -interaction=nonstopmode six_sector_ghost_preprint.tex
```

The PDF was rendered and visually checked before packaging.

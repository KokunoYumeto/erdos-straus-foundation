Inductive Cayley-Dickson Shell Algebras and the Sedenion Ghost Invariant of the 107 Residual Erdos-Straus Shell

Contents:
- cd_shell_ghost_preprint.tex : LaTeX source

The compiled PDF is omitted from this source corpus; rebuild it from the retained TeX.

Build command:
pdflatex -interaction=nonstopmode cd_shell_ghost_preprint.tex
pdflatex -interaction=nonstopmode cd_shell_ghost_preprint.tex

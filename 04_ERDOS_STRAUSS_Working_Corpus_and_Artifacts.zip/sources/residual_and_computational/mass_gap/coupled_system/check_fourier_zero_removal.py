#!/usr/bin/env python3
"""Exact finite verification for the C6 Fourier-zero removal note.

The raw three-origin target is F_k=e_{3+k}+e_3+e_{3-k}.
Its Fourier coefficient is zero exactly when k*m == 2 or 4 mod 6.
The quotient target is D_k=e_3+2e_{3-k}; its Fourier coefficient
(-1)^m(1+2 zeta_6^{-km}) is never zero by the absolute-value argument.
"""

from __future__ import annotations


def raw_zero_modes(k: int) -> list[int]:
    return [m for m in range(6) if (k * m) % 6 in (2, 4)]


def quotient_zero_modes(k: int) -> list[int]:
    # There are no quotient zeros: |2*zeta|=2 cannot cancel |1|=1.
    return []


def main() -> None:
    print("k | raw zero modes | quotient zero modes | raw rank | quotient rank")
    print("--+----------------+---------------------+----------+--------------")
    for k in range(6):
        rz = raw_zero_modes(k)
        qz = quotient_zero_modes(k)
        print(f"{k} | {rz!s:<14} | {qz!s:<19} | {6-len(rz):>8} | {6-len(qz):>12}")


if __name__ == "__main__":
    main()

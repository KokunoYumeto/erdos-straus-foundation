#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, math, random
from typing import Dict, List, Optional, Tuple, Iterable

MOD=107
MOD840=840

# ---------- number theory ----------

def is_probable_prime(n:int)->bool:
    if n<2: return False
    small=[2,3,5,7,11,13,17,19,23,29,31,37]
    for p in small:
        if n%p==0: return n==p
    d=n-1; s=0
    while d%2==0:
        s+=1; d//=2
    # deterministic for < 2^64
    for a in [2,325,9375,28178,450775,9780504,1795265022]:
        if a%n==0: continue
        x=pow(a,d,n)
        if x==1 or x==n-1: continue
        ok=False
        for _ in range(s-1):
            x=(x*x)%n
            if x==n-1:
                ok=True; break
        if not ok: return False
    return True

def pollard_rho(n:int)->int:
    if n%2==0: return 2
    if n%3==0: return 3
    while True:
        c=random.randrange(1,n-1)
        x=random.randrange(2,n-1); y=x; d=1
        def f(v): return (v*v+c)%n
        while d==1:
            x=f(x); y=f(f(y)); d=math.gcd(abs(x-y),n)
        if d!=n: return d

def factor_int(n:int, out:Optional[Dict[int,int]]=None)->Dict[int,int]:
    if out is None: out={}
    if n<0: n=-n
    if n in (0,1): return out
    if is_probable_prime(n):
        out[n]=out.get(n,0)+1; return out
    d=pollard_rho(n)
    factor_int(d,out); factor_int(n//d,out)
    return out

def sigma1(n:int)->int:
    if n<=0: return 0
    fac=factor_int(n)
    ans=1
    for p,e in fac.items(): ans *= (p**(e+1)-1)//(p-1)
    return ans

def E(n:int)->int:
    return 5 - (1 if n%2==0 else 0) + (1 if n%3==0 else 0) - (5 if n%6==0 else 0)

def C(n:int)->int:
    return 5*sigma1(n) - 2*(sigma1(n//2) if n%2==0 else 0) + 3*(sigma1(n//3) if n%3==0 else 0) - 30*(sigma1(n//6) if n%6==0 else 0)

def order_mod(a:int, mod:int=MOD)->Optional[int]:
    a%=mod
    if math.gcd(a,mod)!=1: return None
    x=1
    for k in range(1,mod+1):
        x=(x*a)%mod
        if x==1: return k
    return None

def carmichael(n:int)->int:
    if n<=1: return 1
    vals=[]
    for p,e in factor_int(n).items():
        vals.append(2**(e-2) if p==2 and e>=3 else (p-1)*p**(e-1))
    l=1
    for v in vals: l=l*v//math.gcd(l,v)
    return l

def tetration_10_mod(h:int, mod:int)->int:
    if mod==1: return 0
    if h==1: return 10%mod
    lam=carmichael(mod)
    exp=tetration_10_mod(h-1,lam)
    if h-1>=2: exp += lam
    return pow(10,exp,mod)

# ---------- series ----------

def compute_P_exact(N:int)->List[int]:
    # P=q*T, P(0)=1.  n a_n = - sum_{m=1}^n C_m a_{n-m}
    a=[0]*(N+1); a[0]=1
    Cs=[0]+[C(m) for m in range(1,N+1)]
    for n in range(1,N+1):
        s=sum(Cs[m]*a[n-m] for m in range(1,n+1))
        assert s % n == 0, (n,s)
        a[n]= -s//n
    return a

def inv_series_mod(P:List[int], N:int, mod:int=MOD)->List[int]:
    inv=[0]*(N+1); inv[0]=pow(P[0]%mod,-1,mod)
    for n in range(1,N+1):
        s=sum((P[k]%mod)*inv[n-k] for k in range(1,n+1))
        inv[n]=(-s*inv[0])%mod
    return inv

def eta6_4_mod(N:int, mod:int=MOD)->List[int]:
    q=[0]*(N+1); q[0]=1
    for m in range(1,N//6+1):
        shift=6*m; old=q[:]
        local=[math.comb(4,j)*((-1)**j)%mod for j in range(5)]
        for k in range(shift,N+1):
            v=old[k]
            for j in range(1,min(4,k//shift)+1): v += local[j]*old[k-j*shift]
            q[k]=v%mod
    return q

def conv_mod(a:List[int],b:List[int],N:int,mod:int=MOD)->List[int]:
    c=[0]*(N+1)
    for i,ai in enumerate(a[:N+1]):
        ai%=mod
        if not ai: continue
        for j in range(N-i+1):
            if b[j]: c[i+j]=(c[i+j]+ai*b[j])%mod
    return c

class Series:
    def __init__(self,N:int,mod:int=MOD):
        self.N=N; self.mod=mod
        self.P_exact=compute_P_exact(N+2)
        self.P=[x%mod for x in self.P_exact]
        self.InvP=inv_series_mod(self.P,N+2,mod)
        self.Q6=eta6_4_mod(N+2,mod)
        self.PQ=conv_mod(self.P,self.Q6,N+2,mod)
    def coeffs(self,n:int)->Tuple[Optional[int],Optional[int],Optional[int],Optional[int],int]:
        f=1 if n==0 else C(n)%self.mod
        if n<0 or n>self.N: return None,None,None,None,f
        T=self.P[n+1]%self.mod
        F=(-2*self.PQ[n])%self.mod
        if n>=1:
            inv=self.InvP[n-1]
            J=(T+72*inv)%self.mod
            Y=(T-72*inv)%self.mod
        else:
            J=(T+5)%self.mod; Y=T
        return T,F,J,Y,f

# ---------- residual shell state ----------

def signed_box_image(factors:Dict[int,int],mod:int)->Dict[int,int]:
    counts={1%mod:1}
    for q,e in factors.items():
        q%=mod
        invq=pow(q,-1,mod)
        vals=[pow(q,b,mod) if b>=0 else pow(invq,-b,mod) for b in range(-e,e+1)]
        new={}
        for r,c in counts.items():
            for v in vals: new[(r*v)%mod]=new.get((r*v)%mod,0)+c
        counts=new
    return counts

def subgroup_generated(gens:Iterable[int],mod:int)->set[int]:
    gs=[]
    for g in gens:
        g%=mod
        if math.gcd(g,mod)==1:
            gs += [g,pow(g,-1,mod)]
    sub={1%mod}; changed=True
    while changed:
        changed=False
        for h in list(sub):
            for g in gs:
                v=(h*g)%mod
                if v not in sub:
                    sub.add(v); changed=True
    return sub

def shell_state(p:int,R:int)->Dict[str,object]:
    if (p+R)%4: return {"R":R,"admissible":False}
    a=(p+R)//4
    if math.gcd(p*a,R)!=1: return {"R":R,"admissible":True,"coprime":False,"a":a}
    fac=factor_int(a)
    K=subgroup_generated(fac.keys(),R)
    image=signed_box_image(fac,R)
    t0=(-1)%R; t1=(-pow(p,-1,R))%R
    def state(t:int)->str:
        if t not in K: return 'tau'
        c=image.get(t,0)
        return '0_Z' if c==0 else f'positive:{c}'
    s0=state(t0); s1=state(t1)
    omega='positive' if s0.startswith('positive') or s1.startswith('positive') else ('tau' if s0=='tau' and s1=='tau' else '0_Z')
    fact='*'.join(f'{q}^{e}' if e>1 else str(q) for q,e in sorted(fac.items()))
    return {"R":R,"a":a,"factorization":fact,"target_minus1":t0,"target_edge":t1,"state_minus1":s0,"state_edge":s1,"omega_state":omega,"image_size":len(image),"subgroup_size":len(K)}

KNOWN=[
('S1',1,'standard-runtime'),('S2',6,'standard-runtime'),('S3',21,'standard-runtime'),('S4=Rstar',107,'standard-runtime/residual-shell'),('S5',47176870,'standard-runtime'),
('Sigma1',1,'standard-score'),('Sigma2',4,'standard-score'),('Sigma3',6,'standard-score'),('Sigma4',13,'standard-score'),('Sigma5',4098,'standard-score'),('Space5',12289,'standard-space'),
('Goldbach25',25,'logic-state'),('Goldbach27',27,'logic-state'),('Goldbach43',43,'logic-state'),('RH744',744,'logic-state'),('ZFC745',745,'logic-state'),('ZFC748',748,'logic-state'),('ZFC1919',1919,'logic-state'),('ZFC7910',7910,'logic-state'),
('TwoD_S2_3_2',32,'two-dimensional'),('TwoD_S2_4_2',4632,'two-dimensional'),('TwoD_S2_5_2',25772988638,'two-dimensional'),('TwoD_Sigma2_3_2',11,'two-dimensional'),('TwoD_Sigma2_4_2',244,'two-dimensional'),('TwoD_Sigma2_5_2',935508401,'two-dimensional'),
('Count_S1',32,'catalog-count'),('Count_S2',40,'catalog-count'),('Count_S3',16,'catalog-count'),('Count_Sigma1',16,'catalog-count'),('Count_Sigma2',4,'catalog-count'),('Count_Sigma3',40,'catalog-count'),('Count_Space1',32,'catalog-count'),('Count_Space2',24,'catalog-count'),('Count_Space3',48,'catalog-count'),
('BLB2',8,'blanking'),('BLB3_lb',34,'blanking'),('BLB4_lb',32779477,'blanking'),('BLB5_lb',32810047,'blanking'),('BLB6_lb',65538549,'blanking'),('BLB_2_3_lb',77,'blanking'),('BLB_2_4_lb',1367361263049,'blanking'),
('BBB1',1,'beeping'),('BBB2',6,'beeping'),('BBB3_lb',55,'beeping'),('BBB4_lb',32779478,'beeping'),
('BBf19',370,'fractran'),('BBf20',746,'fractran'),('BBf21_lb',31957632,'fractran'),('lambda29',223,'lambda'),('lambda37',38127987424943,'lambda'),('user6147',6147,'suggested'),('user81991',81991,'suggested'),('primitive_note_1196',1196,'methodology-label')]

def write_csv(path:str,N:int)->None:
    sc=Series(N)
    with open(path,'w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['name','value','source','r107','r840','ord107','T','F','J','Y','f6'])
        for name,n,src in KNOWN:
            T,F,J,Y,f6=sc.coeffs(n)
            w.writerow([name,n,src,n%MOD,n%MOD840,order_mod(n,MOD),T,F,J,Y,f6])
        w.writerow(['S6_visible_lb_10^^15','10^^15','visible-lower-bound',tetration_10_mod(15,MOD),tetration_10_mod(15,MOD840),order_mod(tetration_10_mod(15,MOD),MOD),'','','','',''])

def verify(N:int)->List[str]:
    sc=Series(N)
    out=[]
    def ok(label,lhs,rhs):
        assert lhs%MOD==rhs%MOD, (label,lhs%MOD,rhs%MOD)
        out.append(f'[OK] {label}: {lhs%MOD}')
    p=8803369; R=107; a=(p+R)//4; Nstar=p*a
    S2=6; S3=21; S5=47176870; Sigma5=4098; Space5=12289
    ok('pstar mod 107',p,51); ok('astar mod 107',a,93); ok('Nstar mod 107',Nstar,35)
    ok('S(3)^-1 == pstar',pow(S3,-1,MOD),p)
    ok('S(5) == Nstar',S5,Nstar)
    ok('S(3) S(5) == astar',S3*S5,a)
    ok('-S(3)S(5) == 11^2',-S3*S5,121)
    ok('S(2)S(5) == -4',S2*S5,-4)
    ok('(-S(2)S(5))^-1 == 27',pow((-S2*S5)%MOD,-1,MOD),27)
    for n,r in [(744,-5),(745,-4),(746,-3),(747,-2),(748,-1)]: ok(f'{n} == {r}',n,r)
    ok('[q^107]T == 4^2',sc.coeffs(107)[0] or 0,16)
    ok('[q^107]F == 4',sc.coeffs(107)[1] or 0,4)
    ok('[q^745]J == Sigma(5)',sc.coeffs(745)[2] or 0,Sigma5)
    ok('[q^745]Y == -27',sc.coeffs(745)[3] or 0,-27)
    ok('[q^Space5]f6 == Sigma(5)',sc.coeffs(Space5)[4],Sigma5)
    ok('[q^4632]f6 == 25',sc.coeffs(4632)[4],25)
    ok('6147^-1 == 81991',pow(6147,-1,MOD),81991)
    ok('[q^81991]f6 == 11',sc.coeffs(81991)[4],11)
    ok('10^^15 == 89',tetration_10_mod(15,MOD),89)
    ok('4*(10^^15) == S(5)',4*tetration_10_mod(15,MOD),S5)
    for RR in [27,43,107]:
        st=shell_state(p,RR)
        out.append(f"[OK] shell R={RR}: omega={st.get('omega_state')} a={st.get('a')} factorization={st.get('factorization')} targets=({st.get('target_minus1')},{st.get('target_edge')}) states=({st.get('state_minus1')},{st.get('state_edge')})")
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--max-index',type=int,default=2000)
    ap.add_argument('--csv',default='bb_moonshine_sweep_mod107_enhanced.csv')
    ap.add_argument('--verify',default='verification_output.txt')
    args=ap.parse_args()
    write_csv(args.csv,args.max_index)
    lines=verify(max(args.max_index,2000))
    with open(args.verify,'w') as f: f.write('\n'.join(lines)+'\n')
    for line in lines: print(line)
    print(f'[OK] wrote csv: {args.csv}')
    print(f'[OK] wrote verification: {args.verify}')

if __name__=='__main__': main()

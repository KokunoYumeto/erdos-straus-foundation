#!/usr/bin/env python3
import itertools, math

def factor(n):
    out=[]
    d=2
    while d*d<=n:
        e=0
        while n%d==0:
            n//=d
            e+=1
        if e:
            out.append((d,e))
        d += 1 if d==2 else 2
    if n>1:
        out.append((n,1))
    return out

def discrete_log_table(g, m):
    order=1
    cur=g % m
    while cur != 1:
        cur=(cur*g) % m
        order += 1
    return order, {pow(g,i,m):i for i in range(order)}

def coefficient_data(p, R, primitive):
    a=(p+R)//4
    fac=factor(a)
    order, log=discrete_log_table(primitive, R)
    targets=[(-1)%R, (-pow(p,-1,R))%R]
    target_logs=[log[t] for t in targets]
    intervals=[]
    for ell,e in fac:
        x=log[ell%R]
        intervals.append((ell,e,x,sorted({(b*x)%order for b in range(-e,e+1)})))
    counts={t:0 for t in target_logs}
    vectors=[]
    ranges=[range(-e,e+1) for ell,e,x,I in intervals]
    for betas in itertools.product(*ranges):
        exp=sum(beta*x for beta,(ell,e,x,I) in zip(betas, intervals)) % order
        if exp in counts:
            counts[exp]+=1
            vectors.append((exp,betas))
    return a, fac, order, intervals, targets, target_logs, counts, vectors

def print_case(p,R,g):
    a, fac, order, intervals, targets, target_logs, counts, vectors = coefficient_data(p,R,g)
    print(f"p={p}, R={R}, a={a}")
    print("factorization:", fac)
    print("cyclic order:", order)
    print("intervals:", intervals)
    print("targets:", targets, "target logs:", target_logs)
    print("counts:", counts)
    print("vectors:", vectors)
    print()

if __name__ == "__main__":
    print_case(12289,11,2)
    print_case(8803369,43,2)
    print_case(8803369,107,2)

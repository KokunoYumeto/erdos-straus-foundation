#!/usr/bin/env python3
from __future__ import annotations
import math, csv
from pathlib import Path

MOD=107
NMAX=760

def inv(a,m=MOD):
    return pow(a % m, -1, m)

def sigma1(n:int)->int:
    if n<=0:
        return 0
    s=0
    r=int(math.isqrt(n))
    for d in range(1,r+1):
        if n%d==0:
            s+=d
            if d*d!=n:
                s+=n//d
    return s

def factor_series(m:int, e:int, N:int, mod:int=MOD):
    # Return coefficients of (1-q^m)^e modulo mod up to q^N.
    out=[0]*(N+1); out[0]=1
    if e>=0:
        for k in range(1, min(e,N//m)+1):
            out[m*k]=math.comb(e,k)*((-1)**k)%mod
    else:
        a=-e
        for k in range(1,N//m+1):
            # (1-x)^(-a)=sum binom(a+k-1,k)x^k
            out[m*k]=math.comb(a+k-1,k)%mod
    return out

def conv(a,b,N,mod=MOD):
    c=[0]*(N+1)
    for i,ai in enumerate(a):
        if ai:
            maxj=N-i
            for j in range(maxj+1):
                bj=b[j]
                if bj:
                    c[i+j]=(c[i+j]+ai*bj)%mod
    return c

def eta_product_P(exps:dict[int,int], N:int, mod:int=MOD):
    # P(q)=prod_{d} prod_{m>=1} (1-q^{dm})^{exps[d]}
    P=[0]*(N+1); P[0]=1
    for d,e in exps.items():
        for m in range(d,N+1,d):
            P=conv(P, factor_series(m,e,N,mod), N, mod)
    return P

def inv_series(P,N,mod=MOD):
    assert P[0]%mod==1
    B=[0]*(N+1); B[0]=1
    for n in range(1,N+1):
        s=0
        for k in range(1,n+1):
            s=(s+P[k]*B[n-k])%mod
        B[n]=(-s)%mod
    return B

def coeff_T(P,n):
    # T=q^{-1}P; coefficient q^n is P[n+1]
    return P[n+1] % MOD if n+1 < len(P) else None

def coeff_I(B,scale,n):
    # scale/T = scale*q/P; coefficient q^n is scale*B[n-1]
    if n<1: return 0
    return scale*B[n-1] % MOD

def C6(n):
    return (5*sigma1(n) - 2*sigma1(n//2 if n%2==0 else 0) + 3*sigma1(n//3 if n%3==0 else 0) - 30*sigma1(n//6 if n%6==0 else 0)) % MOD

def C9(n):
    return (3*sigma1(n) - 27*sigma1(n//9 if n%9==0 else 0)) % MOD

def order_mod(a,mod=MOD):
    a%=mod
    if math.gcd(a,mod)!=1: return 0
    x=1
    for k in range(1,mod):
        x=x*a%mod
        if x==1: return k
    raise RuntimeError

# T6 = eta^5 eta(3)/(eta(2) eta(6)^5) = q^-1 P6
P6=eta_product_P({1:5,2:-1,3:1,6:-5}, NMAX+2)
B6=inv_series(P6,NMAX+2)
Q6=eta_product_P({6:4}, NMAX+2) # prod (1-q^{6n})^4
F6=[(-2*x)%MOD for x in conv(P6,Q6,NMAX+2)]

# T9 = eta^3 / eta(9)^3 = q^-1 P9
P9=eta_product_P({1:3,9:-3}, NMAX+2)
B9=inv_series(P9,NMAX+2)

rows=[]
for n in [744,750]:
    T6=coeff_T(P6,n)
    I6=coeff_I(B6,72,n)
    rows.append({
        'n':n,
        'mod107':n%107,
        'mod9':n%9,
        'T6':T6,
        'F6':F6[n],
        'J6':(T6+I6)%MOD,
        'Y6':(T6-I6)%MOD,
        'f6':C6(n),
        'T9':coeff_T(P9,n),
        'I9':coeff_I(B9,27,n),
        'J9':(coeff_T(P9,n)+coeff_I(B9,27,n))%MOD,
        'Y9':(coeff_T(P9,n)-coeff_I(B9,27,n))%MOD,
        'f9':C9(n),
    })

# Assertions from the note
assert [pow(289,j,840) for j in range(6)] == [1,289,361,169,121,529]
assert 107*107 % 840 == 529
assert 744%9 == 6 and 750%9 == 3
assert rows[0]['T9']==0 and rows[1]['T9']==0
assert rows[0]['J9']==35 and rows[0]['Y9']==72 and rows[0]['f9']==89
assert rows[1]['J9']==42 and rows[1]['Y9']==65 and rows[1]['f9']==52
assert rows[1]['J9']*rows[1]['J9'] % MOD == rows[1]['f9']
assert inv(rows[1]['f9']) == 35
assert rows[1]['Y6'] == 93 and rows[1]['F6'] == 106 and rows[1]['f6'] == 21
assert inv(21)==51
assert 47176870 % 107 == 35
assert (21*(47176870%107))%107 == 93
assert (-21*(47176870%107))%107 == (11*11)%107

outdir=Path(__file__).resolve().parents[1]
with open(outdir/'data'/'snowflake_a8_rows.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

tri=sorted({(r*(r+1)//2)%9 for r in range(9)})
report=[]
report.append('SNOWFLAKE/A8 VERIFICATION REPORT')
report.append('MOD=107')
report.append(f'S840 powers of 289: {[pow(289,j,840) for j in range(6)]}')
report.append(f'Triangular residues mod 9: {tri}')
report.append(f'107^2 mod 840 = {107*107%840}')
report.append('Rows:')
for row in rows:
    report.append(str(row))
report.append(f'inv(f9_750) = {inv(rows[1]["f9"])}')
report.append(f'J9_750^2 mod 107 = {rows[1]["J9"]*rows[1]["J9"]%MOD}')
report.append(f'S(5) mod 107 = {47176870%107}')
report.append(f'S(3)^(-1) mod 107 = {inv(21)}')
report.append('All assertions passed.')
(outdir/'reports'/'snowflake_a8_verification.txt').write_text('\n'.join(report))
print('\n'.join(report))

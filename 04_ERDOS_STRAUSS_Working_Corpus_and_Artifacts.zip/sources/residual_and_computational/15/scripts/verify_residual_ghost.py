from functools import lru_cache
from collections import defaultdict
try:
    import sympy as sp
except Exception:
    sp = None

def conj_basis(idx, n):
    return (1, 0) if idx == 0 else (-1, idx)

@lru_cache(None)
def mult_basis(i, j, n=4):
    if n == 0:
        return (1, 0)
    half = 1 << (n-1)
    if i < half and j < half:
        return mult_basis(i, j, n-1)
    if i < half and j >= half:
        coeff, idx = mult_basis(j-half, i, n-1)
        return coeff, idx + half
    if i >= half and j < half:
        s, cidx = conj_basis(j, n-1)
        coeff, idx = mult_basis(i-half, cidx, n-1)
        return coeff*s, idx + half
    s, didx = conj_basis(j-half, n-1)
    coeff, idx = mult_basis(didx, i-half, n-1)
    return -s*coeff, idx

def name(idx):
    if idx == 0: return '1'
    return 'o' + ''.join(str(i+1) for i in range(4) if idx & (1<<i))

def add_vec(a,b):
    r = defaultdict(int); r.update(a)
    for k,v in b.items(): r[k] += v
    return {k:v for k,v in r.items() if v}

def neg_vec(a): return {k:-v for k,v in a.items()}
def scalar(c,a): return {k:c*v for k,v in a.items() if c*v}

def mul_vec(a,b):
    out=defaultdict(int)
    for (i,t1),c1 in a.items():
        for (j,t2),c2 in b.items():
            s,k=mult_basis(i,j,4)
            out[(k,(t1+t2)%2)] += c1*c2*s
    return {k:v for k,v in out.items() if v}

def blade(S):
    idx=0
    for i in S: idx |= 1<<(i-1)
    return idx

O1=blade({1}); O2=blade({2}); O34=blade({3,4}); O1234=blade({1,2,3,4})
X={(O1,0):1,(O1234,1):-1}
Y={(O2,0):1,(O34,1):1}
XY=mul_vec(X,Y); YX=mul_vec(Y,X)
print('XY =', XY)
print('YX =', YX)
assert XY == {} and YX == {}

def assoc(a,b,c):
    return add_vec(mul_vec(mul_vec(a,b),c), neg_vec(mul_vec(a,mul_vec(b,c))))
AXXY=assoc(X,X,Y)
AYYX=assoc(Y,Y,X)
print('[X,X,Y] =', AXXY)
print('-2Y =', scalar(-2,Y))
print('[Y,Y,X] =', AYYX)
print('-2X =', scalar(-2,X))
assert AXXY == scalar(-2,Y)
assert AYYX == scalar(-2,X)

def L(a, v): return mul_vec(a,v)
def Gamma(v): return add_vec(L(X,L(Y,v)), neg_vec(L(Y,L(X,v))))
T={(O34,1):1}
O1tag={(O1,0):1}
print('Gamma(T) =', Gamma(T))
print('Gamma(o1[0]) =', Gamma(O1tag))
assert Gamma(T) == {(O1,0):-2}
assert Gamma(O1tag) == {(O34,1):2}
# Matrix and characteristic polynomial
basis=[(i,t) for t in range(2) for i in range(16)]
index={b:i for i,b in enumerate(basis)}
M=[[0]*32 for _ in range(32)]
for col,b in enumerate(basis):
    img=Gamma({b:1})
    for k,c in img.items():
        M[index[k]][col]=c
if sp is not None:
    x=sp.symbols('x')
    mat=sp.Matrix(M)
    cp=sp.factor(mat.charpoly(x).as_expr())
    print('charpoly =', cp)
    assert sp.expand(cp - x**8*(x**2+4)**8*(x**2+16)**4) == 0
else:
    print('sympy unavailable; skipped charpoly')
print('OK')

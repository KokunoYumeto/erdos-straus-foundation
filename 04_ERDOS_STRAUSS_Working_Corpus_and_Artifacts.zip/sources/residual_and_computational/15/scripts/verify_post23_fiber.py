from math import gcd
import cmath, math
M = 840*11*19*23
S840_order = [1,289,361,169,121,529]
A11 = {1,2,3,4,5,6,9}
A23 = {1,2,3,4,5,6,8,9,12,13,14,16,18}
counts = {s:0 for s in S840_order}
classes = []
for r in range(M):
    if gcd(r,M) != 1:
        continue
    if r % 840 not in counts:
        continue
    if r % 11 not in A11:
        continue
    if r % 23 not in A23:
        continue
    if r % 5 == 1 and r % 19 in {14,15,18}:
        continue
    if r % 7 == 2 and r % 19 in {10,13,15}:
        continue
    classes.append(r)
    counts[r % 840] += 1
v = [counts[s]//91 for s in S840_order]
print('M23 =', M)
print('|V_>23| =', len(classes))
print('S840 order =', S840_order)
print('sector counts =', [counts[s] for s in S840_order])
print('mod19 vector =', v)
print('Fourier coefficients:')
for m in range(6):
    val = sum(v[k]*complex(math.cos(-2*math.pi*m*k/6), math.sin(-2*math.pi*m*k/6)) for k in range(6))
    print(m, round(val.real,12), round(val.imag,12), 'abs', round(abs(val),12))
assert len(classes)==8554
assert [counts[s] for s in S840_order] == [1365,1365,1365,1638,1183,1638]
assert v == [15,15,15,18,13,18]
print('OK')

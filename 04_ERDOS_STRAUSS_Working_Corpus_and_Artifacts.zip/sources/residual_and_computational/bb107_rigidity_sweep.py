#!/usr/bin/env python3
from __future__ import annotations
import csv, math, os
from typing import List, Tuple
import numpy as np

MOD = 107
MAXN = 12290

def compute_P(N: int = MAXN, p: int = MOD) -> np.ndarray:
    """Compute P(q)=prod_{n>=1}(1-q^n)^E(n) modulo p up to q^N."""
    bins = {e: [(((-1)**k) * math.comb(e, k)) % p for k in range(e + 1)] for e in range(7)}
    a = np.zeros(N + 1, dtype=np.int16)
    a[0] = 1
    for n in range(1, N + 1):
        e = 5 - (1 if n % 2 == 0 else 0) + (1 if n % 3 == 0 else 0) - (5 if n % 6 == 0 else 0)
        if e == 0:
            continue
        old = a.astype(np.int32, copy=True)
        new = old.copy()
        for k in range(1, e + 1):
            shift = k * n
            if shift > N:
                break
            new[shift:] += bins[e][k] * old[:N + 1 - shift]
        a = (new % p).astype(np.int16)
    return a

def invert_series(a: np.ndarray, N: int = MAXN, p: int = MOD) -> np.ndarray:
    """Formal inverse of a(q), with a[0]=1, modulo p."""
    b = np.zeros(N + 1, dtype=np.int16)
    b[0] = 1
    aa = a.astype(np.int64)
    for n in range(1, N + 1):
        s = int(np.dot(aa[1:n + 1], b[n - 1::-1].astype(np.int64)))
        b[n] = (-s) % p
    return b

def compute_PQ6(P: np.ndarray, N: int = MAXN, p: int = MOD) -> np.ndarray:
    """Compute P(q)*prod_{n>=1}(1-q^{6n})^4 modulo p up to q^N."""
    R = P.astype(np.int32, copy=True)
    for n in range(1, N // 6 + 1):
        step = 6 * n
        old = R.copy()
        new = old.copy()
        for k, coeff in [(1, -4), (2, 6), (3, -4), (4, 1)]:
            shift = k * step
            if shift > N:
                break
            new[shift:] += coeff * old[:N + 1 - shift]
        R = new % p
    return R.astype(np.int16)

def sigma1(n: int) -> int:
    if n <= 0:
        return 0
    s = 0
    r = math.isqrt(n)
    for d in range(1, r + 1):
        if n % d == 0:
            s += d
            q = n // d
            if q != d:
                s += q
    return s

def C(n: int) -> int:
    return (5 * sigma1(n)
            - 2 * (sigma1(n // 2) if n % 2 == 0 else 0)
            + 3 * (sigma1(n // 3) if n % 3 == 0 else 0)
            - 30 * (sigma1(n // 6) if n % 6 == 0 else 0))

def inv_mod(a: int, p: int = MOD) -> int:
    return pow(int(a) % p, -1, p)

def order_mod(a: int, p: int = MOD) -> int | None:
    a %= p
    if a == 0:
        return None
    x = 1
    for k in range(1, p):
        x = (x * a) % p
        if x == 1:
            return k
    return None

def det_mod(A: List[List[int]], p: int = MOD) -> int:
    A = [list(map(lambda x: x % p, row)) for row in A]
    n = len(A)
    d = 1
    for i in range(n):
        pivot = None
        for r in range(i, n):
            if A[r][i] % p:
                pivot = r
                break
        if pivot is None:
            return 0
        if pivot != i:
            A[i], A[pivot] = A[pivot], A[i]
            d = -d
        piv = A[i][i] % p
        d = (d * piv) % p
        inv = inv_mod(piv, p)
        for r in range(i + 1, n):
            if A[r][i] % p:
                f = A[r][i] * inv % p
                for c in range(i, n):
                    A[r][c] = (A[r][c] - f * A[i][c]) % p
    return d % p

def mat_inv(A: List[List[int]], p: int = MOD) -> List[List[int]]:
    A = [list(map(lambda x: x % p, row)) for row in A]
    n = len(A)
    M = [A[i] + [1 if i == j else 0 for j in range(n)] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] % p:
                pivot = r
                break
        if pivot is None:
            raise ValueError('singular matrix')
        M[col], M[pivot] = M[pivot], M[col]
        inv = inv_mod(M[col][col], p)
        M[col] = [(x * inv) % p for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] % p:
                f = M[r][col] % p
                M[r] = [(M[r][c] - f * M[col][c]) % p for c in range(2 * n)]
    return [row[n:] for row in M]

def mat_mul(A: List[List[int]], B: List[List[int]], p: int = MOD) -> List[List[int]]:
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) % p for j in range(len(B[0]))] for i in range(len(A))]

def mat_sub(A: List[List[int]], B: List[List[int]], p: int = MOD) -> List[List[int]]:
    return [[(A[i][j] - B[i][j]) % p for j in range(len(A[0]))] for i in range(len(A))]

def eye(n: int) -> List[List[int]]:
    return [[1 if i == j else 0 for j in range(n)] for i in range(n)]

def mat_pow(A: List[List[int]], e: int, p: int = MOD) -> List[List[int]]:
    R = eye(len(A))
    B = A
    while e:
        if e & 1:
            R = mat_mul(R, B, p)
        B = mat_mul(B, B, p)
        e >>= 1
    return R

def coeff_transform(P: np.ndarray, Pinv: np.ndarray, PQ6: np.ndarray, n: int) -> Tuple[int, int | None, int | None, int | None, int | None, int]:
    T = int(P[n + 1] % MOD) if n + 1 < len(P) else None
    inv = int(Pinv[n - 1] % MOD) if 0 <= n - 1 < len(Pinv) else None
    J = (T + 72 * inv) % MOD if T is not None and inv is not None else None
    Y = (T - 72 * inv) % MOD if T is not None and inv is not None else None
    F = (-2 * int(PQ6[n] % MOD)) % MOD if n < len(PQ6) else None
    E = C(n) % MOD
    return (n % MOD, T, F, J, Y, E)

def main() -> None:
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    datadir = os.path.join(root, 'data')
    repdir = os.path.join(root, 'reports')
    os.makedirs(datadir, exist_ok=True)
    os.makedirs(repdir, exist_ok=True)
    P = compute_P(MAXN, MOD)
    Pinv = invert_series(P, MAXN, MOD)
    PQ6 = compute_PQ6(P, MAXN, MOD)
    labels = [
        ('S1',1),('S2',6),('BB13_state',13),('S3',21),('Goldbach25',25),('Goldbach27',27),('Goldbach43',43),
        ('BBlambda47',47),('BBlambda95',95),('Rstar',107),('BBlambda201',201),('BB33_279',279),
        ('PA372',372),('BB33_412',412),('Subtle493',493),('BB33_650',650),
        ('RH744',744),('ZFC745',745),('Fractran20_746',746),('edge747',747),('ZFC748',748),('next749',749),('Coxeter750',750),
        ('BB6_holdout_1161',1161),('BB6_holdout_1214',1214),('Space5_12289',12289),
        ('Fractran19_370',370),('BBf21_31957632',31957632),('S5',47176870),('Sigma5',4098),
        ('BBf_candidate_6147',6147),('BBf_candidate_81991',81991),('ZFC1919',1919),('Yedidia7910',7910),
    ]
    with open(os.path.join(datadir, 'bb107_rigidity_sweep.csv'), 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['label','n','n_mod_107','n_mod_840','ord_107','T','F','J','Y','f6'])
        for label,n in labels:
            r,T,F,J,Y,E = coeff_transform(P,Pinv,PQ6,n) if n <= MAXN-1 else (n%MOD,None,None,None,None,C(n)%MOD)
            w.writerow([label,n,n%MOD,n%840,order_mod(n) if math.gcd(n,MOD)==1 else '',T,F,J,Y,E])
    def red(n: int) -> List[int]:
        r,T,F,J,Y,E = coeff_transform(P,Pinv,PQ6,n)
        return [r,T,F,J,E]
    B = [red(n) for n in range(744,749)]
    Binv = mat_inv(B)
    def Ashift(h: int) -> List[List[int]]:
        return mat_mul([red(n) for n in range(744+h, 749+h)], Binv)
    A1 = Ashift(1); A6 = Ashift(6); A21 = Ashift(21); A107 = Ashift(107)
    comm = mat_sub(mat_mul(A1,A6), mat_mul(A6,A1))
    powers1 = [mat_pow(A1,i) for i in range(5)]
    powers6 = [mat_pow(A6,j) for j in range(5)]
    vecmat = []
    for i in range(5):
        for j in range(5):
            M = mat_mul(powers1[i], powers6[j])
            vecmat.append([M[r][c] for r in range(5) for c in range(5)])
    H = [inv_mod(15), (27*inv_mod(77))%MOD, (49*inv_mod(3))%MOD, (10*inv_mod(49))%MOD, (33*inv_mod(2))%MOD]
    poly = [1]
    for x in H:
        new = [0]*(len(poly)+1)
        for i,a in enumerate(poly):
            new[i]=(new[i]+a)%MOD
            new[i+1]=(new[i+1]+a*x)%MOD
        poly = new
    with open(os.path.join(repdir, 'bb107_rigidity_report.txt'), 'w') as f:
        f.write('BB107 rigidity verification report\n')
        f.write('MOD=107, MAXN=%d\n\n' % MAXN)
        pstar=8803369; astar=2200869; Nstar=pstar*astar
        f.write('Core champion congruences:\n')
        f.write(f'pstar mod 107 = {pstar%MOD}\n')
        f.write(f'astar mod 107 = {astar%MOD}\n')
        f.write(f'Nstar mod 107 = {Nstar%MOD}\n')
        f.write(f'S(3)^-1 mod 107 = {inv_mod(21)}\n')
        f.write(f'S(5) mod 107 = {47176870%MOD}\n')
        f.write(f'S(3)S(5) mod 107 = {(21*(47176870%MOD))%MOD}\n')
        f.write(f'-S(3)S(5) mod 107 = {(-21*(47176870%MOD))%MOD}\n')
        f.write('\nSpace(5):\n')
        f.write(f'12289 = 107^2+840: {107**2+840}\n')
        f.write(f'12289 mod 107 = {12289%MOD}\n')
        f.write(f'12289 mod 840 = {12289%840}\n')
        f.write(f'289^5 mod 840 = {pow(289,5,840)}\n')
        f.write(f'coeff vector 12289 = {coeff_transform(P,Pinv,PQ6,12289)}\n')
        f.write('\nBasis block R_B:\n')
        for row in B: f.write(str(row)+'\n')
        f.write(f'det R_B = {det_mod(B)}\n')
        f.write('\nA1:\n')
        for row in A1: f.write(str(row)+'\n')
        f.write(f'det A1 = {det_mod(A1)}, trace A1 = {sum(A1[i][i] for i in range(5))%MOD}\n')
        f.write('\nA6:\n')
        for row in A6: f.write(str(row)+'\n')
        f.write(f'det A6 = {det_mod(A6)}, trace A6 = {sum(A6[i][i] for i in range(5))%MOD}\n')
        f.write(f'comm det = {det_mod(comm)}, comm trace = {sum(comm[i][i] for i in range(5))%MOD}\n')
        f.write(f'vectorized basis det = {det_mod(vecmat)}\n')
        f.write('\nBusy Beaver shift traces:\n')
        for h,A in [(1,A1),(6,A6),(21,A21),(107,A107)]:
            f.write(f'h={h}: det={det_mod(A)}, trace={sum(A[i][i] for i in range(5))%MOD}\n')
        f.write('\nFenrir H29 reduced vector and elementary symmetric polynomial:\n')
        f.write(str(H)+'\n')
        f.write('elementary symmetric coefficients e0..e5 = '+str(poly)+'\n')
        f.write('monic polynomial = X^5 - 6 X^4 + 22 X^3 - 53 X^2 + 98 X - 93 over F_107\n')
    print(os.path.join(datadir, 'bb107_rigidity_sweep.csv'))
    print(os.path.join(repdir, 'bb107_rigidity_report.txt'))
if __name__ == '__main__':
    main()

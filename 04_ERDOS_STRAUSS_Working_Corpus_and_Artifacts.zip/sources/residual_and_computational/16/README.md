# Lorentz-Apollonian hidden-fiber preprint package

Contents:

- `lorentz_apollonian_hidden_fiber.pdf` — compiled preprint.
- `lorentz_apollonian_hidden_fiber.tex` — LaTeX source.
- `scripts/verify_lorentz_apollonian.py` — exact symbolic/integer verification script.
- `verification/lorentz_apollonian_report.txt` — output of the verification script.

To reproduce the verification report:

```bash
python3 scripts/verify_lorentz_apollonian.py > verification/lorentz_apollonian_report.txt
```

To rebuild the PDF:

```bash
pdflatex -halt-on-error -interaction=nonstopmode lorentz_apollonian_hidden_fiber.tex
pdflatex -halt-on-error -interaction=nonstopmode lorentz_apollonian_hidden_fiber.tex
```

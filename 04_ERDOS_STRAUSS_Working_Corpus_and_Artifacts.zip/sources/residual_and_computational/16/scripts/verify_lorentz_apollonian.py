#!/usr/bin/env python3
"""Exact verification script for the Lorentz-Apollonian hidden-fiber preprint.

The script uses integer/rational arithmetic wherever possible and checks:
  * Descartes reflection matrices preserve the Descartes form and square to 1;
  * Hadamard diagonalization of the Descartes form;
  * fixed-coordinate ternary Lorentz slice formula;
  * ternary Fuchsian reflection matrices preserve the (2,1)-form;
  * sample edge products are unipotent of nilpotence index 3;
  * the C3 origin variance identities and integral gap;
  * the R=107 champion-shell enumeration quoted in the paper.
"""
from __future__ import annotations

from itertools import product
from fractions import Fraction
import math
import sympy as sp


def check(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def mat_eq(A, B) -> bool:
    return sp.Matrix(A).equals(sp.Matrix(B))


def main() -> None:
    lines = []
    I4 = sp.eye(4)
    J4 = sp.ones(4)
    D = 2 * I4 - J4
    lines.append("Descartes Gram matrix D=2I4-J4:")
    lines.append(str(D))

    S = []
    for i in range(4):
        M = sp.eye(4)
        for j in range(4):
            M[i, j] = 2 if j != i else -1
        S.append(M)
        check(M.T * D * M == D, f"S_{i+1} does not preserve D")
        check(M * M == I4, f"S_{i+1} is not an involution")
    lines.append("[OK] all four Descartes reflections satisfy S_i^T D S_i = D and S_i^2=I.")

    H = sp.Rational(1, 2) * sp.Matrix(
        [[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]]
    )
    diag = H.T * D * H
    lines.append("Hadamard diagonalization H^T D H:")
    lines.append(str(diag))
    check(diag == sp.diag(-2, 2, 2, 2), "Hadamard diagonalization failed")
    check(H * H == I4, "Hadamard matrix is not involutive")
    lines.append("[OK] F=2(-w^2+X^2+Y^2+Z^2).")

    a, y1, y2, y3 = sp.symbols("a y1 y2 y3")
    b, c, d = y1 - a, y2 - a, y3 - a
    F = 2 * (a**2 + b**2 + c**2 + d**2) - (a + b + c + d) ** 2
    g = y1**2 + y2**2 + y3**2 - 2 * y1 * y2 - 2 * y1 * y3 - 2 * y2 * y3
    check(sp.expand(F - (g + 4 * a**2)) == 0, "fixed-slice identity failed")
    lines.append("[OK] fixed-coordinate identity F(a,b,c,d)=g(b+a,c+a,d+a)+4a^2.")

    G = sp.Matrix([[1, -1, -1], [-1, 1, -1], [-1, -1, 1]])
    eigs = G.eigenvals()
    lines.append(f"Ternary Gram G eigenvalues: {eigs}")
    R = [
        sp.Matrix([[-1, 2, 2], [0, 1, 0], [0, 0, 1]]),
        sp.Matrix([[1, 0, 0], [2, -1, 2], [0, 0, 1]]),
        sp.Matrix([[1, 0, 0], [0, 1, 0], [2, 2, -1]]),
    ]
    for i, Ri in enumerate(R, 1):
        check(Ri.T * G * Ri == G, f"R_{i} does not preserve G")
        check(Ri * Ri == sp.eye(3), f"R_{i} is not involutive")
    lines.append("[OK] ternary sheet reflections preserve G and square to I.")

    U21 = R[1] * R[0]
    N21 = U21 - sp.eye(3)
    check(N21**3 == sp.zeros(3), "N21^3 is not zero")
    check(N21**2 != sp.zeros(3), "N21^2 unexpectedly zero")
    lam = U21.charpoly().gen
    check(sp.expand(U21.charpoly().as_expr() - (lam - 1) ** 3) == 0, "U21 charpoly is not (lambda-1)^3")
    lines.append("R2 R1 =")
    lines.append(str(U21))
    lines.append("N=(R2R1-I), N^2, N^3:")
    lines.append(str(N21))
    lines.append(str(N21**2))
    lines.append(str(N21**3))
    lines.append("[OK] sample edge product is unipotent with nilpotence index 3.")

    # Quaternionic face diagonalization.
    face_gram = sp.Matrix([[0, -2, -2], [-2, 0, -2], [-2, -2, 0]])
    p = sp.Matrix([1, -1, 0])
    q = sp.Matrix([1, 1, -2])
    r = sp.Matrix([1, 1, 1])
    diagvals = [(v.T * face_gram * v)[0] for v in [p, q, r]]
    cross = [(p.T * face_gram * q)[0], (p.T * face_gram * r)[0], (q.T * face_gram * r)[0]]
    check(diagvals == [4, 12, -12], "face diagonal norms failed")
    check(cross == [0, 0, 0], "face diagonal cross-terms failed")
    lines.append(f"[OK] face form diagonalizes as {diagvals}, cross terms {cross}.")

    # C3 origin variance identity.
    m0, m1, m2 = sp.symbols("m0 m1 m2")
    Ssum = m0 + m1 + m2
    var = m0**2 + m1**2 + m2**2 - Ssum**2 / sp.Integer(3)
    diff = ((m0 - m1) ** 2 + (m1 - m2) ** 2 + (m2 - m0) ** 2) / sp.Integer(3)
    check(sp.expand(var - diff) == 0, "C3 variance identity failed")
    r_sym, s_sym = sp.symbols("r s")
    var_rs = sp.expand(var.subs({m0: r_sym, m1: s_sym, m2: r_sym}))
    check(sp.expand(var_rs - sp.Rational(2, 3) * (r_sym - s_sym) ** 2) == 0, "origin-conjugate variance formula failed")
    lines.append("[OK] C3 variance identity and origin-conjugate formula A=2/3(s-r)^2.")

    # Hermitian determinant identity.
    h, u, v, w = sp.symbols("h u v w")
    Hmat = sp.Matrix([[h + w, u + sp.I * v], [u - sp.I * v, h - w]])
    check(sp.expand(Hmat.det() - (h**2 - u**2 - v**2 - w**2)) == 0, "Hermitian determinant identity failed")
    lines.append("[OK] det [[h+w,u+iv],[u-iv,h-w]]=h^2-u^2-v^2-w^2.")

    # Reciprocal geodesic algebra.
    aa, bb, cc, dd = sp.symbols("aa bb cc dd")
    gam = sp.Matrix([[aa, bb], [cc, dd]])
    P = gam.T * gam
    detP = sp.factor(P.det())
    check(detP == (aa * dd - bb * cc) ** 2, "det(gamma^T gamma) formula failed")
    J = sp.Matrix([[0, -1], [1, 0]])
    # Verify J^{-1} A J = A^{-T} under det=1 for generic 2x2 A.
    lhs = J.inv() * gam * J
    rhs = gam.inv().T
    # Substitute det=1 by replacing aa*dd-bb*cc -> 1 is cumbersome; verify after solving dd=(1+bc)/a.
    lhs_sub = lhs.subs(dd, (1 + bb * cc) / aa)
    rhs_sub = rhs.subs(dd, (1 + bb * cc) / aa)
    check(sp.simplify(lhs_sub - rhs_sub) == sp.zeros(2), "J identity failed")
    lines.append("[OK] J^{-1} gamma J = gamma^{-T} for det(gamma)=1.")

    # R=107 enumeration.
    MOD = 107
    ORDER = 106
    logs = [70, 22, 59, 66]
    ranges = [range(-2, 3), range(-2, 3), range(-1, 2), range(-1, 2)]
    target_minus_one = 53
    target_minus_pinv = 60
    hits_53 = []
    hits_60 = []
    for beta in product(*ranges):
        val = sum(b * l for b, l in zip(beta, logs)) % ORDER
        if val == target_minus_one:
            hits_53.append(beta)
        if val == target_minus_pinv:
            hits_60.append(beta)
    expected = [(-2, 0, -1, -1), (2, 0, 1, 1)]
    check(hits_53 == expected, f"unexpected R=107 -1 hits: {hits_53}")
    check(hits_60 == [], f"unexpected R=107 -p^-1 hits: {hits_60}")
    pstar = 8803369
    astar = (pstar + MOD) // 4
    check(astar == 2200869, "a_star mismatch")
    check(astar == 3**2 * 11**2 * 43 * 47, "a_star factorization mismatch")
    check((11**2 + astar) % MOD == 0, "11^2 congruence failed")
    check((3**2 * 43 * 47 + 1) % MOD == 0, "complement square congruence failed")
    lines.append("[OK] R=107 enumeration: only beta=(-2,0,-1,-1),(2,0,1,1) hit log(-1)=53; no hits at log(-p^{-1})=60.")
    lines.append("[OK] a*=3^2*11^2*43*47 and 11^2=-a*, 3^2*43*47=-1 mod 107.")

    # D6/C6 labeling of tetrahedral edges.
    cyc_edges = [(1, 2), (1, 3), (2, 3), (2, 4), (3, 4), (1, 4)]
    def adjacent(e, f):
        return bool(set(e) & set(f))
    check(all(adjacent(cyc_edges[i], cyc_edges[(i + 1) % 6]) for i in range(6)), "edge cycle is not Hamiltonian")
    lines.append(f"[OK] tetrahedral edge Hamiltonian 6-cycle: {cyc_edges}.")

    report = "\n".join(lines) + "\n"
    print(report)


if __name__ == "__main__":
    main()

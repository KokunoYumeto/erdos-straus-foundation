from math import gcd
from collections import deque
from fractions import Fraction

S840 = [1, 289, 361, 169, 121, 529]
M = 840 * 11 * 19 * 23
BASE_PRIMES = [2, 3, 5, 7, 11, 19, 23]
ODD_BASE = [3, 5, 7, 11, 19, 23]

NONVISIBLE_OLD = [
    27, 63, 99, 171, 207, 475, 575,
    1127, 1215, 1539, 2079, 2375,
    4655, 6831, 14375,
]

def crt_pair(a, m, b, n):
    g = gcd(m, n)
    if (b - a) % g:
        return None
    m1 = m // g
    n1 = n // g
    inv = pow(m1, -1, n1)
    t = ((b - a) // g * inv) % n1
    return (a + m * t) % (m * n1), m * n1

def crt_system(pairs):
    a, m = pairs[0]
    for b, n in pairs[1:]:
        out = crt_pair(a, m, b, n)
        if out is None:
            return None
        a, m = out
    return a % m, m

def base_residue(t):
    k, x, y, z = t
    return crt_system([(S840[k], 840), (x, 11), (y, 19), (z, 23)])[0]

def n_mod_selector(t, p):
    k, x, y, z = t
    if p == 2:
        return S840[k] % 8
    if p in (3, 5, 7):
        return S840[k] % (4 * p)
    if p == 11:
        return crt_system([(1, 4), (x, 11)])[0] % 44
    if p == 19:
        return crt_system([(1, 4), (y, 19)])[0] % 76
    if p == 23:
        return crt_system([(1, 4), (z, 23)])[0] % 92
    raise ValueError(p)

def available_from_residue(rho, t):
    A = []
    for p in BASE_PRIMES:
        if p != 2 and rho % p == 0:
            continue
        mod = 8 if p == 2 else 4 * p
        if n_mod_selector(t, p) == (-rho) % mod:
            A.append(p)
    return A

def u_set_mod_g(g, A):
    U = {1 % g}
    for p in A:
        P = {1 % g, p % g, (p * p) % g}
        U = {(u * v) % g for u in U for v in P}
    return U

def hit_state(rho, t):
    a = base_residue(t)
    g = gcd(M, rho)
    A = available_from_residue(rho, t)
    U = u_set_mod_g(g, A)
    return any((-4 * u - a) % g == 0 for u in U)

def semigroup():
    seen = {1 % M}
    q = deque([1 % M])
    while q:
        r = q.popleft()
        for p in ODD_BASE:
            s = (r * p) % M
            if s not in seen:
                seen.add(s)
                q.append(s)
    return seen

def sector(classes):
    v = [0] * 6
    for t in classes:
        v[t[0]] += 1
    return v

base = []
with open("survivors_divisor_visible_4951.txt") as f:
    for line in f:
        if line.strip():
            base.append(tuple(map(int, line.split())))

states = sorted(r for r in semigroup() if r % 4 == 3)
unhit = []
hit = []

for t in base:
    if any(hit_state(rho, t) for rho in states):
        hit.append(t)
    else:
        unhit.append(t)

print("Base", len(base))
print("States", len(states))
print("Hit", len(hit), "Unhit", len(unhit), "Sector", sector(unhit))
print("Pole >=", Fraction(len(unhit), M))

for k in range(6):
    xs = sorted(set(x for kk, x, y, z in unhit if kk == k))
    ys = sorted(set(y for kk, x, y, z in unhit if kk == k))
    zs = sorted(set(z for kk, x, y, z in unhit if kk == k))
    print("k=%d(%d): x=%s y=%s z=%s" % (k, sum(1 for t in unhit if t[0] == k), xs, ys, zs))

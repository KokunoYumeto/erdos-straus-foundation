from fractions import Fraction

M = 840 * 11 * 19 * 23
core_size = 2970

def probe(q):
    assert q % 4 == 3
    assert M % q != 0
    killed = core_size
    surviving = core_size * (q - 2)
    denominator = M * q
    return killed, surviving, Fraction(surviving, denominator)

for q in [31, 43, 47, 59, 67, 71]:
    killed, surviving, pole = probe(q)
    print("q=%d killed=%d surviving=%d pole=%s" % (q, killed, surviving, pole))

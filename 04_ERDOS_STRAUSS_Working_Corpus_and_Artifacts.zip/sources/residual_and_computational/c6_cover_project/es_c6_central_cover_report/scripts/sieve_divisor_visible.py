from math import gcd
from fractions import Fraction

S840 = [1, 289, 361, 169, 121, 529]
M23 = 840 * 11 * 19 * 23
PRIMES = [2, 3, 5, 7, 11, 19, 23]

def crt_pair(a, m, b, n):
    g = gcd(m, n)
    if (b - a) % g:
        return None
    m1 = m // g
    n1 = n // g
    inv = pow(m1, -1, n1)
    t = ((b - a) // g * inv) % n1
    mod = m * n1
    return ((a + m * t) % mod, mod)

def crt_system(pairs):
    a, m = pairs[0]
    for b, n in pairs[1:]:
        out = crt_pair(a, m, b, n)
        if out is None:
            return None
        a, m = out
    return a % m, m

def divisors_from_factorization(factors):
    divs = [1]
    for p, e in factors:
        divs = [d * (p ** a) for d in divs for a in range(e + 1)]
    return sorted(divs)

def base_residue(k, x, y, z):
    return crt_system([(S840[k], 840), (x, 11), (y, 19), (z, 23)])[0]

def selector_residue(k, x, y, z, p):
    if p in (2, 3, 5, 7):
        return S840[k] % (4 * p)
    if p == 11:
        return crt_system([(1, 4), (x, 11)])[0] % 44
    if p == 19:
        return crt_system([(1, 4), (y, 19)])[0] % 76
    if p == 23:
        return crt_system([(1, 4), (z, 23)])[0] % 92
    raise ValueError(p)

def available_primes(R, k, x, y, z):
    out = []
    for p in PRIMES:
        if R % p == 0:
            continue
        if selector_residue(k, x, y, z, p) == (-R) % (4 * p):
            out.append(p)
    return out

def u_set_mod_R(R, plist):
    U = {1 % R}
    for p in plist:
        P = {1 % R, p % R, (p * p) % R}
        U = {(u * v) % R for u in U for v in P}
    return U

def target_set(R, k, x, y, z):
    return {(-4 * u) % R for u in u_set_mod_R(R, available_primes(R, k, x, y, z)) if (-4 * u) % R != 0}

def is_deleted(R, k, x, y, z):
    if M23 % R:
        raise ValueError("R not visible")
    return base_residue(k, x, y, z) % R in target_set(R, k, x, y, z)

R_div = [
    d for d in divisors_from_factorization(
        [(2, 3), (3, 1), (5, 1), (7, 1), (11, 1), (19, 1), (23, 1)]
    )
    if d >= 3 and d % 4 == 3
]

surv = [
    (k, x, y, z)
    for k in range(6)
    for x in range(1, 11)
    for y in range(1, 19)
    for z in range(1, 23)
]

print("initial", len(surv))
for R in R_div:
    new = []
    deleted = 0
    for tup in surv:
        if is_deleted(R, *tup):
            deleted += 1
        else:
            new.append(tup)
    if deleted:
        sector = [0] * 6
        for k, x, y, z in new:
            sector[k] += 1
        print((R, deleted, len(new), sector))
        surv = new

sector = [0] * 6
for k, x, y, z in surv:
    sector[k] += 1

print("final", len(surv), sector, Fraction(len(surv), M23))

with open("survivors_divisor_visible_4951.txt", "w") as f:
    for t in surv:
        f.write("%d %d %d %d\n" % t)

# Finite Central-Cover Reductions for Residual Erdos--Straus Shells

## Contents

- `es_c6_central_cover_report.tex` -- LaTeX source
- `es_c6_central_cover_report.pdf` -- compiled paper
- `scripts/sieve_divisor_visible.py`
- `scripts/all_smooth_semigroup.py`
- `scripts/external_prime_probe.py`

## Build

    pdflatex es_c6_central_cover_report.tex
    pdflatex es_c6_central_cover_report.tex

## Reproduce computations

    cd scripts
    python3 sieve_divisor_visible.py
    python3 all_smooth_semigroup.py
    python3 external_prime_probe.py

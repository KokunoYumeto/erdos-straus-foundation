#!/usr/bin/env bash
set -euo pipefail
pdflatex es_c6_central_cover_report.tex
pdflatex es_c6_central_cover_report.tex

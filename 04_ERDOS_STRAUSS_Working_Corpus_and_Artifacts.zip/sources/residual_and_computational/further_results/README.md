# Dependencies of `combined_live_theorem_package.tex`

The local project archive `BEAVERSHINE/furthe/combined_live_theorem_package_bundle.zip` contains the assembly source, its compiled PDF, and the eight PDFs included by the assembly source. This directory holds an exact extraction of that bounded package for deterministic public-corpus assembly.

The public corpus places the eight included papers beside `combined_live_theorem_package.tex`, preserving the relative filenames used by its `\includepdf` commands. The package hash, member hashes, PDF safety results, and public-source rebuild are checked separately before release.

These papers are retained as historical project inputs. Several carry draft labels or unresolved bibliography markers, and one retains its original “OpenAI technical note” label. Their inclusion makes the assembly source complete; it does not promote their claims beyond the theorem status stated in the current reader.

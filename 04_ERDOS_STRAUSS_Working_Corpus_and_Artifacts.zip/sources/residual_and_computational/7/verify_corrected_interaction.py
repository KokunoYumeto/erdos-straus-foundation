#!/usr/bin/env python3
from __future__ import annotations
import math
from itertools import product
from collections import defaultdict
from pathlib import Path
import sympy as sp

MOD = 107
NMAX = 760
x = sp.symbols('X')


def inv(a:int, m:int=MOD)->int:
    return pow(a % m, -1, m)


def sigma1(n:int)->int:
    if n <= 0:
        return 0
    s = 0
    r = math.isqrt(n)
    for d in range(1, r+1):
        if n % d == 0:
            s += d
            if d*d != n:
                s += n//d
    return s


def factor_int(n:int):
    out=[]
    d=2
    while d*d<=n:
        e=0
        while n%d==0:
            n//=d; e+=1
        if e:
            out.append((d,e))
        d += 1 if d==2 else 2
    if n>1:
        out.append((n,1))
    return out


def factor_series(m:int, e:int, N:int, mod:int=MOD):
    f=[0]*(N+1); f[0]=1
    if e >= 0:
        for k in range(1, min(e, N//m)+1):
            f[m*k] = math.comb(e,k)*((-1)**k) % mod
    else:
        a=-e
        for k in range(1, N//m+1):
            f[m*k] = math.comb(a+k-1,k) % mod
    return f


def conv(a,b,N:int=NMAX,mod:int=MOD):
    c=[0]*(N+1)
    for i,ai in enumerate(a):
        if ai:
            for j,bj in enumerate(b[:N+1-i]):
                if bj:
                    c[i+j] = (c[i+j] + ai*bj) % mod
    return c


def eta_product_P(exps:dict[int,int], N:int=NMAX, mod:int=MOD):
    # If T = prod_d eta(d tau)^a_d = q^alpha P(q), then this returns P(q).
    P=[1]+[0]*N
    for n in range(1, N+1):
        e = sum(a for d,a in exps.items() if n % d == 0)
        if e:
            P = conv(P, factor_series(n, e, N, mod), N, mod)
    alpha_num = sum(d*a for d,a in exps.items())
    return P, alpha_num


def series_inv(P, N:int=NMAX, mod:int=MOD):
    Q=[0]*(N+1); Q[0]=inv(P[0],mod)
    for n in range(1,N+1):
        s=0
        for k in range(1,n+1):
            s=(s+P[k]*Q[n-k])%mod
        Q[n]=(-s*Q[0])%mod
    return Q


def legendre(a,p):
    a%=p
    if a==0: return 0
    v=pow(a,(p-1)//2,p)
    return 1 if v==1 else -1


def subgroup_generated(gens, mod):
    S={1%mod}
    changed=True
    gens=[g%mod for g in gens]
    while changed:
        changed=False
        for s in list(S):
            for g in gens:
                t=(s*g)%mod
                if t not in S:
                    S.add(t); changed=True
    return sorted(S)


def bounded_box(factors, mod):
    vals=[]
    ranges=[range(-e,e+1) for _,e in factors]
    for betas in product(*ranges):
        v=1
        for (q,e),b in zip(factors, betas):
            if b>=0:
                v=(v*pow(q,b,mod))%mod
            else:
                v=(v*pow(inv(q,mod),-b,mod))%mod
        vals.append((v, betas))
    return vals


def circulant_charpoly(k:int):
    vec=[0]*6
    vec[3]=1
    vec[(3-k)%6]+=2
    C=sp.zeros(6)
    for r in range(6):
        for j in range(6):
            C[r,j]=vec[(j-r)%6]
    return vec, int(C.det()), sp.factor(C.charpoly(x).as_expr())


def mat_mod(M):
    return sp.Matrix([[int(v)%MOD for v in row] for row in M])


def charpoly_mod(M):
    expr=sp.Poly(M.charpoly(x).as_expr(), x, modulus=MOD)
    return expr.as_expr(), sp.factor(expr.as_expr(), modulus=MOD)


def main():
    lines=[]
    def emit(s=""):
        print(s); lines.append(str(s))

    emit("CORRECTED INTERACTION OBSTRUCTION VERIFICATION")
    emit(f"MOD={MOD}")
    powers=[pow(289,j,840) for j in range(6)]
    emit(f"powers of 289 mod 840: {powers}")
    assert powers == [1,289,361,169,121,529]

    emit("\nWeighted defect circulants:")
    expected_dets=[-729,63,-81,27,-81,63]
    for k in range(6):
        vec, det, char = circulant_charpoly(k)
        emit(f"k={k}: vec={vec}, det={det}, det mod107={det%MOD}, char={char}")
        assert det == expected_dets[k]

    pstar=8803369
    emit("\nChampion prime support ladder:")
    assert pstar % 840 == 169
    for R in [27,43,107]:
        a=(pstar+R)//4
        fac=factor_int(a)
        gens=[q for q,e in fac]
        Gamma=subgroup_generated(gens,R)
        box=bounded_box(fac,R)
        boxset=sorted(set(v for v,b in box))
        targets=[(-1)%R, (-inv(pstar,R))%R]
        states=[]
        counts=[]
        for t in targets:
            if t not in Gamma:
                states.append('tau')
                counts.append(None)
            else:
                hits=[b for v,b in box if v==t]
                if not hits:
                    states.append('0_Z')
                    counts.append(0)
                else:
                    states.append(str(len(hits)))
                    counts.append(len(hits))
        emit(f"R={R}: a={a}, factors={fac}, targets={targets}, Gamma={Gamma}, box={boxset}, states={states}")
        if R==27: assert states == ['tau','tau']
        if R==43: assert states == ['0_Z','0_Z']
        if R==107:
            assert states == ['2','0_Z']
            hits=[b for v,b in box if v==targets[0]]
            emit(f"R=107 hits for -1: {hits}")
            assert sorted(hits) == [(-2,0,-1,-1),(2,0,1,1)]

    # Eta products.
    P9, alpha9 = eta_product_P({1:3,9:-3})
    assert alpha9 == -24
    Pinv9=series_inv(P9)
    def T9(n): return P9[n+1] % MOD
    def I9(n): return (27*Pinv9[n-1])%MOD
    def f9(n): return (3*sigma1(n)-27*(sigma1(n//9) if n%9==0 else 0))%MOD

    P6, alpha6 = eta_product_P({1:5,2:-1,3:1,6:-5})
    assert alpha6 == -24
    Pinv6=series_inv(P6)
    Q6=[1]+[0]*NMAX
    for n in range(1,NMAX//6+1):
        Q6=conv(Q6, factor_series(6*n,4,NMAX), NMAX, MOD)
    F6_series=conv(P6,Q6,NMAX,MOD)
    F6_series=[(-2*v)%MOD for v in F6_series]
    def T6(n): return P6[n+1]%MOD
    def I6(n): return (72*Pinv6[n-1])%MOD
    def f6(n):
        return (5*sigma1(n)
                -2*(sigma1(n//2) if n%2==0 else 0)
                +3*(sigma1(n//3) if n%3==0 else 0)
                -30*(sigma1(n//6) if n%6==0 else 0))%MOD

    emit("\nEta/Fricke/Eisenstein critical-arm rows:")
    rows9=[]; rows6=[]
    for n in [744,747,750]:
        row9=(n,n%MOD,T9(n),I9(n),(T9(n)+I9(n))%MOD,(T9(n)-I9(n))%MOD,f9(n))
        row6=(n,n%MOD,T6(n),F6_series[n],(T6(n)+I6(n))%MOD,(T6(n)-I6(n))%MOD,f6(n))
        rows9.append(row9); rows6.append(row6)
        emit(f"A8^3 n={n}: (mod107,T9,I9,J9,Y9,f9)={row9[1:]}")
        emit(f"A5^4D4 n={n}: (mod107,T6,F6,J6,Y6,f6)={row6[1:]}")
    assert rows9 == [(744,102,0,35,35,72,89),(747,105,0,31,31,76,45),(750,1,0,42,42,65,52)]
    assert rows6 == [(744,102,34,19,16,52,67),(747,105,83,77,1,58,48),(750,1,101,106,2,93,21)]

    M9=mat_mod([[35,48,89],[31,105,45],[42,52,52]])
    M61=mat_mod([[16,52,19],[1,58,77],[2,93,106]])
    M62=mat_mod([[16,19,67],[1,77,48],[2,106,21]])
    emit("\nResolvent determinants:")
    emit(f"det M9={int(M9.det())%MOD}")
    emit(f"det M61={int(M61.det())%MOD}")
    emit(f"det M62={int(M62.det())%MOD}")
    assert int(M9.det())%MOD == 103
    assert int(M61.det())%MOD == 82
    assert int(M62.det())%MOD == 25

    P1=(M61 * M9.inv_mod(MOD)) % MOD
    P2=(M62 * M9.inv_mod(MOD)) % MOD
    emit("\nTransport matrices:")
    emit(f"P1={P1.tolist()}")
    emit(f"P2={P2.tolist()}")
    assert P1.tolist() == [[32,67,44],[98,72,41],[51,81,71]]
    assert P2.tolist() == [[3,28,46],[106,64,81],[38,47,84]]
    emit(f"det P1={int(P1.det())%MOD}, det P2={int(P2.det())%MOD}")
    assert int(P1.det())%MOD == 33
    assert int(P2.det())%MOD == 74
    cp1, fac1=charpoly_mod(P1)
    cp2, fac2=charpoly_mod(P2)
    emit(f"char P1={cp1}; factor={fac1}")
    emit(f"char P2={cp2}; factor={fac2}")

    out=Path('corrected_interaction_verification_report.txt')
    out.write_text('\n'.join(lines)+"\n")

if __name__ == '__main__':
    main()

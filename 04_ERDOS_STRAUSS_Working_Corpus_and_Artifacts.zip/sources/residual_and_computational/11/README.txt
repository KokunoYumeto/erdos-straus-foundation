Package contents:
- completed_supersignum_tesserine_blade1_integrated_paper.tex

The compiled PDF is omitted from this source corpus; rebuild it from the retained TeX.

Author line in the paper: The Clankers.

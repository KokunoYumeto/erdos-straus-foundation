#!/usr/bin/env python3
"""Exact simplex and Lorentz pullback of the free-shell C1-C2-C3 theorem."""

import sympy as sp


u2 = sp.Matrix(
    [
        [1 / sp.sqrt(2), -1 / sp.sqrt(2), 0],
        [1 / sp.sqrt(6), 1 / sp.sqrt(6), -2 / sp.sqrt(6)],
    ]
)
p2 = sp.eye(3) - sp.ones(3, 3) / 3
e21 = sp.Matrix([[0, 0], [1, 0]])
e12 = e21.T
s2 = e12 + e21

r3 = sp.Matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
f3 = sp.Matrix([[1, 0, 0], [0, 0, 1], [0, 1, 0]])
i3 = sp.eye(3)

b_minus_plus = sp.simplify(u2.T * (2 * e21) * u2)
b_plus_minus = sp.simplify(u2.T * (2 * e12) * u2)
hat_s2 = sp.simplify(u2.T * s2 * u2)
pulled_h = sp.simplify(u2.T * sp.diag(4, -1) * u2)

eta0_projector = sp.simplify(u2.T * sp.diag(1, 0) * u2)
eta1_projector = sp.simplify(u2.T * sp.diag(0, 1) * u2)

for q in range(1, 5):
    iq = sp.eye(q)
    support_isometry = sp.kronecker_product(iq, u2.T, i3)
    support_projection = sp.simplify(support_isometry * support_isometry.T)

    a_minus_plus = sp.kronecker_product(iq, 2 * e21, i3)
    a_plus_minus = a_minus_plus.T
    q_low = sp.kronecker_product(iq, sp.diag(1, 0), i3)
    q_high = sp.kronecker_product(iq, sp.diag(0, 1), i3)

    pulled_a_minus_plus = sp.simplify(
        support_isometry * a_minus_plus * support_isometry.T
    )
    pulled_a_plus_minus = sp.simplify(
        support_isometry * a_plus_minus * support_isometry.T
    )
    assert pulled_a_minus_plus == sp.kronecker_product(iq, b_minus_plus, i3)
    assert pulled_a_plus_minus == sp.kronecker_product(iq, b_plus_minus, i3)

    assert sp.simplify(a_plus_minus * a_minus_plus / 4 - q_low) == sp.zeros(6 * q)
    assert sp.simplify(a_minus_plus * a_plus_minus / 4 - q_high) == sp.zeros(6 * q)

    pulled_q_low = sp.simplify(support_isometry * q_low * support_isometry.T)
    pulled_q_high = sp.simplify(support_isometry * q_high * support_isometry.T)
    assert pulled_q_low == sp.kronecker_product(iq, eta0_projector, i3)
    assert pulled_q_high == sp.kronecker_product(iq, eta1_projector, i3)

    carrier = sp.simplify(a_plus_minus * a_minus_plus - q_high)
    pulled_carrier = sp.simplify(support_isometry * carrier * support_isometry.T)
    assert pulled_carrier == sp.kronecker_product(iq, pulled_h, i3)

    rotation = sp.kronecker_product(iq, sp.eye(2), r3)
    reflection = sp.kronecker_product(iq, s2, f3)
    pulled_rotation = sp.simplify(
        support_isometry * rotation * support_isometry.T
    )
    pulled_reflection = sp.simplify(
        support_isometry * reflection * support_isometry.T
    )
    assert pulled_rotation == sp.kronecker_product(iq, p2, r3)
    assert pulled_reflection == sp.kronecker_product(iq, hat_s2, f3)
    assert sp.simplify(pulled_rotation**3 - support_projection) == sp.zeros(9 * q)
    assert sp.simplify(pulled_reflection**2 - support_projection) == sp.zeros(9 * q)
    assert sp.simplify(
        pulled_reflection * pulled_rotation * pulled_reflection
        - pulled_rotation.T
    ) == sp.zeros(9 * q)

print("PASS every tested orbit count pulls 2E21 to the same 3-by-3 simplex blade")
print("PASS quarter products pull back to the ordered Helmert rank-one projectors")
print("PASS the global Gram-support carrier is the tensor product of the pulled carrier")
print("PASS the C3 rotation and C2 reflection pull back to the exact support operators")
print("PASS the pulled operators satisfy the D3 relations on the support projection")
print("PASS checks hold for one through four complement-orbit factors")

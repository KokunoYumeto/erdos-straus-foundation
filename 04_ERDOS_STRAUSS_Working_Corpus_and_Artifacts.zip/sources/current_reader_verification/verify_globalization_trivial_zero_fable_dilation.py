#!/usr/bin/env python3
"""Exact finite certificate for the globalization/Fable dilation family."""

from fractions import Fraction as Q
from math import factorial


def require(label, assertion):
    if not assertion:
        raise AssertionError(label)
    print(f"{label}: PASS")


q = Q(-1, 2)
endpoint_norm = Q(-1, 4)
seed = Q(1, 1) / q

require("globalization reciprocal is minus two", seed == -2)
require("reciprocal is four times zeta at zero", seed == 4 * q)
require("reciprocal is eight times the endpoint norm", seed == 8 * endpoint_norm)

for n in range(1, 13):
    trivial_zero_coordinate = n * seed
    jacobian_scalar = -2 * n
    collision_scalar = n * endpoint_norm

    require(
        f"dilation {n} reaches the negative even coordinate",
        trivial_zero_coordinate == -2 * n,
    )
    require(
        f"dilation {n} matches the Fable Jacobian scalar",
        jacobian_scalar == trivial_zero_coordinate,
    )
    require(
        f"dilation {n} transports the Fable collision scalar",
        collision_scalar == Q(-n, 4),
    )
    require(
        f"dilation {n} preserves the factor eight",
        jacobian_scalar == 8 * collision_scalar,
    )

    functional_equation_coefficient = (
        Q((-1) ** n * factorial(2 * n), 2 ** (2 * n + 1))
    )
    displayed_coefficient = (
        Q((-1) ** n * factorial(2 * n), 2 * (2 ** (2 * n)))
    )
    require(
        f"trivial-zero jet coefficient {n} has the displayed rational factor",
        functional_equation_coefficient == displayed_coefficient
        and functional_equation_coefficient != 0,
    )

"""Exact checks for the frame-relative cyclic carriers used in the preprint."""

from math import gcd

from sympy import Matrix, Rational, eye, kronecker_product, simplify, sqrt


def assert_zero_matrix(matrix: Matrix) -> None:
    assert all(simplify(entry) == 0 for entry in matrix)


def cyclic_shift_matrix(n: int) -> Matrix:
    matrix = Matrix.zeros(n)
    for column in range(n):
        matrix[(column + 1) % n, column] = 1
    return matrix


def augmentation_fixed_dimension(n: int, k: int) -> int:
    shift = cyclic_shift_matrix(n) ** k
    equations = (shift - eye(n)).col_join(Matrix([[1] * n]))
    return n - equations.rank()


def matrix_from_tensor(vector: Matrix) -> Matrix:
    return Matrix(2, 2, list(vector))


def gram(vectors: list[Matrix]) -> Matrix:
    return Matrix([[simplify(x.dot(y)) for y in vectors] for x in vectors])


def main() -> None:
    half = Rational(1, 2)
    root_three = sqrt(3)
    nu_g = Matrix([1, 0])
    nu_r = Matrix([-half, root_three / 2])
    nu_b = Matrix([-half, -root_three / 2])
    colours = [nu_g, nu_r, nu_b]

    rotation = Matrix([[-half, -root_three / 2],
                       [root_three / 2, -half]])
    assert_zero_matrix(rotation * nu_g - nu_r)
    assert_zero_matrix(rotation * nu_r - nu_b)
    assert_zero_matrix(rotation * nu_b - nu_g)
    assert_zero_matrix(rotation**3 - eye(2))

    diagonal = kronecker_product(rotation, rotation)
    counter = kronecker_product(rotation, rotation.T)
    identity_vector = Matrix([1, 0, 0, 1])
    complex_vector = Matrix([0, -1, 1, 0])
    split_vector = Matrix([1, 0, 0, -1])
    exchange_vector = Matrix([0, 1, 1, 0])

    assert len((diagonal - eye(4)).nullspace()) == 2
    assert len((counter - eye(4)).nullspace()) == 2
    assert_zero_matrix((diagonal - eye(4)) * identity_vector)
    assert_zero_matrix((diagonal - eye(4)) * complex_vector)
    assert_zero_matrix((counter - eye(4)) * split_vector)
    assert_zero_matrix((counter - eye(4)) * exchange_vector)

    phi = [[kronecker_product(colours[u], colours[v])
            for v in range(3)] for u in range(3)]
    d_g = phi[0][0] + phi[1][1] + phi[2][2]
    d_r = phi[0][1] + phi[1][2] + phi[2][0]
    d_b = phi[0][2] + phi[1][0] + phi[2][1]
    a_g = phi[0][0] + phi[1][2] + phi[2][1]
    a_r = phi[0][1] + phi[1][0] + phi[2][2]
    a_b = phi[0][2] + phi[1][1] + phi[2][0]
    d_orbits = [d_g, d_r, d_b]
    a_orbits = [a_g, a_r, a_b]

    assert_zero_matrix(sum(d_orbits, Matrix.zeros(4, 1)))
    assert_zero_matrix(sum(a_orbits, Matrix.zeros(4, 1)))
    assert_zero_matrix(gram(d_orbits) - Matrix([
        [Rational(9, 2), Rational(-9, 4), Rational(-9, 4)],
        [Rational(-9, 4), Rational(9, 2), Rational(-9, 4)],
        [Rational(-9, 4), Rational(-9, 4), Rational(9, 2)],
    ]))
    assert_zero_matrix(gram(a_orbits) - Matrix([
        [Rational(9, 2), Rational(-9, 4), Rational(-9, 4)],
        [Rational(-9, 4), Rational(9, 2), Rational(-9, 4)],
        [Rational(-9, 4), Rational(-9, 4), Rational(9, 2)],
    ]))
    assert_zero_matrix(Matrix([[simplify(x.dot(y)) for y in a_orbits]
                               for x in d_orbits]))

    expected_d = [
        Rational(3, 2) * identity_vector,
        Matrix([Rational(-3, 4), 3 * root_three / 4,
                -3 * root_three / 4, Rational(-3, 4)]),
        Matrix([Rational(-3, 4), -3 * root_three / 4,
                3 * root_three / 4, Rational(-3, 4)]),
    ]
    expected_a = [
        Rational(3, 2) * split_vector,
        Matrix([Rational(-3, 4), 3 * root_three / 4,
                3 * root_three / 4, Rational(3, 4)]),
        Matrix([Rational(-3, 4), -3 * root_three / 4,
                -3 * root_three / 4, Rational(3, 4)]),
    ]
    for actual, expected in zip(d_orbits, expected_d):
        assert_zero_matrix(actual - expected)
    for actual, expected in zip(a_orbits, expected_a):
        assert_zero_matrix(actual - expected)

    fixed_dimensions = {}
    for n in range(2, 7):
        fixed_dimensions[n] = []
        for k in range(1, n):
            actual = augmentation_fixed_dimension(n, k)
            expected = gcd(n, k) - 1
            assert actual == expected
            fixed_dimensions[n].append((k, actual))

    half_turn = cyclic_shift_matrix(4) ** 2
    half_turn_axis = Matrix([1, -1, 1, -1])
    assert_zero_matrix((half_turn - eye(4)) * half_turn_axis)
    assert sum(half_turn_axis) == 0

    print("All exact relative-carrier checks passed.")
    print("C3 diagonal fixed basis: I, J")
    print("C3 counter-rotating fixed basis: K, L")
    print("Diagonal orbit matrices:")
    for vector in d_orbits:
        print(matrix_from_tensor(vector))
    print("Counter-rotating orbit matrices:")
    for vector in a_orbits:
        print(matrix_from_tensor(vector))
    print("Augmentation fixed dimensions for nonidentity powers:")
    for n, values in fixed_dimensions.items():
        print(f"n={n}: {values}")


if __name__ == "__main__":
    main()

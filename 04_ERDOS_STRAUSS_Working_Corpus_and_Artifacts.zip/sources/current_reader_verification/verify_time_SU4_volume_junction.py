from itertools import permutations

from sympy import Matrix


def sign(permutation):
    inversions = sum(
        permutation[a] > permutation[b]
        for a in range(len(permutation))
        for b in range(a + 1, len(permutation))
    )
    return -1 if inversions % 2 else 1


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


perms = tuple(permutations(range(4)))
report("Time alternating tensor has twenty-four exact covers", len(perms) == 24)
report(
    "every Time alternating component uses all four atoms",
    all(set(p) == set(range(4)) for p in perms),
)


def four_arm_contraction(operators):
    total = 0
    for left in perms:
        left_sign = sign(left)
        for right in perms:
            total += (
                left_sign
                * sign(right)
                * operators[0][left[0], right[0]]
                * operators[1][left[1], right[1]]
                * operators[2][left[2], right[2]]
                * operators[3][left[3], right[3]]
            )
    return total / 24


g_left = Matrix(
    [
        [1, 2, -1, 3],
        [0, 1, 4, -2],
        [0, 0, 1, 5],
        [0, 0, 0, 1],
    ]
)
g_right = Matrix(
    [
        [1, 0, 0, 0],
        [-3, 1, 0, 0],
        [2, 4, 1, 0],
        [1, -2, 3, 1],
    ]
)
operators = (
    Matrix([[2, 1, 0, -1], [3, -2, 1, 4], [0, 5, 2, 1], [1, 0, -3, 2]]),
    Matrix([[1, 3, -2, 0], [2, 1, 4, -1], [5, 0, 1, 2], [-2, 3, 0, 1]]),
    Matrix([[3, 0, 1, 2], [-1, 2, 5, 0], [4, 1, -2, 3], [0, -3, 2, 1]]),
    Matrix([[2, -1, 3, 0], [0, 4, 1, 2], [1, 2, 0, -3], [5, 0, -2, 1]]),
)

report("left Time gauge matrix has determinant one", g_left.det() == 1)
report("right Time gauge matrix has determinant one", g_right.det() == 1)

transformed = tuple(g_left * u * g_right.inv() for u in operators)
report(
    "exact four-Time contraction is endpoint-gauge invariant",
    four_arm_contraction(transformed) == four_arm_contraction(operators),
)

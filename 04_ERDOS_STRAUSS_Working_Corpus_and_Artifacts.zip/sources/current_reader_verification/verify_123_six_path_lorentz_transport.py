from sympy import Matrix, Rational, diag, expand, sqrt


q3 = sqrt(3)
eta = diag(-1, 1, 1, 1)

# Raw coordinates use the ordered basis (E11,E12,E21,E22).
raw = [
    Matrix([1, 0, 0, 0]),
    Matrix([0, 0, 0, 1]),
    Matrix([Rational(1, 4), -q3 / 4, 0, Rational(3, 4)]),
    Matrix([Rational(3, 4), q3 / 4, 0, Rational(1, 4)]),
    Matrix([Rational(1, 4), q3 / 4, 0, Rational(3, 4)]),
    Matrix([Rational(3, 4), -q3 / 4, 0, Rational(1, 4)]),
]


def circle_coeff(x):
    a, b, c, d = x
    assert c == 0
    return Matrix([a + d, (a - d) / 2, b, (a + d) / 4])


def sarnak(v):
    A, B0, B1, C = v
    return Matrix([(A + C) / 2, B0, B1, (A - C) / 2])


coeff = [circle_coeff(x) for x in raw]
lorentz = [sarnak(v) for v in coeff]

expected_coeff = [
    Matrix([1, Rational(1, 2), 0, Rational(1, 4)]),
    Matrix([1, -Rational(1, 2), 0, Rational(1, 4)]),
    Matrix([1, -Rational(1, 4), -q3 / 4, Rational(1, 4)]),
    Matrix([1, Rational(1, 4), q3 / 4, Rational(1, 4)]),
    Matrix([1, -Rational(1, 4), q3 / 4, Rational(1, 4)]),
    Matrix([1, Rational(1, 4), -q3 / 4, Rational(1, 4)]),
]

expected_lorentz = [
    Matrix([Rational(5, 8), Rational(1, 2), 0, Rational(3, 8)]),
    Matrix([Rational(5, 8), -Rational(1, 2), 0, Rational(3, 8)]),
    Matrix([Rational(5, 8), -Rational(1, 4), -q3 / 4, Rational(3, 8)]),
    Matrix([Rational(5, 8), Rational(1, 4), q3 / 4, Rational(3, 8)]),
    Matrix([Rational(5, 8), -Rational(1, 4), q3 / 4, Rational(3, 8)]),
    Matrix([Rational(5, 8), Rational(1, 4), -q3 / 4, Rational(3, 8)]),
]

assert coeff == expected_coeff
assert lorentz == expected_lorentz
assert all(expand((u.T * eta * u)[0]) == 0 for u in lorentz)

gram = Matrix(
    [[expand((u.T * eta * v)[0]) for v in lorentz] for u in lorentz]
)
expected_gram = -Rational(1, 8) * Matrix(
    [
        [0, 4, 3, 1, 3, 1],
        [4, 0, 1, 3, 1, 3],
        [3, 1, 0, 4, 3, 1],
        [1, 3, 4, 0, 1, 3],
        [3, 1, 3, 1, 0, 4],
        [1, 3, 1, 3, 4, 0],
    ]
)
assert gram == expected_gram
assert gram.rank() == 3
assert gram.eigenvals() == {
    -Rational(3, 2): 1,
    Rational(3, 4): 2,
    0: 3,
}

R_raw = Matrix(
    [
        [Rational(1, 4), q3 / 2, 0, Rational(3, 4)],
        [-q3 / 4, -Rational(1, 2), 0, q3 / 4],
        [0, 0, 1, 0],
        [Rational(3, 4), -q3 / 2, 0, Rational(1, 4)],
    ]
)
J_raw = Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
R_L = Matrix(
    [
        [1, 0, 0, 0],
        [0, -Rational(1, 2), q3 / 2, 0],
        [0, -q3 / 2, -Rational(1, 2), 0],
        [0, 0, 0, 1],
    ]
)
J_L = diag(1, -1, 1, 1)

assert R_L.T * eta * R_L == eta
assert J_L.T * eta * J_L == eta
assert R_L**3 == Matrix.eye(4)
assert J_L**2 == Matrix.eye(4)
assert J_L * R_L * J_L == R_L.inv()

for x in raw:
    assert sarnak(circle_coeff(R_raw * x)) == R_L * sarnak(circle_coeff(x))
    assert sarnak(circle_coeff(J_raw * x)) == J_L * sarnak(circle_coeff(x))

centre = sum(lorentz, Matrix.zeros(4, 1)) / 6
assert centre == Matrix([Rational(5, 8), 0, 0, Rational(3, 8)])
assert expand((centre.T * eta * centre)[0]) == -Rational(1, 4)
assert R_L * centre == centre
assert J_L * centre == centre

for x, u in zip(raw, lorentz):
    assert expand(x[0] + x[3] - (u[0] + u[3])) == 0
    radial = u - centre
    assert radial[0] == 0 and radial[3] == 0
    assert expand(radial[1] ** 2 + radial[2] ** 2) == Rational(1, 4)


def kocik_equation(u, p):
    T, X, Y, W = u
    return expand((3 * p - 1) * (X**2 + Y**2 + W**2) - (p + 1) * T**2)


assert all(kocik_equation(u, 1) == 0 for u in lorentz)
assert kocik_equation(centre, 17) == 0
for i in range(6):
    for j in range(i + 1, 6):
        chord = lorentz[i] - lorentz[j]
        assert chord != Matrix.zeros(4, 1)
        assert kocik_equation(chord, Rational(1, 3)) == 0

print("PASS exact raw-to-circle and circle-to-Lorentz images for all six paths")
print("PASS six null vectors and complete Lorentz Gram matrix of rank 3")
print("PASS Lorentz D3 matrices and both raw-to-Lorentz intertwining equations")
print("PASS fixed barycentre, support functional T+W, and radius-1/2 shell")
print("PASS Kocik parameters: vertices 1, barycentre 17, nonzero chords 1/3")

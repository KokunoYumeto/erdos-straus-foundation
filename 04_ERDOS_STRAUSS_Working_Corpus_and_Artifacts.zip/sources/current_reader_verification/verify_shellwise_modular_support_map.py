from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import runpy

from sympy import Matrix, eye, kronecker_product, sqrt


def require_matrix_equal(left, right, message):
    difference = left - right
    if any(entry.expand() != 0 for entry in difference):
        raise AssertionError(f"{message}\n{difference}")


# Reuse the exact six-path and Hilbert--Schmidt matrices already checked by
# the preceding verification program.  Its report is suppressed here so this
# script has a stable receipt of its own.
source = Path(__file__).with_name(
    "verify_six_path_eight_cell_standard_bridge.py"
)
with redirect_stdout(StringIO()):
    data = runpy.run_path(str(source))

Xi = data["Xi"]
Q = data["Q"]
gamma_invariant = data["gamma_invariant"]
K_HS = data["K_HS"]
J_HS = data["J_HS"]
second_block_E11 = data["second_block_E11"]

# V is the proved path-to-standard-pair isometry.  The arithmetic collapse
# sends each of the six path basis vectors to the same target matrix unit, so
# its scalar coefficient row is (1,1,1,1,1,1).
V = Q.H * Xi
mu_row = Matrix.ones(1, 6)
support_coefficient = second_block_E11.T
support_projection = second_block_E11 * second_block_E11.T

require_matrix_equal(V.H * V, eye(6), "the path-to-HS map is not isometric")
require_matrix_equal(
    sqrt(6) * support_coefficient * V,
    mu_row,
    "the arithmetic collapse is not the block-two E11 coefficient map",
)
require_matrix_equal(
    V.H * support_projection * V,
    gamma_invariant * gamma_invariant.H,
    "the transported modular support projection is incorrect",
)
require_matrix_equal(
    gamma_invariant * gamma_invariant.H,
    Matrix.ones(6, 6) / 6,
    "the arithmetic support projection is not the equal-weight projection",
)
require_matrix_equal(
    K_HS * support_projection,
    Matrix.zeros(8, 8),
    "the modular generator does not vanish on the support line",
)
require_matrix_equal(
    support_projection * K_HS,
    Matrix.zeros(8, 8),
    "the support line does not lie in the zero modular eigenspace",
)
require_matrix_equal(
    J_HS * support_projection,
    support_projection,
    "modular conjugation does not fix the support projection on the left",
)
require_matrix_equal(
    support_projection * J_HS,
    support_projection,
    "modular conjugation does not fix the support projection on the right",
)

# Tensoring by q complement-orbit labels gives the general free shell.  The
# exact formulas are checked for six independent values of q; their form is
# the Kronecker identity used in the manuscript proof for arbitrary q.
for q in range(1, 7):
    identity_q = eye(q)
    shell_isometry = kronecker_product(identity_q, V)
    shell_collapse = kronecker_product(identity_q, mu_row)
    shell_coefficient = kronecker_product(
        identity_q, support_coefficient
    )
    shell_projection = kronecker_product(
        identity_q, support_projection
    )
    arithmetic_projection = kronecker_product(
        identity_q, gamma_invariant * gamma_invariant.H
    )

    require_matrix_equal(
        shell_collapse,
        sqrt(6) * shell_coefficient * shell_isometry,
        f"the coefficient factorization fails for q={q}",
    )
    require_matrix_equal(
        shell_isometry.H * shell_projection * shell_isometry,
        arithmetic_projection,
        f"the shell support projection fails for q={q}",
    )
    if shell_collapse.rank() != q:
        raise AssertionError(f"wrong shell-collapse rank for q={q}")
    if 6 * q - shell_collapse.rank() != 5 * q:
        raise AssertionError(f"wrong shell-collapse nullity for q={q}")
    if shell_projection.rank() != q:
        raise AssertionError(f"wrong modular-support rank for q={q}")

print("PASS: shellwise arithmetic support is a modular E11 coefficient map")
print("the path-to-standard-pair map is an exact six-dimensional isometry")
print("the arithmetic collapse equals sqrt(6) times the block-two E11 coefficient")
print("the transported support projector is the equal-weight path projector")
print("one through six complement orbits give ranks q and nullities 5q")
print("the modular generator vanishes and conjugation fixes every support line")

def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


ALL_FIVE_PRIMES = (
    3_368_401,
    5_153_569,
    5_719_921,
    7_273_249,
    9_527_281,
    11_996_161,
    13_503_121,
    15_866_449,
    17_722_609,
    17_904_769,
)


def seed_A(a):
    return 59 * a


def seed_B(a):
    return 2


def seed_C(a):
    return 317


def seed_D(a):
    return 16


def seed_E(a):
    return 116


def seed_F(a):
    return 1_352


def seed_G(a):
    return a * a // 4_913


def seed_H(a):
    return 200


def closed_A(p):
    return (
        (p + 27) // 4,
        p * (p + 27) * (59 * p + 1) // 108,
        (p + 27) * (59 * p + 1) // 6_372,
    )


def closed_B(p):
    return (
        (p + 39) // 4,
        p * (p + 47) // 156,
        p * (p + 39) * (p + 47) // 1_248,
    )


def closed_C(p):
    return (
        (p + 27) // 4,
        p * (47 * p + 1) // 4,
        (p + 27) * (47 * p + 1) // 5_072,
    )


def closed_D(p):
    return (
        (p + 31) // 4,
        p * (p + 95) // 124,
        p * (p + 31) * (p + 95) // 7_936,
    )


def closed_E(p):
    return (
        (p + 31) // 4,
        p * (15 * p + 1) // 4,
        (p + 31) * (15 * p + 1) // 1_856,
    )


def closed_F(p):
    return (
        (p + 31) // 4,
        p * (p + 5_439) // 124,
        p * (p + 31) * (p + 5_439) // 670_592,
    )


def closed_G(p):
    common = p * (p + 27) + 19_652
    return (
        (p + 27) // 4,
        p * (p + 27) * common // 2_122_416,
        common // 108,
    )


def closed_H(p):
    return (
        (p + 31) // 4,
        p * (p + 831) // 124,
        p * (p + 31) * (p + 831) // 99_200,
    )


FAMILIES = (
    ("A", 27, "E", 3_985, 6_372, seed_A, closed_A,
     (3_368_401,)),
    ("B", 39, "M", 889, 936, seed_B, closed_B,
     (5_153_569,)),
    ("C", 27, "E", 2_509, 11_412, seed_C, closed_C,
     (5_719_921,)),
    ("D", 31, "M", 1_393, 4_464, seed_D, closed_D,
     (7_273_249, 11_996_161, 15_866_449)),
    ("E", 31, "E", 1_825, 2_088, seed_E, closed_E,
     (9_527_281, 15_866_449)),
    ("F", 31, "M", 39_697, 58_032, seed_F, closed_F,
     (13_503_121,)),
    ("G", 27, "E", 25_405, 31_212, seed_G, closed_G,
     (17_722_609,)),
    ("H", 31, "M", 4_129, 22_320, seed_H, closed_H,
     (17_904_769,)),
)


def reconstructed_denominators(p, residual, endpoint_type, u):
    a = (p + residual) // 4
    N = p * a
    D = p * p * u if endpoint_type == "E" else p * u
    if N * N % D:
        raise AssertionError(("complement divisor", p, residual, u))
    complement = N * N // D
    if (N + D) % residual or (N + complement) % residual:
        raise AssertionError(("endpoint integrality", p, residual, u))
    return a, (N + D) // residual, (N + complement) // residual


covered = set()
for name, residual, endpoint_type, residue, modulus, seed, closed, expected in FAMILIES:
    report(f"family {name} remains in the five-Finger prime class", residue % 36 == 25)
    observed = tuple(p for p in ALL_FIVE_PRIMES if p % modulus == residue)
    report(f"family {name} bounded membership", observed == expected)
    covered.update(observed)

    sample_checks = []
    for step in range(5):
        p = residue + step * modulus
        a = (p + residual) // 4
        u = seed(a)
        sample_checks.append(a * a % u == 0)
        if endpoint_type == "E":
            sample_checks.append((4 * u + 1) % residual == 0)
        else:
            sample_checks.append((u + a) % residual == 0)
        denominators = reconstructed_denominators(
            p, residual, endpoint_type, u
        )
        sample_checks.append(denominators == closed(p))
        x, y, z = denominators
        sample_checks.append(
            4 * x * y * z == p * (x * y + x * z + y * z),
        )
    report(f"family {name} five exact parameter checks", all(sample_checks))

report("eight-family bounded cover", covered == set(ALL_FIVE_PRIMES))

print("bounded all-five primes=", ALL_FIVE_PRIMES)
for name, residual, endpoint_type, residue, modulus, _, _, expected in FAMILIES:
    print(
        name,
        "R=", residual,
        "type=", endpoint_type,
        "progression=", (residue, modulus),
        "bounded rows=", expected,
    )

import sympy as sp


q = sp.sqrt(3)
R = sp.Matrix([
    [sp.Rational(1, 4), q / 2, 0, sp.Rational(3, 4)],
    [-q / 4, sp.Rational(-1, 2), 0, q / 4],
    [0, 0, 1, 0],
    [sp.Rational(3, 4), -q / 2, 0, sp.Rational(1, 4)],
])
J = sp.Matrix([
    [0, 0, 0, 1],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [1, 0, 0, 0],
])
Q_raw = sp.diag(1, 1, -1, 1)
E11 = sp.Matrix([1, 0, 0, 0])

assert R ** 3 == sp.eye(4)
assert J ** 2 == sp.eye(4)
assert J * R * J == R.inv()
print("PASS raw-cell matrices satisfy the D3 relations")

labels = [(m, eps) for m in range(3) for eps in range(2)]
orbit = [sp.simplify((R ** m) * (J ** eps) * E11)
         for m, eps in labels]
expected = [
    sp.Matrix([1, 0, 0, 0]),
    sp.Matrix([0, 0, 0, 1]),
    sp.Matrix([sp.Rational(1, 4), -q / 4, 0, sp.Rational(3, 4)]),
    sp.Matrix([sp.Rational(3, 4), q / 4, 0, sp.Rational(1, 4)]),
    sp.Matrix([sp.Rational(1, 4), q / 4, 0, sp.Rational(3, 4)]),
    sp.Matrix([sp.Rational(3, 4), -q / 4, 0, sp.Rational(1, 4)]),
]
assert orbit == expected
assert len({tuple(v) for v in orbit}) == 6
M = sp.Matrix.hstack(*orbit)
assert M.rank() == 3
print("PASS the E11 orbit has six distinct points and rank 3")

# Source order is (m,eps) = (0,0),(0,1),(1,0),(1,1),(2,0),(2,1).
k1 = sp.Matrix([1, 1, -1, -1, 0, 0])
k2 = sp.Matrix([1, 1, 0, 0, -1, -1])
k3 = sp.Matrix([1, -1, 1, -1, 1, -1])
K = sp.Matrix.hstack(k1, k2, k3)
assert M * K == sp.zeros(4, 3)
assert K.rank() == 3
assert len(M.nullspace()) == 3
print("PASS the three symmetric relations form the full kernel")

for m, eps in labels:
    x = orbit[labels.index((m, eps))]
    xr = orbit[labels.index(((m + 1) % 3, eps))]
    xf = orbit[labels.index(((-m) % 3, (eps + 1) % 2))]
    assert sp.simplify(R * x - xr) == sp.zeros(4, 1)
    assert sp.simplify(J * x - xf) == sp.zeros(4, 1)
print("PASS Psi intertwines both D3 generators")

for x in orbit:
    assert x[0] + x[3] == 1
    assert Q_raw * x == x
print("PASS trace support collapse and positive-quarter carriage")

# Fixed subspaces are kernels of the stacked generator differences.
source_R = sp.zeros(6)
source_J = sp.zeros(6)
for col, (m, eps) in enumerate(labels):
    source_R[labels.index(((m + 1) % 3, eps)), col] = 1
    source_J[labels.index(((-m) % 3, (eps + 1) % 2)), col] = 1
source_fixed = (source_R - sp.eye(6)).col_join(source_J - sp.eye(6)).nullspace()
target_fixed = (R - sp.eye(4)).col_join(J - sp.eye(4)).nullspace()
assert len(source_fixed) == 1
assert len(target_fixed) == 2
assert sp.Matrix.hstack(*target_fixed).columnspace()
print("PASS invariant dimensions: source 1, full raw target 2")
print("PASS rank 3 is maximal for real D3-module maps into the raw carrier")

"""Exact low-cost checks for the Fourier-to-blade channel theorem.

The N=2 calculation uses rational matrices by writing the Fourier unitary
as 2^(-1/2) times an integral Hadamard matrix.  The N=3 calculation imports
the exact Q(omega) arithmetic used by the support-family checker.
"""

from fractions import Fraction

from verify_support_indexed_modular_family import (
    OMEGA,
    conjugate_transpose,
    cyclic_shift,
    fourier_vector,
    matrix_add,
    matrix_multiply,
    matrix_rank,
    matrix_scale,
    support_projection,
    transpose,
)


def qmatrix(rows):
    return [[Fraction(entry) for entry in row] for row in rows]


def qidentity(size):
    return [
        [Fraction(1 if row == column else 0) for column in range(size)]
        for row in range(size)
    ]


def qadd(left, right):
    return [
        [left[i][j] + right[i][j] for j in range(len(left[0]))]
        for i in range(len(left))
    ]


def qscale(scalar, value):
    scalar = Fraction(scalar)
    return [[scalar * entry for entry in row] for row in value]


def qmultiply(left, right):
    return [
        [
            sum(
                (left[i][k] * right[k][j] for k in range(len(right))),
                Fraction(0),
            )
            for j in range(len(right[0]))
        ]
        for i in range(len(left))
    ]


def qtranspose(value):
    return [
        [value[i][j] for i in range(len(value))]
        for j in range(len(value[0]))
    ]


def qfourier_carriage(hadamard, value):
    return qscale(
        Fraction(1, 2),
        qmultiply(qmultiply(qtranspose(hadamard), value), hadamard),
    )


def flatten(value):
    return [entry for row in value for entry in row]


def check_n2() -> None:
    identity = qmatrix([[1, 0], [0, 1]])
    e11 = qmatrix([[1, 0], [0, 0]])
    e12 = qmatrix([[0, 1], [0, 0]])
    e21 = qmatrix([[0, 0], [1, 0]])
    e22 = qmatrix([[0, 0], [0, 1]])

    for label in (0, 1):
        sign = 1 if label == 0 else -1
        hadamard = qmatrix([[1, 1], [sign, -sign]])
        projection = qscale(
            Fraction(1, 2),
            qmatrix([[1, sign], [sign, 1]]),
        )
        complement = qscale(
            Fraction(1, 2),
            qmatrix([[1, -sign], [-sign, 1]]),
        )
        positive_channel = qscale(
            Fraction(1, 2),
            qmatrix([[1, -sign], [sign, -1]]),
        )
        negative_channel = qscale(
            Fraction(1, 2),
            qmatrix([[1, sign], [-sign, -1]]),
        )

        assert qmultiply(qtranspose(hadamard), hadamard) == qscale(2, identity)
        assert qfourier_carriage(hadamard, projection) == e11
        assert qfourier_carriage(hadamard, complement) == e22
        assert qfourier_carriage(hadamard, positive_channel) == e12
        assert qfourier_carriage(hadamard, negative_channel) == e21

        assert qmultiply(qmultiply(projection, positive_channel), complement) == positive_channel
        assert qmultiply(qmultiply(complement, negative_channel), projection) == negative_channel

        rho = qadd(projection, qscale(2, complement))
        rho_inverse = qadd(projection, qscale(Fraction(1, 2), complement))
        assert qmultiply(rho, rho_inverse) == identity
        assert (
            qmultiply(qmultiply(rho, positive_channel), rho_inverse)
            == qscale(Fraction(1, 2), positive_channel)
        )
        assert (
            qmultiply(qmultiply(rho, negative_channel), rho_inverse)
            == qscale(2, negative_channel)
        )

        complement_density = qadd(complement, qscale(2, projection))
        assert complement_density == qscale(2, rho_inverse)

    blade = qscale(2, e21)
    blade_transpose = qscale(2, e12)
    assert qmultiply(qtranspose(blade), blade) == qscale(4, e11)
    assert qmultiply(blade, qtranspose(blade)) == qscale(4, e22)
    assert qmultiply(qtranspose(blade_transpose), blade_transpose) == qscale(4, e22)
    assert qmultiply(blade_transpose, qtranspose(blade_transpose)) == qscale(4, e11)


def check_modular_lorentz_orientation() -> None:
    identity = qmatrix([[1, 0], [0, 1]])
    e11 = qmatrix([[1, 0], [0, 0]])
    e12 = qmatrix([[0, 1], [0, 0]])
    e21 = qmatrix([[0, 0], [1, 0]])
    e22 = qmatrix([[0, 0], [0, 1]])
    blade_sign = qadd(e11, qscale(-1, e22))

    def half_commutator(value):
        return qscale(
            Fraction(1, 2),
            qadd(
                qmultiply(blade_sign, value),
                qscale(-1, qmultiply(value, blade_sign)),
            ),
        )

    assert half_commutator(e21) == qscale(-1, e21)
    assert half_commutator(e12) == e12

    for multiplicity in (1, 2, 3):
        square = Fraction(multiplicity * multiplicity)
        t_value = Fraction(square - 1, 2)
        w_value = Fraction(square + 1, 2)

        negative_form = qadd(qscale(square, e11), qscale(-1, e22))
        positive_form = qadd(qscale(square, e22), qscale(-1, e11))
        expected_negative = qadd(qscale(t_value, identity), qscale(w_value, blade_sign))
        expected_positive = qadd(qscale(t_value, identity), qscale(-w_value, blade_sign))
        assert negative_form == expected_negative
        assert positive_form == expected_positive

        negative_t = (negative_form[0][0] + negative_form[1][1]) / 2
        negative_w = (negative_form[0][0] - negative_form[1][1]) / 2
        positive_t = (positive_form[0][0] + positive_form[1][1]) / 2
        positive_w = (positive_form[0][0] - positive_form[1][1]) / 2
        assert (negative_t, negative_w) == (t_value, w_value)
        assert (positive_t, positive_w) == (t_value, -w_value)

        assert (negative_t - negative_w) / (negative_t + negative_w) == -Fraction(1, square)
        assert (positive_t - positive_w) / (positive_t + positive_w) == -square


def check_quarter_polynomial_and_null_dyad() -> None:
    identity = qidentity(4)
    k_scaled = qmatrix(
        [
            [0, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, -1, 0],
            [0, 0, 0, 0],
        ]
    )
    k_square = qmultiply(k_scaled, k_scaled)
    negative_projector = qscale(
        Fraction(1, 2),
        qmultiply(k_scaled, qadd(k_scaled, qscale(-1, identity))),
    )
    positive_projector = qscale(
        Fraction(1, 2),
        qmultiply(k_scaled, qadd(k_scaled, identity)),
    )
    zero_projector = qadd(identity, qscale(-1, k_square))
    assert negative_projector == qmatrix(
        [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 0],
        ]
    )
    assert positive_projector == qmatrix(
        [
            [0, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
        ]
    )
    assert zero_projector == qmatrix(
        [
            [1, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 1],
        ]
    )
    quarter_reflection = qadd(qadd(identity, k_scaled), qscale(-1, k_square))
    assert quarter_reflection == qmatrix(
        [
            [1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, -1, 0],
            [0, 0, 0, 1],
        ]
    )

    source = (
        Fraction(5, 8),
        Fraction(1, 2),
        Fraction(0),
        Fraction(3, 8),
    )
    target = (
        Fraction(5, 8),
        Fraction(-1, 2),
        Fraction(0),
        Fraction(3, 8),
    )

    def lorentz(left, right):
        return (
            left[1] * right[1]
            + left[2] * right[2]
            + left[3] * right[3]
            - left[0] * right[0]
        )

    assert lorentz(source, source) == 0
    assert lorentz(target, target) == 0
    assert lorentz(source, target) == Fraction(-1, 2)
    source_plus_target = tuple(
        source[index] + target[index] for index in range(4)
    )
    source_minus_target = tuple(
        source[index] - target[index] for index in range(4)
    )
    assert lorentz(source_plus_target, source_plus_target) == -1
    assert lorentz(source_minus_target, source_minus_target) == 1

    carrier = qmatrix(
        [
            [Fraction(5, 8), Fraction(5, 8)],
            [Fraction(1, 2), Fraction(-1, 2)],
            [0, 0],
            [Fraction(3, 8), Fraction(3, 8)],
        ]
    )
    eta = qmatrix(
        [
            [-1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1],
        ]
    )
    gram = qmultiply(qmultiply(qtranspose(carrier), eta), carrier)
    assert gram == qmatrix(
        [
            [0, Fraction(-1, 2)],
            [Fraction(-1, 2), 0],
        ]
    )

    def kocik_cleared(vector, parameter):
        time, x_value, y_value, w_value = vector
        spatial = x_value**2 + y_value**2 + w_value**2
        return (
            (3 * parameter - 1) * spatial
            - (parameter + 1) * time**2
        )

    assert kocik_cleared(source, Fraction(1)) == 0
    assert kocik_cleared(target, Fraction(1)) == 0
    assert kocik_cleared(source_plus_target, Fraction(17)) == 0
    assert kocik_cleared(source_minus_target, Fraction(1, 3)) == 0


def check_n3() -> None:
    unitary = cyclic_shift(3)
    unitary_inverse = transpose(unitary)

    for a in range(3):
        projection = support_projection(3, (a,))
        complementary_labels = [b for b in range(3) if b != a]
        complement = support_projection(3, tuple(complementary_labels))

        positive_generators = []
        negative_generators = []
        for b in complementary_labels:
            va = fourier_vector(3, a)
            vb = fourier_vector(3, b)
            positive = matrix_multiply(va, conjugate_transpose(vb))
            negative = matrix_multiply(vb, conjugate_transpose(va))
            rb = support_projection(3, (b,))

            assert (
                matrix_multiply(
                    matrix_multiply(projection, positive), rb
                )
                == positive
            )
            assert (
                matrix_multiply(
                    matrix_multiply(rb, negative), projection
                )
                == negative
            )

            positive_weight = OMEGA ** ((b - a) % 3)
            negative_weight = OMEGA ** ((a - b) % 3)
            assert (
                matrix_multiply(
                    matrix_multiply(unitary, positive), unitary_inverse
                )
                == matrix_scale(positive_weight, positive)
            )
            assert (
                matrix_multiply(
                    matrix_multiply(unitary, negative), unitary_inverse
                )
                == matrix_scale(negative_weight, negative)
            )

            positive_generators.append(flatten(positive))
            negative_generators.append(flatten(negative))

        assert matrix_rank(positive_generators) == 2
        assert matrix_rank(negative_generators) == 2
        assert matrix_add(projection, complement) == support_projection(
            3, (0, 1, 2)
        )


def main() -> None:
    check_n2()
    check_modular_lorentz_orientation()
    check_quarter_polynomial_and_null_dyad()
    check_n3()
    print("All exact Fourier-to-blade channel checks passed.")
    print("N=2 ordered channels:")
    print("  Pi M Q -> E12 -> plus log(lambda)")
    print("  Q M Pi -> E21 -> minus log(lambda)")
    print("  arithmetic blade 2E21 occupies the directed negative channel")
    print("Modular-Lorentz orientation:")
    print("  K = (log(lambda)/2) ad_J")
    print("  at multiplicity 2: E21 -> (T,W,C/A)=(3/2,5/2,-1/4)")
    print("  at multiplicity 2: E12 -> (T,W,C/A)=(3/2,-5/2,-4)")
    print("Quarter reflection:")
    print("  Q_square = I + K/log(lambda) - (K/log(lambda))^2")
    print("  transported source/range idempotents form a null pair of pairing -1/2")
    print("Kocik-Sarnak support dyad:")
    print("  source and range columns lie on p=1")
    print("  their sum lies on p=17; their difference lies on the p=1/3 boundary")
    print("N=3 singleton channels:")
    print("  each off-diagonal channel has dimension 2")
    print("  the specified C3 shift resolves it into two rank-one character lines")


if __name__ == "__main__":
    main()

from sympy import Matrix, eye, sqrt


def require(label, condition):
    if condition is not True:
        raise AssertionError(label)


e_plus = Matrix([1, 0])
e_minus = Matrix([0, 1])
state_vector = {1: e_plus, 0: e_minus}

E11 = Matrix([[1, 0], [0, 0]])
E12 = Matrix([[0, 1], [0, 0]])
E21 = Matrix([[0, 0], [1, 0]])
E22 = Matrix([[0, 0], [0, 1]])

J = Matrix([[1, 0], [0, -1]])
S = Matrix([[0, 1], [1, 0]])
H = Matrix([[1, 1], [1, -1]]) / sqrt(2)
I2 = eye(2)

P_plus = (I2 + S) / 2
P_minus = (I2 - S) / 2
B_minus_plus = Matrix([[1, 1], [-1, -1]]) / 2
B_plus_minus = Matrix([[1, -1], [1, -1]]) / 2

cases = (
    ("empty", (0, 0, 0), E22, E22, P_minus, P_minus, (0, 0)),
    (
        "exterior-only",
        (1, 0, 1),
        E21,
        E12,
        B_minus_plus,
        B_plus_minus,
        (-1, 1),
    ),
    (
        "middle-only",
        (0, 1, 0),
        E12,
        E21,
        B_plus_minus,
        B_minus_plus,
        (1, -1),
    ),
    ("both", (1, 1, 1), E11, E11, P_plus, P_plus, (0, 0)),
)

print("PASS: complete Boolean endpoint-to-blade cell bridge")
for (
    name,
    bits,
    expected_incoming,
    expected_outgoing,
    expected_incoming_mixer,
    expected_outgoing_mixer,
    expected_boundary,
) in cases:
    b_minus, b_zero, b_plus = bits
    require(f"{name}: reflection palindrome", b_minus == b_plus)

    incoming = state_vector[b_zero] * state_vector[b_minus].T
    outgoing = state_vector[b_plus] * state_vector[b_zero].T
    boundary = (b_zero - b_minus, b_plus - b_zero)

    require(f"{name}: incoming cell", incoming == expected_incoming)
    require(f"{name}: outgoing cell", outgoing == expected_outgoing)
    require(f"{name}: reflected edge", outgoing == incoming.T)
    require(f"{name}: boundary vector", boundary == expected_boundary)
    require(
        f"{name}: incoming output support sign",
        J * incoming == (2 * b_zero - 1) * incoming,
    )
    require(
        f"{name}: incoming input support sign",
        incoming * J == (2 * b_minus - 1) * incoming,
    )
    require(
        f"{name}: incoming source projector",
        incoming.T * incoming
        == state_vector[b_minus] * state_vector[b_minus].T,
    )
    require(
        f"{name}: incoming range projector",
        incoming * incoming.T
        == state_vector[b_zero] * state_vector[b_zero].T,
    )
    require(
        f"{name}: incoming Hadamard image",
        H * incoming * H.T == expected_incoming_mixer,
    )
    require(
        f"{name}: outgoing Hadamard image",
        H * outgoing * H.T == expected_outgoing_mixer,
    )

    print(
        f"{name}: bits={bits}, boundary={boundary}, "
        f"incoming={tuple(incoming)}, outgoing={tuple(outgoing)}"
    )

middle_incoming = state_vector[1] * state_vector[0].T
middle_outgoing = state_vector[0] * state_vector[1].T
require("R107 incoming cell is transposed", middle_incoming == E12)
require("R107 outgoing population lift", 2 * middle_outgoing == 2 * E21)
print("R107: q=1, incoming=E12, outgoing lift=2E21")

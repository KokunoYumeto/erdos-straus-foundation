#!/usr/bin/env python3
"""Vector explanation of the weighted shell spectrum and its two means."""

from fractions import Fraction
from math import exp, log, sqrt
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "figures" / "weighted_shell_control_volume.pdf"

weights_q = (
    Fraction(61445, 943902729),
    Fraction(184335, 339886096),
    Fraction(615, 94864),
    Fraction(921675, 38217124),
    Fraction(123, 484),
    Fraction(1025, 1089),
)
weights = np.array([float(value) for value in weights_q], dtype=float)
q = len(weights)
geometric_mean = exp(sum(log(value) for value in weights) / q)
root_mean_square = sqrt(float(np.dot(weights, weights)) / q)

fig, axes = plt.subplots(1, 2, figsize=(11.8, 5.2))

# Panel A: each complement orbit contributes one scaled two-sheet block.
ax = axes[0]
rows = np.arange(1, q + 1)
for row, alpha in zip(rows, weights):
    ax.plot([-alpha, 4 * alpha], [row, row], color="0.68", linewidth=1.2)
    ax.scatter([-alpha], [row], s=68, color="#2f6fbb", zorder=3)
    ax.scatter([4 * alpha], [row], s=68, color="#c43c35", zorder=3)
ax.axvline(0, color="0.35", linewidth=1.0)
ax.set_yticks(rows, [rf"$O_{index}$" for index in rows])
ax.invert_yaxis()
ax.set_xlabel("carrier eigenvalue")
ax.set_title("A. Six exact 12289 orbit blocks", loc="left", fontweight="bold")
ax.grid(axis="x", alpha=0.18)
ax.scatter([], [], s=68, color="#2f6fbb", label=r"$-\alpha_O$ (multiplicity $3$)")
ax.scatter([], [], s=68, color="#c43c35", label=r"$4\alpha_O$ (multiplicity $3$)")
ax.legend(frameon=False, fontsize=9, loc="lower right")

# Panel B: lengths use the quadratic mean; determinant uses the geometric mean.
ax = axes[1]
bar_colors = ["#8267a8", "#5e83ba", "#45a0a1", "#63a85d", "#d29b3d", "#c75d55"]
ax.bar(rows, weights, color=bar_colors, alpha=0.9)
ax.axhline(
    geometric_mean,
    color="#2d8a4b",
    linewidth=2.0,
    label=r"$G=(\prod_O\alpha_O)^{1/q}$",
)
ax.axhline(
    root_mean_square,
    color="#d27a24",
    linewidth=2.0,
    linestyle="--",
    label=r"$R=(q^{-1}\sum_O\alpha_O^2)^{1/2}$",
)
ax.set_xticks(rows, [rf"$O_{index}$" for index in rows])
ax.set_ylabel(r"orbit amplitude $\alpha_O$")
ax.set_title("B. Logarithmic and quadratic coordinates", loc="left", fontweight="bold")
ax.grid(axis="y", alpha=0.18)
ax.legend(frameon=False, fontsize=8.7, loc="upper left")
ax.text(
    0.5,
    -0.25,
    r"$\operatorname{Vol}^{1/(6q)}=2G\leq2R$"
    "\n"
    r"$L_H^2=51qR^2,\qquad L_K^2=\frac{75}{2}qR^2$",
    transform=ax.transAxes,
    ha="center",
    va="top",
    fontsize=10.5,
)

fig.suptitle(
    "Amplitude-weighted shell: orbitwise spectrum and sharp volume bound",
    fontsize=13.5,
    fontweight="bold",
)
fig.tight_layout(rect=(0, 0.06, 1, 0.93))
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, bbox_inches="tight")
plt.close(fig)
print(OUT)

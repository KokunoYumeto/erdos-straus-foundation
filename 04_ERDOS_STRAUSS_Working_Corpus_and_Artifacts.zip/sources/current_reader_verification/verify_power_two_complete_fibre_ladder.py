#!/usr/bin/env python3
"""Exact checks for the power-of-two complete-target-fibre ladder."""

from __future__ import annotations

from fractions import Fraction
from math import gcd

from sympy import factorint, isprime


def multiplicative_order(a: int, modulus: int) -> int:
    if gcd(a, modulus) != 1:
        raise ValueError("the residue is not a unit")
    value = 1
    for order in range(1, modulus + 1):
        value = value * a % modulus
        if value == 1:
            return order
    raise AssertionError("finite multiplicative order was not found")


def inverse_mod(a: int, modulus: int) -> int:
    return pow(a, -1, modulus)


def cyclic_stabilizer(subset: set[int], modulus: int) -> set[int]:
    return {
        shift
        for shift in range(modulus)
        if {(x + shift) % modulus for x in subset} == subset
    }


def abstract_ladder_checks(max_exponent: int) -> int:
    assertions = 0
    for exponent in range(1, max_exponent + 1):
        quotient_order = 2 * exponent + 4
        displacement = exponent + 2
        projected_order = quotient_order // 2

        interval = {
            k % quotient_order for k in range(-exponent, exponent + 1)
        }
        assert len(interval) == 2 * exponent + 1
        assertions += 1
        assert cyclic_stabilizer(interval, quotient_order) == {0}
        assertions += 1

        displacement_subgroup = {0, displacement}
        assert {
            (x + displacement) % quotient_order
            for x in displacement_subgroup
        } == displacement_subgroup
        assertions += 1
        assert (2 * displacement) % quotient_order == 0
        assertions += 1

        projected_interval = {
            k % projected_order for k in range(-exponent, exponent + 1)
        }
        assert projected_interval == set(range(projected_order))
        assertions += 1
        assert 2 * exponent + 1 >= projected_order
        assertions += 1

        assert exponent + 2 == quotient_order // 2
        assertions += 1
        assert 3 * quotient_order == 6 * exponent + 12
        assertions += 1
    return assertions


def residual_primes(max_exponent: int) -> list[tuple[int, int]]:
    result: list[tuple[int, int]] = []
    for exponent in range(1, max_exponent + 1):
        required_order = 6 * exponent + 12
        for residual in sorted(factorint(2**required_order - 1)):
            if isprime(residual) and multiplicative_order(2, residual) == required_order:
                result.append((exponent, residual))
    return result


def exact_group_check(exponent: int, residual: int) -> int:
    quotient_order = 2 * exponent + 4
    full_order = 3 * quotient_order
    assert multiplicative_order(2, residual) == full_order

    omega = pow(2, quotient_order, residual)
    assert omega != 1
    assert pow(omega, 3, residual) == 1
    order_three = {1, omega, omega * omega % residual}

    full_group = {pow(2, k, residual) for k in range(full_order)}
    assert len(full_group) == full_order
    assert order_three <= full_group

    local_two = {
        pow(2, k, residual) if k >= 0
        else pow(inverse_mod(2, residual), -k, residual)
        for k in range(-exponent, exponent + 1)
    }
    carrier = {
        x * y % residual for x in local_two for y in order_three
    }
    stabilizer = {
        h
        for h in full_group
        if {h * x % residual for x in carrier} == carrier
    }
    assert stabilizer == order_three

    q_classes = (omega, omega * omega % residual)
    for q_class in q_classes:
        assert {inverse_mod(q_class, residual), 1, q_class} == order_three

        p_class = pow(2, exponent + 2, residual) * q_class % residual
        quotient_exponent = exponent + 2
        assert quotient_exponent == quotient_order // 2
        assert p_class * p_class % residual in order_three
        assert p_class not in order_three

        if q_class == omega:
            assert p_class == residual - 1
        else:
            assert p_class * q_class % residual == residual - 1

    return 14


def first_prime_pair(
    exponent: int,
    residual: int,
    q_class: int,
    bound: int,
) -> tuple[int, int] | None:
    for q in range(q_class, bound + 1, residual):
        if q > 1 and isprime(q):
            p = 2 ** (exponent + 2) * q - residual
            if p > 0 and isprime(p):
                return q, p
    return None


def decomposition(
    exponent: int,
    residual: int,
    branch: int,
    q: int,
    p: int,
) -> tuple[int, int, int]:
    power = 2**exponent
    a = power * q
    assert p + residual == 4 * a

    if branch == 1:
        assert (p + 1) % residual == 0
        b = power * q * ((p + 1) // residual)
        c = p * b
    elif branch == 2:
        assert (p * q + 1) % residual == 0
        b = power * ((p * q + 1) // residual)
        c = p * q * b
    else:
        raise ValueError("branch must be one or two")

    assert Fraction(4, p) == Fraction(1, a) + Fraction(1, b) + Fraction(1, c)
    return a, b, c


def arithmetic_checks(
    rungs: list[tuple[int, int]],
    q_bound: int,
) -> tuple[int, list[tuple[int, int, int, int, int, tuple[int, int, int] | None]]]:
    assertions = 0
    records: list[
        tuple[int, int, int, int, int, tuple[int, int, int] | None]
    ] = []
    for exponent, residual in rungs:
        quotient_order = 2 * exponent + 4
        omega = pow(2, quotient_order, residual)
        for branch, q_class in enumerate(
            (omega, omega * omega % residual),
            start=1,
        ):
            pair = first_prime_pair(exponent, residual, q_class, q_bound)
            certificate = None
            if pair is not None:
                q, p = pair
                assert q % residual == q_class
                assertions += 1
                certificate = decomposition(
                    exponent,
                    residual,
                    branch,
                    q,
                    p,
                )
                assertions += 1
                records.append(
                    (
                        exponent,
                        residual,
                        branch,
                        q_class,
                        q,
                        certificate,
                    )
                )
            else:
                records.append(
                    (
                        exponent,
                        residual,
                        branch,
                        q_class,
                        0,
                        None,
                    )
                )
    return assertions, records


def main() -> None:
    abstract_assertions = abstract_ladder_checks(200)
    rungs = residual_primes(8)

    expected = [
        (1, 19),
        (2, 241),
        (3, 331),
        (4, 37),
        (4, 109),
        (5, 5419),
        (6, 97),
        (6, 673),
        (7, 87211),
        (8, 61),
        (8, 1321),
    ]
    assert rungs == expected

    group_assertions = sum(
        exact_group_check(exponent, residual)
        for exponent, residual in rungs
    )
    arithmetic_assertions, records = arithmetic_checks(
        rungs,
        q_bound=500_000,
    )

    print("PASS: power-of-two complete-target-fibre ladder")
    print(f"abstract cyclic assertions: {abstract_assertions}")
    print(f"exact residual-group assertions: {group_assertions}")
    print(f"arithmetic certificate assertions: {arithmetic_assertions}")
    print(f"residual rungs through exponent 8: {len(rungs)}")
    for exponent, residual, branch, q_class, q, certificate in records:
        if certificate is None:
            print(
                "rung "
                f"e={exponent}, R={residual}, branch={branch}, "
                f"q-class={q_class}: no pair through 500000"
            )
        else:
            p = 2 ** (exponent + 2) * q - residual
            a, b, c = certificate
            print(
                "rung "
                f"e={exponent}, R={residual}, branch={branch}, "
                f"q={q}, p={p}, denominators=({a},{b},{c})"
            )


if __name__ == "__main__":
    main()

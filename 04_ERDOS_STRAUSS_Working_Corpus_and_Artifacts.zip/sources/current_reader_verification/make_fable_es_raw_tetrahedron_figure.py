#!/usr/bin/env python3
"""Vector image of the exact ES-aligned raw-cell tetrahedron and its quarter altitude."""

from pathlib import Path

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np


HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "figures" / "fable_es_raw_tetrahedron.pdf"

sqrt3 = np.sqrt(3.0)
# Plot coordinates are (X,W,Y), so the transported fixed axis is vertical.
p_star = np.array([0.0, 0.0, 5.0 / 4.0])
face = np.array(
    [
        [2.0, 0.0, 3.0 / 2.0],
        [-1.0, sqrt3, 3.0 / 2.0],
        [-1.0, -sqrt3, 3.0 / 2.0],
    ]
)
centroid = face.mean(axis=0)
colors = ["#c43c35", "#2f6fbb", "#2d8a4b"]

fig = plt.figure(figsize=(10.8, 5.2))
ax = fig.add_subplot(1, 2, 1, projection="3d")

face_poly = Poly3DCollection(
    [face],
    facecolors="#9ecae1",
    edgecolors="0.35",
    linewidths=1.2,
    alpha=0.30,
)
ax.add_collection3d(face_poly)
for index in range(3):
    next_index = (index + 1) % 3
    ax.plot(
        [face[index, 0], face[next_index, 0]],
        [face[index, 1], face[next_index, 1]],
        [face[index, 2], face[next_index, 2]],
        color="0.35",
        linewidth=1.2,
    )
    ax.plot(
        [p_star[0], face[index, 0]],
        [p_star[1], face[index, 1]],
        [p_star[2], face[index, 2]],
        color="0.42",
        linewidth=1.1,
    )
    ax.scatter(*face[index], s=72, color=colors[index], depthshade=False)

ax.scatter(*p_star, s=86, color="#e08b2c", depthshade=False)
ax.scatter(*centroid, s=42, color="black", depthshade=False)
ax.plot(
    [p_star[0], centroid[0]],
    [p_star[1], centroid[1]],
    [p_star[2], centroid[2]],
    color="#8b1a1a",
    linewidth=2.3,
)
ax.text(0.18, 0.04, 1.37, r"$1/4$", color="#8b1a1a", fontsize=10)

ax.set_xlim(-2.15, 2.15)
ax.set_ylim(-1.95, 1.95)
ax.set_zlim(1.19, 1.56)
ax.set_box_aspect((4.3, 3.9, 0.37))
ax.set_zticks([5.0 / 4.0, 3.0 / 2.0])
ax.set_zticklabels([r"$5/4$", r"$3/2$"])
ax.grid(False)
ax.set_xlabel(r"$X$")
ax.set_ylabel(r"$W$")
ax.set_zlabel(r"$Y$")
ax.view_init(elev=19, azim=-56)
ax.set_title("A. Transported raw-cell tetrahedron", loc="left", fontweight="bold")

ax2 = fig.add_subplot(1, 2, 2)
ax2.set_xlim(0.0, 1.15)
ax2.set_ylim(1.18, 1.57)
ax2.axis("off")
ax2.plot([0.28, 0.28], [1.21, 1.54], color="0.35", linewidth=1.2)
ax2.scatter([0.28], [5.0 / 4.0], s=95, color="#e08b2c", zorder=3)
ax2.scatter([0.28], [3.0 / 2.0], s=65, color="black", zorder=3)
ax2.plot([0.42, 0.42], [5.0 / 4.0, 3.0 / 2.0], color="#8b1a1a", linewidth=2.0)
ax2.plot([0.39, 0.45], [5.0 / 4.0, 5.0 / 4.0], color="#8b1a1a", linewidth=1.3)
ax2.plot([0.39, 0.45], [3.0 / 2.0, 3.0 / 2.0], color="#8b1a1a", linewidth=1.3)
ax2.text(0.47, 1.372, r"$1/4$", color="#8b1a1a", fontsize=12, va="center")
ax2.text(
    0.24,
    5.0 / 4.0,
    r"$p_\ast:\ Y=5/4$",
    fontsize=10,
    va="center",
    ha="right",
)
ax2.text(
    0.24,
    3.0 / 2.0,
    r"$\bar p_{\rm face}:\ Y=3/2$",
    fontsize=10,
    va="center",
    ha="right",
)
ax2.text(
    0.60,
    1.515,
    r"$\|p_a-p_b\|=2\sqrt{3}$" "\n"
    r"$\|p_\ast-p_a\|=\sqrt{65}/4$" "\n"
    r"$\operatorname{Vol}(\Delta_{\rm spatial})=\sqrt{3}/4$",
    fontsize=10.5,
    linespacing=1.6,
    va="top",
)
ax2.text(
    0.60,
    1.335,
    r"raw axis: $3\mapsto 1/4$" "\n"
    r"axial factor: $1/12$" "\n"
    r"$J_{\rm sp\mid raw}=\sqrt{2}/24$",
    fontsize=10.5,
    linespacing=1.6,
    va="top",
)
ax2.set_title("B. Exact altitude and affine distortion", loc="left", fontweight="bold")

fig.suptitle(
    "The negative quarter cell is the spatial apex below the null face",
    fontsize=13.5,
    fontweight="bold",
)
fig.subplots_adjust(left=0.03, right=0.98, bottom=0.07, top=0.84, wspace=0.25)
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, bbox_inches="tight")
plt.close(fig)
print(OUT)

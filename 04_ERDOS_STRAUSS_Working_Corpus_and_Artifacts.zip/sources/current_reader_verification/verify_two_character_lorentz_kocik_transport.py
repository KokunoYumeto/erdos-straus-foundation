import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def matrix_equal(left, right, label):
    require(left.shape == right.shape, f"{label}: shape")
    for entry in left - right:
        require(sp.factor(entry) == 0, f"{label}: {sp.factor(entry)}")


# Ordered two-character reconstruction and its two labelled null displacements.
lambda_plus, lambda_minus = sp.symbols("lambda_plus lambda_minus", real=True)
alpha_1 = lambda_plus - lambda_minus
two_alpha_2 = lambda_plus + lambda_minus

circle_to_sarnak = sp.Matrix(
    [
        [sp.Rational(1, 2), 0, 0, sp.Rational(1, 2)],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [sp.Rational(1, 2), 0, 0, -sp.Rational(1, 2)],
    ]
)
epsilon_minus = sp.Matrix([0, 0, 0, -1])
n_minus = circle_to_sarnak * epsilon_minus
matrix_equal(
    n_minus,
    sp.Matrix([sp.Rational(-1, 2), 0, 0, sp.Rational(1, 2)]),
    "negative coefficient null direction",
)

resolved = sp.Matrix.hstack(alpha_1 * n_minus, two_alpha_2 * n_minus)
matrix_equal(
    resolved[:, 0] + resolved[:, 1],
    2 * lambda_plus * n_minus,
    "character-resolved sum",
)
matrix_equal(
    resolved[:, 1] - resolved[:, 0],
    2 * lambda_minus * n_minus,
    "character-resolved ordered difference",
)

base_coefficients = sp.Matrix([4, 0, 0, 0])
aggregate_coefficients = (
    base_coefficients
    + alpha_1 * epsilon_minus
    + two_alpha_2 * epsilon_minus
)
aggregate_sarnak = circle_to_sarnak * aggregate_coefficients
matrix_equal(
    aggregate_coefficients,
    sp.Matrix([4, 0, 0, -2 * lambda_plus]),
    "aggregate coefficient vector",
)
matrix_equal(
    aggregate_sarnak,
    sp.Matrix([2 - lambda_plus, 0, 0, 2 + lambda_plus]),
    "aggregate Sarnak vector",
)
U = sp.factor(aggregate_sarnak[0] + aggregate_sarnak[3])
V = sp.factor(aggregate_sarnak[0] - aggregate_sarnak[3])
require(U == 4, "fixed aggregate U coordinate")
require(V == -2 * lambda_plus, "aggregate V coordinate")

# The coefficient-inversion coordinate is q=-alpha^Sigma/4=-lambda_plus/2.
q = sp.symbols("q", nonzero=True, real=True)
q_from_character = -lambda_plus / 2
require(
    sp.factor(q_from_character + (2 * lambda_plus) / 4) == 0,
    "coefficient-inversion coordinate",
)

# Exact Kocik parameter along the shell line.
D = lambda_plus**2 + 8 * lambda_plus + 4
kappa = sp.factor((lambda_plus**2 + 4) / D)
T = 2 - lambda_plus
W = 2 + lambda_plus
require(
    sp.factor((3 * kappa - 1) * W**2 - (kappa + 1) * T**2) == 0,
    "cleared Kocik equation",
)
require(
    sp.factor(1 - kappa - 8 * lambda_plus / D) == 0,
    "upper Kocik bound identity",
)
require(
    sp.factor(
        kappa
        - sp.Rational(1, 3)
        - 2 * (lambda_plus - 2) ** 2 / (3 * D)
    )
    == 0,
    "lower Kocik bound identity",
)
require(
    sp.factor(sp.diff(kappa, lambda_plus) - 8 * (lambda_plus**2 - 4) / D**2)
    == 0,
    "Kocik derivative",
)
require(
    sp.factor(kappa.subs(lambda_plus, 4 / lambda_plus) - kappa) == 0,
    "two-sheet amplitude exchange",
)

kappa_q = sp.factor((q**2 + 1) / (q**2 - 4 * q + 1))
require(
    sp.factor(kappa.subs(lambda_plus, -2 * q) - kappa_q) == 0,
    "Kocik parameter in coefficient-inversion coordinate",
)
require(sp.factor(kappa_q.subs(q, 1 / q) - kappa_q) == 0, "q reciprocity")
require(kappa_q.subs(q, sp.Rational(-1, 4)) == sp.Rational(17, 33), "quarter value")
require(kappa_q.subs(q, -4) == sp.Rational(17, 33), "reciprocal quarter value")

s_q = sp.Matrix([2 * (1 + q), 0, 0, 2 * (1 - q)])
reflection_W = sp.diag(1, 1, 1, -1)
matrix_equal(
    s_q.subs(q, 1 / q),
    reflection_W * s_q / q,
    "reciprocal shell reflection",
)

# Exact relation to the established p=17 support-dyad carrier.
u_sigma = sp.Matrix([sp.Rational(5, 4), 0, 0, sp.Rational(3, 4)])
quarter_shell = sp.Matrix([sp.Rational(3, 2), 0, 0, sp.Rational(5, 2)])
swap_TW = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
matrix_equal(quarter_shell, 2 * swap_TW * u_sigma, "quarter-to-dyad transposition")

p = sp.symbols("p")
p_transposed = sp.factor(p / (2 * p - 1))
ratio = sp.factor((p + 1) / (3 * p - 1))
ratio_transposed = sp.factor((p_transposed + 1) / (3 * p_transposed - 1))
require(sp.factor(ratio_transposed - 1 / ratio) == 0, "Kocik transposition law")
require(p_transposed.subs(p, 17) == sp.Rational(17, 33), "p=17 transposition")

# The second Hadamard transform gives the exact target Lorentz cone.
sqrt2 = sp.sqrt(2)
U0 = sp.Matrix([[1, 1], [1, -1]]) / sqrt2
target_cone_matrix = sp.Matrix(
    [
        [lambda_plus, lambda_minus],
        [lambda_minus, lambda_plus],
    ]
)
matrix_equal(
    U0.T * target_cone_matrix * U0,
    sp.diag(two_alpha_2, alpha_1),
    "target cone spectrum",
)
require(
    sp.factor(target_cone_matrix.det() - 2 * alpha_1 * (two_alpha_2 / 2)) == 0,
    "target Lorentz norm",
)

alpha1_exact = sp.Rational(1026107, 426888)
alpha2_exact = sp.Rational(
    5176199252561022635,
    209357204251173091344,
)
lambda_plus_exact = sp.factor(alpha2_exact + alpha1_exact / 2)
lambda_minus_exact = sp.factor(alpha2_exact - alpha1_exact / 2)
require(
    lambda_plus_exact
    == sp.Rational(
        128395625711903946059,
        104678602125586545672,
    ),
    "12289 lambda_plus",
)
require(
    lambda_minus_exact
    == -sp.Rational(
        14143643992119252,
        12015450198070081,
    ),
    "12289 lambda_minus",
)
require(
    sp.factor(lambda_plus_exact**2 - lambda_minus_exact**2)
    == sp.Rational(
        5311334286447633252931945,
        44686039104187389308828736,
    ),
    "12289 target Lorentz norm",
)

lines = [
    "PASS: two-character Lorentz and Kocik transport",
    "the ordered target displacements retain both lambda_plus and lambda_minus",
    "their sum is the aggregate 2 lambda_plus null displacement",
    "their ordered difference is the 2 lambda_minus null displacement",
    "the aggregate Sarnak coordinates are (2-lambda_plus,0,0,2+lambda_plus)",
    "the aggregate null coordinates are U=4 and V=-2 lambda_plus",
    "the shell-line Kocik parameter is (lambda_plus^2+4)/(lambda_plus^2+8 lambda_plus+4)",
    "the Kocik parameter is invariant under lambda_plus -> 4/lambda_plus",
    "the coefficient coordinate q=-lambda_plus/2 is exchanged with q^{-1}",
    "q=-1/4 and q=-4 both give Kocik parameter 17/33",
    "the quarter shell is twice the T-W transposition of the p=17 support dyad",
    "T-W transposition sends p to p/(2p-1)",
    "the second Hadamard transform has eigenvalues 2 alpha_2 and alpha_1",
    "the target Lorentz norm is 2 alpha_1 alpha_2",
    "the exact 12289 skew character lambda_minus is negative",
    "the exact 12289 target character vector is timelike",
]

print("\n".join(lines))

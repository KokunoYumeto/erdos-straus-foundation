#!/usr/bin/env python3
"""Exact checks for the simplex-synthesis 1-2-3 modular intertwiner."""

import sympy as sp


support_maps = {}
densities = {
    1: sp.diag(1),
    2: sp.diag(2, 3),
    3: sp.diag(5, 7, 11),
}

figure_synthesis = {
    1: sp.Matrix([[1, -1]]),
    2: sp.Matrix(
        [
            [1, -sp.Rational(1, 2), -sp.Rational(1, 2)],
            [0, sp.sqrt(3) / 2, -sp.sqrt(3) / 2],
        ]
    ),
    3: sp.Matrix(
        [
            [1, 1, -1, -1],
            [1, -1, 1, -1],
            [1, -1, -1, 1],
        ]
    ) / sp.sqrt(3),
}

for n in (1, 2, 3):
    # The ordered Helmert rows give one exact coordinate realization of the
    # basis-free synthesis unitary from the all-one orthogonal complement.
    rows = []
    for k in range(1, n + 1):
        row = [sp.Integer(0)] * (n + 1)
        denominator = sp.sqrt(k * (k + 1))
        for j in range(k):
            row[j] = 1 / denominator
        row[k] = -sp.Rational(k, 1) / denominator
        rows.append(row)
    unitary = sp.Matrix(rows)

    ones = sp.ones(n + 1, 1)
    projection = sp.eye(n + 1) - sp.Rational(1, n + 1) * ones * ones.T
    synthesis = sp.sqrt(sp.Rational(n + 1, n)) * unitary
    gram = sp.Rational(n + 1, n) * projection
    displayed_synthesis = figure_synthesis[n]

    assert sp.simplify(unitary * unitary.T) == sp.eye(n)
    assert sp.simplify(unitary.T * unitary) == projection
    assert sp.simplify(synthesis.T * synthesis) == gram
    assert unitary * ones == sp.zeros(n, 1)
    assert sp.simplify(displayed_synthesis.T * displayed_synthesis) == gram
    assert sp.simplify(displayed_synthesis * displayed_synthesis.T) == (
        sp.Rational(n + 1, n) * sp.eye(n)
    )

    density = densities[n]
    pulled_density = sp.simplify(unitary.T * density * unitary)
    support_inverse = sp.simplify(unitary.T * density.inv() * unitary)
    assert sp.simplify(pulled_density * support_inverse) == projection
    assert sp.simplify(support_inverse * pulled_density) == projection

    for i in range(n):
        for j in range(n):
            matrix_unit = sp.zeros(n)
            matrix_unit[i, j] = 1
            pulled_unit = sp.simplify(unitary.T * matrix_unit * unitary)
            expected = sp.Rational(density[i, i], density[j, j]) * pulled_unit
            modular_image = sp.simplify(
                pulled_density * pulled_unit * support_inverse
            )
            assert sp.simplify(modular_image - expected) == sp.zeros(n + 1)

    support_maps[n] = unitary

dimension_matrix = sp.Matrix(3, 3, lambda a, b: (a + 1) * (b + 1))
assert dimension_matrix == sp.Matrix([[1, 2, 3], [2, 4, 6], [3, 6, 9]])

for j in range(2):
    for k in range(3):
        forward_weights = [
            sp.Rational(1, densities[2][j, j]),
            sp.Rational(densities[2][j, j], densities[3][k, k]),
            sp.Rational(densities[3][k, k], 1),
        ]
        assert sp.prod(forward_weights) == 1

assert densities[1] == sp.eye(1)
assert densities[2][0, 0] != densities[2][1, 1]
assert len(set(densities[3].diagonal())) == 3

print("PASS synthesis unitary identifies each simplex support with dimensions 1,2,3")
print("PASS displayed segment, triangle, and tetrahedron realize the exact simplex Gram forms")
print("PASS simplex Gram form pulls back from the support unitary exactly")
print("PASS positive sector densities and support inverses transport exactly")
print("PASS every support matrix unit has the expected modular eigenvalue")
print("PASS nine transported linking corners have dimension matrix [[1,2,3],[2,4,6],[3,6,9]]")
print("PASS all six oriented three-sector modular weight products equal one")
print("PASS the C1 Hamiltonian is zero while the C2 and C3 examples are nontrivial")

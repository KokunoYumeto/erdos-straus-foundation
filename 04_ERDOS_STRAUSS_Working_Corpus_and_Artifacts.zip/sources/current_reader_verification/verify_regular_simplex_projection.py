#!/usr/bin/env python3
"""Exact checks for the regular-simplex vertex-projection theorem."""

from sympy import Matrix, Rational, simplify, symbols


def symbolic_check():
    n = symbols("n", integer=True, positive=True)
    projected_norm = 1 - 1 / n**2
    projected_cross = -1 / n - 1 / n**2
    assert simplify(projected_norm - (n**2 - 1) / n**2) == 0
    assert simplify(projected_cross + (n + 1) / n**2) == 0
    assert simplify(projected_cross / projected_norm + 1 / (n - 1)) == 0


def gram_check(n):
    gram = Matrix(
        n + 1,
        n + 1,
        lambda i, j: Rational(1) if i == j else Rational(-1, n),
    )
    ones = Matrix.ones(n + 1, 1)
    assert gram * ones == Matrix.zeros(n + 1, 1)
    assert gram.rank() == n

    opposite = gram[1:, 1:]
    column = gram[1:, 0]
    projected = opposite - column * column.T
    expected = Matrix(
        n,
        n,
        lambda i, j: (
            Rational(n * n - 1, n * n)
            if i == j
            else Rational(-(n + 1), n * n)
        ),
    )
    assert projected == expected
    assert projected * Matrix.ones(n, 1) == Matrix.zeros(n, 1)
    assert projected.rank() == n - 1
    return projected


if __name__ == "__main__":
    symbolic_check()
    for dimension in range(2, 10):
        gram_check(dimension)
    four = gram_check(4)
    print("PASS symbolic projected norm = (n^2-1)/n^2")
    print("PASS symbolic projected cross term = -(n+1)/n^2")
    print("PASS unit-rescaled opposite-face Gram has cross term -1/(n-1)")
    print("PASS exact Gram checks for n=2,...,9")
    print("PASS n=4 hidden centroid displacement = -v0/4")
    print(
        "PASS n=4 projected face Gram = diagonal "
        f"{four[0, 0]}, off diagonal {four[0, 1]}"
    )

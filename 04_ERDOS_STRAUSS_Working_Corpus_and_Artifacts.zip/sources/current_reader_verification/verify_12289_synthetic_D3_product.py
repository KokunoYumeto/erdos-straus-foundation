from collections import Counter
from itertools import product
from pathlib import Path


p = 12289
R = 11
a = 3075
v = (3, 6, 3)


def target(j):
    if j == 0:
        return (-p) % R
    if j == 1:
        return (-1) % R
    if j == 2:
        return (-pow(p, -1, R)) % R
    raise ValueError(j)


def U(w):
    return (w[2], w[0], w[1])


def U_power(w, exponent):
    result = w
    for _ in range(exponent % 3):
        result = U(result)
    return result


def S0(w):
    return (w[2], w[1], w[0])


divisors = sorted(
    3**e3 * 5**e5 * 41**e41
    for e3, e5, e41 in product(range(3), range(5), range(3))
)
a_inverse = pow(a, -1, R)
X = tuple(
    (j, u)
    for j in range(3)
    for u in divisors
    if (u * a_inverse) % R == target(j)
)
if len(X) != 12 or len(set(X)) != 12:
    raise AssertionError(f"certificate-set cardinality: {len(X)}")
if Counter(j for j, _ in X) != Counter({0: 3, 1: 6, 2: 3}):
    raise AssertionError("origin multiplicities differ from (3,6,3)")


def iota(x):
    j, u = x
    return (2 - j, a * a // u)


if any(iota(iota(x)) != x for x in X):
    raise AssertionError("arithmetic complement is not involutive")
if any(iota(x) == x for x in X):
    raise AssertionError("arithmetic complement must be fixed-point-free")
if {iota(x) for x in X} != set(X):
    raise AssertionError("arithmetic complement does not preserve X")

O = tuple(U_power(v, m) for m in range(3))
if O != ((3, 6, 3), (3, 3, 6), (6, 3, 3)):
    raise AssertionError(f"coordinate orbit: {O}")
if len(set(O)) != 3:
    raise AssertionError("coordinate orbit must have three points")
for basis_vector in ((1, 0, 0), (0, 1, 0), (0, 0, 1)):
    if S0(S0(basis_vector)) != basis_vector:
        raise AssertionError("S0^2 differs from the identity")
    if S0(U(S0(basis_vector))) != U_power(basis_vector, -1):
        raise AssertionError("S0 U S0 differs from U^{-1}")
if S0(v) != v:
    raise AssertionError("S0 does not fix the base coordinate vector")

cover = tuple((m, j, u) for m in range(3) for j, u in X)
if len(cover) != 36:
    raise AssertionError(f"cover cardinality: {len(cover)}")


def r(point):
    m, j, u = point
    return ((m + 1) % 3, j, u)


def s(point):
    m, j, u = point
    return ((-m) % 3, 2 - j, a * a // u)


def pi_X(point):
    _, j, u = point
    return (j, u)


def pi_O(point):
    m, _, _ = point
    return U_power(v, m)


def theta(point):
    return (pi_X(point), pi_O(point))


for point in cover:
    if r(r(r(point))) != point:
        raise AssertionError("r^3 differs from the identity")
    if s(s(point)) != point:
        raise AssertionError("s^2 differs from the identity")
    if s(r(s(point))) != r(r(point)):
        raise AssertionError("srs differs from r^{-1}")
    if pi_X(r(point)) != pi_X(point):
        raise AssertionError("pi_X r differs from pi_X")
    if pi_X(s(point)) != iota(pi_X(point)):
        raise AssertionError("pi_X s differs from iota pi_X")
    if pi_O(r(point)) != U(pi_O(point)):
        raise AssertionError("pi_O r differs from U pi_O")
    if pi_O(s(point)) != S0(pi_O(point)):
        raise AssertionError("pi_O s differs from S0 pi_O")

theta_image = {theta(point) for point in cover}
full_product = {(x, w) for x in X for w in O}
if theta_image != full_product or len(theta_image) != 36:
    raise AssertionError("joint product map is not bijective")

pi_X_fibres = Counter(pi_X(point) for point in cover)
pi_O_fibres = Counter(pi_O(point) for point in cover)
if set(pi_X_fibres.values()) != {3}:
    raise AssertionError(f"arithmetic projection fibres: {pi_X_fibres}")
if set(pi_O_fibres.values()) != {12}:
    raise AssertionError(f"coordinate projection fibres: {pi_O_fibres}")


def c3_orbit(point):
    return frozenset((point, r(point), r(r(point))))


def d3_orbit(point):
    reflected = s(point)
    return frozenset(
        (point, r(point), r(r(point)), reflected, r(reflected), r(r(reflected)))
    )


c3_orbits = {c3_orbit(point) for point in cover}
d3_orbits = {d3_orbit(point) for point in cover}
iota_orbits = {frozenset((x, iota(x))) for x in X}
if len(c3_orbits) != 12 or {len(orbit) for orbit in c3_orbits} != {3}:
    raise AssertionError("C3 quotient does not have twelve three-point fibres")
if len(d3_orbits) != 6 or {len(orbit) for orbit in d3_orbits} != {6}:
    raise AssertionError("D3 quotient does not have six free six-point orbits")
if len(iota_orbits) != 6 or {len(orbit) for orbit in iota_orbits} != {2}:
    raise AssertionError("arithmetic complement quotient does not have six pairs")

for orbit in d3_orbits:
    projected = frozenset(pi_X(point) for point in orbit)
    if projected not in iota_orbits:
        raise AssertionError("a D3 orbit does not descend to one iota orbit")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{thm:12289-synthetic-D3-product-factorization}",
    r"\label{eq:12289-product-bijection}",
    r"\label{eq:12289-product-D3-action}",
    r"\label{eq:12289-product-quotients}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact product factorization of the 12289 synthetic D3 cover",
            "arithmetic certificate set size = 12 with origin counts (3,6,3)",
            "coordinate orbit = {(3,6,3),(3,3,6),(6,3,3)}",
            "joint map cover -> arithmetic set x coordinate orbit is bijective",
            "arithmetic projection fibre size = 3",
            "coordinate-orbit projection fibre size = 12",
            "C3 quotient size = 12",
            "D3 quotient size = arithmetic complement quotient size = 6",
            "all D3 relations and both projection equivariance identities verified",
        )
    )
)

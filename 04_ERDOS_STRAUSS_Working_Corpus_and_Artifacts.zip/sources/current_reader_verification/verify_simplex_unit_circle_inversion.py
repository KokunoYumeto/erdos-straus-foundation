#!/usr/bin/env python3
"""Exact unit-circle inversion on the two arithmetic blade carriers."""

import sympy as sp


u2 = sp.Matrix(
    [
        [1 / sp.sqrt(2), -1 / sp.sqrt(2), 0],
        [1 / sp.sqrt(6), 1 / sp.sqrt(6), -2 / sp.sqrt(6)],
    ]
)
p2 = sp.eye(3) - sp.ones(3, 3) / 3
s2 = sp.Matrix([[0, 1], [1, 0]])
hat_s2 = sp.simplify(u2.T * s2 * u2)
expected_hat_s2 = sp.Matrix([[1, 0, -1], [0, -1, 1], [-1, 1, 0]]) / sp.sqrt(3)

assert sp.simplify(hat_s2 - expected_hat_s2) == sp.zeros(3)
assert sp.simplify(hat_s2**2 - p2) == sp.zeros(3)

# The coefficient action for inversion in x^2+y^2-1=0.
m_unit = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)

v_minus_plus = sp.Matrix([4, 0, 0, -1])
v_plus_minus_raw = sp.Matrix([-1, 0, 0, 1])
v_plus_minus_twice = sp.Matrix([-1, 0, 0, 4])

assert m_unit * v_minus_plus == v_plus_minus_twice
assert m_unit * v_plus_minus_raw == -v_plus_minus_raw
assert m_unit**2 == sp.eye(4)


def sarnak(v):
    a, b0, b1, c = v
    return sp.Matrix([(a + c) / 2, b0, b1, (a - c) / 2])


l_minus_plus = sarnak(v_minus_plus)
l_plus_minus_raw = sarnak(v_plus_minus_raw)
l_plus_minus_twice = sarnak(v_plus_minus_twice)

assert l_minus_plus == sp.Matrix([sp.Rational(3, 2), 0, 0, sp.Rational(5, 2)])
assert l_plus_minus_twice == sp.Matrix(
    [sp.Rational(3, 2), 0, 0, -sp.Rational(5, 2)]
)
assert l_plus_minus_raw == sp.Matrix([0, 0, 0, -1])
assert sarnak(-v_plus_minus_raw) == sp.Matrix([0, 0, 0, 1])

h_minus_plus = sp.diag(4, -1)
h_plus_minus_raw = sp.diag(-1, 1)
h_plus_minus_twice = sp.diag(-1, 4)

pulled_minus_plus = sp.simplify(u2.T * h_minus_plus * u2)
pulled_plus_minus_raw = sp.simplify(u2.T * h_plus_minus_raw * u2)
pulled_plus_minus_twice = sp.simplify(u2.T * h_plus_minus_twice * u2)

expected_pulled_twice = sp.Matrix(
    [[1, 7, -8], [7, 1, -8], [-8, -8, 16]]
) / 6
assert sp.simplify(pulled_plus_minus_twice - expected_pulled_twice) == sp.zeros(3)
assert sp.simplify(
    hat_s2 * pulled_minus_plus * hat_s2 - pulled_plus_minus_twice
) == sp.zeros(3)
assert sp.simplify(
    hat_s2 * pulled_plus_minus_raw * hat_s2 + pulled_plus_minus_raw
) == sp.zeros(3)

print("PASS unit-circle inversion reverses the first and fourth circle coefficients")
print("PASS the multiplicity-two directed carrier maps to its multiplicity-two transpose")
print("PASS the actual multiplicity-one transposed raw carrier maps to its negative")
print("PASS Sarnak coordinates transform by (T,X,Y,W) to (T,X,Y,-W)")
print("PASS the pulled sheet exchange is the stated 3-by-3 support involution")
print("PASS simplex-support conjugation reproduces both coefficient transformations")

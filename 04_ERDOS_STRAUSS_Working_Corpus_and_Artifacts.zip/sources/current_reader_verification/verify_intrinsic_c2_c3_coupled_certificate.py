from collections import defaultdict
from functools import lru_cache
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def unit_group_coefficients(a, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(a):
        local = defaultdict(int)
        local[1] += 1
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] += 1
            local[pow(residue, -1, modulus)] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left * right) % modulus] += left_count * right_count
        coefficients = dict(product)
    return coefficients


two_torsion = {unit for unit in range(1, 7) if pow(unit, 2, 7) == 1}
three_torsion = {unit for unit in range(1, 7) if pow(unit, 3, 7) == 1}
if two_torsion != {1, 6} or three_torsion != {1, 2, 4}:
    raise AssertionError("incorrect intrinsic torsion subgroups of U_7")

theta = {unit: (pow(unit, 3, 7), pow(unit, 4, 7)) for unit in range(1, 7)}
if len(set(theta.values())) != 6:
    raise AssertionError("the intrinsic C2 x C3 map is not bijective")
for unit, pair in theta.items():
    if pair[0] not in two_torsion or pair[1] not in three_torsion:
        raise AssertionError("an intrinsic component lies outside its subgroup")
    if pair[0] * pair[1] % 7 != unit:
        raise AssertionError("intrinsic component reconstruction fails")
if theta[6] != (6, 1):
    raise AssertionError("minus one does not map to the C2-odd C3-neutral target")

shell_count = 0
r7_shell_count = 0
balanced_divisor_count = 0

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue
    for R in divisors(p - 1):
        if R % 4 != 3:
            continue
        shell_count += 1
        a = (p + R) // 4
        coefficients = unit_group_coefficients(a, R)
        coefficient = coefficients.get(R - 1, 0)
        balanced = [r for r in divisors(a) if (r + 1) % R == 0]
        if coefficient < 2 * len(balanced):
            raise AssertionError(
                f"balanced coefficient bound fails at p={p}, R={R}, a={a}"
            )
        if 3 * coefficient < 6 * len(balanced):
            raise AssertionError(
                f"balanced rank bound fails at p={p}, R={R}, a={a}"
            )

        for r in balanced:
            low = a // r
            high = a * r
            if r == 1 or low == high or low * high != a * a:
                raise AssertionError(
                    f"balanced complement pair fails at p={p}, R={R}, r={r}"
                )
            if (low + a) % R or (high + a) % R:
                raise AssertionError(
                    f"balanced middle orbit fails at p={p}, R={R}, r={r}"
                )
            if (4 * low + 1) % R or (4 * high + 1) % R:
                raise AssertionError(
                    f"balanced exterior orbits fail at p={p}, R={R}, r={r}"
                )
            balanced_divisor_count += 1

        if R == 7:
            r7_shell_count += 1
            component_coefficients = defaultdict(int)
            for residue, count in coefficients.items():
                component_coefficients[theta[residue]] += count
            if component_coefficients[(6, 1)] != coefficient:
                raise AssertionError(
                    f"intrinsic C2 x C3 coefficient fails at p={p}, a={a}"
                )


if not shell_count or not r7_shell_count or not balanced_divisor_count:
    raise AssertionError("the intrinsic coupled-shell test families were not all present")

print("PASS: intrinsic C2 x C3 coupled-shell certificate")
print("u maps bijectively to the pair (u^3,u^4) in U_7[2] x U_7[3]")
print("minus one maps to the C2-odd and C3-neutral pair (-1,1)")
print("the coefficient at (-1,1) equals the original minus-one coefficient")
print("each balanced divisor contributes two ordered terms and one packet")
print("each such packet supplies two exterior orbits and one middle orbit")
print("all coupled shells through p=5000 passed")

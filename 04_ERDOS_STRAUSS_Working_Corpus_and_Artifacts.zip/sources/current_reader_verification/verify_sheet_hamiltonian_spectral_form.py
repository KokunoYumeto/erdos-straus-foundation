from sympy import Matrix, eye, exp, log, symbols


def require(label, condition):
    if condition is not True:
        raise AssertionError(label)
    print(f"{label}: PASS")


a, b = symbols("a b", real=True)
delta_plus, delta_minus = symbols("delta_plus delta_minus", positive=True)

S = Matrix([[0, 1], [1, 0]])
I2 = eye(2)
u_plus = Matrix([1, 1]) / 2**0.5
u_minus = Matrix([1, -1]) / 2**0.5
P_plus = (I2 + S) / 2
P_minus = (I2 - S) / 2

K = Matrix([[a, b], [b, a]])
kappa_plus = a + b
kappa_minus = a - b

require("sheet exchange is a self-adjoint involution", S.T == S and S * S == I2)
require("sheet projectors resolve the identity", P_plus + P_minus == I2)
require("sheet projectors are orthogonal", P_plus * P_minus == Matrix.zeros(2))
require("sheet-equivariant Hamiltonian spectral form", K == kappa_plus * P_plus + kappa_minus * P_minus)
require("sheet-equivariant Hamiltonian commutes with exchange", K * S == S * K)
require("positive sheet eigenvalue", K * Matrix([1, 1]) == kappa_plus * Matrix([1, 1]))
require("negative sheet eigenvalue", K * Matrix([1, -1]) == kappa_minus * Matrix([1, -1]))

Delta = delta_plus * P_plus + delta_minus * P_minus
K_delta = -log(delta_plus) * P_plus - log(delta_minus) * P_minus
require("positive modular operator commutes with exchange", Delta * S == S * Delta)
require("logarithmic Hamiltonian is self-adjoint", K_delta.T == K_delta)
require("logarithmic Hamiltonian commutes with exchange", K_delta * S == S * K_delta)
require(
    "exponential reconstructs the modular operator",
    exp(log(delta_plus)) * P_plus + exp(log(delta_minus)) * P_minus == Delta,
)

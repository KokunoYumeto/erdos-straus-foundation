#!/usr/bin/env python3
"""Exact checks for the zero-defect three-origin critical family."""

from itertools import product
from math import gcd, prod


def interval(n, half_width):
    return {k % n for k in range(-half_width, half_width + 1)}


def sumset(intervals, n):
    return {
        sum(choice) % n
        for choice in product(*[sorted(values) for values in intervals])
    }


def stabilizer(values, n):
    return {
        h for h in range(n)
        if {(x + h) % n for x in values} == values
    }


def check_cyclic_family():
    checked = 0
    for m in range(1, 65):
        n = 2 * m + 4
        target = {m + 1, m + 2, m + 3}

        decompositions = [(m,)]
        decompositions.extend((r, m - r) for r in range(1, m))
        for widths in decompositions:
            intervals = tuple(interval(n, e) for e in widths)
            carrier = sumset(intervals, n)
            expected = interval(n, m)
            kappa = 1 + sum(len(values) - 1 for values in intervals)
            delta = n - len(carrier) - len(target)
            epsilon = len(carrier) - kappa

            assert carrier == expected
            assert carrier.isdisjoint(target)
            assert carrier | target == set(range(n))
            assert stabilizer(carrier, n) == {0}
            assert (delta, epsilon) == (0, 0)
            checked += 1
    return checked


def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]


def divisors_from_factorization(factors):
    values = {1}
    for prime, exponent in factors.items():
        values = {
            value * prime ** power
            for value in values
            for power in range(exponent + 1)
        }
    return sorted(values)


def product_set(left, right, modulus):
    return {(x * y) % modulus for x in left for y in right}


def multiplicative_coset(x, subgroup, modulus):
    return frozenset((x * k) % modulus for k in subgroup)


def multiplicative_image_count(values, subgroup, modulus):
    return len({
        multiplicative_coset(x, subgroup, modulus)
        for x in values
    })


def check_arithmetic_realization():
    p, R, a = 5, 7, 3
    N = p * a
    H = set(range(1, R))
    carrier = {pow(3, exponent, R) for exponent in (-1, 0, 1)}
    target = {
        (-p) % R,
        (-1) % R,
        (-pow(p, -1, R)) % R,
    }
    K = {
        h for h in H
        if {(h * x) % R for x in carrier} == carrier
    }

    assert carrier == {1, 3, 5}
    assert target == {2, 4, 6}
    assert carrier.isdisjoint(target)
    assert carrier | target == H
    assert K == {1}
    assert len(carrier) == 3
    assert 1 + (len(carrier) - 1) == 3
    assert not [d for d in divisors(N * N) if d % R == (-N) % R]

    R_success = 3
    a_success = (p + R_success) // 4
    N_success = p * a_success
    d = 2
    b = (N_success + d) // R_success
    c = (N_success + N_success * N_success // d) // R_success
    assert (a_success, N_success, b, c) == (2, 10, 4, 20)
    assert 4 * a_success * b * c == p * (b * c + a_success * c + a_success * b)
    return (p, R, a, N, tuple(sorted(carrier)), tuple(sorted(target))), (a_success, b, c)


def check_adjacent_zero_defect_pair():
    p = 353
    receipts = []
    data = (
        (31, {2: 5, 3: 1}, {1, 2, 4, 8, 16}),
        (27, {5: 1, 19: 1}, {1, 10, 19}),
    )
    for R, factors_a, expected_stabilizer in data:
        a = (p + R) // 4
        assert a == prod(prime ** exponent for prime, exponent in factors_a.items())
        intervals = [
            {pow(prime, k, R) for k in range(-exponent, exponent + 1)}
            for prime, exponent in factors_a.items()
        ]
        carrier = {1}
        for values in intervals:
            carrier = product_set(carrier, values, R)
        units = {x for x in range(1, R) if gcd(x, R) == 1}
        target = {(-p) % R, (-1) % R, (-pow(p, -1, R)) % R}
        stabilizer = {
            h for h in units
            if {(h * x) % R for x in carrier} == carrier
        }
        assert stabilizer == expected_stabilizer
        q = len(units) // len(stabilizer)
        carrier_q = multiplicative_image_count(carrier, stabilizer, R)
        target_q = multiplicative_image_count(target, stabilizer, R)
        local_q = [
            multiplicative_image_count(values, stabilizer, R)
            for values in intervals
        ]
        kappa = 1 + sum(size - 1 for size in local_q)
        delta = q - carrier_q - target_q
        epsilon = carrier_q - kappa
        assert carrier.isdisjoint(target)
        assert (q, carrier_q, target_q, kappa) == (6, 3, 3, 3)
        assert (delta, epsilon) == (0, 0)

        factors_n_squared = {prime: 2 * exponent for prime, exponent in factors_a.items()}
        factors_n_squared[p] = 2
        N = p * a
        candidates = [
            d for d in divisors_from_factorization(factors_n_squared)
            if d % R == (-N) % R
        ]
        assert candidates == []
        receipts.append((R, a, N, tuple(local_q), tuple(sorted(stabilizer))))
    return tuple(receipts)


if __name__ == "__main__":
    count = check_cyclic_family()
    failed_shell, successful_shell = check_arithmetic_realization()
    adjacent_pair = check_adjacent_zero_defect_pair()
    print("PASS zero-defect cyclic family cases =", count)
    print("PASS arithmetic zero-defect shell =", failed_shell)
    print("PASS same-prime successful shell denominators =", successful_shell)
    print("PASS adjacent zero-defect shell pair =", adjacent_pair)

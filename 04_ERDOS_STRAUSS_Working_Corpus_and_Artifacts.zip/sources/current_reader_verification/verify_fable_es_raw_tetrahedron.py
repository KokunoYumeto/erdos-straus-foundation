#!/usr/bin/env python3
"""Exact transport of the Fable raw-cell tetrahedron to ES-aligned coordinates."""

import sympy as sp


half = sp.Rational(1, 2)
quarter = sp.Rational(1, 4)
sqrt3 = sp.sqrt(3)

# Columns are the coefficient vectors of E11,E12,E21,E22 after T_square.
T_square = sp.Matrix(
    [
        [1, 0, 2, 1],
        [half, 0, 0, -half],
        [0, 1, 0, 0],
        [quarter, 0, -half, quarter],
    ]
)

# (a,b0,b1,c) -> (T,X,Y,W).
Psi = sp.Matrix(
    [
        [half, 0, 0, half],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [half, 0, 0, -half],
    ]
)

# A(T,X,Y,W)=(T,W,X,Y).
A = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
    ]
)
Phi = A.inv() * Psi * T_square

v_star = sp.Matrix([0, 0, 1, 0])
v_0 = sp.Matrix([2, 2, 0, 2])
v_plus = sp.Matrix([2 + sqrt3, -1, 0, 2 - sqrt3])
v_minus = sp.Matrix([2 - sqrt3, -1, 0, 2 + sqrt3])
raw_vertices = (v_star, v_0, v_plus, v_minus)

transported = tuple(Phi * vector for vector in raw_vertices)
expected = (
    sp.Matrix([sp.Rational(3, 4), 0, sp.Rational(5, 4), 0]),
    sp.Matrix([sp.Rational(5, 2), 2, sp.Rational(3, 2), 0]),
    sp.Matrix([sp.Rational(5, 2), -1, sp.Rational(3, 2), sqrt3]),
    sp.Matrix([sp.Rational(5, 2), -1, sp.Rational(3, 2), -sqrt3]),
)
assert transported == expected


def lorentz_norm(vector: sp.Matrix) -> sp.Expr:
    t, x, y, w = vector
    return sp.expand(x**2 + y**2 + w**2 - t**2)


assert lorentz_norm(transported[0]) == 1
assert all(lorentz_norm(vector) == 0 for vector in transported[1:])

R_raw = sp.Matrix(
    [
        [quarter, sqrt3 / 2, 0, sp.Rational(3, 4)],
        [-sqrt3 / 4, -half, 0, sqrt3 / 4],
        [0, 0, 1, 0],
        [sp.Rational(3, 4), -sqrt3 / 2, 0, quarter],
    ]
)
J_raw = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
R_face = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, -half, 0, -sqrt3 / 2],
        [0, 0, 1, 0],
        [0, sqrt3 / 2, 0, -half],
    ]
)
s_w = sp.diag(1, 1, 1, -1)
assert Phi * R_raw == R_face * Phi
assert Phi * J_raw == s_w * Phi

spatial = tuple(sp.Matrix([vector[1], vector[2], vector[3]]) for vector in transported)
p_star, p_0, p_plus, p_minus = spatial
face_centroid = (p_0 + p_plus + p_minus) / 3
assert face_centroid == sp.Matrix([0, sp.Rational(3, 2), 0])
assert p_star == sp.Matrix([0, sp.Rational(5, 4), 0])
assert face_centroid - p_star == sp.Matrix([0, quarter, 0])

face_edge_sq = sp.expand((p_0 - p_plus).dot(p_0 - p_plus))
apex_edge_sq = sp.expand((p_star - p_0).dot(p_star - p_0))
assert face_edge_sq == 12
assert apex_edge_sq == sp.Rational(65, 16)
assert all(
    sp.expand((p_star - point).dot(p_star - point)) == apex_edge_sq
    for point in (p_0, p_plus, p_minus)
)

edge_matrix = sp.Matrix.hstack(p_0 - p_star, p_plus - p_star, p_minus - p_star)
volume = sp.Abs(edge_matrix.det()) / 6
assert volume == sqrt3 / 4

# Exact metric comparison on the tetrahedral affine tangent span.
raw_edge_matrix = sp.Matrix.hstack(
    v_0 - v_star,
    v_plus - v_star,
    v_minus - v_star,
)
lorentz_edge_matrix = sp.Matrix.hstack(
    transported[1] - transported[0],
    transported[2] - transported[0],
    transported[3] - transported[0],
)
eta_lorentz = sp.diag(-1, 1, 1, 1)

gram_raw = sp.simplify(raw_edge_matrix.T * raw_edge_matrix)
gram_lorentz = sp.simplify(
    lorentz_edge_matrix.T * eta_lorentz * lorentz_edge_matrix
)
gram_spatial = sp.simplify(edge_matrix.T * edge_matrix)

assert Phi == sp.Matrix(
    [
        [sp.Rational(5, 8), 0, sp.Rational(3, 4), sp.Rational(5, 8)],
        [0, 1, 0, 0],
        [sp.Rational(3, 8), 0, sp.Rational(5, 4), sp.Rational(3, 8)],
        [half, 0, 0, -half],
    ]
)
assert Phi.det() == -half
assert gram_raw == sp.Matrix([[13, 7, 7], [7, 16, 4], [7, 4, 16]])
assert gram_lorentz == sp.Matrix([[1, -5, -5], [-5, 1, -5], [-5, -5, 1]])
assert gram_spatial == sp.Rational(1, 16) * sp.Matrix(
    [[65, -31, -31], [-31, 65, -31], [-31, -31, 65]]
)

lam = sp.symbols("lambda")
lorentz_polynomial = sp.factor((gram_lorentz - lam * gram_raw).det())
lorentz_expected = -324 * (lam - 1) * (2 * lam - 1) * (3 * lam + 1)
assert sp.expand(lorentz_polynomial - lorentz_expected) == 0
spatial_polynomial = sp.factor((gram_spatial - lam * gram_raw).det())
spatial_expected = (
    -sp.Rational(27, 4)
    * (lam - 1)
    * (2 * lam - 1)
    * (144 * lam - 1)
)
assert sp.expand(spatial_polynomial - spatial_expected) == 0

u_x = sp.Matrix([-2, 1, 1])
u_w = sp.Matrix([0, -1, 1])
u_axis = sp.Matrix([1, 1, 1])
metric_data = (
    (u_x, sp.Integer(1), sp.Integer(1)),
    (u_w, half, half),
    (u_axis, -sp.Rational(1, 3), sp.Rational(1, 144)),
)
for direction, lorentz_value, spatial_value in metric_data:
    assert gram_lorentz * direction == lorentz_value * gram_raw * direction
    assert gram_spatial * direction == spatial_value * gram_raw * direction

assert raw_edge_matrix * u_x == sp.Matrix([0, -6, 0, 0])
assert edge_matrix * u_x == sp.Matrix([-6, 0, 0])
assert raw_edge_matrix * u_w == sp.Matrix([-2 * sqrt3, 0, 0, 2 * sqrt3])
assert edge_matrix * u_w == sp.Matrix([0, 0, -2 * sqrt3])
assert raw_edge_matrix * u_axis / 3 == sp.Matrix([2, 0, -1, 2])
assert edge_matrix * u_axis / 3 == sp.Matrix([0, quarter, 0])

raw_volume = sp.sqrt(sp.factor(gram_raw.det())) / 6
spatial_volume = sp.sqrt(sp.factor(gram_spatial.det())) / 6
spatial_volume_factor = sp.simplify(spatial_volume / raw_volume)
assert raw_volume == 3 * sp.sqrt(6)
assert spatial_volume == sqrt3 / 4
assert spatial_volume_factor == sp.sqrt(2) / 24

# Affine-invariant positive-polar geodesic length and volume Jacobian.
positive_polar_spectrum = (sp.Integer(1), 1 / sp.sqrt(2), sp.Rational(1, 12))
positive_polar_determinant = sp.prod(positive_polar_spectrum)
assert positive_polar_determinant == sp.sqrt(2) / 24

a, b = sp.symbols("a b", real=True)
assert sp.expand(2 * (a**2 + b**2) - (a + b) ** 2 - (a - b) ** 2) == 0
assert sp.simplify(sp.Rational(12, 1) / sp.sqrt(2) - 6 * sp.sqrt(2)) == 0
trace_log = a + b
anisotropy_sq = trace_log**2 / 6 + (a - b) ** 2 / 2
assert sp.expand(a**2 + b**2 - trace_log**2 / 3 - anisotropy_sq) == 0
assert len(set(positive_polar_spectrum)) == 3

# Marked D3 identification of the transported face with the 12289 count orbit.
B_count = sp.Matrix(
    [
        [4, -1, 0, -sqrt3],
        [4, 2, 0, 0],
        [4, -1, 0, sqrt3],
    ]
)
U_orb = sp.Matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
S_orb = sp.Matrix([[0, 0, 1], [0, 1, 0], [1, 0, 0]])
assert B_count * R_face == U_orb * B_count
assert B_count * s_w == S_orb * B_count

e_0 = sp.Matrix([1, 1, 0, 0])
e_plus = sp.Matrix([1, -half, 0, sqrt3 / 2])
e_minus = sp.Matrix([1, -half, 0, -sqrt3 / 2])
count_orbit = (
    sp.Matrix([3, 6, 3]),
    sp.Matrix([3, 3, 6]),
    sp.Matrix([6, 3, 3]),
)
assert tuple(B_count * e for e in (e_0, e_plus, e_minus)) == count_orbit
assert U_orb * count_orbit[0] == count_orbit[1]
assert S_orb * count_orbit[0] == count_orbit[0]

D_count = sp.Matrix([[-1, -sqrt3], [2, 0], [-1, sqrt3]])
assert D_count.T * D_count == 6 * sp.eye(2)
assert D_count.rank() == 2

X, W = sp.symbols("X W", real=True)
face_point = sp.Matrix([1, X, 0, W])
count_point = B_count * face_point
assert sp.expand(sum(count_point) - 12) == 0
X_back = sp.expand((count_point[1] - 4) / 2)
W_back = sp.simplify((count_point[2] - count_point[0]) / (2 * sqrt3))
assert X_back == X
assert W_back == W

omega = -half + sp.I * sqrt3 / 2
Z_count = sp.expand(
    count_point[0] + omega * count_point[1] + omega**2 * count_point[2]
)
assert sp.simplify(Z_count - 3 * omega * (X + sp.I * W)) == 0
centered_count_norm = sp.expand(
    (count_point - sp.Matrix([4, 4, 4])).dot(
        count_point - sp.Matrix([4, 4, 4])
    )
)
assert centered_count_norm == 6 * (X**2 + W**2)

origin_counts = (3, 6, 3)
assert origin_counts[0] == origin_counts[2]
assert len(set(origin_counts)) == 2

# Unique affine descent from the transported tetrahedron to the 12289 count plane.
count_center = sp.Matrix([4, 4, 4])
K_count = sp.Matrix(
    [
        [-half, 0, -sqrt3 / 2],
        [1, 0, 0],
        [-half, 0, sqrt3 / 2],
    ]
)


def Pi_count(point):
    return count_center + K_count * point


assert tuple(Pi_count(p) for p in (p_star, p_0, p_plus, p_minus)) == (
    count_center,
    *count_orbit,
)
assert K_count.T * K_count == sp.diag(sp.Rational(3, 2), 0, sp.Rational(3, 2))
assert K_count.rank() == 2
assert K_count.nullspace() == [sp.Matrix([0, 1, 0])]
assert Pi_count(face_centroid) == Pi_count(p_star) == count_center
assert face_centroid - p_star == sp.Matrix([0, quarter, 0])
assert edge_matrix.det() != 0

# Canonical signed face height and the minimal injective axial completion.
height_gradient = sp.Matrix([0, -1, 0])


def face_height(point):
    return sp.Rational(3, 2) - point[1]


assert tuple(face_height(p) for p in (p_0, p_plus, p_minus)) == (0, 0, 0)
assert face_height(p_star) == quarter
R_spatial = R_face[1:4, 1:4]
s_spatial = s_w[1:4, 1:4]
assert R_spatial * face_centroid == face_centroid
assert s_spatial * face_centroid == face_centroid
assert height_gradient.T * R_spatial == height_gradient.T
assert height_gradient.T * s_spatial == height_gradient.T

K_count_completed = K_count.col_join(height_gradient.T)
assert K_count_completed.T * K_count_completed == sp.diag(
    sp.Rational(3, 2), 1, sp.Rational(3, 2)
)
assert K_count_completed.rank() == 3
assert sp.sqrt((K_count_completed.T * K_count_completed).det()) == sp.Rational(
    3, 2
)

m_0, m_1, height = sp.symbols("m_0 m_1 height", real=True)
m_2 = 12 - m_0 - m_1
count_symbolic = sp.Matrix([m_0, m_1, m_2])
point_recovered = sp.Matrix(
    [
        m_1 - 4,
        sp.Rational(3, 2) - height,
        (m_2 - m_0) / sqrt3,
    ]
)
assert sp.simplify(Pi_count(point_recovered) - count_symbolic) == sp.zeros(3, 1)
assert face_height(point_recovered) == height

ell_x, ell_y, ell_w = sp.symbols("ell_x ell_y ell_w", real=True)
ell_gradient = sp.Matrix([[ell_x, ell_y, ell_w]])
K_with_scalar = K_count.col_join(ell_gradient)
assert sp.factor((K_with_scalar.T * K_with_scalar).det()) == (
    sp.Rational(9, 4) * ell_y**2
)

# Exact central-fibre parametrization and its positive-cone split-zero lift.
t_axis = sp.symbols("t_axis", real=True)
q_axis = face_centroid + t_axis * (p_star - face_centroid)
assert q_axis == sp.Matrix([0, sp.Rational(3, 2) - t_axis / 4, 0])
assert Pi_count(q_axis) == count_center
assert face_height(q_axis) == t_axis / 4

tau_pair = sp.Matrix([0, 0])
face_height_pair = tau_pair
t_positive = sp.symbols("t_positive", positive=True)
positive_height_pair = sp.Matrix([t_positive / 4, 1])
assert face_height_pair == sp.Matrix([0, 0])
assert positive_height_pair[0] == t_positive / 4
assert positive_height_pair[1] == 1
assert sp.Matrix([quarter, 1]) == positive_height_pair.subs(t_positive, 1)

print("PASS raw-cell transport gives the exact ES-aligned tetrahedron")
print("PASS transported apex is spacelike and the three face vertices are null")
print("PASS the full raw-cell D3 action intertwines with the ES face matrices")
print("PASS face centroid and apex differ by the exact spatial quarter")
print("PASS face and apex edge lengths are 2 sqrt(3) and sqrt(65)/4")
print("PASS spatial tetrahedron volume is sqrt(3)/4")
print("PASS affine Lorentz signature has exact generalized values 1, 1/2, -1/3")
print("PASS spatial tangent factors are 1, 1/sqrt(2), and 1/12")
print("PASS the quarter is the unique axial image of a raw length-three displacement")
print("PASS spatial-to-raw affine volume factor is sqrt(2)/24")
print("PASS affine-invariant geodesic length and volume obey the exact log identity")
print("PASS trace and traceless anisotropy give the exact orthogonal length split")
print("PASS the sharp logarithmic volume bound is strict on the spatial carrier")
print("PASS the marked Fable face is affinely D3-isomorphic to the 12289 count orbit")
print("PASS the count-plane map has exact squared similarity factor 6")
print("PASS the C3 character coordinate is exactly 3 omega times X+iW")
print("PASS unequal arithmetic fibre sizes obstruct a cyclic certificate-set lift")
print("PASS the unique tetrahedral count descent maps apex to orbit barycenter")
print("PASS the exact quarter spans the count-descent kernel")
print("PASS the induced quotient has squared similarity factor 3/2")
print("PASS the marked face selects the unique unit axial height with apex value 1/4")
print("PASS axial completion is bijective with metric diag(3/2,1,3/2)")
print("PASS one scalar restores injectivity exactly when it detects the Y-axis")
print("PASS the central count fibre is the exact quarter-height segment")
print("PASS its cone lift sends the face endpoint to tau and positive height to support")

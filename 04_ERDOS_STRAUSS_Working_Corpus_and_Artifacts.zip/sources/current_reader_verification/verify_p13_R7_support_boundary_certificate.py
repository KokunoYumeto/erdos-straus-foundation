from fractions import Fraction


def add(left, right):
    return left[0] + right[0], left[1] + right[1]


def multiply(left, right):
    a, b = left
    c, d = right
    return a * c - b * d, a * d + b * c + b * d


def power(value, exponent):
    result = (1, 0)
    for _ in range(exponent % 6):
        result = multiply(result, value)
    return result


zeta = (0, 1)
zero = (0, 0)
one = (1, 0)

assert power(zeta, 2) == (-1, 1)
assert power(zeta, 3) == (-1, 0)
assert power(zeta, 6) == one

p = 13
residual = 7
a = 5
generator = 3
group = tuple(pow(generator, exponent, residual) for exponent in range(6))
assert group == (1, 3, 2, 6, 4, 5)

inverse_a = pow(a, -1, residual)
divisors = (1, 5, 25)
centered_support = tuple(
    sorted(divisor * inverse_a % residual for divisor in divisors)
)
assert centered_support == (1, 3, 5)

measure = (1, 1, 0, 0, 0, 1)
assert tuple(group[index] for index, value in enumerate(measure) if value) == (
    1,
    3,
    5,
)

fourier = []
for character_index in range(6):
    value = zero
    for exponent, multiplicity in enumerate(measure):
        value = add(
            value,
            (
                multiplicity
                * power(zeta, -character_index * exponent)[0],
                multiplicity
                * power(zeta, -character_index * exponent)[1],
            ),
        )
    fourier.append(value)

assert tuple(fourier) == (
    (3, 0),
    (2, 0),
    (0, 0),
    (-1, 0),
    (0, 0),
    (2, 0),
)

absolute_fourier = (3, 2, 0, 1, 0, 2)
principal_mass = absolute_fourier[0]
unweighted_mass = sum(absolute_fourier[1:])
assert principal_mass == 3
assert unweighted_mass == 5

target_exponents = (0, 3)
target_filter = tuple(
    Fraction(abs(1 + (-1) ** character_index), 2)
    for character_index in range(6)
)
assert target_filter == (1, 0, 1, 0, 1, 0)
filtered_mass = sum(
    absolute_fourier[index] * target_filter[index]
    for index in range(1, 6)
)
assert filtered_mass == 0

displacement_orbits = ((0, 3), (1, 4), (2, 5))
support_exponents = {0, 1, 5}
boundary_energy = sum(
    Fraction(
        sum(index in support_exponents for index in orbit)
        * (
            2
            - sum(index in support_exponents for index in orbit)
        ),
        2,
    )
    for orbit in displacement_orbits
)
assert boundary_energy == Fraction(3, 2)

boundary_rotated_lower_square = 6 * boundary_energy
assert boundary_rotated_lower_square == 9
boundary_rotated_lower = 3
boundary_upper = unweighted_mass - boundary_rotated_lower
assert boundary_upper == 2
assert boundary_upper < principal_mass

print("PASS: exact (p,R,a)=(13,7,5) support-boundary certificate")
print(f"group in generator order: {group}")
print(f"centered measure: {measure}")
print(f"Fourier transform in Q[zeta_6]/(Phi_6): {tuple(fourier)}")
print(f"target exponents: {target_exponents}")
print(f"target filter: {target_filter}")
print(
    f"M={principal_mass}, S={unweighted_mass}, "
    f"S_A={filtered_mass}"
)
print(f"displacement orbits: {displacement_orbits}")
print(f"support-boundary energy: {boundary_energy}")
print(
    "support-boundary upper bound: "
    f"S-sqrt(|Q|*B)={boundary_upper}<{principal_mass}=M"
)

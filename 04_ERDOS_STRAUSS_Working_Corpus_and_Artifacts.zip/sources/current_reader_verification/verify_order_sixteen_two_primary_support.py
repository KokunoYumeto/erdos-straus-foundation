#!/usr/bin/env python3
"""Exact finite support-monoid audit for the abelian groups of order sixteen."""

from __future__ import annotations

import argparse
import itertools
import math
from collections import Counter, deque
from dataclasses import dataclass
from functools import reduce
from typing import Iterable


@dataclass(frozen=True)
class FiniteAbelianGroup:
    name: str
    moduli: tuple[int, ...]

    def __post_init__(self) -> None:
        elements = tuple(itertools.product(*(range(m) for m in self.moduli)))
        object.__setattr__(self, "elements", elements)
        object.__setattr__(self, "index", {x: i for i, x in enumerate(elements)})
        zero = (0,) * len(self.moduli)
        object.__setattr__(self, "zero", zero)
        object.__setattr__(self, "zero_index", self.index[zero])
        add_table = tuple(
            tuple(
                self.index[tuple((xj + yj) % m for xj, yj, m in zip(x, y, self.moduli))]
                for y in elements
            )
            for x in elements
        )
        object.__setattr__(self, "add_table", add_table)

    @property
    def size(self) -> int:
        return len(self.elements)

    def add(self, x: tuple[int, ...], y: tuple[int, ...]) -> tuple[int, ...]:
        return tuple((a + b) % m for a, b, m in zip(x, y, self.moduli))

    def scalar(self, n: int, x: tuple[int, ...]) -> tuple[int, ...]:
        return tuple((n * a) % m for a, m in zip(x, self.moduli))

    def order(self, x: tuple[int, ...]) -> int:
        factors = [m // math.gcd(m, a) for a, m in zip(x, self.moduli)]
        return math.lcm(*factors)

    def mask(self, points: Iterable[tuple[int, ...]]) -> int:
        answer = 0
        for point in points:
            answer |= 1 << self.index[point]
        return answer

    def points(self, mask: int) -> tuple[tuple[int, ...], ...]:
        return tuple(
            x for i, x in enumerate(self.elements)
            if mask & (1 << i)
        )

    def sumset(self, left: int, right: int) -> int:
        left_indices = [i for i in range(self.size) if left & (1 << i)]
        right_indices = [i for i in range(self.size) if right & (1 << i)]
        answer = 0
        for i in left_indices:
            row = self.add_table[i]
            for j in right_indices:
                answer |= 1 << row[j]
        return answer

    def translate(self, mask: int, shift: tuple[int, ...]) -> int:
        j = self.index[shift]
        answer = 0
        for i in range(self.size):
            if mask & (1 << i):
                answer |= 1 << self.add_table[i][j]
        return answer

    def generated_subgroup(self, points: Iterable[tuple[int, ...]]) -> int:
        generators = tuple(points)
        seen = {self.zero}
        queue = deque([self.zero])
        while queue:
            x = queue.popleft()
            for g in generators:
                y = self.add(x, g)
                if y not in seen:
                    seen.add(y)
                    queue.append(y)
        return self.mask(seen)

    def standard_generators(self) -> tuple[tuple[int, ...], ...]:
        answer = []
        for i in range(len(self.moduli)):
            x = [0] * len(self.moduli)
            x[i] = 1
            answer.append(tuple(x))
        return tuple(answer)


GROUPS = {
    "C16": FiniteAbelianGroup("C16", (16,)),
    "C8xC2": FiniteAbelianGroup("C8xC2", (8, 2)),
    "C4xC4": FiniteAbelianGroup("C4xC4", (4, 4)),
    "C4xC2xC2": FiniteAbelianGroup("C4xC2xC2", (4, 2, 2)),
    "C2xC2xC2xC2": FiniteAbelianGroup("C2xC2xC2xC2", (2, 2, 2, 2)),
}


EXPECTED = {
    "C16": {
        "local": 35,
        "reachable": 63,
        "generating_nonfull": 51,
        "automorphisms": 8,
        "orbits": 17,
        "minimum": 3,
        "minimum_orbits": 1,
        "sizes": {3: 4, 5: 4, 6: 2, 7: 4, 8: 2, 9: 12, 10: 2,
                  11: 4, 12: 5, 13: 6, 14: 5, 15: 1},
    },
    "C8xC2": {
        "local": 19,
        "reachable": 64,
        "generating_nonfull": 36,
        "automorphisms": 16,
        "orbits": 12,
        "minimum": 6,
        "minimum_orbits": 1,
        "sizes": {6: 4, 8: 4, 9: 4, 10: 4, 12: 10, 13: 4, 14: 3, 15: 3},
    },
    "C4xC4": {
        "local": 15,
        "reachable": 54,
        "generating_nonfull": 24,
        "automorphisms": 96,
        "orbits": 4,
        "minimum": 9,
        "minimum_orbits": 1,
        "sizes": {9: 12, 12: 6, 14: 3, 15: 3},
    },
    "C4xC2xC2": {
        "local": 15,
        "reachable": 60,
        "generating_nonfull": 11,
        "automorphisms": 192,
        "orbits": 3,
        "minimum": 12,
        "minimum_orbits": 1,
        "sizes": {12: 4, 14: 6, 15: 1},
    },
    "C2xC2xC2xC2": {
        "local": 15,
        "reachable": 67,
        "generating_nonfull": 0,
        "automorphisms": 20160,
        "orbits": 0,
        "minimum": 16,
        "minimum_orbits": 1,
        "sizes": {},
    },
}


def interval_supports(
    group: FiniteAbelianGroup,
) -> tuple[tuple[int, ...], dict[int, tuple[tuple[int, ...], int]]]:
    records: dict[int, tuple[tuple[int, ...], int]] = {}
    for u in group.elements:
        if u == group.zero:
            continue
        for radius in range(1, group.order(u) + 1):
            mask = group.mask(group.scalar(beta, u) for beta in range(-radius, radius + 1))
            witness = (u, radius)
            if mask not in records or witness < records[mask]:
                records[mask] = witness
    return tuple(sorted(records)), records


def interval_mask(
    group: FiniteAbelianGroup,
    radius: int,
    direction: tuple[int, ...],
) -> int:
    return group.mask(
        group.scalar(beta, direction)
        for beta in range(-radius, radius + 1)
    )


def sum_masks(group: FiniteAbelianGroup, *masks: int) -> int:
    identity = 1 << group.zero_index
    return reduce(group.sumset, masks, identity)


def structural_templates(group: FiniteAbelianGroup) -> dict[str, int]:
    I = lambda radius, direction: interval_mask(group, radius, direction)

    if group.name == "C16":
        q = (1,)
        h = (8,)
        return {
            "I1(q)": I(1, q),
            "I2(q)": I(2, q),
            "I1(q)+H2": sum_masks(group, I(1, q), I(1, h)),
            "I3(q)": I(3, q),
            "I1(q)+I1(7q)": sum_masks(group, I(1, q), I(1, (7,))),
            "I4(q)": I(4, q),
            "I1(q)+I1(4q)": sum_masks(group, I(1, q), I(1, (4,))),
            "I1(q)+I1(6q)": sum_masks(group, I(1, q), I(1, (6,))),
            "I2(q)+H2": sum_masks(group, I(2, q), I(1, h)),
            "I5(q)": I(5, q),
            "I2(q)+I1(7q)": sum_masks(group, I(2, q), I(1, (7,))),
            "I1(q)+I2(4q)": sum_masks(group, I(1, q), I(2, (4,))),
            "I6(q)": I(6, q),
            "I1(q)+I2(6q)": sum_masks(group, I(1, q), I(2, (6,))),
            "I2(q)+I1(6q)": sum_masks(group, I(2, q), I(1, (6,))),
            "I3(q)+H2": sum_masks(group, I(3, q), I(1, h)),
            "I7(q)": I(7, q),
        }

    if group.name == "C8xC2":
        q = (1, 0)
        r = (0, 1)
        q_plus_r = group.add(q, r)
        two_q_plus_r = group.add(group.scalar(2, q), r)
        four_q = group.scalar(4, q)
        return {
            "I1(q)+H(r)": sum_masks(group, I(1, q), I(1, r)),
            "I1(q)+I1(q+r)": sum_masks(group, I(1, q), I(1, q_plus_r)),
            "I1(q)+I1(2q+r)": sum_masks(group, I(1, q), I(1, two_q_plus_r)),
            "I2(q)+H(r)": sum_masks(group, I(2, q), I(1, r)),
            "I1(q)+I2(q+r)": sum_masks(group, I(1, q), I(2, q_plus_r)),
            "I1(q)+H(4q)+H(r)": sum_masks(
                group, I(1, q), I(1, four_q), I(1, r)
            ),
            "I1(q)+I2(2q+r)": sum_masks(
                group, I(1, q), I(2, two_q_plus_r)
            ),
            "I2(q)+I1(2q+r)": sum_masks(
                group, I(2, q), I(1, two_q_plus_r)
            ),
            "I1(q)+I1(q+r)+H(4q)": sum_masks(
                group, I(1, q), I(1, q_plus_r), I(1, four_q)
            ),
            "I3(q)+H(r)": sum_masks(group, I(3, q), I(1, r)),
            "I2(q)+I2(q+r)": sum_masks(group, I(2, q), I(2, q_plus_r)),
            "I1(q)+I3(q+r)": sum_masks(group, I(1, q), I(3, q_plus_r)),
        }

    if group.name == "C4xC4":
        q = (1, 0)
        r = (0, 1)
        two_q_two_r = group.add(group.scalar(2, q), group.scalar(2, r))
        two_q_plus_r = group.add(group.scalar(2, q), r)
        return {
            "I1(q)+I1(r)": sum_masks(group, I(1, q), I(1, r)),
            "I2(q)+I1(r)": sum_masks(group, I(2, q), I(1, r)),
            "I1(q)+I1(r)+H(2q+2r)": sum_masks(
                group, I(1, q), I(1, r), I(1, two_q_two_r)
            ),
            "I1(q)+I1(r)+I1(2q+r)": sum_masks(
                group, I(1, q), I(1, r), I(1, two_q_plus_r)
            ),
        }

    if group.name == "C4xC2xC2":
        q = (1, 0, 0)
        r = (0, 1, 0)
        s = (0, 0, 1)
        q_plus_r = group.add(q, r)
        q_plus_s = group.add(q, s)
        return {
            "I1(q)+H(r)+H(s)": sum_masks(
                group, I(1, q), I(1, r), I(1, s)
            ),
            "I1(q)+I1(q+s)+H(r)": sum_masks(
                group, I(1, q), I(1, q_plus_s), I(1, r)
            ),
            "I1(q)+I1(q+r)+I1(q+s)": sum_masks(
                group, I(1, q), I(1, q_plus_r), I(1, q_plus_s)
            ),
        }

    if group.name == "C2xC2xC2xC2":
        return {}

    raise AssertionError(f"no template family for {group.name}")


def support_monoid(
    group: FiniteAbelianGroup,
    local_masks: tuple[int, ...],
) -> dict[int, tuple[int, ...]]:
    identity = 1 << group.zero_index
    witness: dict[int, tuple[int, ...]] = {identity: ()}
    queue = deque([identity])
    while queue:
        current = queue.popleft()
        for local in local_masks:
            target = group.sumset(current, local)
            if target not in witness:
                witness[target] = witness[current] + (local,)
                queue.append(target)
    return witness


def homomorphism_map(
    group: FiniteAbelianGroup,
    images: tuple[tuple[int, ...], ...],
) -> tuple[int, ...]:
    answer = []
    for x in group.elements:
        y = group.zero
        for coefficient, image in zip(x, images):
            y = group.add(y, group.scalar(coefficient, image))
        answer.append(group.index[y])
    return tuple(answer)


def automorphisms(group: FiniteAbelianGroup) -> tuple[tuple[int, ...], ...]:
    candidate_images = []
    for modulus in group.moduli:
        candidate_images.append(
            tuple(x for x in group.elements if group.scalar(modulus, x) == group.zero)
        )
    answer = []
    for images in itertools.product(*candidate_images):
        point_map = homomorphism_map(group, images)
        if len(set(point_map)) == group.size:
            answer.append(point_map)
    return tuple(answer)


def transform_mask(mask: int, point_map: tuple[int, ...]) -> int:
    answer = 0
    for i, j in enumerate(point_map):
        if mask & (1 << i):
            answer |= 1 << j
    return answer


def automorphism_orbits(
    supports: set[int],
    auts: tuple[tuple[int, ...], ...],
) -> tuple[tuple[int, tuple[int, ...]], ...]:
    unseen = set(supports)
    answer = []
    while unseen:
        seed = min(unseen)
        orbit = tuple(sorted({transform_mask(seed, aut) for aut in auts}))
        if not set(orbit) <= supports:
            raise AssertionError("automorphism left the generating support set")
        representative = min(orbit)
        answer.append((representative, orbit))
        unseen.difference_update(orbit)
    return tuple(sorted(answer, key=lambda item: (item[0].bit_count(), item[0])))


def translation_stabilizer(group: FiniteAbelianGroup, support: int) -> tuple[tuple[int, ...], ...]:
    return tuple(x for x in group.elements if group.translate(support, x) == support)


def point_text(x: tuple[int, ...]) -> str:
    if len(x) == 1:
        return str(x[0])
    return "(" + ",".join(str(a) for a in x) + ")"


def set_text(points: Iterable[tuple[int, ...]]) -> str:
    return "{" + ",".join(point_text(x) for x in points) + "}"


def audit_group(group: FiniteAbelianGroup, detail: bool) -> dict[str, object]:
    local_masks, local_records = interval_supports(group)
    reachable = support_monoid(group, local_masks)
    full = (1 << group.size) - 1
    generating = {
        support for support in reachable
        if group.generated_subgroup(group.points(support)) == full
    }
    generating_nonfull = {
        support for support in generating
        if support != full
    }
    auts = automorphisms(group)
    orbits = automorphism_orbits(generating_nonfull, auts)
    size_distribution = dict(sorted(Counter(s.bit_count() for s in generating_nonfull).items()))
    templates = structural_templates(group)
    template_representatives = {
        label: min(transform_mask(mask, aut) for aut in auts)
        for label, mask in templates.items()
    }

    expected = EXPECTED[group.name]
    assert len(local_masks) == expected["local"]
    assert len(reachable) == expected["reachable"]
    assert len(generating_nonfull) == expected["generating_nonfull"]
    assert len(auts) == expected["automorphisms"]
    assert len(orbits) == expected["orbits"]
    assert size_distribution == expected["sizes"]
    assert len(set(template_representatives.values())) == expected["orbits"]
    assert set(template_representatives.values()) == {
        representative for representative, _ in orbits
    }
    minimum = min(s.bit_count() for s in generating)
    minimum_supports = {s for s in generating if s.bit_count() == minimum}
    minimum_orbits = automorphism_orbits(minimum_supports, auts)
    assert minimum == expected["minimum"]
    assert len(minimum_orbits) == expected["minimum_orbits"]

    print(f"{group.name}: local={len(local_masks)}, reachable={len(reachable)}, "
          f"generating_nonfull={len(generating_nonfull)}, "
          f"automorphisms={len(auts)}, orbits={len(orbits)}")
    print(f"{group.name}: size_distribution={size_distribution}")
    print(
        f"{group.name}: minimum_generating_support={minimum}, "
        f"minimum_orbits={len(minimum_orbits)}"
    )
    if templates:
        print(
            f"{group.name}: structural_templates="
            + ", ".join(
                f"{label}[{mask.bit_count()}]"
                for label, mask in templates.items()
            )
        )

    if detail:
        for number, (support, orbit) in enumerate(orbits, 1):
            complement = full ^ support
            complement_points = group.points(complement)
            stabilizer = translation_stabilizer(group, support)
            order_distribution = dict(sorted(Counter(group.order(x) for x in complement_points).items()))
            factor_data = []
            for local in reachable[support]:
                u, radius = local_records[local]
                factor_data.append(
                    f"I_{radius}({point_text(u)}):{set_text(group.points(local))}"
                )
            print(
                f"{group.name}.orbit{number}: support_size={support.bit_count()}, "
                f"orbit_size={len(orbit)}, complement={set_text(complement_points)}, "
                f"complement_orders={order_distribution}, "
                f"translation_stabilizer={set_text(stabilizer)}, "
                f"minimal_factors=[{'; '.join(factor_data)}]"
            )

    return {
        "local_masks": local_masks,
        "reachable": reachable,
        "generating_nonfull": generating_nonfull,
        "generating": generating,
        "automorphisms": auts,
        "orbits": orbits,
        "size_distribution": size_distribution,
        "templates": templates,
        "template_representatives": template_representatives,
        "minimum": minimum,
        "minimum_orbits": minimum_orbits,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--group",
        choices=("all", *GROUPS.keys()),
        default="all",
    )
    parser.add_argument("--detail", action="store_true")
    args = parser.parse_args()

    selected = GROUPS.values() if args.group == "all" else (GROUPS[args.group],)
    total_orbits = 0
    for group in selected:
        result = audit_group(group, args.detail)
        if group.name != "C2xC2xC2xC2":
            total_orbits += len(result["orbits"])
    if args.group == "all":
        assert total_orbits == 36
        print("PASS: complete order-sixteen two-primary support monoids")
        print("non_elementary_automorphism_types=36")


if __name__ == "__main__":
    main()

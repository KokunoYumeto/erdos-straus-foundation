from fractions import Fraction
from functools import lru_cache
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


def is_squarefree(value):
    for prime in range(2, isqrt(value) + 1):
        if value % (prime * prime) == 0:
            return False
    return True


def prime_factors(value):
    factors = []
    remaining = value
    prime = 2
    while prime * prime <= remaining:
        if remaining % prime == 0:
            factors.append(prime)
            while remaining % prime == 0:
                remaining //= prime
        prime += 1
    if remaining > 1:
        factors.append(remaining)
    return tuple(factors)


def factor_exponents(value):
    factors = {}
    remaining = value
    prime = 2
    while prime * prime <= remaining:
        exponent = 0
        while remaining % prime == 0:
            exponent += 1
            remaining //= prime
        if exponent:
            factors[prime] = exponent
        prime += 1
    if remaining > 1:
        factors[remaining] = 1
    return factors


tested_shells = 0
occupied_shells = 0
tested_identities = 0

for p in primes_up_to(20000):
    if p % 12 != 1:
        continue

    a = (p + 3) // 4
    if a % 3 != 1 or 4 * a - p != 3:
        raise AssertionError(f"R=3 shell data fail at p={p}")
    tested_shells += 1

    coordinates = {
        (s, t, a // (s * t))
        for s in divisors(a)
        if is_squarefree(s)
        for t in divisors(a // s)
    }
    packets = {
        (s, min(t, m), max(t, m))
        for s, t, m in coordinates
        if s % 3 == 2
    }
    exterior = {
        (s, t, m)
        for s, t, m in coordinates
        if (4 * s * t * t + 1) % 3 == 0
    }
    middle = {
        (s, min(t, m), max(t, m))
        for s, t, m in coordinates
        if (t + m) % 3 == 0
    }

    expected_exterior = {
        (s, t, m)
        for s, t, m in coordinates
        if (s, min(t, m), max(t, m)) in packets
    }
    if exterior != expected_exterior:
        raise AssertionError(f"exterior packet criterion fails at p={p}")
    if middle != packets:
        raise AssertionError(f"middle packet criterion fails at p={p}")
    if len(exterior) != 2 * len(packets):
        raise AssertionError(f"two exterior orientations fail at p={p}")

    q = len(exterior) + len(middle)
    if q != 3 * len(packets):
        raise AssertionError(f"three-orbit balance fails at p={p}")

    exponents = factor_exponents(a)
    tau_a_squared = 1
    tau_one_mod_three_squared = 1
    for prime, exponent in exponents.items():
        tau_a_squared *= 2 * exponent + 1
        if prime % 3 == 1:
            tau_one_mod_three_squared *= 2 * exponent + 1
    difference = tau_a_squared - tau_one_mod_three_squared
    if difference % 4 or len(packets) != difference // 4:
        raise AssertionError(f"multiplicative packet formula fails at p={p}, a={a}")
    if q * 4 != 3 * difference:
        raise AssertionError(f"multiplicative shell-rank formula fails at p={p}, a={a}")

    has_two_mod_three_factor = any(q_factor % 3 == 2 for q_factor in prime_factors(a))
    if (q > 0) != has_two_mod_three_factor:
        raise AssertionError(f"factor criterion fails at p={p}, a={a}")

    if q:
        occupied_shells += 1

    for q_factor in prime_factors(a):
        if q_factor % 3 != 2:
            continue
        m = a // q_factor

        b_middle = p * q_factor * (m + 1) // 3
        c_middle = p * a * (m + 1) // 3
        if Fraction(4, p) != (
            Fraction(1, a) + Fraction(1, b_middle) + Fraction(1, c_middle)
        ):
            raise AssertionError(
                f"middle factor identity fails at p={p}, q={q_factor}"
            )

        b_exterior = p * q_factor * (m + p) // 3
        c_exterior = a * (p + m) // 3
        if Fraction(4, p) != (
            Fraction(1, a) + Fraction(1, b_exterior) + Fraction(1, c_exterior)
        ):
            raise AssertionError(
                f"exterior factor identity fails at p={p}, q={q_factor}"
            )
        tested_identities += 2


if not tested_shells or not occupied_shells or not tested_identities:
    raise AssertionError("the tested R=3 family was empty")

print("PASS: R=3 three-orbit balance")
print("for p=1 mod 12, a=(p+3)/4 is 1 mod 3")
print("a squarefree coordinate packet is occupied exactly when s=2 mod 3")
print("each occupied packet contains two exterior orientations and one middle orbit")
print("q_3,p equals three times the packet count")
print("the packet count is (tau(a^2)-tau(a_+^2))/4")
print("the shell is occupied exactly when a has a prime factor equal to 2 mod 3")
print("both factor-based unit-fraction identities were checked through p=20000")

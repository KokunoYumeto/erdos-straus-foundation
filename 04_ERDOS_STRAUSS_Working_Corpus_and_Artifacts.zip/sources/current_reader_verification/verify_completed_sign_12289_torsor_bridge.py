"""Exact finite check of the completed-history/12289 channel crosswalk."""

from itertools import product

from verify_completed_sign_sedenion_64 import basis, completed_product


SIGNS = ("-", "+")


def flip(sign):
    return "+" if sign == "-" else "-"


def history_product(history):
    (epsilon, delta), (lam, eta), blade = history
    mul = {("-", "-"): "+", ("-", "+"): "-", ("+", "-"): "-", ("+", "+"): "+"}
    return (mul[(epsilon, lam)], mul[(delta, eta)], blade)


def transpose_history(history):
    (epsilon, delta), (lam, eta), blade = history
    return ((lam, delta), (epsilon, eta), blade)


def reverse_history(history):
    first, second, blade = history
    return (second, first, blade)


def arithmetic_flip(channel):
    sigma, upsilon = channel
    return (flip(sigma), upsilon)


def coordinate_flip(channel):
    sigma, upsilon = channel
    return (sigma, flip(upsilon))


def full_transpose(channel):
    sigma, upsilon = channel
    return (flip(sigma), flip(upsilon))


h21 = (("-", "+"), ("+", "-"), "34")
histories = {
    h21,
    transpose_history(h21),
    reverse_history(h21),
    reverse_history(transpose_history(h21)),
}
channels = set(product(SIGNS, repeat=2))

phi = {
    h21: ("-", "-"),
    transpose_history(h21): ("-", "+"),
    reverse_history(h21): ("+", "-"),
    reverse_history(transpose_history(h21)): ("+", "+"),
}

assert len(histories) == 4
assert all(history_product(h) == ("-", "-", "34") for h in histories)
assert set(phi) == histories
assert set(phi.values()) == channels

for h in histories:
    assert phi[transpose_history(h)] == coordinate_flip(phi[h])
    assert phi[reverse_history(h)] == arithmetic_flip(phi[h])
    assert transpose_history(reverse_history(h)) == reverse_history(
        transpose_history(h)
    )

for channel in channels:
    assert arithmetic_flip(arithmetic_flip(channel)) == channel
    assert coordinate_flip(coordinate_flip(channel)) == channel
    assert arithmetic_flip(coordinate_flip(channel)) == coordinate_flip(
        arithmetic_flip(channel)
    )
    assert full_transpose(channel) == arithmetic_flip(coordinate_flip(channel))

directed_history_orbit = {h21, reverse_history(h21)}
transposed_history_orbit = {
    transpose_history(h21),
    reverse_history(transpose_history(h21)),
}
assert {phi[h] for h in directed_history_orbit} == {("-", "-"), ("+", "-")}
assert {phi[h] for h in transposed_history_orbit} == {("-", "+"), ("+", "+")}

source_range = {
    ("-", "-"): (("<", "22"), (">", "33")),
    ("-", "+"): (("<", "33"), (">", "22")),
    ("+", "-"): ((">", "22"), ("<", "33")),
    ("+", "+"): ((">", "33"), ("<", "22")),
}

for channel in channels:
    source, target = source_range[channel]
    t_source, t_target = source_range[full_transpose(channel)]
    assert t_source == target
    assert t_target == source


def add_vector(x, y):
    return ((x[0] + y[0]) % 2, (x[1] + y[1]) % 2)


def apply_matrix(matrix, x):
    return (
        (matrix[0][0] * x[0] + matrix[0][1] * x[1]) % 2,
        (matrix[1][0] * x[0] + matrix[1][1] * x[1]) % 2,
    )


points = set(product((0, 1), repeat=2))
L = ((0, 1), (1, 1))
R = ((0, 1), (1, 0))
c = (1, 0)


def affine_phi(x):
    return add_vector(apply_matrix(L, x), c)


history_bits = {
    h21: (1, 0),
    transpose_history(h21): (0, 0),
    reverse_history(h21): (0, 1),
    reverse_history(transpose_history(h21)): (1, 1),
}
channel_bits = {
    channel: (int(channel[0] == "-"), int(channel[1] == "-"))
    for channel in channels
}

for h in histories:
    assert affine_phi(history_bits[h]) == channel_bits[phi[h]]

assert apply_matrix(L, (1, 0)) == (0, 1)
assert apply_matrix(L, (1, 1)) == (1, 0)
for x in points:
    assert affine_phi(affine_phi(affine_phi(x))) == x
assert {x for x in points if affine_phi(x) == x} == {(0, 1)}


def permutation_of(function):
    ordered = ((0, 0), (0, 1), (1, 0), (1, 1))
    return tuple(ordered.index(function(x)) for x in ordered)


def compose(p, q):
    return tuple(p[q[i]] for i in range(4))


translation_permutations = {
    permutation_of(lambda x, v=v: add_vector(x, v)) for v in points
}
phi_permutation = permutation_of(affine_phi)

tetrahedral_group = set(translation_permutations)
changed = True
while changed:
    changed = False
    for p in list(tetrahedral_group):
        for q in list(tetrahedral_group) + [phi_permutation]:
            for candidate in (compose(p, q), compose(q, p)):
                if candidate not in tetrahedral_group:
                    tetrahedral_group.add(candidate)
                    changed = True
assert len(tetrahedral_group) == 12


def inversion_parity(p):
    return sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4)) % 2


assert all(inversion_parity(p) == 0 for p in tetrahedral_group)

R_permutation = permutation_of(lambda x: apply_matrix(R, x))
L_permutation = permutation_of(lambda x: apply_matrix(L, x))
assert compose(R_permutation, compose(L_permutation, R_permutation)) == compose(
    L_permutation, L_permutation
)

full_affine_group = set(tetrahedral_group)
changed = True
while changed:
    changed = False
    for p in list(full_affine_group):
        for q in list(full_affine_group) + [R_permutation]:
            for candidate in (compose(p, q), compose(q, p)):
                if candidate not in full_affine_group:
                    full_affine_group.add(candidate)
                    changed = True
assert len(full_affine_group) == 24


def transform_sign(sign, matrix):
    x = (sign & 1, (sign >> 1) & 1)
    y = apply_matrix(matrix, x)
    return y[0] | (y[1] << 1)


def transform_completed(value, matrix):
    return {
        (transform_sign(sign, matrix), blade): coefficient
        for (sign, blade), coefficient in value.items()
    }


for matrix in (L, R):
    for left_sign, right_sign, left_blade, right_blade in product(
        range(4), range(4), range(16), range(16)
    ):
        left = basis(left_sign, left_blade)
        right = basis(right_sign, right_blade)
        transformed_product = transform_completed(
            completed_product(left, right), matrix
        )
        product_of_transforms = completed_product(
            basis(transform_sign(left_sign, matrix), left_blade),
            basis(transform_sign(right_sign, matrix), right_blade),
        )
        assert transformed_product == product_of_transforms

blade_blocks = [
    {(sign, blade) for sign in range(4)}
    for blade in range(16)
]
assert len(blade_blocks) == 16
assert len(set().union(*blade_blocks)) == 64
for block in blade_blocks:
    for matrix in (L, R):
        assert {
            (transform_sign(sign, matrix), blade) for sign, blade in block
        } == block

print("PASS: completed-history/12289 four-channel torsor bridge")
print("history fibre size = 4 and channel carrier size = 4")
print("upper-sign transposition maps exactly to the coordinate B flip")
print("factor-order reversal maps exactly to the arithmetic A flip")
print("the two flips commute and act freely and transitively")
print("their composite agrees with full transpose on all four channels")
print("the h21 factor-order orbit is exactly the two-channel V21 carrier")
print("the h12 factor-order orbit is exactly the two-channel V12 carrier")
print("all four source/range pairs reverse exactly under full transpose")
print("the bit crosswalk is affine with linear part [[0,1],[1,1]]")
print("the affine crosswalk has order 3, fixes one point, and cycles three")
print("translations plus the crosswalk generate 12 even permutations = A4")
print("adjoining the coordinate-swap mirror generates all 24 permutations = S4")
print("L and R preserve all 4096 homogeneous completed-algebra products")
print("the 64 homogeneous cells split into 16 invariant tetrahedral four-cell blocks")
print("the mirror action stays within 64 cells; retaining a mirror label gives 128 dimensions")

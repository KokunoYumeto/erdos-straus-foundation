from collections import Counter
from math import gcd
import sys

from scan_coupled_shell_coverage import (
    divisors_from_factorization,
    factor_integer,
    prime_sieve,
)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


PRIME_LIMIT = 2_000


def multiplicative_order(value, modulus):
    current = 1
    for order in range(1, modulus + 1):
        current = current * value % modulus
        if current == 1:
            return order
    raise AssertionError("multiplicative order was not found")


sieve = prime_sieve(PRIME_LIMIT)
trial_sieve = prime_sieve(PRIME_LIMIT)
trial_primes = [
    value for value in range(2, PRIME_LIMIT + 1) if trial_sieve[value]
]

shell_count = 0
divisor_count = 0
target_order_counts = Counter()

for p in range(5, PRIME_LIMIT + 1, 4):
    if not sieve[p]:
        continue
    for residual in range(3, 2 * p, 4):
        a = (p + residual) // 4
        if gcd(a, residual) != 1 or gcd(p, residual) != 1:
            raise AssertionError("shell parameters are not units")

        factors = factor_integer(a, trial_primes)
        square_factors = tuple(
            (prime, 2 * exponent) for prime, exponent in factors
        )
        divisors = divisors_from_factorization(square_factors)
        divisor_set = set(divisors)
        residues = Counter(divisor % residual for divisor in divisors)

        inverse_four = pow(4, -1, residual)
        exterior = (-inverse_four) % residual
        middle = (-a) % residual
        opposite_exterior = p * middle % residual

        if middle != p * exterior % residual:
            raise AssertionError("multiplicative endpoint transport failed")

        def complement_on_residues(value):
            return a * a * pow(value, -1, residual) % residual

        if complement_on_residues(middle) != middle:
            raise AssertionError("middle target is not fixed")
        if complement_on_residues(exterior) != opposite_exterior:
            raise AssertionError("exterior target exchange failed")
        if complement_on_residues(opposite_exterior) != exterior:
            raise AssertionError("opposite exterior target exchange failed")

        inverse_p = pow(p, -1, residual)
        for residue in residues:
            left = complement_on_residues(
                p * complement_on_residues(residue) % residual
            )
            right = inverse_p * residue % residual
            if left != right:
                raise AssertionError("J T J = T^{-1} failed")

        for divisor in divisors:
            complement = a * a // divisor
            if complement not in divisor_set:
                raise AssertionError("divisor complement left the divisor set")
            expected = complement_on_residues(divisor % residual)
            if complement % residual != expected:
                raise AssertionError("divisor complement residue failed")

        exterior_count = residues[exterior]
        middle_count = residues[middle]
        opposite_count = residues[opposite_exterior]
        if exterior_count != opposite_count:
            raise AssertionError("exterior target fibre counts differ")
        if middle_count % 2:
            raise AssertionError("middle target fibre count is odd")
        shell_rank = exterior_count + middle_count // 2
        if 2 * shell_rank != (
            exterior_count + middle_count + opposite_count
        ):
            raise AssertionError("three-fibre rank identity failed")

        shell_count += 1
        divisor_count += len(divisors)
        target_order_counts[multiplicative_order(p % residual, residual)] += 1


p = 73
residual = 7
a = 20
middle = (-a) % residual
cycle = []
current = middle
for _ in range(6):
    cycle.append(current)
    current = current * p % residual

if tuple(cycle) != (1, 3, 2, 6, 4, 5):
    raise AssertionError("unexpected p=73 target cycle")


def phi_seven(value):
    sheet = 1 if pow(value, 3, 7) == 1 else -1
    return sheet, sheet * value % 7


phi_cycle = tuple(phi_seven(value) for value in cycle)
expected_phi_cycle = (
    (1, 1),
    (-1, 4),
    (1, 2),
    (-1, 1),
    (1, 4),
    (-1, 2),
)
if phi_cycle != expected_phi_cycle:
    raise AssertionError("unexpected C2-sheet/C3-phase cycle")

print("PASS: exact endpoint dihedral orbit")
print("multiplication by p carries exterior to middle target")
print("divisor complement fixes middle and exchanges exterior targets")
print("J T J = T^{-1} on every tested divisor residue")
print("twice the shell rank equals the three labelled fibre counts")
print(f"all admissible shells through p={PRIME_LIMIT}: {shell_count}")
print(f"divisors checked with multiplicity: {divisor_count}")
print(f"distinct target rotation orders: {len(target_order_counts)}")
print(f"largest target rotation order: {max(target_order_counts)}")
print(f"order-one coupled shells: {target_order_counts[1]}")
print(f"order-six target shells: {target_order_counts[6]}")
print(f"p=73, R=7 target C6 cycle: {tuple(cycle)}")
print(f"p=73, R=7 C2-sheet/C3-phase cycle: {phi_cycle}")

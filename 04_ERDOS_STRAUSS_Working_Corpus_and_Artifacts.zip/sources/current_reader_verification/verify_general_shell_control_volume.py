#!/usr/bin/env python3
"""Exact control-length and determinant-volume data of the free-shell carrier."""

import sympy as sp


for q in range(1, 6):
    omega = 2 * q
    h_block = sp.diag(4, -1)
    h = sp.kronecker_product(sp.eye(q), h_block, sp.eye(3))
    identity = sp.eye(6 * q)
    k = h - sp.Rational(3, 2) * identity

    assert h.shape == (3 * omega, 3 * omega)
    assert h.rank() == 3 * omega
    assert h.eigenvals() == {sp.Integer(4): 3 * q, sp.Integer(-1): 3 * q}

    determinant_volume = abs(int(h.det()))
    length_h_squared = sp.trace(h**2)
    length_k_squared = sp.trace(k**2)

    assert determinant_volume == 4 ** (3 * q) == 2 ** (3 * omega)
    assert length_h_squared == 51 * q == sp.Rational(51, 2) * omega
    assert sp.trace(k) == 0
    assert length_k_squared == sp.Rational(75, 2) * q
    assert length_k_squared == sp.Rational(75, 4) * omega

    log_volume_coefficient_h = sp.simplify(
        (3 * omega * sp.log(2)) / length_h_squared
    )
    log_volume_coefficient_k = sp.simplify(
        (3 * omega * sp.log(2)) / length_k_squared
    )
    assert log_volume_coefficient_h == sp.Rational(2, 17) * sp.log(2)
    assert log_volume_coefficient_k == sp.Rational(4, 25) * sp.log(2)

print("PASS support dimension equals 6q and 3 Omega")
print("PASS shell spectrum is 4^[3q] together with (-1)^[3q]")
print("PASS determinant volume equals 4^(3q) and 2^(3 Omega)")
print("PASS Hilbert--Schmidt length squared equals 51q")
print("PASS traceless length squared equals 75q/2")
print("PASS log volume equals (2 log 2/17)L_H^2 and (4 log 2/25)L_K^2")
print("PASS checks hold for one through five complement-orbit factors")

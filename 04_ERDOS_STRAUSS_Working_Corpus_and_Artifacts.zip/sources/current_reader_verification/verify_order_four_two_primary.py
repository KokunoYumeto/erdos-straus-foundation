from fractions import Fraction
from itertools import product


def convolution(order, factors, add, scale):
    values = [0] * order
    values[0] = 1
    for direction, exponent in factors:
        local = [0] * order
        for beta in range(-exponent, exponent + 1):
            local[scale(beta, direction)] += 1
        nxt = [0] * order
        for x, left in enumerate(values):
            for y, right in enumerate(local):
                nxt[add(x, y)] += left * right
        values = nxt
    return values


def i_power(exponent):
    return ((1, 0), (0, 1), (-1, 0), (0, -1))[exponent % 4]


def gaussian_sum(character, direction, exponent):
    real = 0
    imag = 0
    for beta in range(-exponent, exponent + 1):
        value = i_power(-character * direction * beta)
        real += value[0]
        imag += value[1]
    assert imag == 0
    return real


def c4_checks():
    options = tuple(product(range(4), range(1, 4)))
    checked = 0
    zero_cases = 0
    for length in range(1, 5):
        for factors in product(options, repeat=length):
            if not any(direction % 2 for direction, _ in factors):
                continue
            checked += 1
            values = convolution(
                4,
                factors,
                lambda x, y: (x + y) % 4,
                lambda beta, direction: (beta * direction) % 4,
            )
            mass = 1
            for _, exponent in factors:
                mass *= 2 * exponent + 1

            odd_length = 1
            two_length = 1
            for direction, exponent in factors:
                local_length = 2 * exponent + 1
                if direction % 2:
                    odd_length *= local_length
                elif direction == 2:
                    two_length *= local_length

            transforms = []
            for character in range(4):
                coefficient = 1
                for direction, exponent in factors:
                    coefficient *= gaussian_sum(character, direction, exponent)
                transforms.append(coefficient)

            assert transforms[0] == mass
            assert Fraction(abs(transforms[1]), mass) == Fraction(
                1, odd_length * two_length
            )
            assert Fraction(abs(transforms[2]), mass) == Fraction(1, odd_length)
            assert Fraction(abs(transforms[3]), mass) == Fraction(
                1, odd_length * two_length
            )

            exceptional = odd_length == 3 and two_length == 1
            assert (min(values) == 0) == exceptional
            if exceptional:
                zero_cases += 1
                odd_direction = next(
                    direction
                    for direction, exponent in factors
                    if direction % 2 and exponent == 1
                )
                assert values[(2 * odd_direction) % 4] == 0
                assert sorted(values) == [0, mass // 3, mass // 3, mass // 3]
            else:
                assert min(values) > 0
    return checked, zero_cases


def xor_add(x, y):
    return x ^ y


def binary_character(character, value):
    dot = ((character & 1) * (value & 1)) ^ (
        ((character >> 1) & 1) * ((value >> 1) & 1)
    )
    return -1 if dot else 1


def spans_klein_four(factors):
    nonzero = {direction for direction, _ in factors if direction}
    return len(nonzero) >= 2


def v4_checks():
    options = tuple(product(range(4), range(1, 4)))
    checked = 0
    for length in range(2, 5):
        for factors in product(options, repeat=length):
            if not spans_klein_four(factors):
                continue
            checked += 1
            values = convolution(
                4,
                factors,
                xor_add,
                lambda beta, direction: direction if beta % 2 else 0,
            )
            mass = 1
            for _, exponent in factors:
                mass *= 2 * exponent + 1

            transforms = []
            for character in range(4):
                coefficient = 1
                for direction, exponent in factors:
                    local = sum(
                        binary_character(
                            character, direction if beta % 2 else 0
                        )
                        for beta in range(-exponent, exponent + 1)
                    )
                    coefficient *= local
                transforms.append(coefficient)

            assert transforms[0] == mass
            nonprincipal_mass = sum(abs(value) for value in transforms[1:])
            assert Fraction(nonprincipal_mass, mass) <= Fraction(7, 9)
            assert Fraction(min(values), 1) >= Fraction(mass, 9)
            assert min(values) > 0
    return checked


c4_count, c4_zero_count = c4_checks()
v4_count = v4_checks()

print("PASS: exact order-four 2-primary classification")
print(f"C4_products_checked={c4_count}")
print(f"C4_extremal_zero_products={c4_zero_count}")
print("every C4 zero is the antipode of one length-three generator")
print(f"Klein_four_products_checked={v4_count}")
print("every Klein-four coefficient is at least one ninth of the total mass")
print("every Klein-four target coefficient is strictly positive")

from fractions import Fraction

import sympy as sp


U, V, S, T = sp.symbols("U V S T")

endpoint_cubic = T * S * (S - T)
fable_cubic = V * (U - sp.Rational(1, 2) * V) * (
    U + sp.Rational(1, 2) * V
)
pullback = sp.expand(
    endpoint_cubic.subs({S: U + sp.Rational(1, 2) * V, T: V})
)

assert sp.expand(pullback - fable_cubic) == 0

marked_points = {
    (Fraction(-1, 2), Fraction(1, 1)): (Fraction(0), Fraction(1)),
    (Fraction(1, 2), Fraction(1, 1)): (Fraction(1), Fraction(1)),
    (Fraction(1), Fraction(0)): (Fraction(1), Fraction(0)),
}

for (u, v), expected in marked_points.items():
    image = (u + Fraction(1, 2) * v, v)
    assert image == expected

q = Fraction(-1, 2)
gamma = q

assert 2 * q + 1 == 0
assert 2 * gamma + 1 == 0
assert 4 * q == 1 / q == -2
assert 4 * gamma == -2

rho_zero = q
rho_one = -q
assert rho_zero * rho_one == Fraction(-1, 4)

print("centered endpoint cubic pullback: PASS")
print("three marked projective points: PASS")
print("scalar-locus isomorphism gamma=q=-1/2: PASS")
print("4*q=q^(-1)=-2: PASS")
print("centered endpoint product=-1/4: PASS")

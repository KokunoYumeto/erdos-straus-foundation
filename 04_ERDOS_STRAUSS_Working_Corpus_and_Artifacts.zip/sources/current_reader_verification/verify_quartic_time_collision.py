"""Exact symbolic audit of the quartic marked-factor Time collision."""

import sympy as sp


a, y, z, w = sp.symbols("a y z w")
ii = sp.I

b = ii + a * y
c = -ii + 2 * a * y + a**2 * z
d = -ii * y - a * (ii * z + 2 * y**2) - a**2 * y * z
e = 2 * z - 7 * ii * y**2 + a * w
f = (
    ii * w
    + 3 * ii * y**3
    - 4 * y * z
    + a * (6 * ii * y**2 * z + w * y + 4 * y**4)
    + 2 * a**2 * y**3 * z
)

resultant = -b**3 * c + a * b**2 * d - a**2 * b * e + a**3 * f
fixed_coefficient = a * d + b * c
assert sp.expand(resultant - 1) == 0
assert sp.expand(fixed_coefficient - 1) == 0

P = sp.Matrix([a * c, a * e + b * d, a * f + b * e, b * f])
DP = P.jacobian((a, y, z, w))
assert sp.expand(DP.det() + 2) == 0

sqrt2 = sp.sqrt(2)
points = {
    "M": (0, 0, ii / 2, 0),
    "N": (ii, -1, -3 * ii, 13),
    "T": (1 / sqrt2, -1 - sqrt2 * ii, 2 * sqrt2 + 6 * ii, -34 - 19 * sqrt2 * ii),
    "E": (1 / sqrt2, 1 - sqrt2 * ii, -2 * sqrt2 + 6 * ii, 34 - 19 * sqrt2 * ii),
}

target = sp.Matrix([0, 0, -1, 0])
for label, point in points.items():
    value = P.subs(dict(zip((a, y, z, w), point))).applyfunc(sp.simplify)
    assert value == target, (label, value)

# Recover every marked factor and check that its product is
# U^3 V - U V^3 and its resultant is one.
U, V = sp.symbols("U V")
H = U**3 * V - U * V**3
for label, point in points.items():
    subs = dict(zip((a, y, z, w), point))
    aa, bb, cc, dd, ee, ff = [
        sp.simplify(expr.subs(subs)) for expr in (a, b, c, d, e, f)
    ]
    L = aa * U + bb * V
    Q3 = cc * U**3 + dd * U**2 * V + ee * U * V**2 + ff * V**3
    assert sp.expand(L * Q3 - H) == 0, label
    res_value = -bb**3 * cc + aa * bb**2 * dd - aa**2 * bb * ee + aa**3 * ff
    assert sp.simplify(res_value - 1) == 0, label

print("Quartic branch incidence equations: exact")
print("Quartic Jacobian determinant: -2")
print("Four distinct source points have common target: (0, 0, -1, 0)")
print("All four marked factors multiply to U^3 V - U V^3 with resultant one")
print("All exact quartic Time-collision checks passed.")

#!/usr/bin/env python3
"""Exact two-torsion carry characters of the order-sixteen carriers."""

from __future__ import annotations

import itertools

from verify_order_sixteen_four_sheet_carrier import (
    CARRIERS,
    cocycle_is_coboundary,
)
from verify_order_sixteen_carrier_dihedral_irreducibles import (
    carrier_orbit_modules,
    irreducible_multiplicities,
    permutation_character,
)


def zero_sheet(carrier):
    return next(
        sheet
        for sheet in carrier.sheets
        if all(coordinate == 0 for coordinate in sheet)
    )


def verify_two_torsion_character(carrier) -> dict[str, object]:
    zero = zero_sheet(carrier)
    two_torsion = tuple(
        sheet
        for sheet in carrier.sheets
        if carrier.sheet_add(sheet, sheet) == zero
    )
    carry_character = {
        sheet: carrier.cocycle(sheet, sheet) % 2
        for sheet in two_torsion
    }

    for left in two_torsion:
        for right in two_torsion:
            assert (
                carry_character[carrier.sheet_add(left, right)]
                == (carry_character[left] + carry_character[right]) % 2
            )

    tested_cochains = 0
    nonzero_sheets = tuple(
        sheet for sheet in carrier.sheets if sheet != zero
    )
    for values in itertools.product(range(4), repeat=len(nonzero_sheets)):
        cochain = {zero: 0}
        cochain.update(dict(zip(nonzero_sheets, values)))
        for sheet in two_torsion:
            changed_diagonal = (
                carrier.cocycle(sheet, sheet)
                + 2 * cochain[sheet]
                - cochain[carrier.sheet_add(sheet, sheet)]
            ) % 4
            assert changed_diagonal % 2 == carry_character[sheet]
        tested_cochains += 1

    modules = carrier_orbit_modules(carrier)
    odd_carry_modules = modules.count("V1")
    multiplicities = irreducible_multiplicities(
        permutation_character(carrier)
    )
    spectral_defect = multiplicities[3] - multiplicities[1]
    weight = sum(carry_character.values())

    assert weight == odd_carry_modules == spectral_defect
    if weight:
        assert 2 * weight == len(two_torsion)
    assert (weight > 0) == (not cocycle_is_coboundary(carrier))

    return {
        "two_torsion": two_torsion,
        "values": tuple(carry_character[sheet] for sheet in two_torsion),
        "weight": weight,
        "odd_carry_modules": odd_carry_modules,
        "spectral_defect": spectral_defect,
        "tested_cochains": tested_cochains,
    }


def main() -> None:
    for carrier in CARRIERS:
        result = verify_two_torsion_character(carrier)
        print(
            f"{carrier.name}: "
            f"S[2]={len(result['two_torsion'])}, "
            f"q={result['values']}, "
            f"weight={result['weight']}, "
            f"V1={result['odd_carry_modules']}, "
            f"delta={result['spectral_defect']}, "
            f"cochains={result['tested_cochains']}"
        )
    print(
        "PASS: two-torsion carry character, cohomology invariance, "
        "and spectral-weight formula"
    )


if __name__ == "__main__":
    main()

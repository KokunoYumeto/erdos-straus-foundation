#!/usr/bin/env python3
"""Vector image of the exact Fable-face transport to the ES Lorentz slice."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Arc, FancyArrowPatch
import numpy as np


HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "figures" / "fable_es_face_transport.pdf"

sqrt3 = np.sqrt(3.0)
fable = np.array(
    [
        [0.0, 1.0],
        [sqrt3 / 2.0, -0.5],
        [-sqrt3 / 2.0, -0.5],
    ]
)
es = np.array(
    [
        [1.0, 0.0],
        [-0.5, sqrt3 / 2.0],
        [-0.5, -sqrt3 / 2.0],
    ]
)
colors = ["#c43c35", "#2f6fbb", "#2d8a4b"]

fig, axes = plt.subplots(1, 2, figsize=(10.8, 5.0))

for ax in axes:
    theta = np.linspace(0.0, 2.0 * np.pi, 400)
    ax.plot(np.cos(theta), np.sin(theta), color="0.82", linewidth=1.0)
    ax.set_aspect("equal")
    ax.set_xlim(-1.28, 1.28)
    ax.set_ylim(-1.28, 1.28)
    ax.set_xticks([-1, 0, 1])
    ax.set_yticks([-1, 0, 1])
    ax.grid(alpha=0.16)

# Fable point-circle face.
ax = axes[0]
ax.plot(
    np.r_[fable[:, 0], fable[0, 0]],
    np.r_[fable[:, 1], fable[0, 1]],
    color="0.45",
    linewidth=1.4,
)
for point, color in zip(fable, colors):
    ax.scatter(*point, s=105, color=color, zorder=3)
ax.axvline(0, color="0.35", linestyle="--", linewidth=1.1)
ax.text(0.07, 1.05, r"$\widehat v_0=(1,0,1,0)$", fontsize=9.5)
ax.text(0.53, -0.69, r"$\widehat v_+$", fontsize=10)
ax.text(-1.13, -0.69, r"$\widehat v_-$", fontsize=10)
ax.text(0.05, -1.18, r"$J_F:\ X\mapsto-X$", fontsize=9)
ax.set_xlabel(r"$X$")
ax.set_ylabel(r"$Y$")
ax.set_title("A. Fable tetrahedral face", loc="left", fontweight="bold")

# ES-aligned face.
ax = axes[1]
ax.plot(
    np.r_[es[:, 0], es[0, 0]],
    np.r_[es[:, 1], es[0, 1]],
    color="0.45",
    linewidth=1.4,
)
for point, color in zip(es, colors):
    ax.scatter(*point, s=105, color=color, zorder=3)
ax.axhline(0, color="0.35", linestyle="--", linewidth=1.1)
ax.text(0.19, 0.07, r"$e_0=(1,1,0,0)$", fontsize=9.5)
ax.text(-1.16, 0.91, r"$e_+$", fontsize=10)
ax.text(-1.16, -1.01, r"$e_-$", fontsize=10)
ax.text(-0.02, -1.18, r"$s_W:\ W\mapsto-W$", fontsize=9)
ax.annotate(
    "",
    xy=(-0.58, 0.82),
    xytext=(0.82, 0.22),
    arrowprops=dict(
        arrowstyle="->",
        connectionstyle="arc3,rad=0.28",
        color="#6f4aa8",
        linewidth=1.8,
    ),
)
ax.text(0.1, 0.75, r"$R_{\rm face}$", color="#6f4aa8", fontsize=10)
ax.set_xlabel(r"$X$")
ax.set_ylabel(r"$W$")
ax.set_title("B. Erdős--Strauss-aligned null face", loc="left", fontweight="bold")

# Exact coordinate transport between the two panels.
arrow = FancyArrowPatch(
    (0.475, 0.50),
    (0.545, 0.50),
    transform=fig.transFigure,
    arrowstyle="-|>",
    mutation_scale=15,
    linewidth=1.5,
    color="black",
)
fig.add_artist(arrow)
fig.text(0.508, 0.54, r"$A^{-1}$", ha="center", va="bottom", fontsize=11)

fig.suptitle(
    "The Fable face action transported to denominator exchange",
    fontsize=13.5,
    fontweight="bold",
)
fig.text(
    0.5,
    0.015,
    r"$\langle p_a,p_b\rangle=-\frac{1}{2}\ (a\ne b),\qquad"
    r"\ R_{\mathrm{face}}^3=s_W^2=I,\qquad"
    r"\ s_WR_{\mathrm{face}}s_W=R_{\mathrm{face}}^{-1}$",
    ha="center",
    fontsize=10.5,
)
fig.tight_layout(rect=(0, 0.07, 1, 0.93), w_pad=3.4)
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, bbox_inches="tight")
plt.close(fig)
print(OUT)

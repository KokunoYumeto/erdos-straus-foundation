#!/usr/bin/env python3
"""Exact balance among carrier deficit, blade count, and D8 spectral carry."""

from __future__ import annotations

from verify_order_sixteen_four_sheet_carrier import (
    CARRIERS,
    cocycle_is_coboundary,
)
from verify_order_sixteen_carrier_inversion_blade import inversion_orbits
from verify_order_sixteen_carrier_dihedral_irreducibles import (
    irreducible_multiplicities,
    permutation_character,
)


def verify_spectral_support_balance(carrier) -> dict[str, int]:
    inverse_coordinates = carrier.coordinates()
    minimum_coordinates = frozenset(
        inverse_coordinates[element] for element in carrier.minimum_support
    )
    sheet_projection = {sheet for sheet, _cell in minimum_coordinates}
    cell_projection = {cell for _sheet, cell in minimum_coordinates}
    correlation_defect = (
        len(sheet_projection) * len(cell_projection) - len(minimum_coordinates)
    )

    _fixed, paired_orbits = inversion_orbits(carrier, minimum_coordinates)
    blade_blocks = len(paired_orbits)

    character = permutation_character(carrier)
    chi_pp, chi_pm, chi_mp, chi_mm, rho = irreducible_multiplicities(character)
    spectral_defect = chi_mm - chi_pm
    extension_indicator = int(not cocycle_is_coboundary(carrier))

    assert rho == 4
    assert chi_pp + chi_pm + chi_mp + chi_mm + 2 * rho == 16
    assert correlation_defect + blade_blocks == 4
    assert correlation_defect + spectral_defect == 4 * extension_indicator
    assert (
        blade_blocks - spectral_defect
        == 4 * (1 - extension_indicator)
    )
    assert spectral_defect == extension_indicator * blade_blocks

    return {
        "correlation_defect": correlation_defect,
        "blade_blocks": blade_blocks,
        "spectral_defect": spectral_defect,
        "extension_indicator": extension_indicator,
    }


def main() -> None:
    for carrier in CARRIERS:
        result = verify_spectral_support_balance(carrier)
        print(
            f"{carrier.name}: d={result['correlation_defect']}, "
            f"b={result['blade_blocks']}, "
            f"delta={result['spectral_defect']}, "
            f"e={result['extension_indicator']}, "
            f"d+delta={result['correlation_defect'] + result['spectral_defect']}, "
            f"b-delta={result['blade_blocks'] - result['spectral_defect']}"
        )
    print(
        "PASS: exact spectral-support balance and extension-class partition"
    )


if __name__ == "__main__":
    main()

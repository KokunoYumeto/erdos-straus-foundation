from collections import defaultdict
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def unit_group_coefficients(a, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(a):
        local = defaultdict(int)
        local[1] += 1
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] += 1
            local[pow(residue, -1, modulus)] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left * right) % modulus] += left_count * right_count
        coefficients = dict(product)
    return coefficients


prime_count = 0
shell_count = 0
coupled_shell_count = 0
positive_coupled_prime_count = 0
positive_remainder_prime_count = 0

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue
    prime_count += 1
    q_total = 0
    q_remainder = 0
    coupled_coefficient_mass = 0
    every_remainder_shell_in_target_kernel = True

    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        R = 4 * a - p
        if R <= 0 or R % 4 != 3:
            raise AssertionError(f"invalid shell at p={p}, a={a}, R={R}")
        shell_count += 1

        a_squared_divisors = divisors(a * a)
        exterior_count = sum(
            1 for u in a_squared_divisors if (4 * u + 1) % R == 0
        )
        middle_orbits = {
            tuple(sorted((u, a * a // u)))
            for u in a_squared_divisors
            if (u + a) % R == 0
        }
        q_shell = exterior_count + len(middle_orbits)
        q_total += q_shell

        if (p - 1) % R:
            q_remainder += q_shell
            if q_shell:
                every_remainder_shell_in_target_kernel = False
            continue

        coupled_shell_count += 1
        if gcd(R, a) != 1:
            raise AssertionError(
                f"coupled-shell coprimality fails at p={p}, a={a}, R={R}"
            )
        coefficient = unit_group_coefficients(a, R).get(R - 1, 0)
        if coefficient % 2:
            raise AssertionError(
                f"odd coupled coefficient at p={p}, a={a}, R={R}"
            )
        if 2 * q_shell != 3 * coefficient:
            raise AssertionError(
                f"coupled rank formula fails at p={p}, a={a}, R={R}"
            )
        coupled_coefficient_mass += coefficient

    if 2 * q_total != 2 * q_remainder + 3 * coupled_coefficient_mass:
        raise AssertionError(f"primewise rank decomposition fails at p={p}")
    if 6 * q_total != 6 * q_remainder + 9 * coupled_coefficient_mass:
        raise AssertionError(f"volume-exponent decomposition fails at p={p}")
    if 2 * (3 * q_total) != (
        2 * (3 * q_remainder) + 9 * coupled_coefficient_mass
    ):
        raise AssertionError(f"modular-polar rank decomposition fails at p={p}")
    if 2 * 51 * q_total != (
        2 * 51 * q_remainder + 153 * coupled_coefficient_mass
    ):
        raise AssertionError(f"H-length decomposition fails at p={p}")
    if 2 * 75 * q_total != (
        2 * 75 * q_remainder + 225 * coupled_coefficient_mass
    ):
        raise AssertionError(f"K-length decomposition fails at p={p}")
    if (q_total == 0) != (
        q_remainder == 0 and coupled_coefficient_mass == 0
    ):
        raise AssertionError(f"zero-rank criterion fails at p={p}")
    if (q_remainder == 0) != every_remainder_shell_in_target_kernel:
        raise AssertionError(f"remainder target-kernel criterion fails at p={p}")
    if (q_total == 0) != (
        every_remainder_shell_in_target_kernel
        and coupled_coefficient_mass == 0
    ):
        raise AssertionError(f"separated target-kernel obstruction fails at p={p}")

    if coupled_coefficient_mass:
        positive_coupled_prime_count += 1
    if q_remainder:
        positive_remainder_prime_count += 1


if not prime_count or not shell_count or not coupled_shell_count:
    raise AssertionError("the primewise shell test family was empty")
if not positive_coupled_prime_count or not positive_remainder_prime_count:
    raise AssertionError("both summands were not represented in the test range")

print("PASS: primewise coupled-coefficient decomposition")
print("Q_p equals the remainder-shell rank plus three halves of the coupled mass")
print("the determinant-volume exponent splits as 6 Q_rem plus 9 C_coup")
print("the C3-amplified modular-polar rank splits as 3 Q_rem plus nine halves C_coup")
print("the two control-length squares split with the same arithmetic summands")
print("zero aggregate rank is equivalent to simultaneous vanishing of both summands")
print("the remainder target kernels and coupled coefficient zeros separate the obstruction")
print("positive coupled mass gives an Erdos-Strauss certificate at the tested prime")
print("all primewise shells through p=5000 passed")

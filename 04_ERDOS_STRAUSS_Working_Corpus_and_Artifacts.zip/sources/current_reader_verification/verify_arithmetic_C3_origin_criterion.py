from itertools import permutations, product
from pathlib import Path


p = 12289
R = 11
a = 3075


def target(j):
    if j == 0:
        return (-p) % R
    if j == 1:
        return (-1) % R
    if j == 2:
        return (-pow(p, -1, R)) % R
    raise ValueError(j)


divisors = sorted(
    3 ** e3 * 5 ** e5 * 41 ** e41
    for e3, e5, e41 in product(range(3), range(5), range(3))
)
if len(divisors) != 45 or len(set(divisors)) != 45:
    raise AssertionError("the divisor box must contain 45 distinct divisors")

a_inverse = pow(a, -1, R)
fibres = {
    j: tuple(u for u in divisors if (u * a_inverse) % R == target(j))
    for j in range(3)
}
counts = tuple(len(fibres[j]) for j in range(3))
if counts != (3, 6, 3):
    raise AssertionError(f"origin-fibre counts: {counts}")

for j in range(3):
    image = tuple(sorted(a * a // u for u in fibres[j]))
    expected = tuple(sorted(fibres[2 - j]))
    if image != expected:
        raise AssertionError(f"divisor complement fails on fibre {j}")

edge_multipliers = (
    target(1) * pow(target(0), -1, R) % R,
    target(2) * pow(target(1), -1, R) % R,
    target(0) * pow(target(2), -1, R) % R,
)
expected_edges = (pow(p, -1, R), pow(p, -1, R), pow(p, 2, R))
if edge_multipliers != expected_edges:
    raise AssertionError(
        f"edge multipliers {edge_multipliers} != {expected_edges}"
    )
if edge_multipliers != (6, 6, 4):
    raise AssertionError(f"12289 edge multipliers: {edge_multipliers}")
if pow(p, 3, R) != 8:
    raise AssertionError(f"12289^3 modulo 11: {pow(p, 3, R)}")
if pow(p, 3, R) == 1:
    raise AssertionError("the three residue multipliers must not be uniform")

stabilizer = tuple(
    permutation
    for permutation in permutations(range(3))
    if tuple(counts[index] for index in permutation) == counts
)
if stabilizer != ((0, 1, 2), (2, 1, 0)):
    raise AssertionError(f"multiplicity stabilizer: {stabilizer}")

if len(set(counts)) == 1:
    raise AssertionError("equal fibre cardinality would permit a C3 action")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{thm:arithmetic-C3-realization-criterion}",
    r"Its full coordinate-permutation \(D_3\) orbit is",
    "cover acts on the first coordinate \\(m\\) and preserves each arithmetic\n"
    "origin label.",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing downstream typing: {fragment}")
for stale_fragment in (
    "single closed symmetry object",
    "question:arithmetic-C3-realization",
):
    if stale_fragment in preprint:
        raise AssertionError(f"stale downstream typing: {stale_fragment}")

lines = [
    "PASS: exact arithmetic C3-origin criterion at 12289",
    "origin fibres (m0,m1,m2) = (3,6,3)",
    "divisor complement sends fibre j bijectively to fibre 2-j",
    "cyclic edge multipliers modulo 11 = (6,6,4)",
    "12289^3 modulo 11 = 8, so the closing edge is not the same multiplier",
    "multiplicity stabilizer = {identity, exterior-fibre exchange}",
    "no fibre-cycling C3 action exists on the 12289 certificate set",
    "downstream coordinate-orbit and synthetic-cover typing verified",
]
print("\n".join(lines))

from fractions import Fraction as F


def mat_vec(matrix, vector):
    return tuple(sum(row[j] * vector[j] for j in range(len(vector)))
                 for row in matrix)


def scale(c, vector):
    return tuple(c * x for x in vector)


def outer(u, v):
    return tuple(tuple(x * y for y in v) for x in u)


e0 = (F(1), F(0))
e1 = (F(0), F(1))

# The second linking block uses v_i u_j = |f_i><f_j|.
E21 = outer(e1, e0)
E12 = outer(e0, e1)
assert E21 == ((F(0), F(0)), (F(1), F(0)))
assert E12 == ((F(0), F(1)), (F(0), F(0)))
print("PASS support-line factors map exactly to E21 and E12")

I_minus = (
    (F(0), F(0), F(0), F(1)),
    (F(0), F(1, 4), F(0), F(0)),
    (F(0), F(0), F(1, 4), F(0)),
    (F(1, 16), F(0), F(0), F(0)),
)

# Coefficient order is (a,b0,b1,c).
T_E21 = (F(2), F(0), F(0), F(-1, 2))
T_E12 = (F(0), F(0), F(1), F(0))
T_2E21 = scale(F(2), T_E21)

assert mat_vec(I_minus, T_E21) == scale(F(-1, 4), T_E21)
assert mat_vec(I_minus, T_E12) == scale(F(1, 4), T_E12)
assert mat_vec(I_minus, T_2E21) == scale(F(-1, 4), T_2E21)
print("PASS quarter eigenvalues: E21 -> -1/4 and E12 -> +1/4")

# In units ell=log(3/2), K has signs (-,+) on (E21,E12).
source_K_over_ell = (F(-1), F(1))
target_4I = (
    mat_vec(tuple(tuple(F(4) * x for x in row) for row in I_minus), T_E21),
    mat_vec(tuple(tuple(F(4) * x for x in row) for row in I_minus), T_E12),
)
assert target_4I[0] == scale(source_K_over_ell[0], T_E21)
assert target_4I[1] == scale(source_K_over_ell[1], T_E12)
print("PASS Phi K = 4 log(3/2) I_minus Phi on the ordered blade plane")

# Exponentiating the Hamiltonian signs recovers the modular weights.
delta_weights = (F(3, 2), F(2, 3))
assert delta_weights[0] * delta_weights[1] == F(1)
print("PASS exponential weights: E21 -> 3/2 and E12 -> 2/3")

assert T_2E21 == (F(4), F(0), F(0), F(-1))
assert T_E12 == (F(0), F(0), F(1), F(0))
print("PASS ordered coefficients retained: 2E21 -> (4,0,0,-1); E12 -> (0,0,1,0)")

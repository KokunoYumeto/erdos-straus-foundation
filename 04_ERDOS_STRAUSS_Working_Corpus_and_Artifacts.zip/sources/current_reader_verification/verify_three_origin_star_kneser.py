#!/usr/bin/env python3
"""Exact checks for the three-origin Star--Kneser refinement."""

from itertools import product


def subgroup(n, order):
    assert n % order == 0
    return {(j * (n // order)) % n for j in range(order)}


def coset(x, K, n):
    return frozenset((x + k) % n for k in K)


def image_count(values, K, n):
    return len({coset(x, K, n) for x in values})


def sumset(intervals, n):
    return {
        sum(choice) % n
        for choice in product(*[sorted(A) for A in intervals])
    }


def stabilizer(B, n):
    return {k for k in range(n) if {(b + k) % n for b in B} == B}


def surplus(intervals, targets, K, n):
    kappa = 1 + sum(image_count(A, K, n) - 1 for A in intervals)
    target_cost = image_count(targets, K, n)
    quotient_order = n // len(K)
    return kappa, target_cost, kappa + target_cost - quotient_order


def check_12289():
    n = 10
    intervals = ({0, 2, 8}, {0, 2, 4, 6, 8}, {0, 3, 7})
    two_targets = {4, 5}
    three_targets = {4, 5, 6}
    orders = (1, 2, 5, 10)
    old = []
    new = []
    for order in orders:
        K = subgroup(n, order)
        old.append(surplus(intervals, two_targets, K, n)[2])
        new.append(surplus(intervals, three_targets, K, n)[2])
    assert tuple(old) == (1, 6, 2, 1)
    assert tuple(new) == (2, 7, 2, 1)
    B = sumset(intervals, n)
    assert B == set(range(n))
    return tuple(old), tuple(new)


def check_champion_43():
    n = 14
    intervals = ({0, 4, 10}, {0, 1, 13})
    B = sumset(intervals, n)
    assert B == {0, 1, 3, 4, 5, 9, 10, 11, 13}
    two_targets = {7, 8}
    three_targets = {6, 7, 8}
    assert B.isdisjoint(two_targets)
    assert B.isdisjoint(three_targets)
    orders = (1, 2, 7, 14)
    old = []
    new = []
    for order in orders:
        K = subgroup(n, order)
        old.append(surplus(intervals, two_targets, K, n)[2])
        new.append(surplus(intervals, three_targets, K, n)[2])
    assert tuple(old) == (-7, 0, 2, 1)
    assert tuple(new) == (-6, 1, 2, 1)

    K = stabilizer(B, n)
    assert K == {0}
    kappa, target_cost, sigma = surplus(intervals, three_targets, K, n)
    quotient_order = n // len(K)
    B_image_count = image_count(B, K, n)
    hole_margin = quotient_order - B_image_count - target_cost
    kneser_slack = B_image_count - kappa
    assert (hole_margin, kneser_slack, -sigma) == (2, 4, 6)
    assert -sigma == hole_margin + kneser_slack
    return tuple(old), tuple(new), (hole_margin, kneser_slack)


def check_general_cyclic_identity():
    checked = 0
    for n in range(3, 25):
        for x in range(n):
            A = {0, x % n, (-x) % n}
            for y in range(n):
                B = sumset((A, {0, y % n, (-y) % n}), n)
                assert B == {(-b) % n for b in B}
                for u in range(n):
                    central = 0 if n % 2 else n // 2
                    T2 = {central, u}
                    T3 = {central, u, (-u) % n}
                    assert bool(B & T2) == bool(B & T3)
                    if B.isdisjoint(T3):
                        K = stabilizer(B, n)
                        kappa, t3, sigma = surplus((A, {0, y % n, (-y) % n}), T3, K, n)
                        q = n // len(K)
                        bq = image_count(B, K, n)
                        hole = q - bq - t3
                        slack = bq - kappa
                        assert hole >= 0 and slack >= 0
                        assert -sigma == hole + slack
                    checked += 1
    return checked


if __name__ == "__main__":
    old_12289, new_12289 = check_12289()
    print("PASS 12289 two-origin surplus =", old_12289)
    print("PASS 12289 three-origin surplus =", new_12289)
    old_43, new_43, defect_43 = check_champion_43()
    print("PASS champion R=43 two-origin surplus =", old_43)
    print("PASS champion R=43 three-origin surplus =", new_43)
    print("PASS champion R=43 defect decomposition =", defect_43)
    checked = check_general_cyclic_identity()
    print("PASS cyclic hit-equivalence and exact defect decomposition cases =", checked)

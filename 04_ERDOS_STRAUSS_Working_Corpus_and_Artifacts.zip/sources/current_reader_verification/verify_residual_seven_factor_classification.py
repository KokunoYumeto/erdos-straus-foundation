from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for d in range(3, isqrt(n) + 1, 2):
        if n % d == 0:
            return False
    return True


def divisors(n):
    values = []
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            values.append(d)
            if d * d != n:
                values.append(n // d)
    return sorted(values)


def residue_valuations(n):
    counts = {r: 0 for r in range(1, 7)}
    ell = 2
    while ell * ell <= n:
        while n % ell == 0:
            counts[ell % 7] += 1
            n //= ell
        ell += 1
    if n > 1:
        counts[n % 7] += 1
    return counts


def exterior_count(a):
    return sum(1 for u in divisors(a * a) if (4 * u + 1) % 7 == 0)


def middle_coefficient(a):
    ds = divisors(a)
    return sum(
        1
        for x in ds
        for y in ds
        if gcd(x, y) == 1 and a % (x * y) == 0 and (x + y) % 7 == 0
    )


def predicted_occupied(a):
    nu = residue_valuations(a)
    return (
        nu[5] + nu[6] > 0
        or nu[3] >= 3
        or (nu[3] >= 1 and nu[2] + nu[4] >= 1)
    )


integer_rows = []
occupied_integer_count = 0
for a in range(1, 3001):
    if a % 7 == 0:
        continue
    e = exterior_count(a)
    c = middle_coefficient(a)
    actual = e + c // 2 > 0
    predicted = predicted_occupied(a)
    occupied_integer_count += int(actual)
    integer_rows.append(actual == predicted)

report(
    "R=7 factor-residue classification on coprime integers",
    all(integer_rows),
)

prime_rows = []
occupied_prime_count = 0
hard_locus_rows = []
hard_locus_occupied_count = 0
hard_locus_empty = []
primes = [p for p in range(13, 20001) if p % 12 == 1 and is_prime(p)]
for p in primes:
    a = (p + 7) // 4
    e = exterior_count(a)
    c = middle_coefficient(a)
    actual = e + c // 2 > 0
    predicted = predicted_occupied(a)
    occupied_prime_count += int(actual)
    prime_rows.append(actual == predicted)
    if p % 24 == 1:
        cofactor = (p + 7) // 8
        nu_cofactor = residue_valuations(cofactor)
        cofactor_prediction = (
            nu_cofactor[3] + nu_cofactor[5] + nu_cofactor[6] > 0
        )
        hard_locus_occupied_count += int(actual)
        hard_locus_rows.append(
            a == 2 * cofactor
            and actual == cofactor_prediction
        )
        if not actual:
            hard_locus_empty.append((p, cofactor))

report(
    "R=7 affine prime-shell classification",
    all(prime_rows),
)
report(
    "R=7 p=1 mod 24 nonresidue-cofactor criterion",
    all(hard_locus_rows),
)

print(f"coprime integers checked: {len(integer_rows)}")
print(f"occupied coprime integers: {occupied_integer_count}")
print(f"affine prime shells checked: {len(prime_rows)}")
print(f"occupied affine prime shells: {occupied_prime_count}")
print(f"p=1 mod 24 shells checked: {len(hard_locus_rows)}")
print(f"p=1 mod 24 occupied shells: {hard_locus_occupied_count}")
print(f"p=1 mod 24 empty shells: {len(hard_locus_empty)}")
print(f"first empty hard-locus pairs (p,c): {hard_locus_empty[:12]}")

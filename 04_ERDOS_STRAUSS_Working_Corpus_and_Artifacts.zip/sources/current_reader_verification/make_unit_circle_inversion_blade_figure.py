#!/usr/bin/env python3
"""Create the exact unit-circle inversion image for the arithmetic blade cells."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "unit_circle_inversion_blade_channels.pdf"
OUT.parent.mkdir(parents=True, exist_ok=True)

plt.rcParams.update(
    {
        "font.family": "serif",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "legend.fontsize": 8,
        "pdf.fonttype": 42,
    }
)

fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(10.4, 4.65))

theta = np.linspace(0, 2 * np.pi, 900)
colors = {
    "directed": "#b33c2e",
    "fixed": "#252525",
    "transpose": "#25835b",
    "arrow": "#415a77",
}

for radius, color, width, style, label in (
    (
        0.5,
        colors["directed"],
        2.4,
        "-",
        r"$4(x^2+y^2)-1=0$  ($2E_{21}$)",
    ),
    (
        1.0,
        colors["fixed"],
        1.7,
        "--",
        r"$x^2+y^2-1=0$  (raw $E_{12}$; fixed set)",
    ),
    (
        2.0,
        colors["transpose"],
        2.4,
        "-",
        r"$4-(x^2+y^2)=0$  ($2E_{12}$)",
    ),
):
    ax0.plot(
        radius * np.cos(theta),
        radius * np.sin(theta),
        color=color,
        lw=width,
        ls=style,
        label=label,
    )

angle = np.deg2rad(34)
p_small = np.array([0.5 * np.cos(angle), 0.5 * np.sin(angle)])
p_large = np.array([2.0 * np.cos(angle), 2.0 * np.sin(angle)])
ax0.plot(
    [0, p_large[0]],
    [0, p_large[1]],
    color="#9a9a9a",
    lw=0.8,
    zorder=0,
)
ax0.scatter(*p_small, s=34, color=colors["directed"], zorder=5)
ax0.scatter(*p_large, s=34, color=colors["transpose"], zorder=5)
ax0.add_patch(
    FancyArrowPatch(
        p_small,
        p_large,
        arrowstyle="-|>",
        mutation_scale=14,
        lw=1.5,
        color=colors["arrow"],
        connectionstyle="arc3,rad=0.08",
    )
)
mid = 0.54 * p_small + 0.46 * p_large
ax0.text(
    mid[0] + 0.02,
    mid[1] + 0.12,
    r"$I_u:\ r\mapsto r^{-1}$",
    color=colors["arrow"],
)
ax0.scatter(0, 0, s=18, color="black", zorder=6)
ax0.axhline(0, color="#c8c8c8", lw=0.7, zorder=-2)
ax0.axvline(0, color="#c8c8c8", lw=0.7, zorder=-2)
ax0.set_aspect("equal", adjustable="box")
ax0.set_xlim(-2.18, 2.18)
ax0.set_ylim(-2.18, 2.18)
ax0.set_xlabel("$x$")
ax0.set_ylabel("$y$")
ax0.set_title("A. Exact Euclidean circle inversion")
ax0.legend(loc="upper left", frameon=False)

ax1.axhline(0, color="#737373", lw=1.0, ls="--")
ax1.axvline(0, color="#c8c8c8", lw=0.7)
points = {
    r"$2E_{21}$": (1.5, 2.5, colors["directed"]),
    r"$2E_{12}$": (1.5, -2.5, colors["transpose"]),
    r"raw $E_{12}$": (0.0, -1.0, "#4059ad"),
    r"$-\,$raw $E_{12}$": (0.0, 1.0, "#7a5195"),
}
for label, (t, w, color) in points.items():
    ax1.scatter(t, w, s=48, color=color, zorder=5)
    dx = 0.08 if t == 0 else 0.1
    dy = 0.12 if w >= 0 else -0.25
    ax1.text(t + dx, w + dy, label, color=color)

ax1.add_patch(
    FancyArrowPatch(
        (1.5, 2.5),
        (1.5, -2.5),
        arrowstyle="-|>",
        mutation_scale=14,
        lw=1.5,
        color=colors["arrow"],
        connectionstyle="arc3,rad=-0.16",
    )
)
ax1.add_patch(
    FancyArrowPatch(
        (0.0, -1.0),
        (0.0, 1.0),
        arrowstyle="-|>",
        mutation_scale=14,
        lw=1.5,
        color=colors["arrow"],
        connectionstyle="arc3,rad=-0.22",
    )
)
ax1.text(
    2.08,
    0.05,
    r"$W=0$",
    ha="right",
    va="bottom",
    color="#555555",
)
ax1.text(
    0.52,
    0.02,
    r"$I_u:(T,W)\mapsto(T,-W)$",
    ha="center",
    va="bottom",
    transform=ax1.transAxes,
    color=colors["arrow"],
)
ax1.set_xlim(-0.55, 2.2)
ax1.set_ylim(-3.05, 3.05)
ax1.set_xlabel("$T$")
ax1.set_ylabel("$W$")
ax1.set_title("B. The same action in the Sarnak $(T,W)$ plane")
ax1.spines["top"].set_visible(False)
ax1.spines["right"].set_visible(False)

fig.suptitle(
    "Unit-circle inversion retains the arithmetic multiplicity distinction",
    y=0.995,
    fontsize=12,
)
fig.text(
    0.5,
    0.012,
    r"$M_u(a,b_0,b_1,c)=(c,b_0,b_1,a)$; "
    r"the raw $E_{12}$ circle is projectively fixed, whereas $2E_{21}$ maps to $2E_{12}$.",
    ha="center",
    fontsize=9,
)
fig.tight_layout(rect=(0, 0.05, 1, 0.96))
fig.savefig(OUT, bbox_inches="tight")
print(OUT)

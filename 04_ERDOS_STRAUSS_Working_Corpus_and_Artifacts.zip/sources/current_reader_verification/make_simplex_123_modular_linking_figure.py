#!/usr/bin/env python3
"""Render the exact simplex-support to 1-2-3 linking-algebra image."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Polygon, Rectangle
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures" / "simplex_123_modular_linking.pdf"

COLORS = {
    1: "#d1495b",
    2: "#2a9d8f",
    3: "#277da1",
}


def add_arrow(ax, start, end, color, rad=0.0):
    ax.add_patch(
        FancyArrowPatch(
            start,
            end,
            arrowstyle="-|>",
            mutation_scale=13,
            linewidth=1.5,
            color=color,
            connectionstyle=f"arc3,rad={rad}",
        )
    )


fig, ax = plt.subplots(figsize=(13.2, 8.0))
ax.set_xlim(0, 13.2)
ax.set_ylim(0, 8.0)
ax.axis("off")

ax.text(
    6.6,
    7.72,
    "Regular-simplex support carried into the full 1–2–3 modular linking algebra",
    ha="center",
    va="center",
    fontsize=17,
    weight="bold",
)
ax.text(
    6.6,
    7.32,
    r"$U_n^*U_n=P_n,\qquad U_nU_n^*=I_{V_n}$",
    ha="center",
    va="center",
    fontsize=13,
)

# Rank-one support: the centered regular 1-simplex.
segment = np.array([[-0.95, 0.0], [0.95, 0.0]]) + np.array([1.8, 5.95])
ax.plot(segment[:, 0], segment[:, 1], color="#555555", lw=2)
ax.scatter(segment[:, 0], segment[:, 1], s=72, color=COLORS[1], zorder=4)
ax.scatter([1.8], [5.95], s=32, color="black", zorder=5)
ax.text(1.8, 6.88, r"$\mathrm{C}^{2}\ \longrightarrow\ \mathrm{Ran}(P_1)$",
        ha="center", fontsize=13)
ax.text(1.8, 6.48, "centered segment", ha="center", fontsize=11)
ax.text(1.8, 5.53, r"$v_0+v_1=0,\quad \operatorname{rank}P_1=1$",
        ha="center", fontsize=11)

# Rank-two support: exact unit regular 2-simplex.
triangle = np.array(
    [
        [1.0, 0.0],
        [-0.5, np.sqrt(3.0) / 2.0],
        [-0.5, -np.sqrt(3.0) / 2.0],
    ]
)
triangle = 0.92 * triangle + np.array([6.6, 5.95])
ax.add_patch(
    Polygon(triangle, closed=True, facecolor="#2a9d8f22",
            edgecolor="#555555", lw=1.8)
)
ax.scatter(triangle[:, 0], triangle[:, 1], s=72, color=COLORS[2], zorder=4)
ax.scatter([6.6], [5.95], s=32, color="black", zorder=5)
ax.text(6.6, 6.88, r"$\mathrm{C}^{3}\ \longrightarrow\ \mathrm{Ran}(P_2)$",
        ha="center", fontsize=13)
ax.text(6.6, 6.48, "equilateral triangle", ha="center", fontsize=11)
ax.text(6.6, 5.00, r"$v_0+v_1+v_2=0,\quad \operatorname{rank}P_2=2$",
        ha="center", fontsize=11)

# Rank-three support: exact unit regular 3-simplex, shown by an orthographic view.
tetrahedron_3d = np.array(
    [
        [1.0, 1.0, 1.0],
        [1.0, -1.0, -1.0],
        [-1.0, 1.0, -1.0],
        [-1.0, -1.0, 1.0],
    ]
) / np.sqrt(3.0)
view = np.array([2.0, 3.0, 4.0])
view /= np.linalg.norm(view)
screen_x = np.cross(np.array([0.0, 0.0, 1.0]), view)
screen_x /= np.linalg.norm(screen_x)
screen_y = np.cross(view, screen_x)
projection = np.vstack([screen_x, screen_y])
tetrahedron = (projection @ tetrahedron_3d.T).T
tetrahedron = 1.15 * tetrahedron + np.array([11.4, 5.86])
for i in range(4):
    for j in range(i + 1, 4):
        ax.plot(
            [tetrahedron[i, 0], tetrahedron[j, 0]],
            [tetrahedron[i, 1], tetrahedron[j, 1]],
            color="#666666",
            lw=1.4,
            zorder=1,
        )
ax.scatter(tetrahedron[:, 0], tetrahedron[:, 1], s=72, color=COLORS[3], zorder=4)
ax.scatter([11.4], [5.86], s=32, color="black", zorder=5)
ax.text(11.4, 6.88, r"$\mathrm{C}^{4}\ \longrightarrow\ \mathrm{Ran}(P_3)$",
        ha="center", fontsize=13)
ax.text(11.4, 6.48, "regular tetrahedron", ha="center", fontsize=11)
ax.text(11.4, 4.72, r"$\sum_{i=0}^{3}v_i=0,\quad \operatorname{rank}P_3=3$",
        ha="center", fontsize=11)

# The exact 1+2+3 linking block.  Side lengths encode sector dimensions.
x_edges = np.array([4.55, 5.25, 6.65, 8.75])
y_edges = np.array([3.45, 3.00, 2.10, 0.75])
for a in range(1, 4):
    for b in range(1, 4):
        left, right = x_edges[b - 1], x_edges[b]
        top, bottom = y_edges[a - 1], y_edges[a]
        diagonal = a == b
        face = COLORS[a] + ("55" if diagonal else "16")
        ax.add_patch(
            Rectangle(
                (left, bottom),
                right - left,
                top - bottom,
                facecolor=face,
                edgecolor="#333333",
                lw=1.25,
            )
        )
        ax.text(
            (left + right) / 2,
            (top + bottom) / 2 + 0.08,
            rf"$L_{{{a}{b}}}$",
            ha="center",
            va="center",
            fontsize=11,
        )
        ax.text(
            (left + right) / 2,
            (top + bottom) / 2 - 0.17,
            rf"$\dim={a*b}$",
            ha="center",
            va="center",
            fontsize=8.8,
            color="#333333",
        )

for b in range(1, 4):
    ax.text(
        (x_edges[b - 1] + x_edges[b]) / 2,
        3.63,
        rf"$V_{b}$",
        ha="center",
        fontsize=11,
        color=COLORS[b],
        weight="bold",
    )
for a in range(1, 4):
    ax.text(
        4.36,
        (y_edges[a - 1] + y_edges[a]) / 2,
        rf"$V_{a}$",
        ha="right",
        va="center",
        fontsize=11,
        color=COLORS[a],
        weight="bold",
    )

ax.text(
    6.65,
    0.34,
    r"$PM_9(\mathrm{C})P\ \longrightarrow\ M_6(\mathrm{C}),"
    r"\qquad \Phi(X)=UXU^*$",
    ha="center",
    va="center",
    fontsize=12.5,
)

diagonal_centers = [
    ((x_edges[0] + x_edges[1]) / 2, (y_edges[0] + y_edges[1]) / 2),
    ((x_edges[1] + x_edges[2]) / 2, (y_edges[1] + y_edges[2]) / 2),
    ((x_edges[2] + x_edges[3]) / 2, (y_edges[2] + y_edges[3]) / 2),
]
shape_starts = [(1.8, 5.22), (6.6, 4.75), (11.4, 4.48)]
for n, (start, end) in enumerate(zip(shape_starts, diagonal_centers), start=1):
    add_arrow(ax, start, end, COLORS[n], rad=(0.08 if n == 1 else -0.08 if n == 3 else 0.0))
    mid_x = (start[0] + end[0]) / 2
    mid_y = (start[1] + end[1]) / 2
    ax.text(mid_x, mid_y + 0.12, rf"$U_{n}$", fontsize=11,
            color=COLORS[n], ha="center")

ax.text(
    10.15,
    2.98,
    "Diagonal sectors retain",
    fontsize=10.5,
    weight="bold",
)
ax.text(
    10.15,
    2.68,
    r"$K_1,\;K_2,\;K_3$ separately.",
    fontsize=11.5,
)
ax.text(
    10.15,
    2.22,
    "Off-diagonal rectangles retain",
    fontsize=10.5,
    weight="bold",
)
ax.text(
    10.15,
    1.92,
    "all inter-sector maps.",
    fontsize=10.5,
)
ax.text(
    10.15,
    1.43,
    r"$\Phi_{ab}(XY)=\Phi_{ac}(X\,Y)$",
    fontsize=11.5,
)
ax.text(
    10.15,
    1.03,
    r"$\Phi\Delta_a=\Delta_d\Phi$",
    fontsize=11.5,
)

OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, bbox_inches="tight", pad_inches=0.16)
plt.close(fig)
print(OUT)

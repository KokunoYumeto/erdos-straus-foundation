"""Bounded census of the prime-cofactor R=19 blade through R=23.

The family is

    p = 260*ell - 19,
    a_19 = 65*ell,
    b_ell = (p + 23)/12 = (65*ell + 1)/3.

The complete R=19 incidence table says that its hidden matrix is E21
exactly when log_2(ell) modulo 19 is 0 or 5.  The fixed-target R=23
colon theorem says that the next shell is occupied exactly when the
factor-log monomial of b_ell lies in J_23^(3).  This script enumerates
that pullback and records the realized complement profiles.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import argparse
import hashlib
from itertools import product

from sympy import factorint, isprime, primerange


R19_LOG = {pow(2, exponent, 19): exponent for exponent in range(18)}
R23_LOG = {pow(5, exponent, 23): exponent for exponent in range(22)}

R23_EXTERIOR_TARGETS = frozenset((7, 13, 19))
R23_MIDDLE_TARGETS = frozenset((5, 11, 17))

DEFAULT_BOUND = 10_000_000
EXPECTED_DEFAULT_COUNTS = {
    "ell_mod3": 332_192,
    "ell_primes": 664_579,
    "prime_pairs": 7_328,
    "prime_pairs_log_0": 3_663,
    "prime_pairs_log_5": 3_665,
    "r19_log_0": 18_426,
    "r19_log_5": 18_488,
    "r23_empty": 1_534,
    "r23_empty_even_only": 1_463,
    "r23_empty_log_0": 786,
    "r23_empty_log_5": 748,
    "r23_empty_odd_bearing": 71,
    "r23_occupied": 5_794,
}
EXPECTED_DEFAULT_SURVIVOR_HASH = (
    "6f318e7183729c5cbe35655674865e65bc5380b896a6ec935d487a547314d465"
)


def additive_reach(logs: tuple[int, ...], alphabet: tuple[int, ...]) -> set[int]:
    reached = {0}
    for logarithm in logs:
        reached = {
            (old + coefficient * logarithm) % 22
            for old, coefficient in product(reached, alphabet)
        }
    return reached


def r23_state(logs: tuple[int, ...]) -> tuple[tuple[int, int, int], tuple[int, int, int]]:
    exterior = additive_reach(logs, (0, 1, 2))
    middle = additive_reach(logs, (-1, 0, 1))
    return (
        tuple(int(target in exterior) for target in sorted(R23_EXTERIOR_TARGETS)),
        tuple(int(target in middle) for target in sorted(R23_MIDDLE_TARGETS)),
    )


def r23_occupied(logs: tuple[int, ...]) -> bool:
    exterior, middle = r23_state(logs)
    return any(exterior) or any(middle)


def factor_logs(factors: dict[int, int], modulus: int, logarithms: dict[int, int]) -> tuple[int, ...]:
    result = []
    for prime, exponent in sorted(factors.items()):
        logarithm = logarithms[prime % modulus]
        if logarithm:
            result.extend([logarithm] * exponent)
    return tuple(sorted(result))


def profile(logs: tuple[int, ...]) -> tuple[int, ...]:
    counts = Counter(logs)
    return tuple(counts[index] for index in range(1, 22))


def dominates(left: tuple[int, ...], right: tuple[int, ...]) -> bool:
    return all(a >= b for a, b in zip(left, right))


def maximal_profiles(rows: set[tuple[int, ...]]) -> tuple[tuple[int, ...], ...]:
    return tuple(
        row
        for row in sorted(rows)
        if not any(other != row and dominates(other, row) for other in rows)
    )


def compact_profile(row: tuple[int, ...]) -> str:
    entries = [f"{index}^{exponent}" for index, exponent in enumerate(row, 1) if exponent]
    return "1" if not entries else ".".join(entries)


def factor_signature(factors: dict[int, int]) -> str:
    entries = []
    for prime, exponent in sorted(factors.items()):
        logarithm = R23_LOG[prime % 23]
        entries.append(f"{prime}^{exponent}[{logarithm}]")
    return "*".join(entries)


def survivor_kind(logs: tuple[int, ...]) -> str:
    if all(logarithm % 2 == 0 for logarithm in logs):
        return "even-only"
    names = {
        (1, 2): "5-coset",
        (2, 21): "14-coset",
        (1, 2, 21): "paired-5-and-14-cosets",
    }
    return names[logs]


@dataclass(frozen=True)
class Survivor:
    ell: int
    p: int
    r19_log: int
    b: int
    factors: tuple[tuple[int, int], ...]
    logs: tuple[int, ...]
    state: tuple[tuple[int, int, int], tuple[int, int, int]]

    @property
    def profile(self) -> tuple[int, ...]:
        return profile(self.logs)


def census(bound: int) -> tuple[dict[str, int], tuple[Survivor, ...]]:
    counts = Counter()
    survivors = []
    for ell in primerange(2, bound + 1):
        counts["ell_primes"] += 1
        if ell in (5, 13, 19, 23):
            continue
        if ell % 3 != 1:
            continue
        counts["ell_mod3"] += 1
        r19_log = R19_LOG[ell % 19]
        if r19_log not in (0, 5):
            continue
        counts[f"r19_log_{r19_log}"] += 1
        p = 260 * ell - 19
        if not isprime(p):
            continue
        counts["prime_pairs"] += 1
        counts[f"prime_pairs_log_{r19_log}"] += 1

        assert p % 12 == 1
        b = (65 * ell + 1) // 3
        assert 12 * b == p + 23
        factors_dict = factorint(b)
        assert all(isprime(q) for q in factors_dict)
        assert 23 not in factors_dict
        logs = factor_logs(factors_dict, 23, R23_LOG)
        state = r23_state(logs)
        if r23_occupied(logs):
            counts["r23_occupied"] += 1
        else:
            counts["r23_empty"] += 1
            counts[f"r23_empty_log_{r19_log}"] += 1
            if logs and all(value % 2 == 0 for value in logs):
                counts["r23_empty_even_only"] += 1
            elif logs:
                counts["r23_empty_odd_bearing"] += 1
            else:
                counts["r23_empty_trivial_monomial"] += 1
            survivors.append(
                Survivor(
                    ell=ell,
                    p=p,
                    r19_log=r19_log,
                    b=b,
                    factors=tuple(sorted(factors_dict.items())),
                    logs=logs,
                    state=state,
                )
            )
    return dict(counts), tuple(survivors)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bound", type=int, default=DEFAULT_BOUND)
    parser.add_argument("--show-rows", action="store_true")
    args = parser.parse_args()

    counts, survivors = census(args.bound)
    profiles = {row.profile for row in survivors}
    maximal = maximal_profiles(profiles)
    pattern_counts = Counter(survivor_kind(row.logs) for row in survivors)
    class_pattern_counts = Counter(
        (row.r19_log, survivor_kind(row.logs)) for row in survivors
    )

    survivor_serialization = "\n".join(
        f"{row.ell}|{row.p}|{row.r19_log}|{row.b}|{row.factors}|{row.logs}|{row.state}"
        for row in survivors
    )
    profile_serialization = "\n".join(compact_profile(row) for row in maximal)
    survivor_hash = hashlib.sha256(
        survivor_serialization.encode("ascii")
    ).hexdigest()

    # Exact local complement classification once the forced factor 2 is present.
    safe_odd_pairs = tuple(
        logarithm
        for logarithm in range(1, 22, 2)
        if not r23_occupied(tuple(sorted((2, logarithm))))
    )
    extension_12 = tuple(
        logarithm
        for logarithm in range(1, 22)
        if not r23_occupied(tuple(sorted((1, 2, logarithm))))
    )
    extension_221 = tuple(
        logarithm
        for logarithm in range(1, 22)
        if not r23_occupied(tuple(sorted((2, 21, logarithm))))
    )
    extension_1221 = tuple(
        logarithm
        for logarithm in range(1, 22)
        if not r23_occupied(tuple(sorted((1, 2, 21, logarithm))))
    )
    assert safe_odd_pairs == (1, 21)
    assert extension_12 == (21,)
    assert extension_221 == (1,)
    assert extension_1221 == ()
    assert all(
        survivor_kind(row.logs) in {
            "even-only",
            "5-coset",
            "14-coset",
            "paired-5-and-14-cosets",
        }
        for row in survivors
    )

    if args.bound == DEFAULT_BOUND:
        assert counts == EXPECTED_DEFAULT_COUNTS
        assert survivor_hash == EXPECTED_DEFAULT_SURVIVOR_HASH

    print("PASS: prime-cofactor R=19 blade / R=23 pullback census")
    print(f"ell bound: {args.bound}")
    print("counts: " + repr(dict(sorted(counts.items()))))
    print(f"distinct empty profiles: {len(profiles)}")
    print(f"maximal realized empty profiles: {len(maximal)}")
    print("empty-pattern counts: " + repr(dict(sorted(pattern_counts.items()))))
    print(
        "R19-class / empty-pattern counts: "
        + repr(dict(sorted(class_pattern_counts.items())))
    )
    for kind in sorted(pattern_counts):
        rows = tuple(row for row in survivors if survivor_kind(row.logs) == kind)
        for label, row in (("first", rows[0]), ("last", rows[-1])):
            print(
                f"  {kind} {label}: ell={row.ell}; p={row.p}; b={row.b}; "
                f"factors={factor_signature(dict(row.factors))}; logs={row.logs}"
            )
    longest = max(survivors, key=lambda row: (len(row.logs), row.ell))
    print(
        f"longest empty log multiset: length={len(longest.logs)}; "
        f"ell={longest.ell}; logs={longest.logs}"
    )
    print("exact forced-log classification: odd pair survivors=(1,21); "
          "extensions of (1,2)=(21); extensions of (2,21)=(1); "
          "extensions of (1,2,21)=empty")
    if args.show_rows:
        print("empty rows:")
        for row in survivors:
            print(
                f"  ell={row.ell}; p={row.p}; log19={row.r19_log}; "
                f"b={row.b}; factors={factor_signature(dict(row.factors))}; "
                f"logs={row.logs}; state={row.state}"
            )
    print("survivor SHA-256: " + survivor_hash)
    print(
        "maximal-profile SHA-256: "
        + hashlib.sha256(profile_serialization.encode("ascii")).hexdigest()
    )


if __name__ == "__main__":
    main()

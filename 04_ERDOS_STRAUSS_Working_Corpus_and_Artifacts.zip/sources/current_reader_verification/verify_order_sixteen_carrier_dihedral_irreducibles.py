#!/usr/bin/env python3
"""Exact irreducible D8 decompositions of the order-16 carrier actions."""

from __future__ import annotations

from fractions import Fraction

from verify_order_sixteen_four_sheet_carrier import CARRIERS
from verify_order_sixteen_carrier_inversion_blade import (
    carrier_inverse,
    sheet_inverse,
)
from verify_order_sixteen_carrier_dihedral_fourier import cell_rotation_power


IRREDUCIBLE_SIGNS = {
    "chi_pp": (1, 1),
    "chi_pm": (1, -1),
    "chi_mp": (-1, 1),
    "chi_mm": (-1, -1),
}

EXPECTED_CHARACTERS = {
    "C16": (16, 0, 0, 0, 2, 2, 2, 2),
    "C8xC2": (16, 0, 0, 0, 4, 4, 4, 4),
    "C4xC4": (16, 0, 0, 0, 4, 0, 4, 0),
    "C4xC2xC2": (16, 0, 0, 0, 8, 0, 8, 0),
}

EXPECTED_MULTIPLICITIES = {
    "C16": (3, 1, 2, 2, 4),
    "C8xC2": (4, 0, 2, 2, 4),
    "C4xC4": (3, 1, 3, 1, 4),
    "C4xC2xC2": (4, 0, 4, 0, 4),
}

EXPECTED_ORBIT_MODULES = {
    "C16": ("V0", "V1", "Reg"),
    "C8xC2": ("V0", "V0", "V1", "V1"),
    "C4xC4": ("V0", "V0", "Reg"),
    "C4xC2xC2": ("V0", "V0", "V0", "V0"),
}

NONSPLIT_CARRIERS = {"C16", "C8xC2"}


def group_action(carrier, coordinate, rotation_exponent: int, reflected: int):
    answer = coordinate
    if reflected:
        answer = carrier_inverse(carrier, answer)
    return cell_rotation_power(answer, rotation_exponent)


def permutation_character(carrier) -> tuple[int, ...]:
    coordinates = tuple(carrier.coordinates().values())
    return tuple(
        sum(
            group_action(carrier, coordinate, rotation_exponent, reflected)
            == coordinate
            for coordinate in coordinates
        )
        for reflected in range(2)
        for rotation_exponent in range(4)
    )


def one_dimensional_character(
    rotation_sign: int,
    reflection_sign: int,
) -> tuple[int, ...]:
    return tuple(
        rotation_sign**rotation_exponent * reflection_sign**reflected
        for reflected in range(2)
        for rotation_exponent in range(4)
    )


RHO_CHARACTER = (2, 0, -2, 0, 0, 0, 0, 0)


def character_inner_product(left: tuple[int, ...], right: tuple[int, ...]) -> int:
    answer = Fraction(sum(a * b for a, b in zip(left, right, strict=True)), 8)
    assert answer.denominator == 1
    return answer.numerator


def irreducible_multiplicities(character: tuple[int, ...]) -> tuple[int, ...]:
    one_dimensional = tuple(
        character_inner_product(
            character,
            one_dimensional_character(rotation_sign, reflection_sign),
        )
        for rotation_sign, reflection_sign in IRREDUCIBLE_SIGNS.values()
    )
    return one_dimensional + (character_inner_product(character, RHO_CHARACTER),)


def carrier_orbit_modules(carrier) -> tuple[str, ...]:
    modules = []
    remaining = set(carrier.sheets)
    while remaining:
        sheet = min(remaining)
        opposite = sheet_inverse(carrier, sheet)
        if opposite != sheet:
            modules.append("Reg")
            remaining.remove(sheet)
            remaining.remove(opposite)
            continue
        carry = carrier.cocycle(sheet, opposite)
        modules.append("V0" if carry % 2 == 0 else "V1")
        remaining.remove(sheet)
    return tuple(sorted(modules))


def verify_irreducible_decomposition(carrier) -> dict[str, object]:
    character = permutation_character(carrier)
    assert character == EXPECTED_CHARACTERS[carrier.name]

    multiplicities = irreducible_multiplicities(character)
    assert multiplicities == EXPECTED_MULTIPLICITIES[carrier.name]
    assert (
        sum(multiplicities[:4]) + 2 * multiplicities[4]
        == 16
    )

    modules = carrier_orbit_modules(carrier)
    assert modules == tuple(sorted(EXPECTED_ORBIT_MODULES[carrier.name]))

    chi_pp, chi_pm, chi_mp, chi_mm, rho = multiplicities
    identity_trace = character[0]
    inversion_trace = character[4]
    rotated_inversion_trace = character[5]
    assert identity_trace == 16
    assert inversion_trace // 2 == chi_mp - chi_pm
    assert rotated_inversion_trace // 2 == chi_mm - chi_pm
    assert (rotated_inversion_trace > 0) == (
        carrier.name in NONSPLIT_CARRIERS
    )
    assert (chi_mm > chi_pm) == (carrier.name in NONSPLIT_CARRIERS)
    assert rho == 4

    return {
        "character": character,
        "modules": modules,
        "multiplicities": multiplicities,
        "rotated_inversion_trace": rotated_inversion_trace,
    }


def main() -> None:
    for carrier in CARRIERS:
        result = verify_irreducible_decomposition(carrier)
        print(
            f"{carrier.name}: character={result['character']}, "
            f"orbit_modules={result['modules']}, "
            f"multiplicities={result['multiplicities']}, "
            f"trace_RU={result['rotated_inversion_trace']}"
        )
    print(
        "PASS: exact D8 irreducible decompositions and spectral carry criterion"
    )


if __name__ == "__main__":
    main()

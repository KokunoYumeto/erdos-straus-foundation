#!/usr/bin/env python3
"""Exact four-sheet-by-four-cell carriers for the non-elementary groups of order 16."""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Callable, Iterable


Element = tuple[int, ...]
Sheet = tuple[int, ...]


def add_moduli(moduli: tuple[int, ...], x: Element, y: Element) -> Element:
    return tuple((a + b) % modulus for a, b, modulus in zip(x, y, moduli))


def scalar_moduli(moduli: tuple[int, ...], coefficient: int, x: Element) -> Element:
    return tuple((coefficient * a) % modulus for a, modulus in zip(x, moduli))


def sumsets(
    moduli: tuple[int, ...],
    *subsets: Iterable[Element],
) -> frozenset[Element]:
    answer = frozenset({(0,) * len(moduli)})
    for subset in subsets:
        answer = frozenset(
            add_moduli(moduli, left, right)
            for left in answer
            for right in subset
        )
    return answer


def interval(moduli: tuple[int, ...], direction: Element) -> frozenset[Element]:
    return frozenset(
        scalar_moduli(moduli, coefficient, direction)
        for coefficient in (-1, 0, 1)
    )


def binary(moduli: tuple[int, ...], direction: Element) -> frozenset[Element]:
    return frozenset({(0,) * len(moduli), direction})


@dataclass(frozen=True)
class Carrier:
    name: str
    moduli: tuple[int, ...]
    sheets: tuple[Sheet, ...]
    sheet_add: Callable[[Sheet, Sheet], Sheet]
    cocycle: Callable[[Sheet, Sheet], int]
    phi: Callable[[Sheet, int], Element]
    minimum_support: frozenset[Element]
    expected_coordinates: frozenset[tuple[int, ...]]
    expected_projection_sizes: tuple[int, int]
    expected_correlation_defect: int
    expected_coboundary: bool

    @property
    def elements(self) -> tuple[Element, ...]:
        return tuple(itertools.product(*(range(modulus) for modulus in self.moduli)))

    def coordinates(self) -> dict[Element, tuple[Sheet, int]]:
        return {
            self.phi(sheet, cell): (sheet, cell)
            for sheet in self.sheets
            for cell in range(4)
        }


def c4_add(x: Sheet, y: Sheet) -> Sheet:
    return ((x[0] + y[0]) % 4,)


def c2_square_add(x: Sheet, y: Sheet) -> Sheet:
    return (x[0] ^ y[0], x[1] ^ y[1])


def c16_cocycle(x: Sheet, y: Sheet) -> int:
    return (x[0] + y[0]) // 4


def c8c2_cocycle(x: Sheet, y: Sheet) -> int:
    return x[0] * y[0]


def zero_cocycle(_x: Sheet, _y: Sheet) -> int:
    return 0


C4_SHEETS = tuple((x,) for x in range(4))
C2_SQUARE_SHEETS = tuple(itertools.product(range(2), repeat=2))


CARRIERS = (
    Carrier(
        name="C16",
        moduli=(16,),
        sheets=C4_SHEETS,
        sheet_add=c4_add,
        cocycle=c16_cocycle,
        phi=lambda sheet, cell: ((sheet[0] + 4 * cell) % 16,),
        minimum_support=interval((16,), (1,)),
        expected_coordinates=frozenset({(0, 0), (1, 0), (3, 3)}),
        expected_projection_sizes=(3, 2),
        expected_correlation_defect=3,
        expected_coboundary=False,
    ),
    Carrier(
        name="C8xC2",
        moduli=(8, 2),
        sheets=C2_SQUARE_SHEETS,
        sheet_add=c2_square_add,
        cocycle=c8c2_cocycle,
        phi=lambda sheet, cell: ((sheet[0] + 2 * cell) % 8, sheet[1]),
        minimum_support=sumsets(
            (8, 2),
            interval((8, 2), (1, 0)),
            binary((8, 2), (0, 1)),
        ),
        expected_coordinates=frozenset(
            {
                (0, 0, 0),
                (0, 1, 0),
                (1, 0, 0),
                (1, 0, 3),
                (1, 1, 0),
                (1, 1, 3),
            }
        ),
        expected_projection_sizes=(4, 2),
        expected_correlation_defect=2,
        expected_coboundary=False,
    ),
    Carrier(
        name="C4xC4",
        moduli=(4, 4),
        sheets=C4_SHEETS,
        sheet_add=c4_add,
        cocycle=zero_cocycle,
        phi=lambda sheet, cell: (cell, sheet[0]),
        minimum_support=sumsets(
            (4, 4),
            interval((4, 4), (1, 0)),
            interval((4, 4), (0, 1)),
        ),
        expected_coordinates=frozenset(
            (sheet, cell)
            for sheet in (0, 1, 3)
            for cell in (0, 1, 3)
        ),
        expected_projection_sizes=(3, 3),
        expected_correlation_defect=0,
        expected_coboundary=True,
    ),
    Carrier(
        name="C4xC2xC2",
        moduli=(4, 2, 2),
        sheets=C2_SQUARE_SHEETS,
        sheet_add=c2_square_add,
        cocycle=zero_cocycle,
        phi=lambda sheet, cell: (cell, sheet[0], sheet[1]),
        minimum_support=sumsets(
            (4, 2, 2),
            interval((4, 2, 2), (1, 0, 0)),
            binary((4, 2, 2), (0, 1, 0)),
            binary((4, 2, 2), (0, 0, 1)),
        ),
        expected_coordinates=frozenset(
            (first, second, cell)
            for first, second in C2_SQUARE_SHEETS
            for cell in (0, 1, 3)
        ),
        expected_projection_sizes=(4, 3),
        expected_correlation_defect=0,
        expected_coboundary=True,
    ),
)


def cochain(code: int, sheet_index: int) -> int:
    if sheet_index == 0:
        return 0
    return (code // (4 ** (sheet_index - 1))) % 4


def cocycle_is_coboundary(carrier: Carrier) -> bool:
    sheet_index = {sheet: index for index, sheet in enumerate(carrier.sheets)}
    for code in range(4 ** 3):
        good = True
        for left in carrier.sheets:
            for right in carrier.sheets:
                total = carrier.sheet_add(left, right)
                coboundary = (
                    cochain(code, sheet_index[left])
                    + cochain(code, sheet_index[right])
                    - cochain(code, sheet_index[total])
                ) % 4
                if carrier.cocycle(left, right) % 4 != coboundary:
                    good = False
                    break
            if not good:
                break
        if good:
            return True
    return False


def verify_carrier(carrier: Carrier) -> dict[str, object]:
    coordinates = carrier.coordinates()
    assert len(coordinates) == 16
    assert set(coordinates) == set(carrier.elements)

    for left_sheet in carrier.sheets:
        for right_sheet in carrier.sheets:
            for left_cell in range(4):
                for right_cell in range(4):
                    left = carrier.phi(left_sheet, left_cell)
                    right = carrier.phi(right_sheet, right_cell)
                    actual = add_moduli(carrier.moduli, left, right)
                    expected = carrier.phi(
                        carrier.sheet_add(left_sheet, right_sheet),
                        (
                            left_cell
                            + right_cell
                            + carrier.cocycle(left_sheet, right_sheet)
                        )
                        % 4,
                    )
                    assert actual == expected

    zero_sheet = carrier.sheets[0]
    for sheet in carrier.sheets:
        assert carrier.cocycle(zero_sheet, sheet) == 0
        assert carrier.cocycle(sheet, zero_sheet) == 0
    for first in carrier.sheets:
        for second in carrier.sheets:
            for third in carrier.sheets:
                left = (
                    carrier.cocycle(first, second)
                    + carrier.cocycle(carrier.sheet_add(first, second), third)
                ) % 4
                right = (
                    carrier.cocycle(second, third)
                    + carrier.cocycle(first, carrier.sheet_add(second, third))
                ) % 4
                assert left == right

    inverse = carrier.coordinates()
    minimum_coordinates = frozenset(
        (*inverse[element][0], inverse[element][1])
        for element in carrier.minimum_support
    )
    assert minimum_coordinates == carrier.expected_coordinates
    sheet_projection = {coordinate[:-1] for coordinate in minimum_coordinates}
    cell_projection = {coordinate[-1] for coordinate in minimum_coordinates}
    projection_sizes = (len(sheet_projection), len(cell_projection))
    defect = projection_sizes[0] * projection_sizes[1] - len(minimum_coordinates)
    assert projection_sizes == carrier.expected_projection_sizes
    assert defect == carrier.expected_correlation_defect

    coboundary = cocycle_is_coboundary(carrier)
    assert coboundary == carrier.expected_coboundary
    return {
        "coordinates": tuple(sorted(minimum_coordinates)),
        "projection_sizes": projection_sizes,
        "defect": defect,
        "coboundary": coboundary,
    }


def main() -> None:
    for carrier in CARRIERS:
        result = verify_carrier(carrier)
        print(
            f"{carrier.name}: carrier=4x4, "
            f"cocycle_coboundary={result['coboundary']}, "
            f"minimum={len(carrier.minimum_support)}, "
            f"projection_sizes={result['projection_sizes']}, "
            f"correlation_defect={result['defect']}"
        )
        print(f"{carrier.name}: minimum_coordinates={result['coordinates']}")
    print("PASS: exact order-sixteen four-sheet carriers and minimum-support locations")


if __name__ == "__main__":
    main()

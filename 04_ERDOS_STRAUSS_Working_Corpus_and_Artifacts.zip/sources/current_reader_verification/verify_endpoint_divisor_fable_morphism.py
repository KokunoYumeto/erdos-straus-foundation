from fractions import Fraction


q = Fraction(-1, 2)
rho_0 = Fraction(-1, 2)
rho_1 = Fraction(1, 2)

residue_zero = Fraction(1)
residue_one = Fraction(1)
residue_infinity = -(residue_zero + residue_one)

equalizer_second_value = -Fraction(1) * (1 + Fraction(1))
fable_jacobian = 4 * q

tau = (Fraction(0), 0)
supported_zero = (Fraction(0), 1)
analytic_zero_image = supported_zero

checks = [
    ("centered endpoint product is -1/4", rho_0 * rho_1 == Fraction(-1, 4)),
    ("finite logarithmic residues are 1 and 1",
     residue_zero == 1 and residue_one == 1),
    ("projective logarithmic residue is -2", residue_infinity == -2),
    ("equalizer second component is -2", equalizer_second_value == -2),
    ("fourfold zeta endpoint is -2", fable_jacobian == -2),
    ("zeta endpoint inverse is -2", q != 0 and 1 / q == -2),
    ("analytic zero enters the supported sheet", analytic_zero_image == supported_zero),
    ("supported zero and absence remain different", supported_zero != tau),
]

for name, passed in checks:
    print(f"{name}: {'PASS' if passed else 'FAIL'}")

if not all(passed for _, passed in checks):
    raise SystemExit(1)

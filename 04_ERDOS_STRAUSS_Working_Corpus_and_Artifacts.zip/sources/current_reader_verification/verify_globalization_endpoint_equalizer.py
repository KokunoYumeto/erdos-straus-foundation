from fractions import Fraction


def zeta_endpoint_sheet(u: Fraction) -> Fraction:
    q = Fraction(-1, 2)
    return (1 + u) * q - u


def stone_defect(u: Fraction) -> Fraction:
    lam = 1 + u
    return lam - lam * lam


def common_value_inverse(w: Fraction) -> Fraction:
    return -(2 * w + 1) / 3


q = Fraction(-1, 2)

for u in (Fraction(-7, 3), Fraction(-1, 2), Fraction(0), Fraction(1), Fraction(9, 5)):
    lhs = zeta_endpoint_sheet(u) - stone_defect(u)
    rhs = (u - 1) * (u + Fraction(1, 2))
    assert lhs == rhs

equalizer_points = (Fraction(-1, 2), Fraction(1))
equalizer_values = (Fraction(1, 4), Fraction(-2))

for u, w in zip(equalizer_points, equalizer_values):
    assert zeta_endpoint_sheet(u) == w
    assert stone_defect(u) == w
    assert common_value_inverse(w) == u
    assert (u - 1) * (2 * u + 1) == 0
    assert (4 * w - 1) * (w + 2) == 0

assert q * q == Fraction(1, 4)
assert q * (-q) == Fraction(-1, 4)
assert 4 * q == q ** -1 == Fraction(-2)

print("globalization equalizer factorization: PASS")
print("equalizer component u=-1/2 has common value +1/4: PASS")
print("equalizer component u=1 has common value -2: PASS")
print("common-value inverse u=-(2w+1)/3: PASS")
print("centered reflection changes q^2 to q(-q)=-1/4: PASS")
print("Fable Jacobian scalar 4q=q^(-1)=-2: PASS")

import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def matrix_equal(left, right, label):
    require(left.shape == right.shape, f"{label}: shape")
    for entry in left - right:
        if sp.simplify(entry) != 0:
            raise AssertionError(f"{label}: {sp.factor(entry)}")


# Symbolic three-orbit model.
h1, h2, h3 = sp.symbols("h1 h2 h3", positive=True)
t = sp.symbols("t")
hs = [h1, h2, h3]
sigma_x = sp.Matrix([[0, 1], [1, 0]])
P = sp.diag(sigma_x, sigma_x, sigma_x)
H = sp.diag(h1, h1, h2, h2, h3, h3)
D = H * H
Lambda = H * P

Jplus = sp.zeros(6, 3)
for orbit in range(3):
    Jplus[2 * orbit, orbit] = 1 / sp.sqrt(2)
    Jplus[2 * orbit + 1, orbit] = 1 / sp.sqrt(2)

matrix_equal(Jplus.T * Jplus, sp.eye(3), "invariant isometry")
matrix_equal(
    Jplus.T * D * Jplus,
    sp.diag(h1**2, h2**2, h3**2),
    "quotient amplitude operator",
)

expected_lambda_poly = sp.prod(t**2 - h**2 for h in hs)
expected_D_poly = sp.prod((t - h**2) ** 2 for h in hs)
require(
    sp.factor(Lambda.charpoly(t).as_expr() - expected_lambda_poly) == 0,
    "signed characteristic polynomial",
)
require(
    sp.factor(D.charpoly(t).as_expr() - expected_D_poly) == 0,
    "amplitude characteristic polynomial",
)

for k in range(4):
    require(sp.simplify(sp.trace(Lambda ** (2 * k + 1))) == 0, f"odd moment {k}")
for k in range(1, 5):
    expected = 2 * sum(h ** (2 * k) for h in hs)
    require(sp.simplify(sp.trace(Lambda ** (2 * k)) - expected) == 0, f"even moment {k}")
    require(sp.simplify(sp.trace(D**k) - expected) == 0, f"amplitude moment {k}")


# Exact 12289 shell.
p = 12289
a = 3075
R0 = 11
N0 = p * a
divisors = sorted(
    int(d)
    for d in sp.divisors(N0 * N0)
    if (int(d) + N0) % R0 == 0
)
require(len(divisors) == 12, "12289 shell size")

low = [d for d in divisors if d < N0]
require(
    low == [615, 5125, 61445, 230625, 2765025, 23041875],
    "ordered orbit representatives",
)

orbit_alphas = [
    sp.Rational(4 * N0 * d, (N0 + d) ** 2)
    for d in low
]
expected_alphas = [
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(615, 94864),
    sp.Rational(921675, 38217124),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
]
require(orbit_alphas == expected_alphas, "six exact orbit amplitudes")
require(len(set(orbit_alphas)) == 6, "pairwise distinct orbit amplitudes")

full_alpha_sum = sum(
    sp.Rational(4 * N0 * d, (N0 + d) ** 2)
    for d in divisors
)
require(
    sp.simplify(full_alpha_sum - 2 * sum(orbit_alphas)) == 0,
    "orbit amplitude sum",
)

ainv = pow(a, -1, R0)
pinv = pow(p, -1, R0)
targets = {0: (-p) % R0, 1: (-1) % R0, 2: (-pinv) % R0}
X = []
for j in range(3):
    for u in sp.divisors(a * a):
        if (int(u) * ainv) % R0 == targets[j]:
            X.append((j, int(u), p**j * int(u)))

origin_counts = {
    j: sum(1 for jj, _, _ in X if jj == j)
    for j in range(3)
}
require(origin_counts == {0: 3, 1: 6, 2: 3}, "origin counts")

external_pairs = 0
middle_pairs = 0
seen = set()
for j, u, d in X:
    if d in seen:
        continue
    e = N0 * N0 // d
    seen.add(d)
    seen.add(e)
    reflected_j = 2 - j
    if {j, reflected_j} == {0, 2}:
        external_pairs += 1
    elif j == 1 and reflected_j == 1:
        middle_pairs += 1
    else:
        raise AssertionError("unexpected orbit type")

require((external_pairs, middle_pairs) == (3, 3), "orbit-type counts")
require(external_pairs + middle_pairs == 6, "quotient carrier count")

lines = [
    "PASS: exact complement-orbit spectral descent",
    "symbolic complement blocks have spectra +sqrt(alpha_O) and -sqrt(alpha_O)",
    "the quotient invariant space carries one exact alpha_O eigenvalue per orbit",
    "all odd signed moments vanish and every even moment is twice the quotient moment",
    "the signed and unsigned characteristic polynomials factor orbit by orbit",
    "12289 has six complement orbits: three exterior and three middle",
    "the six exact 12289 orbit amplitudes match the maintained theorem",
    "the six 12289 orbit amplitudes are pairwise distinct",
    "the full shell amplitude is twice the sum of the quotient amplitudes",
    "the two-valued parity coefficient function retains the orbit counts but not the six amplitude values",
]

print("\n".join(lines))

from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(value):
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    trial = 3
    while trial <= isqrt(value):
        if value % trial == 0:
            return False
        trial += 2
    return True


def factorization(value):
    factors = {}
    trial = 2
    while trial * trial <= value:
        while value % trial == 0:
            factors[trial] = factors.get(trial, 0) + 1
            value //= trial
        trial = 3 if trial == 2 else trial + 2
    if value > 1:
        factors[value] = factors.get(value, 0) + 1
    return factors


def divisors_from_factorization(factors):
    divisors = [1]
    for prime, exponent in factors.items():
        divisors = [
            divisor * prime**power
            for divisor in divisors
            for power in range(exponent + 1)
        ]
    return sorted(divisors)


def shell_sets(prime, residual):
    denominator = (prime + residual) // 4
    divisors = divisors_from_factorization(factorization(denominator**2))
    exterior = [value for value in divisors if (4 * value + 1) % residual == 0]
    middle = [value for value in divisors if (value + denominator) % residual == 0]
    return denominator, exterior, middle


def occupied(prime, residual):
    _, exterior, middle = shell_sets(prime, residual)
    return bool(exterior or middle)


SPLIT = {
    3: {1},
    7: {1, 2, 4},
    11: {1, 3, 4, 5, 9},
    15: {1, 2, 4, 8},
    19: {1, 4, 5, 6, 7, 9, 11, 16, 17},
}


def split_supported(value, residual):
    return all(
        prime % residual in SPLIT[residual]
        for prime in factorization(value)
    )


def first_occupied_after_23(prime, ceiling=403):
    for residual in range(27, ceiling + 1, 4):
        if occupied(prime, residual):
            return residual
    return None


BOUND = 20_000_000
CLASS_MODULUS = 35_420

classes = [
    d
    for d in range(CLASS_MODULUS)
    if d % 4 == 3
    and d % 23 in {3, 9}
    and d % 7 in {1, 5, 6}
    and d % 11 in {1, 3, 4, 5, 9}
    and d % 5 in {0, 2}
]

rows = []
for residue_class in classes:
    d = residue_class if residue_class > 0 else CLASS_MODULUS
    while True:
        prime = 36 * d - 11
        if prime >= BOUND:
            break
        if is_prime(prime):
            if occupied(prime, 23):
                d += CLASS_MODULUS
                continue
            fingers = (
                9 * d - 2,
                (9 * d - 1) // 2,
                d,
                (9 * d + 1) // 2,
                9 * d + 2,
            )
            split_flags = tuple(
                split_supported(value, residual)
                for value, residual in zip(fingers, (3, 7, 11, 15, 19))
            )
            empty_flags = tuple(
                not occupied(prime, residual)
                for residual in (3, 7, 11, 15, 19)
            )
            if split_flags[:4] != empty_flags[:4]:
                raise AssertionError(
                    ("first-four split equivalence", prime, split_flags, empty_flags)
                )
            if split_flags[4] and not empty_flags[4]:
                raise AssertionError(
                    ("residual-nineteen split safe face", prime, fingers[4])
                )
            rows.append((prime, d, fingers, split_flags, empty_flags))
        d += CLASS_MODULUS

first_four = [row for row in rows if all(row[3][:4])]
all_five = [row for row in first_four if all(row[3])]
residual_nineteen_empty = [row for row in first_four if row[4][4]]

observed_all_five = sorted([
    (
        prime,
        d,
        fingers,
        tuple(sorted(factorization(fingers[4]).items())),
        first_occupied_after_23(prime),
    )
    for prime, d, fingers, _, _ in all_five
])

expected_all_five = [
    (3_368_401, 93_567, (842_101, 421_051, 93_567, 421_052, 842_105),
     ((5, 1), (11, 1), (61, 1), (251, 1)), 27),
    (5_153_569, 143_155, (1_288_393, 644_197, 143_155, 644_198, 1_288_397),
     ((11, 1), (117_127, 1)), 39),
    (5_719_921, 158_887, (1_429_981, 714_991, 158_887, 714_992, 1_429_985),
     ((5, 1), (285_997, 1)), 27),
    (7_273_249, 202_035, (1_818_313, 909_157, 202_035, 909_158, 1_818_317),
     ((1_818_317, 1),), 31),
    (9_527_281, 264_647, (2_381_821, 1_190_911, 264_647, 1_190_912, 2_381_825),
     ((5, 2), (95_273, 1)), 31),
    (11_996_161, 333_227, (2_999_041, 1_499_521, 333_227, 1_499_522, 2_999_045),
     ((5, 1), (7, 2), (12_241, 1)), 31),
    (13_503_121, 375_087, (3_375_781, 1_687_891, 375_087, 1_687_892, 3_375_785),
     ((5, 1), (7, 1), (96_451, 1)), 31),
    (15_866_449, 440_735, (3_966_613, 1_983_307, 440_735, 1_983_308, 3_966_617),
     ((3_966_617, 1),), 31),
    (17_722_609, 492_295, (4_430_653, 2_215_327, 492_295, 2_215_328, 4_430_657),
     ((7, 1), (11, 2), (5_231, 1)), 27),
    (17_904_769, 497_355, (4_476_193, 2_238_097, 497_355, 2_238_098, 4_476_197),
     ((11, 1), (503, 1), (809, 1)), 31),
]

report("three-adic residue-class count", len(classes) == 60)
report("bounded three-adic empty-edge row count", len(rows) == 147)
report("bounded first-four split row count", len(first_four) == 25)
report("bounded all-five split row count", len(all_five) == 10)
report("bounded residual-nineteen empty count", len(residual_nineteen_empty) == 14)
if observed_all_five != expected_all_five:
    print("observed all-five rows:")
    for row in observed_all_five:
        print(row)
    print("expected all-five rows:")
    for row in expected_all_five:
        print(row)
report("bounded all-five split rows", observed_all_five == expected_all_five)

p = 3_368_401
d = 93_567
fingers = (842_101, 421_051, 93_567, 421_052, 842_105)
expected_finger_factorizations = (
    {13: 1, 211: 1, 307: 1},
    {29: 1, 14_519: 1},
    {3: 1, 31_189: 1},
    {2: 2, 105_263: 1},
    {5: 1, 11: 1, 61: 1, 251: 1},
)

report("least all-five row prime", is_prime(p))
report(
    "least all-five row Pocklington certificate",
    p - 1 == 2**4 * 3 * 5**2 * 7 * 401
    and is_prime(401)
    and pow(31, p - 1, p) == 1
    and tuple(pow(31, (p - 1) // q, p) for q in (2, 3, 5, 7, 401))
    == (3_368_400, 2_938_148, 263_135, 1_806_350, 1_223_878)
    and all(
        gcd(pow(31, (p - 1) // q, p) - 1, p) == 1
        for q in (2, 3, 5, 7, 401)
    ),
)
report("least all-five row affine parameter", p == 36 * d - 11)
report(
    "least all-five row coordinates",
    fingers
    == (
        9 * d - 2,
        (9 * d - 1) // 2,
        d,
        (9 * d + 1) // 2,
        9 * d + 2,
    ),
)
report(
    "least all-five row Finger factorizations",
    tuple(factorization(value) for value in fingers)
    == expected_finger_factorizations,
)
report(
    "least all-five row split support",
    all(
        split_supported(value, residual)
        for value, residual in zip(fingers, (3, 7, 11, 15, 19))
    ),
)
report(
    "least all-five row first six shells empty",
    all(not occupied(p, residual) for residual in (3, 7, 11, 15, 19, 23)),
)

residual = 27
a, exterior, middle = shell_sets(p, residual)
u = exterior[0]
N = p * a
D = p**2 * u
complement = N**2 // D
b = (N + D) // residual
c = (N + complement) // residual

report("residual-twenty-seven denominator", a == 842_107)
report(
    "residual-twenty-seven denominator factorization",
    factorization(a) == {7: 1, 59: 1, 2_039: 1},
)
report("residual-twenty-seven exterior set", exterior == [49_684_313])
report("residual-twenty-seven middle set", middle == [])
report("residual-twenty-seven orbit count", len(exterior) + len(middle) // 2 == 1)
report("unique exterior seed", u == 59 * a)
report("origin-two divisor", D == 563_724_440_583_478_782_713)
report("complement divisor", complement == 14_273 == a // 59)
report(
    "reconstructed denominators",
    (a, b, c) == (842_107, 20_878_683_089_630_846_060, 105_057_558_340),
)
report(
    "Erdos-Straus identity by cross multiplication",
    4 * a * b * c == p * (a * b + a * c + b * c),
)

progression_modulus = 6_372
progression_residue = 3_985
report(
    "residual-twenty-seven exterior progression congruences",
    p % progression_modulus == progression_residue
    and (progression_residue + 27) % 236 == 0
    and (59 * progression_residue + 1) % 27 == 0,
)
report(
    "residual-twenty-seven exterior progression",
    b == p * (p + 27) * (59 * p + 1) // 108
    and c == (p + 27) * (59 * p + 1) // 6_372
    and 4 * p * (59 * p + 1) + 108 + 6_372 * p
    == 4 * (p + 27) * (59 * p + 1),
)

print(f"bound={BOUND}")
print(f"three-adic empty R=23 edge rows={len(rows)}")
print(f"first-four split-supported rows={len(first_four)}")
print(f"all-five split-supported rows={len(all_five)}")
print(f"residual-nineteen empty first-four rows={len(residual_nineteen_empty)}")
for row in observed_all_five:
    print(row)
print(f"least row p={p}")
print(f"least row d={d}")
print(f"least row Fingers={fingers}")
print(f"R=27 exterior={exterior}")
print(f"R=27 middle={middle}")
print(f"N={N}")
print(f"D={D}")
print(f"N^2/D={complement}")
print(f"(a,b,c)={(a,b,c)}")

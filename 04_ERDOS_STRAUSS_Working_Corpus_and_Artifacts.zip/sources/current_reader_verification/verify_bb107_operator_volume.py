#!/usr/bin/env python3
"""Independent finite-field checks for the BB(5)/107 rigidity package.

This checker intentionally avoids the large eta-product coefficient replay.
It verifies the displayed arithmetic, the 5-by-5 matrices, and the resulting
25-dimensional algebraic-volume determinant using only exact integer
arithmetic modulo 107.
"""

from __future__ import annotations

from itertools import product
from math import comb, gcd, isqrt


P = 107


def mat_identity(n: int) -> list[list[int]]:
    return [[int(i == j) for j in range(n)] for i in range(n)]


def mat_mul(a: list[list[int]], b: list[list[int]]) -> list[list[int]]:
    return [
        [sum(a[i][k] * b[k][j] for k in range(len(b))) % P
         for j in range(len(b[0]))]
        for i in range(len(a))
    ]


def mat_sub(a: list[list[int]], b: list[list[int]]) -> list[list[int]]:
    return [[(x - y) % P for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def mat_pow(a: list[list[int]], exponent: int) -> list[list[int]]:
    out = mat_identity(len(a))
    base = a
    e = exponent
    while e:
        if e & 1:
            out = mat_mul(out, base)
        base = mat_mul(base, base)
        e >>= 1
    return out


def det_mod(matrix: list[list[int]]) -> int:
    a = [[x % P for x in row] for row in matrix]
    n = len(a)
    determinant = 1
    for column in range(n):
        pivot = next((r for r in range(column, n) if a[r][column]), None)
        if pivot is None:
            return 0
        if pivot != column:
            a[column], a[pivot] = a[pivot], a[column]
            determinant = -determinant
        pivot_value = a[column][column]
        determinant = determinant * pivot_value % P
        inverse = pow(pivot_value, -1, P)
        a[column] = [(inverse * x) % P for x in a[column]]
        for row in range(column + 1, n):
            factor = a[row][column]
            if factor:
                a[row] = [
                    (x - factor * y) % P
                    for x, y in zip(a[row], a[column])
                ]
    return determinant % P


def mat_inv(matrix: list[list[int]]) -> list[list[int]]:
    n = len(matrix)
    a = [
        [x % P for x in row] + [int(i == j) for j in range(n)]
        for i, row in enumerate(matrix)
    ]
    for column in range(n):
        pivot = next((r for r in range(column, n) if a[r][column]), None)
        if pivot is None:
            raise ValueError("singular matrix")
        a[column], a[pivot] = a[pivot], a[column]
        inverse = pow(a[column][column], -1, P)
        a[column] = [(inverse * x) % P for x in a[column]]
        for row in range(n):
            if row == column:
                continue
            factor = a[row][column]
            if factor:
                a[row] = [
                    (x - factor * y) % P
                    for x, y in zip(a[row], a[column])
                ]
    return [row[n:] for row in a]


def eta_exponent(n: int) -> int:
    return (5 - int(n % 2 == 0) + int(n % 3 == 0)
            - 5 * int(n % 6 == 0))


def eta_product_coefficients(limit: int) -> list[int]:
    coefficients = [0] * (limit + 1)
    coefficients[0] = 1
    for n in range(1, limit + 1):
        exponent = eta_exponent(n)
        if exponent == 0:
            continue
        old = coefficients[:]
        updated = old[:]
        for k in range(1, exponent + 1):
            shift = k * n
            if shift > limit:
                break
            factor = (-1) ** k * comb(exponent, k)
            for index in range(shift, limit + 1):
                updated[index] += factor * old[index - shift]
        coefficients = [x % P for x in updated]
    return coefficients


def invert_series(coefficients: list[int]) -> list[int]:
    inverse = [0] * len(coefficients)
    inverse[0] = 1
    for n in range(1, len(coefficients)):
        inverse[n] = -sum(
            coefficients[k] * inverse[n - k] for k in range(1, n + 1)
        ) % P
    return inverse


def eta6_fourth_product(coefficients: list[int]) -> list[int]:
    limit = len(coefficients) - 1
    out = coefficients[:]
    for n in range(1, limit // 6 + 1):
        step = 6 * n
        old = out[:]
        updated = old[:]
        for k, factor in ((1, -4), (2, 6), (3, -4), (4, 1)):
            shift = k * step
            if shift > limit:
                break
            for index in range(shift, limit + 1):
                updated[index] += factor * old[index - shift]
        out = [x % P for x in updated]
    return out


def sigma1(n: int) -> int:
    total = 0
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            total += d
            if d * d != n:
                total += n // d
    return total


def eisenstein_coefficient(n: int) -> int:
    return (
        5 * sigma1(n)
        - (2 * sigma1(n // 2) if n % 2 == 0 else 0)
        + (3 * sigma1(n // 3) if n % 3 == 0 else 0)
        - (30 * sigma1(n // 6) if n % 6 == 0 else 0)
    )


def coefficient_row(
    n: int,
    coefficients: list[int],
    inverse: list[int],
    eta6: list[int],
) -> list[int]:
    t_value = coefficients[n + 1]
    reciprocal_value = inverse[n - 1]
    j_value = (t_value + 72 * reciprocal_value) % P
    f_value = (-2 * eta6[n]) % P
    e_value = eisenstein_coefficient(n) % P
    return [n % P, t_value, f_value, j_value, e_value]


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    for q in range(2, isqrt(n) + 1):
        if n % q == 0:
            return False
    return True


def check(condition: bool, statement: str) -> None:
    if not condition:
        raise AssertionError(statement)
    print(f"PASS: {statement}")


R_B = [
    [102, 34, 19, 16, 67],
    [103, 56, 19, 32, 6],
    [104, 105, 6, 96, 47],
    [105, 83, 77, 1, 48],
    [106, 62, 12, 58, 58],
]

A1 = [
    [0, 1, 0, 0, 0],
    [0, 0, 1, 0, 0],
    [0, 0, 0, 1, 0],
    [0, 0, 0, 0, 1],
    [72, 40, 4, 32, 46],
]

A6 = [
    [62, 30, 43, 97, 102],
    [3, 12, 64, 68, 35],
    [54, 74, 14, 80, 85],
    [13, 76, 44, 102, 40],
    [10, 47, 88, 31, 73],
]


def main() -> None:
    s3 = 21
    s5 = 47_176_870
    sigma5 = 4098
    p_star = 8_803_369
    a_star = 2_200_869
    n_star = p_star * a_star
    space5 = 12_289

    check(pow(s3, -1, P) == p_star % P == 51,
          "S(3)^(-1), p_star, and 51 agree modulo 107")
    check(s5 % P == n_star % P == 35,
          "S(5), p_star*a_star, and 35 agree modulo 107")
    check((s3 * s5) % P == a_star % P == 93,
          "S(3)S(5), a_star, and 93 agree modulo 107")
    check((-s3 * s5) % P == 11**2 % P == 14,
          "-S(3)S(5), 11^2, and 14 agree modulo 107")

    check(space5 == P**2 + 840,
          "12289 equals 107^2+840")
    check(is_prime(space5), "12289 is prime")
    check(space5 % P == (-4**2) % P == 91,
          "12289 and -4^2 agree modulo 107")
    check(space5 % 840 == pow(289, 5, 840) == 529,
          "12289 and 289^5 agree modulo 840 at 529")
    square_image = {
        (u * u) % 840 for u in range(840) if gcd(u, 840) == 1
    }
    check(square_image == {1, 121, 169, 289, 361, 529},
          "the unit-square image modulo 840 is the six-element C6 fiber")

    c_space5 = 5 * (1 + space5)
    check(c_space5 == 61_450 and c_space5 % P == sigma5 % P == 32,
          "the Eisenstein coefficient at 12289 equals Sigma(5) modulo 107")

    coefficient_limit = 755
    coefficients = eta_product_coefficients(coefficient_limit)
    inverse = invert_series(coefficients)
    eta6 = eta6_fourth_product(coefficients)
    derived_r_b = [
        coefficient_row(n, coefficients, inverse, eta6)
        for n in range(744, 749)
    ]
    check(derived_r_b == R_B,
          "the 744--748 coefficient recurrence reproduces R_B")
    inverse_r_b = mat_inv(derived_r_b)
    derived_a1 = mat_mul([
        coefficient_row(n, coefficients, inverse, eta6)
        for n in range(745, 750)
    ], inverse_r_b)
    derived_a6 = mat_mul([
        coefficient_row(n, coefficients, inverse, eta6)
        for n in range(750, 755)
    ], inverse_r_b)
    check(derived_a1 == A1, "the coefficient recurrence reproduces A1")
    check(derived_a6 == A6, "the coefficient recurrence reproduces A6")

    check(det_mod(R_B) == 8, "det(R_B)=8 modulo 107")
    check(det_mod(A1) == 72 and sum(A1[i][i] for i in range(5)) % P == 46,
          "A1 has determinant 72 and trace 46 modulo 107")
    check(det_mod(A6) == 40 and sum(A6[i][i] for i in range(5)) % P == 49,
          "A6 has determinant 40 and trace 49 modulo 107")

    commutator = mat_sub(mat_mul(A1, A6), mat_mul(A6, A1))
    check(det_mod(commutator) == 15,
          "the A1,A6 commutator is invertible with determinant 15")
    check(sum(commutator[i][i] for i in range(5)) % P == 0,
          "the A1,A6 commutator has trace zero")

    powers1 = [mat_pow(A1, i) for i in range(5)]
    powers6 = [mat_pow(A6, j) for j in range(5)]
    vectors: list[list[int]] = []
    for i, j in product(range(5), repeat=2):
        matrix = mat_mul(powers1[i], powers6[j])
        vectors.append([matrix[r][c] for r in range(5) for c in range(5)])
    volume = det_mod(vectors)
    check(volume == 32 == sigma5 % P,
          "the ordered 25-monomial algebraic volume equals Sigma(5) modulo 107")
    check(volume != 0,
          "the 25 monomials A1^i A6^j form a basis of M5(F_107)")


if __name__ == "__main__":
    main()

from collections import defaultdict
from functools import lru_cache
from math import gcd
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


residue_to_exponent = {pow(3, exponent, 7): exponent for exponent in range(6)}


def c6_coefficients(a):
    coefficients = {0: 1}
    for prime, exponent in factorization(a):
        generator_exponent = residue_to_exponent[prime % 7]
        local = defaultdict(int)
        local[0] += 1
        for power in range(1, exponent + 1):
            local[(power * generator_exponent) % 6] += 1
            local[(-power * generator_exponent) % 6] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left + right) % 6] += left_count * right_count
        coefficients = dict(product)
    return coefficients


def occupancy_data(a):
    has_c2_only = False
    has_c3_only = False
    mixed_exponent = 0
    for prime, exponent in factorization(a):
        residue = prime % 7
        if residue == 6:
            has_c2_only = True
        elif residue in (2, 4):
            has_c3_only = True
        elif residue in (3, 5):
            mixed_exponent += exponent
    criterion = (
        has_c2_only
        or mixed_exponent >= 3
        or (mixed_exponent >= 1 and has_c3_only)
    )
    return has_c2_only, has_c3_only, mixed_exponent, criterion


branch_c2_only = False
branch_three_mixed = False
branch_mixed_c3 = False
branch_empty = False

for a in range(1, 20001):
    if gcd(a, 7) != 1:
        continue
    coefficient = c6_coefficients(a).get(3, 0)
    has_c2_only, has_c3_only, mixed_exponent, criterion = occupancy_data(a)
    if (coefficient > 0) != criterion:
        raise AssertionError(
            f"R=7 occupancy criterion fails at a={a}, coefficient={coefficient}"
        )
    if has_c2_only:
        branch_c2_only = True
    elif mixed_exponent >= 3:
        branch_three_mixed = True
    elif mixed_exponent >= 1 and has_c3_only:
        branch_mixed_c3 = True
    elif coefficient == 0:
        branch_empty = True


if not all((branch_c2_only, branch_three_mixed, branch_mixed_c3, branch_empty)):
    raise AssertionError("the exhaustive range did not represent every criterion branch")

print("PASS: exact R=7 coupled-shell occupancy criterion")
print("a prime factor equal to 6 mod 7 reaches the target directly")
print("three mixed C2-C3 prime-power units reach the target")
print("one mixed unit and one nontrivial C3 unit reach the target")
print("without those cases the C2-odd C3-neutral target is absent")
print("the criterion agrees with the z^3 coefficient for every a at most 20000")

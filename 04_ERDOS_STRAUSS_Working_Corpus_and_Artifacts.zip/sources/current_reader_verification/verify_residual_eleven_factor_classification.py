from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for d in range(3, isqrt(n) + 1, 2):
        if n % d == 0:
            return False
    return True


def divisors(n):
    values = []
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            values.append(d)
            if d * d != n:
                values.append(n // d)
    return sorted(values)


def weak_compositions(total, parts, prefix=()):
    if parts == 1:
        yield prefix + (total,)
        return
    for value in range(total + 1):
        yield from weak_compositions(
            total - value,
            parts - 1,
            prefix + (value,),
        )


def residue_reachable(valuations, target, channel):
    reached = {0}
    for exponent, multiplicity in enumerate(valuations, 1):
        if channel == "exterior":
            coefficients = range(0, 2 * multiplicity + 1)
        else:
            coefficients = range(-multiplicity, multiplicity + 1)
        reached = {
            (old + exponent * coefficient) % 10
            for old in reached
            for coefficient in coefficients
        }
    return target in reached


def minimal_elements(vectors):
    result = []
    for vector in sorted(set(vectors), key=lambda row: (sum(row), row)):
        if not any(
            all(lower[i] <= vector[i] for i in range(9))
            for lower in result
        ):
            result.append(vector)
    return result


EXPECTED_MINIMAL_STATES = {
    (0, 0, 1, 0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 1, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0, 1, 0, 1),
    (0, 0, 0, 0, 0, 0, 1, 1, 0),
    (0, 0, 0, 0, 0, 1, 0, 0, 1),
    (0, 0, 0, 0, 0, 1, 1, 0, 0),
    (0, 0, 0, 1, 0, 0, 0, 0, 1),
    (0, 1, 0, 0, 0, 0, 0, 0, 1),
    (0, 1, 0, 0, 0, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 1, 0, 0, 0),
    (1, 0, 0, 1, 0, 0, 0, 0, 0),
    (1, 1, 0, 0, 0, 0, 0, 0, 0),
    (2, 0, 0, 0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0, 0, 1, 2),
    (0, 0, 0, 0, 0, 0, 0, 2, 1),
    (0, 0, 0, 2, 0, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 2, 0),
    (1, 0, 0, 0, 0, 0, 2, 0, 0),
    (0, 0, 0, 0, 0, 0, 0, 0, 4),
    (0, 0, 0, 1, 0, 0, 3, 0, 0),
    (0, 0, 0, 0, 0, 0, 5, 0, 0),
}


occupied_bounded_states = []
bounded_state_count = 0
for total in range(1, 10):
    for valuations in weak_compositions(total, 9):
        bounded_state_count += 1
        exterior = residue_reachable(valuations, 3, "exterior")
        middle = residue_reachable(valuations, 5, "middle")
        if exterior or middle:
            occupied_bounded_states.append(valuations)

computed_minimal_states = set(minimal_elements(occupied_bounded_states))
report(
    "R=11 minimal factor-residue antichain",
    computed_minimal_states == EXPECTED_MINIMAL_STATES,
)


POWER_RESIDUES = tuple(pow(2, exponent, 11) for exponent in range(1, 10))
LOG_OF_RESIDUE = {
    residue: exponent
    for exponent, residue in enumerate(POWER_RESIDUES, 1)
}


def valuation_vector(n):
    vector = [0] * 9
    ell = 2
    while ell * ell <= n:
        while n % ell == 0:
            exponent = LOG_OF_RESIDUE.get(ell % 11)
            if exponent is not None:
                vector[exponent - 1] += 1
            n //= ell
        ell += 1
    if n > 1:
        exponent = LOG_OF_RESIDUE.get(n % 11)
        if exponent is not None:
            vector[exponent - 1] += 1
    return tuple(vector)


def predicted_occupied(a):
    valuations = valuation_vector(a)
    return any(
        all(generator[i] <= valuations[i] for i in range(9))
        for generator in EXPECTED_MINIMAL_STATES
    )


def exterior_count(a):
    return sum(
        1
        for u in divisors(a * a)
        if (4 * u + 1) % 11 == 0
    )


def middle_coefficient(a):
    ds = divisors(a)
    return sum(
        1
        for x in ds
        for y in ds
        if gcd(x, y) == 1
        and a % (x * y) == 0
        and (x + y) % 11 == 0
    )


integer_rows = []
occupied_integer_count = 0
for a in range(1, 3001):
    if a % 11 == 0:
        continue
    exterior = exterior_count(a)
    middle = middle_coefficient(a)
    actual = exterior + middle // 2 > 0
    occupied_integer_count += int(actual)
    integer_rows.append(actual == predicted_occupied(a))

report(
    "R=11 classification on coprime integers",
    all(integer_rows),
)


prime_rows = []
occupied_prime_count = 0
primes = [
    p
    for p in range(13, 20001)
    if p % 12 == 1 and is_prime(p)
]
for p in primes:
    a = (p + 11) // 4
    exterior = exterior_count(a)
    middle = middle_coefficient(a)
    actual = exterior + middle // 2 > 0
    occupied_prime_count += int(actual)
    prime_rows.append(actual == predicted_occupied(a))

report(
    "R=11 affine prime-shell classification",
    all(prime_rows),
)


def colon_minimal_states(power):
    reduced = []
    for generator in EXPECTED_MINIMAL_STATES:
        row = list(generator)
        row[7] = max(0, row[7] - power)
        reduced.append(tuple(row))
    return set(minimal_elements(reduced))


EXPECTED_COLON_ONE = {
    (0, 0, 0, 0, 1, 0, 0, 0, 0),
    (0, 0, 1, 0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0, 1, 0, 0),
    (0, 0, 0, 0, 0, 1, 0, 0, 1),
    (0, 0, 0, 0, 0, 0, 0, 0, 2),
    (0, 0, 0, 1, 0, 0, 0, 0, 1),
    (0, 1, 0, 0, 0, 0, 0, 0, 1),
    (0, 0, 0, 0, 0, 0, 0, 1, 1),
    (1, 0, 0, 0, 0, 1, 0, 0, 0),
    (1, 0, 0, 1, 0, 0, 0, 0, 0),
    (1, 1, 0, 0, 0, 0, 0, 0, 0),
    (1, 0, 0, 0, 0, 0, 0, 1, 0),
    (2, 0, 0, 0, 0, 0, 0, 0, 0),
}

EXPECTED_COLON_TWO = {
    (1, 0, 0, 0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 0, 0, 0, 0, 1),
    (0, 0, 0, 0, 0, 0, 1, 0, 0),
    (0, 0, 1, 0, 0, 0, 0, 0, 0),
    (0, 0, 0, 0, 1, 0, 0, 0, 0),
}

report(
    "R=11 forced-X3 colon ideal",
    colon_minimal_states(1) == EXPECTED_COLON_ONE,
)
report(
    "R=11 forced-X3^2 colon stabilization",
    colon_minimal_states(2) == EXPECTED_COLON_TWO
    and colon_minimal_states(3) == EXPECTED_COLON_TWO,
)


def predicted_after_removing_threes(a, power, generators):
    if a % (3 ** power) != 0:
        return False
    valuations = valuation_vector(a // (3 ** power))
    return any(
        all(generator[i] <= valuations[i] for i in range(9))
        for generator in generators
    )


def colon_one_empty_by_factor_branches(n):
    valuations = valuation_vector(n)
    nu = {
        residue: valuations[LOG_OF_RESIDUE[residue] - 1]
        for residue in POWER_RESIDUES
    }
    five_class_branch = all(
        nu[residue] == 0
        for residue in {2, 6, 7, 8, 10}
    )
    sparse_two_six_branch = (
        all(nu[residue] == 0 for residue in {3, 4, 5, 7, 8, 9, 10})
        and nu[2] <= 1
        and nu[6] <= 1
        and nu[2] + nu[6] >= 1
    )
    return five_class_branch or sparse_two_six_branch


def edge_r11_empty_by_factor_branches(x):
    c = 2 * x - 1
    if x % 3 == 2:
        reduced = c // 3
        valuations = valuation_vector(reduced)
        prime_residues = {
            residue
            for residue, exponent in zip(POWER_RESIDUES, valuations)
            if exponent > 0
        }
        return prime_residues <= {1, 3, 4, 5, 9}
    return colon_one_empty_by_factor_branches(c)


forced_three_rows = []
mod36_rows = []
mod36_empty_count = 0
allowed_empty_residues = {1, 3, 4, 5, 9}
colon_complement_rows = []
for c in range(1, 3001):
    if c % 11 == 0:
        continue
    valuations = valuation_vector(c)
    colon_occupied = any(
        all(generator[i] <= valuations[i] for i in range(9))
        for generator in EXPECTED_COLON_ONE
    )
    colon_complement_rows.append(
        (not colon_occupied) == colon_one_empty_by_factor_branches(c)
    )

edge_branch_rows = []
for p in primes:
    a = (p + 11) // 4
    actual = predicted_occupied(a)
    forced_three_rows.append(
        a % 3 == 0
        and actual
        == predicted_after_removing_threes(a, 1, EXPECTED_COLON_ONE)
    )
    if p % 36 == 25:
        reduced = a // 9
        prime_residues = {
            residue
            for residue, exponent in zip(
                POWER_RESIDUES,
                valuation_vector(reduced),
            )
            if exponent > 0
        }
        five_class_empty = prime_residues <= allowed_empty_residues
        mod36_empty_count += int(not actual)
        mod36_rows.append(
            a % 9 == 0
            and actual
            == predicted_after_removing_threes(
                a,
                2,
                EXPECTED_COLON_TWO,
            )
            and (not actual) == five_class_empty
        )
    if p % 48 == 1 and p % 23 in {5, 14}:
        x = (p + 23) // 24
        edge_branch_rows.append(
            (not actual) == edge_r11_empty_by_factor_branches(x)
        )

report(
    "R=11 forced factor 3 on affine prime shells",
    all(forced_three_rows),
)
report(
    "R=11 mod-36 five-class survivor criterion",
    all(mod36_rows),
)
report(
    "R=11 first-colon complement branches",
    all(colon_complement_rows),
)
report(
    "R=11 explicit branches on R=23 edges",
    bool(edge_branch_rows) and all(edge_branch_rows),
)

print(f"bounded valuation states checked: {bounded_state_count}")
print(f"minimal occupied states: {len(computed_minimal_states)}")
print(f"coprime integers checked: {len(integer_rows)}")
print(f"occupied coprime integers: {occupied_integer_count}")
print(f"affine prime shells checked: {len(prime_rows)}")
print(f"occupied affine prime shells: {occupied_prime_count}")
print(f"forced-X3 colon generators: {len(EXPECTED_COLON_ONE)}")
print(f"forced-X3^2 colon generators: {len(EXPECTED_COLON_TWO)}")
print(f"mod-36 prime shells checked: {len(mod36_rows)}")
print(f"empty mod-36 prime shells: {mod36_empty_count}")
print(f"first-colon complements checked: {len(colon_complement_rows)}")
print(f"R=23 edge R=11 branches checked: {len(edge_branch_rows)}")

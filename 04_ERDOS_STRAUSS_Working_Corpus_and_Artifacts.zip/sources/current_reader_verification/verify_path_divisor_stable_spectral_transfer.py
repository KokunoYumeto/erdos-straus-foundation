from collections import Counter
from pathlib import Path

import sympy as sp


def assert_matrix_zero(matrix, label):
    for index, entry in enumerate(matrix):
        if sp.cancel(sp.expand(entry)) != 0:
            raise AssertionError(f"{label}: entry {index} = {sp.factor(entry)}")


# Three independent orbit amplitudes are enough to verify the tensor-factor
# calculation symbolically.  The proof is blockwise and therefore extends to
# every finite occupied orbit set.
a0, a1, a2 = sp.symbols("a0 a1 a2", positive=True)
amplitudes = [a0, a1, a2]
q = len(amplitudes)

D_orb = sp.diag(*amplitudes)
D_path = sp.kronecker_product(D_orb, sp.eye(3))
D_div = sp.kronecker_product(D_orb, sp.eye(2))
left = sp.kronecker_product(D_path, sp.eye(2))
right = sp.kronecker_product(D_div, sp.eye(3))

# The column basis is (orbit, rotation, sheet-copy); the row basis is
# (orbit, sheet, rotation).  P is the exact tensor-factor flip.
P = sp.zeros(6 * q)
for orbit in range(q):
    for rotation in range(3):
        for sheet in range(2):
            column = (orbit * 3 + rotation) * 2 + sheet
            row = (orbit * 2 + sheet) * 3 + rotation
            P[row, column] = 1

assert_matrix_zero(P.T * P - sp.eye(6 * q), "stable map is unitary")
assert_matrix_zero(P * left * P.T - right, "stable operator intertwining")

# An independent 4:5 carrier instance checks the finite-fibre theorem beyond
# the arithmetic 3:2 specialization.
D_test = sp.diag(sp.Rational(2, 7), sp.Rational(5, 11))
D_A = sp.kronecker_product(D_test, sp.eye(4))
D_B = sp.kronecker_product(D_test, sp.eye(5))
left_45 = sp.kronecker_product(D_A, sp.eye(5))
right_45 = sp.kronecker_product(D_B, sp.eye(4))
P45 = sp.zeros(40)
for orbit in range(2):
    for a_index in range(4):
        for b_index in range(5):
            column = (orbit * 4 + a_index) * 5 + b_index
            row = (orbit * 5 + b_index) * 4 + a_index
            P45[row, column] = 1
assert_matrix_zero(P45.T * P45 - sp.eye(40), "4:5 flip is unitary")
assert_matrix_zero(P45 * left_45 * P45.T - right_45, "4:5 stable exchange")

path_spectrum = Counter()
div_spectrum = Counter()
for amplitude in amplitudes:
    path_spectrum[amplitude] += 3
    div_spectrum[amplitude] += 2
for amplitude in amplitudes:
    if 2 * path_spectrum[amplitude] != 3 * div_spectrum[amplitude]:
        raise AssertionError(f"spectral multiplicity at {amplitude}")

t = sp.symbols("t")
test_function = t**4 + 2 * t**2 - 3 * t + 5
path_functional_trace = sum(
    3 * test_function.subs(t, amplitude) for amplitude in amplitudes
)
div_functional_trace = sum(
    2 * test_function.subs(t, amplitude) for amplitude in amplitudes
)
if sp.expand(2 * path_functional_trace - 3 * div_functional_trace) != 0:
    raise AssertionError("finite functional trace transfer")

for exponent in range(7):
    path_moment = sp.trace(D_path**exponent)
    div_moment = sp.trace(D_div**exponent)
    if sp.expand(2 * path_moment - 3 * div_moment) != 0:
        raise AssertionError(f"moment transfer k={exponent}")

path_characteristic = sp.factor(D_path.charpoly(t).as_expr())
div_characteristic = sp.factor(D_div.charpoly(t).as_expr())
expected_characteristic = sp.prod((t - amplitude) ** 6 for amplitude in amplitudes)
if sp.expand(path_characteristic**2 - expected_characteristic) != 0:
    raise AssertionError("path characteristic polynomial")
if sp.expand(div_characteristic**3 - expected_characteristic) != 0:
    raise AssertionError("divisor characteristic polynomial")

E22 = sp.Matrix([[0, 0], [0, 1]])
amplitude_sum = sum(amplitudes)
alpha_sigma = 2 * amplitude_sum
Delta_path = -3 * amplitude_sum * E22
Delta_div = -2 * amplitude_sum * E22
assert_matrix_zero(
    2 * Delta_path - 3 * Delta_div,
    "aggregate target coefficient transfer",
)
assert_matrix_zero(
    3 * Delta_div + 3 * alpha_sigma * E22,
    "aggregate target coefficient value",
)

n_target = sp.Matrix([-sp.Rational(1, 2), 0, 0, sp.Rational(1, 2)])
nu_path = 3 * amplitude_sum * n_target
nu_div = 2 * amplitude_sum * n_target
assert_matrix_zero(2 * nu_path - 3 * nu_div, "target-null mass transfer")
assert_matrix_zero(
    3 * nu_div - 3 * alpha_sigma * n_target,
    "target-null mass value",
)

# Exact finite receipt on the six complement-orbit amplitudes of the 12289
# shell.  Each appears three times upstairs and twice on divisor space.
amplitudes_12289 = [
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(921675, 38217124),
    sp.Rational(615, 94864),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
]
for exponent in range(7):
    path_value = 3 * sum(a**exponent for a in amplitudes_12289)
    div_value = 2 * sum(a**exponent for a in amplitudes_12289)
    if 2 * path_value != 3 * div_value:
        raise AssertionError(f"12289 exact moment transfer k={exponent}")

lines = [
    "PASS the finite-fibre stable exchange holds on an independent 4:5 carrier instance",
    "PASS the explicit C3:C2 tensor-factor flip is unitary",
    "PASS the tensor-factor flip intertwines the doubled path and tripled divisor operators",
    "PASS every orbit amplitude has path multiplicity three and divisor multiplicity two",
    "PASS the spectral counting measures satisfy 2 mu_path = 3 mu_div",
    "PASS finite functional traces obey the exact 2:3 transfer",
    "PASS all spectral moments through degree six obey the exact 2:3 transfer",
    "PASS the squared path and cubed divisor characteristic polynomials coincide",
    "PASS aggregate arithmetic target coefficients obey the exact 2:3 transfer",
    "PASS aggregate Lorentz target-null masses obey the exact 2:3 transfer",
    "PASS all six exact 12289 orbit amplitudes obey the moment transfer through degree six",
]

output = Path(__file__).with_name(
    "verify_path_divisor_stable_spectral_transfer_output.txt"
)
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

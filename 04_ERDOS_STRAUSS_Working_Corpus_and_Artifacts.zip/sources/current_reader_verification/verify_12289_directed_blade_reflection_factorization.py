from itertools import product
from pathlib import Path


p = 12289
R = 11
a = 3075
N_arith = p * a


def zeros(rows, columns):
    return [[0 for _ in range(columns)] for _ in range(rows)]


def identity(size):
    result = zeros(size, size)
    for index in range(size):
        result[index][index] = 1
    return result


def add(*matrices):
    rows = len(matrices[0])
    columns = len(matrices[0][0])
    return [
        [sum(matrix[row][column] for matrix in matrices) for column in range(columns)]
        for row in range(rows)
    ]


def subtract(left, right):
    return [
        [left[row][column] - right[row][column] for column in range(len(left[0]))]
        for row in range(len(left))
    ]


def scale(scalar, matrix):
    return [[scalar * entry for entry in row] for row in matrix]


def matmul(left, right):
    return [
        [
            sum(left[row][inner] * right[inner][column] for inner in range(len(right)))
            for column in range(len(right[0]))
        ]
        for row in range(len(left))
    ]


def transpose(matrix):
    return [list(column) for column in zip(*matrix)]


def matrix_power(matrix, exponent):
    result = identity(len(matrix))
    for _ in range(exponent):
        result = matmul(result, matrix)
    return result


def kronecker(left, right):
    return [
        [
            left[i][j] * right[r][c]
            for j in range(len(left[0]))
            for c in range(len(right[0]))
        ]
        for i in range(len(left))
        for r in range(len(right))
    ]


def matrix_unit(size, row, column, coefficient=1):
    result = zeros(size, size)
    result[row][column] = coefficient
    return result


U = [
    [0, 0, 1],
    [1, 0, 0],
    [0, 1, 0],
]
U2 = matmul(U, U)
K0 = [
    [1, 0, 0],
    [0, 0, 1],
    [0, 1, 0],
]
E11_3 = matrix_unit(3, 0, 0)
B_minus = matrix_unit(3, 2, 1, 2)
B_plus = matrix_unit(3, 1, 2, 2)

if scale(2, K0) != add(scale(2, E11_3), B_minus, B_plus):
    raise AssertionError("K0 blade factorization failed")

B_minus_orbit = []
B_plus_orbit = []
K_orbit = []
for m in range(3):
    Um = matrix_power(U, m)
    Uminusm = matrix_power(U, (-m) % 3)
    Bm = matmul(matmul(Um, B_minus), Uminusm)
    Bp = matmul(matmul(Um, B_plus), Uminusm)
    Km = matmul(matmul(Um, K0), Uminusm)
    fixed = matmul(matmul(Um, E11_3), Uminusm)
    if scale(2, Km) != add(scale(2, fixed), Bm, Bp):
        raise AssertionError(f"rotated reflection factorization failed at m={m}")
    if matmul(matmul(Km, Bm), Km) != Bp:
        raise AssertionError(f"reflection did not reverse the directed blade at m={m}")
    B_minus_orbit.append(Bm)
    B_plus_orbit.append(Bp)
    K_orbit.append(Km)

if add(*B_minus_orbit) != scale(2, U):
    raise AssertionError("directed blade orbit does not sum to 2U")
if add(*B_plus_orbit) != scale(2, U2):
    raise AssertionError("transposed blade orbit does not sum to 2U^2")
J3 = [[1, 1, 1], [1, 1, 1], [1, 1, 1]]
if add(*K_orbit) != J3:
    raise AssertionError("the three coordinate reflections do not sum to J3")

v = [[3], [6], [3]]
Uv = matmul(U, v)
U2v = matmul(U2, v)
M = [[v[row][0], Uv[row][0], U2v[row][0]] for row in range(3)]
oriented_orbit = subtract(M, transpose(M))
blade_orbit_difference = subtract(add(*B_minus_orbit), add(*B_plus_orbit))
if scale(2, oriented_orbit) != scale(3, blade_orbit_difference):
    raise AssertionError("oriented orbit is not the exact directed-blade orbit sum")


def target(j):
    if j == 0:
        return (-p) % R
    if j == 1:
        return (-1) % R
    if j == 2:
        return (-pow(p, -1, R)) % R
    raise ValueError(j)


divisors = sorted(
    3**e3 * 5**e5 * 41**e41
    for e3, e5, e41 in product(range(3), range(5), range(3))
)
a_inverse = pow(a, -1, R)
X = tuple(
    (j, u)
    for j in range(3)
    for u in divisors
    if (u * a_inverse) % R == target(j)
)
X_index = {x: index for index, x in enumerate(X)}


def iota(x):
    j, u = x
    return (2 - j, a * a // u)


def d_value(x):
    j, u = x
    return p**j * u


X_low = tuple(x for x in X if d_value(x) < N_arith)
if len(X) != 12 or len(X_low) != 6:
    raise AssertionError(f"certificate counts: total={len(X)}, low={len(X_low)}")
if any(d_value(x) * d_value(iota(x)) != N_arith**2 for x in X):
    raise AssertionError("complement product identity failed")
if {x for low in X_low for x in (low, iota(low))} != set(X):
    raise AssertionError("low representatives do not partition the certificate set")

A_minus = zeros(12, 12)
A_plus = zeros(12, 12)
Q_low = zeros(12, 12)
Q_high = zeros(12, 12)
P_iota = zeros(12, 12)
for x in X:
    P_iota[X_index[iota(x)]][X_index[x]] = 1
for x in X_low:
    low = X_index[x]
    high = X_index[iota(x)]
    A_minus[high][low] = 2
    A_plus[low][high] = 2
    Q_low[low][low] = 1
    Q_high[high][high] = 1

if scale(2, P_iota) != add(A_minus, A_plus):
    raise AssertionError("arithmetic complement blade factorization failed")
if matmul(A_plus, A_minus) != scale(4, Q_low):
    raise AssertionError("arithmetic source projector identity failed")
if matmul(A_minus, A_plus) != scale(4, Q_high):
    raise AssertionError("arithmetic range projector identity failed")
if matmul(A_minus, A_minus) != zeros(12, 12):
    raise AssertionError("A_minus must be square-zero")
if matmul(A_plus, A_plus) != zeros(12, 12):
    raise AssertionError("A_plus must be square-zero")
if matmul(matmul(P_iota, A_minus), P_iota) != A_plus:
    raise AssertionError("arithmetic complement does not reverse the directed channel")

reflection_product = kronecker(P_iota, K0)
reflection_expansion_times_four = add(
    scale(2, kronecker(add(A_minus, A_plus), E11_3)),
    kronecker(add(A_minus, A_plus), add(B_minus, B_plus)),
)
if scale(4, reflection_product) != reflection_expansion_times_four:
    raise AssertionError("joint reflection directed-channel expansion failed")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{thm:12289-directed-blade-reflection-factorization}",
    r"\label{eq:12289-arithmetic-directed-channel-operators}",
    r"\label{eq:12289-coordinate-directed-channel-orbits}",
    r"\label{eq:12289-oriented-orbit-as-directed-blade-sum}",
    r"\label{eq:12289-joint-reflection-directed-channel-expansion}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact 12289 directed-blade reflection factorization",
            "six arithmetic complement pairs carry ordered blocks 2E21 and 2E12",
            "P_iota = (A_minus + A_plus)/2 and exchanges the two directed channels",
            "K0 = E11 + (B_minus + B_plus)/2 with B_minus=2E32 and B_plus=2E23",
            "the three B_minus conjugates sum to 2U",
            "the three B_plus conjugates sum to 2U^2",
            "M_12289-M_12289^T equals 3/2 times the directed orbit difference",
            "the 36-dimensional reflection has the exact four-channel expansion",
        )
    )
)

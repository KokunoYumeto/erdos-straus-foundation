from collections import Counter, defaultdict
from math import gcd
import sys

from scan_coupled_shell_coverage import (
    divisors_from_factorization,
    factor_integer,
    prime_sieve,
)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


PRIME_LIMIT = 2_000
EXAMPLE_LIMIT = 4


def rotational_stabilizer(support, modulus):
    anchor = next(iter(support))
    inverse_anchor = pow(anchor, -1, modulus)
    candidates = {value * inverse_anchor % modulus for value in support}
    return {
        value
        for value in candidates
        if gcd(value, modulus) == 1
        and {value * residue % modulus for residue in support} == support
    }


sieve = prime_sieve(PRIME_LIMIT)
trial_primes = [value for value in range(2, PRIME_LIMIT + 1) if sieve[value]]

pattern_counts = Counter()
pattern_rotation_invariant_counts = Counter()
pattern_stabilizer_orders = defaultdict(Counter)
examples = defaultdict(list)
rotation_invariant_examples = defaultdict(list)
both_without_rotation_invariance = []
shell_count = 0
divisor_count = 0

for p in range(5, PRIME_LIMIT + 1, 4):
    if not sieve[p]:
        continue
    for residual in range(3, 2 * p, 4):
        a = (p + residual) // 4
        factors = factor_integer(a, trial_primes)
        square_factors = tuple(
            (prime, 2 * exponent) for prime, exponent in factors
        )
        divisors = divisors_from_factorization(square_factors)
        support = {divisor % residual for divisor in divisors}
        if any(gcd(value, residual) != 1 for value in support):
            raise AssertionError("divisor support left the unit group")

        inverse_four = pow(4, -1, residual)
        exterior = (-inverse_four) % residual
        middle = (-a) % residual
        opposite = p * middle % residual
        if middle != p * exterior % residual:
            raise AssertionError("endpoint transport failed")

        complement_support = {
            a * a * pow(value, -1, residual) % residual
            for value in support
        }
        if complement_support != support:
            raise AssertionError("support is not complement-stable")
        if (exterior in support) != (opposite in support):
            raise AssertionError("the exterior pair has unequal support")

        exterior_hit = exterior in support
        middle_hit = middle in support
        pattern = (
            "both"
            if exterior_hit and middle_hit
            else "exterior-only"
            if exterior_hit
            else "middle-only"
            if middle_hit
            else "empty"
        )

        stabilizer = rotational_stabilizer(support, residual)
        if 1 not in stabilizer:
            raise AssertionError("rotational stabilizer lacks the identity")
        for left in stabilizer:
            if pow(left, -1, residual) not in stabilizer:
                raise AssertionError("rotational stabilizer lacks an inverse")
            for right in stabilizer:
                if left * right % residual not in stabilizer:
                    raise AssertionError("rotational stabilizer is not a subgroup")

        p_residue = p % residual
        rotation_invariant = p_residue in stabilizer
        if rotation_invariant:
            orbit_hits = {
                exterior in support,
                middle in support,
                opposite in support,
            }
            if len(orbit_hits) != 1:
                raise AssertionError(
                    "rotation-stable support has nonuniform target occupancy"
                )
        if pattern in {"exterior-only", "middle-only"} and rotation_invariant:
            raise AssertionError("one-sided occupancy is rotation-stable")

        pattern_counts[pattern] += 1
        pattern_rotation_invariant_counts[(pattern, rotation_invariant)] += 1
        pattern_stabilizer_orders[pattern][len(stabilizer)] += 1
        shell_count += 1
        divisor_count += len(divisors)

        record = (
            p,
            residual,
            a,
            tuple(sorted(support)),
            tuple(sorted(stabilizer)),
            (exterior, middle, opposite),
        )
        if len(examples[pattern]) < EXAMPLE_LIMIT:
            examples[pattern].append(record)
        if rotation_invariant and len(rotation_invariant_examples[pattern]) < 2:
            rotation_invariant_examples[pattern].append(record)
        if (
            pattern == "both"
            and not rotation_invariant
            and len(both_without_rotation_invariance) < EXAMPLE_LIMIT
        ):
            both_without_rotation_invariance.append(record)


print("PASS: exact endpoint support and rotational stabilizers")
print(f"all admissible shells through p={PRIME_LIMIT}: {shell_count}")
print(f"divisors checked with multiplicity: {divisor_count}")
print("occupancy pattern counts:")
for pattern in ("empty", "exterior-only", "middle-only", "both"):
    print(f"  {pattern}: {pattern_counts[pattern]}")
print("pattern counts split by p-stability of the support:")
for pattern in ("empty", "exterior-only", "middle-only", "both"):
    for stable in (False, True):
        print(
            f"  {pattern}, pS=S is {stable}: "
            f"{pattern_rotation_invariant_counts[(pattern, stable)]}"
        )
print("rotational stabilizer order ranges:")
for pattern in ("empty", "exterior-only", "middle-only", "both"):
    orders = pattern_stabilizer_orders[pattern]
    print(
        f"  {pattern}: min={min(orders)}, max={max(orders)}, "
        f"distinct={len(orders)}"
    )
print("first examples by occupancy pattern:")
for pattern in ("empty", "exterior-only", "middle-only", "both"):
    print(f"  {pattern}:")
    for record in examples[pattern]:
        p, residual, a, support, stabilizer, targets = record
        print(
            f"    p={p}, R={residual}, a={a}, targets={targets}, "
            f"S={support}, H={stabilizer}"
        )
print("first simultaneous-occupancy examples with pS != S:")
for record in both_without_rotation_invariance:
    p, residual, a, support, stabilizer, targets = record
    print(
        f"  p={p}, R={residual}, a={a}, targets={targets}, "
        f"S={support}, H={stabilizer}"
    )

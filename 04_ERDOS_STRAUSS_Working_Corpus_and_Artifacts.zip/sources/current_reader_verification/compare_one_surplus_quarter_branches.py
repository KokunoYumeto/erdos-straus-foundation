"""Exact comparison of the two positive-surplus R=19 quarter shells."""

from collections import defaultdict
from itertools import product
from math import gcd, isqrt, prod
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


PRIMES = (118_801, 359_041)
RESIDUALS = tuple(range(3, 60, 4))


def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def factor_multiset(factors):
    return tuple(
        prime
        for prime, exponent in factors
        for _ in range(exponent)
    )


def divisors(factors, doubled=False):
    values = [1]
    for prime, exponent in factors:
        if doubled:
            exponent *= 2
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(sorted(values))


def reachability(modulus, residues, alphabet):
    values = defaultdict(list)
    for exponents in product(alphabet, repeat=len(residues)):
        value = 1
        for residue, exponent in zip(residues, exponents):
            value = value * pow(residue, exponent, modulus) % modulus
        values[value].append(exponents)
    return dict(values)


def shell(prime, residual):
    denominator = (prime + residual) // 4
    factors = factorization(denominator)
    repeated = factor_multiset(factors)
    residues = tuple(prime_factor % residual for prime_factor in repeated)
    exterior_reach = reachability(residual, residues, (0, 1, 2))
    middle_reach = reachability(residual, residues, (-1, 0, 1))
    quarter = -pow(4, -1, residual) % residual
    minus = residual - 1
    matrix = (
        (int(quarter in exterior_reach), int(minus in exterior_reach)),
        (int(quarter in middle_reach), int(minus in middle_reach)),
    )
    square_divisors = divisors(factors, doubled=True)
    exterior = tuple(
        divisor for divisor in square_divisors
        if (4 * divisor + 1) % residual == 0
    )
    middle = tuple(
        divisor for divisor in square_divisors
        if (divisor + denominator) % residual == 0
    )
    rank = len(exterior) + len(middle) // 2
    return {
        "a": denominator,
        "factors": factors,
        "residues": residues,
        "matrix": matrix,
        "exterior_reach": exterior_reach,
        "middle_reach": middle_reach,
        "quarter": quarter,
        "minus": minus,
        "exterior": exterior,
        "middle": middle,
        "rank": rank,
    }


def matrix_name(matrix):
    names = {
        ((0, 0), (0, 0)): "0",
        ((0, 1), (0, 0)): "E12",
        ((0, 0), (1, 0)): "E21",
        ((0, 1), (1, 0)): "S",
        ((1, 1), (1, 1)): "I+S",
    }
    return names.get(matrix, repr(matrix))


records = {}
for prime in PRIMES:
    rows = []
    for residual in RESIDUALS:
        data = shell(prime, residual)
        rows.append((residual, data))
        if data["rank"]:
            break
    records[prime] = tuple(rows)


for prime, rows in records.items():
    for residual, data in rows:
        assert prod(p**e for p, e in data["factors"]) == data["a"]
        assert bool(data["rank"]) == bool(
            data["matrix"][0][0] or data["matrix"][1][1]
        )


first = records[118_801]
second = records[359_041]
assert first[-1][0] == 59 and first[-1][1]["rank"] == 2
assert second[-1][0] == 23 and second[-1][1]["rank"] > 0
assert shell(118_801, 19)["matrix"] == ((0, 0), (1, 0))
assert shell(359_041, 19)["matrix"] == ((0, 0), (1, 0))


for prime, cofactor in ((118_801, 457), (359_041, 1381)):
    assert prime == 260 * cofactor - 19
    assert shell(prime, 19)["a"] == 65 * cofactor
    assert shell(prime, 23)["a"] == 65 * cofactor + 1
    assert 13 * pow(5, -1, 19) % 19 == 14

assert factorization(457) == ((457, 1),)
assert factorization(1381) == ((1381, 1),)


# Primitive-log table for a_19=5*13*c when c is prime to 19.
def additive_reach(logs, alphabet):
    return {
        sum(coefficient * value for coefficient, value in zip(choice, logs)) % 18
        for choice in product(alphabet, repeat=len(logs))
    }


log_table = defaultdict(list)
for cofactor_log in range(18):
    logs = (16, 5, cofactor_log)  # log_2(5), log_2(13), log_2(c)
    exterior = additive_reach(logs, (0, 1, 2))
    middle = additive_reach(logs, (-1, 0, 1))
    matrix = (
        (int(7 in exterior), int(9 in exterior)),
        (int(7 in middle), int(9 in middle)),
    )
    log_table[matrix_name(matrix)].append(cofactor_log)


assert 0 in log_table["E21"]
assert 5 in log_table["E21"]


r23_first = shell(118_801, 23)
r23_second = shell(359_041, 23)
assert r23_first["matrix"] == ((0, 0), (0, 0))
assert r23_second["matrix"] == ((1, 1), (1, 1))

quadratic_residues_23 = frozenset(pow(value, 2, 23) for value in range(1, 23))
units_23 = frozenset(range(1, 23))
assert quadratic_residues_23 == frozenset((1, 2, 3, 4, 6, 8, 9, 12, 13, 16, 18))
assert frozenset(r23_first["exterior_reach"]) == quadratic_residues_23
assert frozenset(r23_first["middle_reach"]) == quadratic_residues_23
base_second_exterior = frozenset(reachability(23, (2, 3, 3), (0, 1, 2)))
base_second_middle = frozenset(reachability(23, (2, 3, 3), (-1, 0, 1)))
assert base_second_exterior == quadratic_residues_23
assert base_second_middle == quadratic_residues_23
assert 19 not in quadratic_residues_23
assert frozenset(r23_second["exterior_reach"]) == units_23
assert frozenset(r23_second["middle_reach"]) == units_23

exterior_witness = r23_second["exterior"][0]
lift = (r23_second["a"] + 359_041 * exterior_witness) // 23
denominator_two = 359_041 * lift
denominator_three = r23_second["a"] * lift // exterior_witness
assert 4 * r23_second["a"] * denominator_two * denominator_three == (
    359_041
    * (
        denominator_two * denominator_three
        + r23_second["a"] * denominator_three
        + r23_second["a"] * denominator_two
    )
)


def least_witness(reach, target):
    return min(reach[target])


print("PASS: one-surplus quarter branch comparison")
print("a19 parameterization: p=260*c-19, a19=65*c, a23=65*c+1")
for prime, rows in records.items():
    print(f"p={prime}")
    for residual, data in rows:
        print(
            f"  R={residual}: a={data['a']}; factors={data['factors']}; "
            f"residues={data['residues']}; Xi={matrix_name(data['matrix'])}; "
            f"|E|={len(data['exterior'])}; |M|={len(data['middle'])}; q={data['rank']}"
        )
print("R19 prime-cofactor log table: " + repr(dict(sorted(log_table.items()))))
print("p=118801 R23 complete reachability: E="
      + repr(tuple(sorted(r23_first["exterior_reach"])))
      + "; M=" + repr(tuple(sorted(r23_first["middle_reach"]))))
print("p=359041 R23 complete reachability: E="
      + repr(tuple(sorted(r23_second["exterior_reach"])))
      + "; M=" + repr(tuple(sorted(r23_second["middle_reach"]))))
print("p=359041 R23 divisor sections: E=" + repr(r23_second["exterior"])
      + "; M=" + repr(r23_second["middle"]))
print("R23 quadratic-residue split: Q=" + repr(tuple(sorted(quadratic_residues_23)))
      + "; 118801 reaches Q in both alphabets; 359041 reaches U23 in both")
print("p=359041 R23 target witnesses: "
      + repr({
          "E->t": least_witness(r23_second["exterior_reach"], 17),
          "E->s": least_witness(r23_second["exterior_reach"], 22),
          "M->t": least_witness(r23_second["middle_reach"], 17),
          "M->s": least_witness(r23_second["middle_reach"], 22),
      }))
print("p=359041 decomposition: 4/359041=1/89766+1/"
      + str(denominator_two) + "+1/" + str(denominator_three))

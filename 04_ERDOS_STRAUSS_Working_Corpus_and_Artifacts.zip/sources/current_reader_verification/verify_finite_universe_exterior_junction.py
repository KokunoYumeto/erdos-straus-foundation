from itertools import permutations
from math import factorial

from sympy import Matrix


def permutation_sign(permutation):
    inversions = sum(
        permutation[a] > permutation[b]
        for a in range(len(permutation))
        for b in range(a + 1, len(permutation))
    )
    return -1 if inversions % 2 else 1


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def exterior_contraction(operators):
    n = len(operators)
    perms = tuple(permutations(range(n)))
    total = 0
    for left in perms:
        left_sign = permutation_sign(left)
        for right in perms:
            term = left_sign * permutation_sign(right)
            for j in range(n):
                term *= operators[j][left[j], right[j]]
            total += term
    return total / factorial(n)


for n in range(2, 6):
    perms = tuple(permutations(range(n)))
    report(
        f"rank {n} alternating components are exactly the n-factorial covers",
        len(perms) == factorial(n)
        and all(set(p) == set(range(n)) for p in perms),
    )
    report(
        f"rank {n} exact-cover support law",
        all(
            len(set(p)) == n
            and set().union(*(set([entry]) for entry in p)) == set(range(n))
            for p in perms
        ),
    )

    g_left = Matrix.eye(n)
    g_right = Matrix.eye(n)
    for j in range(n - 1):
        g_left[j, j + 1] = j + 2
        g_right[j + 1, j] = -(j + 3)

    operators = tuple(
        Matrix(
            n,
            n,
            lambda a, b, j=j: (
                (j + 2) * (a + 1)
                + (b + 1) ** 2
                + (j + 3 if a == b else 0)
            ),
        )
        for j in range(n)
    )
    transformed = tuple(g_left * u * g_right.inv() for u in operators)

    report(f"rank {n} left endpoint determinant", g_left.det() == 1)
    report(f"rank {n} right endpoint determinant", g_right.det() == 1)
    report(
        f"rank {n} exact exterior contraction is endpoint-gauge invariant",
        exterior_contraction(transformed) == exterior_contraction(operators),
    )

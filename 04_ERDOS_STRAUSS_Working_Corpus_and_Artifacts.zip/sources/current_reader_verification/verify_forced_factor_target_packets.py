from itertools import combinations_with_replacement
from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for divisor in range(3, isqrt(n) + 1, 2):
        if n % divisor == 0:
            return False
    return True


def factorization(n):
    factors = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            n //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor += 1 if divisor == 2 else 2
    if n > 1:
        factors.append((n, 1))
    return factors


def divisors(n):
    values = [1]
    for prime, exponent in factorization(n):
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(values)


def restricted_eleven_divisor_count(n, upper_bound):
    return sum(
        divisor <= upper_bound and divisor % 12 == 11
        for divisor in divisors(n)
    )


def weak_compositions(total, parts, prefix=()):
    if parts == 1:
        yield prefix + (total,)
        return
    for value in range(total + 1):
        yield from weak_compositions(
            total - value,
            parts - 1,
            prefix + (value,),
        )


def valuation_vector(n, modulus):
    residues = tuple(range(2, modulus))
    residue_index = {
        residue: index
        for index, residue in enumerate(residues)
    }
    vector = [0] * len(residues)
    for prime, exponent in factorization(n):
        residue = prime % modulus
        if residue in residue_index:
            vector[residue_index[residue]] += exponent
    return tuple(vector)


def reachable_set(valuations, modulus, channel):
    reached = {1}
    for residue, multiplicity in zip(range(2, modulus), valuations):
        if channel == "exterior":
            coefficients = range(0, 2 * multiplicity + 1)
        else:
            coefficients = range(-multiplicity, multiplicity + 1)
        reached = {
            old * pow(residue, coefficient, modulus) % modulus
            for old in reached
            for coefficient in coefficients
        }
    return reached


def factor_packet_sets(modulus, extracted_factor):
    inverse_factor = pow(extracted_factor, -1, modulus)
    exterior_target = (-pow(4, -1, modulus)) % modulus
    middle_target = modulus - 1
    exterior = {
        exterior_target,
        exterior_target * inverse_factor % modulus,
        exterior_target * inverse_factor**2 % modulus,
    }
    middle = {
        middle_target * extracted_factor % modulus,
        middle_target,
        middle_target * inverse_factor % modulus,
    }
    return exterior, middle


def packet_sets(modulus):
    return factor_packet_sets(modulus, 3)


def multiply_2_by_2(left, right, modulus):
    return tuple(
        tuple(
            sum(left[row][k] * right[k][column] for k in range(2))
            % modulus
            for column in range(2)
        )
        for row in range(2)
    )


def packet_exchange_matrix(modulus):
    alpha = pow(12, -1, modulus)
    return (
        (0, alpha),
        (pow(alpha, -1, modulus), 0),
    )


def residue_of_valuations(valuations, modulus):
    value = 1
    for residue, multiplicity in zip(range(2, modulus), valuations):
        value = value * pow(residue, multiplicity, modulus) % modulus
    return value


def prime_twisted_packet(modulus, prime_residue):
    middle_packet = packet_sets(modulus)[1]
    inverse_prime = pow(prime_residue, -1, modulus)
    return middle_packet | {
        inverse_prime * value % modulus
        for value in middle_packet
    }


def factor_prime_twisted_packet(modulus, prime_residue, extracted_factor):
    middle_packet = factor_packet_sets(modulus, extracted_factor)[1]
    inverse_prime = pow(prime_residue, -1, modulus)
    return middle_packet | {
        inverse_prime * value % modulus
        for value in middle_packet
    }


def expected_prime_twisted_volume(modulus, prime_residue):
    inverse_three = pow(3, -1, modulus)
    if prime_residue == 1:
        return 3
    if prime_residue in {3, inverse_three}:
        return 4
    if prime_residue in {9 % modulus, inverse_three**2 % modulus}:
        return 5
    return 6


def multiplicative_order(value, modulus):
    current = 1
    for order in range(1, modulus + 1):
        current = current * value % modulus
        if current == 1:
            return order
    raise AssertionError((value, modulus))


discrete_log_23 = {
    pow(5, exponent, 23): exponent for exponent in range(22)
}
target_log_packet_23 = {5, 11, 17}


def signed_log_box_23(n):
    reached = {0}
    for prime, multiplicity in factorization(n):
        logarithm = discrete_log_23[prime % 23]
        reached = {
            (old + coefficient * logarithm) % 22
            for old in reached
            for coefficient in range(-multiplicity, multiplicity + 1)
        }
    return reached


def log_packet_occupied_23(prime):
    reduced = (prime + 23) // 12
    prime_logarithm = discrete_log_23[prime % 23]
    target = target_log_packet_23 | {
        (value - prime_logarithm) % 22
        for value in target_log_packet_23
    }
    return bool(signed_log_box_23(reduced) & target)


def signed_log_box_from_multiset_23(logarithms):
    reached = {0}
    for logarithm in logarithms:
        reached = {
            (old + coefficient * logarithm) % 22
            for old in reached
            for coefficient in (-1, 0, 1)
        }
    return reached


def nonzero_log_multiset_23(n):
    logarithms = []
    for prime, multiplicity in factorization(n):
        logarithm = discrete_log_23[prime % 23]
        if logarithm:
            logarithms.extend([logarithm] * multiplicity)
    return tuple(sorted(logarithms))


edge_target_one_23 = target_log_packet_23 | {
    (value - 1) % 22 for value in target_log_packet_23
}
edge_target_minus_one_23 = target_log_packet_23 | {
    (value + 1) % 22 for value in target_log_packet_23
}
edge_forbidden_23 = (
    edge_target_one_23
    | {(-value) % 22 for value in edge_target_one_23}
)
edge_safe_multisets_23 = {
    length: {
        logarithms
        for logarithms in combinations_with_replacement(range(1, 22), length)
        if not (
            signed_log_box_from_multiset_23(logarithms)
            & edge_forbidden_23
        )
    }
    for length in range(1, 5)
}
edge_exception_patterns_23 = {
    1: {
        (3,),
        (1, 2),
        (1, 1, 1),
    },
    21: {
        (1,),
        (2, 21),
        (8, 15),
        (1, 1, 21),
        (15, 15, 15),
    },
}


def expected_segment_volume(modulus, prime_residue, generator):
    inverse_generator = pow(generator, -1, modulus)
    if prime_residue == 1:
        return 3
    if prime_residue in {generator % modulus, inverse_generator}:
        return 4
    if prime_residue in {
        generator**2 % modulus,
        inverse_generator**2 % modulus,
    }:
        return 5
    return 6


def packet_occupied(reduced_valuations, modulus):
    exterior_packet, middle_packet = packet_sets(modulus)
    exterior_reached = reachable_set(
        reduced_valuations,
        modulus,
        "exterior",
    )
    middle_reached = reachable_set(
        reduced_valuations,
        modulus,
        "middle",
    )
    return bool(
        exterior_reached & exterior_packet
        or middle_reached & middle_packet
    )


def one_box_occupied(reduced_valuations, modulus):
    exterior_packet, middle_packet = packet_sets(modulus)
    middle_reached = reachable_set(
        reduced_valuations,
        modulus,
        "middle",
    )
    inverse_b = pow(
        residue_of_valuations(reduced_valuations, modulus),
        -1,
        modulus,
    )
    target = middle_packet | {
        inverse_b * value % modulus
        for value in exterior_packet
    }
    return bool(middle_reached & target)


def factor_one_box_occupied(
    reduced_valuations,
    modulus,
    prime_residue,
    extracted_factor,
):
    middle_reached = reachable_set(
        reduced_valuations,
        modulus,
        "middle",
    )
    target = factor_prime_twisted_packet(
        modulus,
        prime_residue,
        extracted_factor,
    )
    return bool(middle_reached & target)


def occupied_after_inserting_three(reduced_valuations, modulus):
    full = list(reduced_valuations)
    full[1] += 1
    exterior_reached = reachable_set(full, modulus, "exterior")
    middle_reached = reachable_set(full, modulus, "middle")
    exterior_target = (-pow(4, -1, modulus)) % modulus
    middle_target = modulus - 1
    return bool(
        exterior_target in exterior_reached
        or middle_target in middle_reached
    )


report(
    "R=11 three-position packet collision",
    packet_sets(11) == ({7, 8, 10}, {7, 8, 10}),
)
report(
    "R=23 three-position packet separation",
    packet_sets(23) == ({7, 17, 21}, {15, 20, 22}),
)
expected_volume_rows = {
    11: {
        3: {1},
        4: {3, 4},
        5: {5, 9},
        6: {2, 6, 7, 8, 10},
    },
    23: {
        3: {1},
        4: {3, 8},
        5: {9, 18},
        6: {
            2, 4, 5, 6, 7, 10, 11, 12, 13,
            14, 15, 16, 17, 19, 20, 21, 22,
        },
    },
}
computed_volume_rows = {}
for modulus in (11, 23):
    computed_volume_rows[modulus] = {
        volume: {
            residue
            for residue in range(1, modulus)
            if gcd(residue, modulus) == 1
            and len(prime_twisted_packet(modulus, residue)) == volume
        }
        for volume in range(3, 7)
    }
report(
    "R=11 and R=23 prime-twisted target-volume tables",
    computed_volume_rows == expected_volume_rows,
)

universal_homotheties = [
    packet_sets(modulus)[0]
    == {
        pow(12, -1, modulus) * value % modulus
        for value in packet_sets(modulus)[1]
    }
    for modulus in range(11, 12000, 12)
]
report(
    "universal forced-3 packet homothety",
    all(universal_homotheties),
)

universal_exchange_involutions = [
    multiply_2_by_2(
        packet_exchange_matrix(modulus),
        packet_exchange_matrix(modulus),
        modulus,
    )
    == ((1, 0), (0, 1))
    for modulus in range(11, 12000, 12)
]
report(
    "universal weighted packet exchange involution",
    all(universal_exchange_involutions),
)
report(
    "first two weighted packet exchange matrices",
    packet_exchange_matrix(11) == ((0, 1), (1, 0))
    and packet_exchange_matrix(23) == ((0, 2), (12, 0)),
)

universal_collisions = [
    modulus
    for modulus in range(11, 12000, 12)
    if packet_sets(modulus)[0] == packet_sets(modulus)[1]
]
report(
    "unique universal forced-3 packet collision",
    universal_collisions == [11],
)
equal_amplitude_residuals = [
    modulus
    for modulus in range(11, 12000, 12)
    if pow(12, -1, modulus) == 1
]
report(
    "unique universal equal-amplitude blade carriage",
    equal_amplitude_residuals == [11],
)

prime_twisted_volume_rows = []
prime_twisted_residues_checked = 0
for modulus in range(11, 1200, 12):
    for residue in range(1, modulus):
        if gcd(residue, modulus) != 1:
            continue
        prime_twisted_residues_checked += 1
        prime_twisted_volume_rows.append(
            len(prime_twisted_packet(modulus, residue))
            == expected_prime_twisted_volume(modulus, residue)
        )
report(
    "universal prime-twisted target-volume formula",
    all(prime_twisted_volume_rows),
)

divisor_count_rows = []
divisor_count_primes = 0
divisor_count_shells = 0
for prime in range(13, 5001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    divisor_count_primes += 1
    k = (prime - 1) // 12
    actual = {volume: 0 for volume in range(3, 7)}
    for m in range(1, 2 * k + 1):
        modulus = 12 * m - 1
        volume = len(
            prime_twisted_packet(modulus, prime % modulus)
        )
        actual[volume] += 1
        divisor_count_shells += 1
    upper_bound = 24 * k - 1
    expected = {
        3: restricted_eleven_divisor_count(k, upper_bound),
        4: (
            restricted_eleven_divisor_count(6 * k - 1, upper_bound)
            + restricted_eleven_divisor_count(18 * k + 1, upper_bound)
        ),
        5: (
            restricted_eleven_divisor_count(3 * k - 2, upper_bound)
            + restricted_eleven_divisor_count(27 * k + 2, upper_bound)
        ),
    }
    expected[6] = 2 * k - expected[3] - expected[4] - expected[5]
    divisor_count_rows.append(actual == expected)
report(
    "divisor counts for submaximal prime-twisted targets",
    all(divisor_count_rows),
)

factor_two_short_cycles = [
    modulus
    for modulus in range(3, 12000, 4)
    if multiplicative_order(2, modulus) <= 4
]
report(
    "factor-2 short-cycle residuals",
    factor_two_short_cycles == [3, 7, 15],
)

factor_two_exceptional_rows = []
for residue in range(1, 3):
    factor_two_exceptional_rows.append(
        len(factor_prime_twisted_packet(3, residue, 2)) == 2
    )
subgroup_seven = {1, 2, 4}
for residue in range(1, 7):
    factor_two_exceptional_rows.append(
        len(factor_prime_twisted_packet(7, residue, 2))
        == (3 if residue in subgroup_seven else 6)
    )
subgroup_fifteen = {1, 2, 4, 8}
for residue in range(1, 15):
    if gcd(residue, 15) != 1:
        continue
    expected_volume = (
        3
        if residue == 1
        else 4
        if residue in subgroup_fifteen
        else 6
    )
    factor_two_exceptional_rows.append(
        len(factor_prime_twisted_packet(15, residue, 2))
        == expected_volume
    )
report(
    "factor-2 exceptional target-volume laws",
    all(factor_two_exceptional_rows),
)

factor_two_generic_rows = []
factor_two_generic_units_checked = 0
for modulus in range(3, 1200, 4):
    if modulus in {3, 7, 15}:
        continue
    for residue in range(1, modulus):
        if gcd(residue, modulus) != 1:
            continue
        factor_two_generic_units_checked += 1
        factor_two_generic_rows.append(
            len(factor_prime_twisted_packet(modulus, residue, 2))
            == expected_segment_volume(modulus, residue, 2)
        )
report(
    "factor-2 generic target-volume law",
    all(factor_two_generic_rows),
)


state_counts = {}
for modulus in (11, 23):
    checked = 0
    rows = []
    reachability_homotheties = []
    one_box_rows = []
    for total in range(0, 5):
        for valuations in weak_compositions(total, modulus - 2):
            checked += 1
            rows.append(
                packet_occupied(valuations, modulus)
                == occupied_after_inserting_three(valuations, modulus)
            )
            exterior_reached = reachable_set(
                valuations,
                modulus,
                "exterior",
            )
            middle_reached = reachable_set(
                valuations,
                modulus,
                "middle",
            )
            b_residue = residue_of_valuations(valuations, modulus)
            reachability_homotheties.append(
                exterior_reached
                == {
                    b_residue * value % modulus
                    for value in middle_reached
                }
            )
            one_box_rows.append(
                packet_occupied(valuations, modulus)
                == one_box_occupied(valuations, modulus)
            )
    state_counts[modulus] = checked
    report(
        f"R={modulus} packet identity on bounded states",
        all(rows),
    )
    report(
        f"R={modulus} one-box reachability homothety",
        all(reachability_homotheties),
    )
    report(
        f"R={modulus} one-box packet criterion",
        all(one_box_rows),
    )


def original_occupied(a, modulus):
    exterior = any(
        (4 * divisor + 1) % modulus == 0
        for divisor in divisors(a * a)
    )
    ds = divisors(a)
    middle = any(
        gcd(left, right) == 1
        and a % (left * right) == 0
        and (left + right) % modulus == 0
        for left in ds
        for right in ds
    )
    return exterior or middle


factor_two_affine_rows = []
factor_two_affine_primes = 0
factor_two_affine_shells = 0
factor_two_automatic_rows = []
factor_two_r15_rows = []
for prime in range(13, 1001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    factor_two_affine_primes += 1
    k = (prime - 1) // 12
    parity = k % 2
    first_shell_occupied = None
    second_shell_occupied = None
    for m in range(1, 3 * k + 1):
        j = 2 * m - parity
        modulus = 8 * m - 4 * parity - 1
        reduced = (3 * k - parity) // 2 + m
        a = 2 * reduced
        packet_value = factor_one_box_occupied(
            valuation_vector(reduced, modulus),
            modulus,
            prime % modulus,
            2,
        )
        factor_two_affine_rows.append(
            j >= 1
            and j <= 6 * k
            and 4 * j - 1 == modulus
            and 8 * reduced == prime + modulus
            and packet_value == original_occupied(a, modulus)
        )
        factor_two_affine_shells += 1
        if m == 1:
            first_shell_occupied = packet_value
        if m == 2:
            second_shell_occupied = packet_value
    if parity == 1:
        factor_two_automatic_rows.append(first_shell_occupied)
    elif prime % 7 not in subgroup_seven:
        factor_two_automatic_rows.append(first_shell_occupied)
    if parity == 0 and prime % 15 in {7, 13}:
        factor_two_r15_rows.append(second_shell_occupied)
report(
    "universal every-second-shell packet criterion",
    all(factor_two_affine_rows),
)
report(
    "automatic factor-2 R=3 and R=7 families",
    all(factor_two_automatic_rows),
)
report(
    "automatic factor-2 R=15 families",
    all(factor_two_r15_rows),
)


prime_rows = []
prime_count = 0
factor_three_r11_rows = []
factor_three_r23_two_power_rows = []
factor_three_r23_packet = {15, 20, 22}
factor_three_r23_power_one = {
    target * pow(2, exponent, 23) % 23
    for target in factor_three_r23_packet
    for exponent in range(-1, 2)
}
factor_three_r23_power_two = {
    target * pow(2, exponent, 23) % 23
    for target in factor_three_r23_packet
    for exponent in range(-2, 3)
}
factor_three_r23_nonresidues = {
    unit for unit in range(1, 23) if pow(unit, 11, 23) == 22
}
factor_three_r23_factor_three = {
    target * pow(3, exponent, 23) % 23
    for target in factor_three_r23_packet
    for exponent in range(-1, 2)
}
factor_three_r23_factor_seventeen = {
    target * pow(17, exponent, 23) % 23
    for target in factor_three_r23_packet
    for exponent in range(-1, 2)
}
factor_three_r23_factor_three_rows = []
factor_three_r23_factor_seventeen_rows = []
r23_log_rows = []
r23_character_rows = []
r23_edge_pattern_rows = []
r23_edge_two_adic_rows = []
r23_edge_adjacent_isolation_rows = []
r23_edge_first_six_rows = []
for prime in range(13, 20001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    prime_count += 1
    for modulus in (11, 23):
        a = (prime + modulus) // 4
        reduced = a // 3
        packet_value = packet_occupied(
            valuation_vector(reduced, modulus),
            modulus,
        )
        original_value = original_occupied(a, modulus)
        prime_rows.append(a % 3 == 0 and packet_value == original_value)
        if modulus == 11 and prime % 11 in {7, 8, 10}:
            factor_three_r11_rows.append(original_value)
        if modulus == 23 and (
            (
                prime % 48 == 1
                and prime % 23 in factor_three_r23_power_one
            )
            or (
                prime % 48 == 25
                and prime % 23 in factor_three_r23_power_two
            )
        ):
            factor_three_r23_two_power_rows.append(original_value)
        if (
            modulus == 23
            and prime % 144 == 49
            and prime % 23 in {5, 14}
        ):
            factor_three_r23_factor_three_rows.append(original_value)
        if (
            modulus == 23
            and prime % 204 == 181
            and prime % 23 in factor_three_r23_factor_seventeen
        ):
            factor_three_r23_factor_seventeen_rows.append(original_value)
        if modulus == 23:
            r23_log_rows.append(
                log_packet_occupied_23(prime) == original_value
            )
            negative_count = sum(
                multiplicity
                for factor, multiplicity in factorization(reduced)
                if pow(factor % 23, 11, 23) == 22
            )
            prime_character = pow(prime % 23, 11, 23)
            reduced_character = pow(reduced % 23, 11, 23)
            r23_character_rows.append(
                reduced_character == prime_character
                and negative_count % 2
                == (0 if prime_character == 1 else 1)
                and not (
                    prime_character == 1
                    and original_value
                    and negative_count < 2
                )
            )
            prime_logarithm = discrete_log_23[prime % 23]
            if prime_logarithm in edge_exception_patterns_23:
                r23_edge_pattern_rows.append(
                    (not original_value)
                    == (
                        nonzero_log_multiset_23(reduced)
                        in edge_exception_patterns_23[prime_logarithm]
                    )
                )
                if prime % 48 == 1:
                    reduced_factors = factorization(reduced)
                    nontrivial_odd_factors = [
                        (factor, multiplicity)
                        for factor, multiplicity in reduced_factors
                        if factor != 2 and factor % 23 != 1
                    ]
                    two_adic_survivor = (
                        dict(reduced_factors).get(2) == 1
                        and len(nontrivial_odd_factors) == 1
                        and nontrivial_odd_factors[0][1] == 1
                        and nontrivial_odd_factors[0][0] % 23
                        == prime % 23
                        and all(
                            factor == 2
                            or factor % 23 == 1
                            or (factor, multiplicity)
                            == nontrivial_odd_factors[0]
                            for factor, multiplicity in reduced_factors
                        )
                    )
                    r23_edge_two_adic_rows.append(
                        (not original_value) == two_adic_survivor
                    )
                    if two_adic_survivor:
                        distinguished_prime = nontrivial_odd_factors[0][0]
                        tail = reduced // (2 * distinguished_prime)
                        c_value = reduced - 1
                        adjacent = (
                            3 * c_value - 2,
                            3 * c_value - 1,
                            c_value,
                            3 * c_value + 1,
                            3 * c_value + 2,
                        )
                        r23_edge_adjacent_isolation_rows.append(
                            adjacent
                            == (
                                3 * reduced - 5,
                                3 * reduced - 4,
                                reduced - 1,
                                3 * reduced - 2,
                                3 * reduced - 1,
                            )
                            and tuple(gcd(reduced, value) for value in adjacent)
                            == (gcd(reduced, 5), 2, 1, 2, 1)
                            and gcd(
                                tail,
                                adjacent[0]
                                * adjacent[1]
                                * adjacent[2]
                                * adjacent[3]
                                * adjacent[4],
                            )
                            == 1
                            and gcd(
                                distinguished_prime,
                                adjacent[1]
                                * adjacent[2]
                                * adjacent[3]
                                * adjacent[4],
                            )
                            == 1
                            and gcd(distinguished_prime, adjacent[0])
                            == gcd(distinguished_prime, 5)
                        )
                        ell_u = distinguished_prime * tail
                        condition_three = all(
                            factor % 3 == 1
                            for factor, _ in factorization(6 * ell_u - 5)
                        )
                        condition_seven = all(
                            factor % 7 in {1, 2, 4}
                            for factor, _ in factorization(3 * ell_u - 2)
                        )
                        condition_fifteen = all(
                            factor % 15 in {1, 2, 4, 8}
                            for factor, _ in factorization(3 * ell_u - 1)
                        )
                        specialized_first_six = (
                            condition_three
                            and condition_seven
                            and not original_occupied((prime + 11) // 4, 11)
                            and condition_fifteen
                            and not original_occupied((prime + 19) // 4, 19)
                        )
                        actual_first_six = all(
                            not original_occupied(
                                (prime + modulus) // 4,
                                modulus,
                            )
                            for modulus in (3, 7, 11, 15, 19, 23)
                        )
                        r23_edge_first_six_rows.append(
                            distinguished_prime % 2 == 1
                            and tail % 2 == 1
                            and specialized_first_six == actual_first_six
                        )

report(
    "R=11 and R=23 affine-shell packet criterion",
    all(prime_rows),
)
report(
    "R=23 primitive logarithm and target coordinates",
    len(discrete_log_23) == 22
    and {
        discrete_log_23[value]
        for value in factor_three_r23_packet
    }
    == target_log_packet_23,
)
report(
    "R=23 additive signed-box criterion",
    all(r23_log_rows),
)
report(
    "R=23 quadratic-character balance",
    all(r23_character_rows),
)
report(
    "R=23 edge-log effective forbidden set",
    edge_forbidden_23
    == {4, 5, 6, 10, 11, 12, 16, 17, 18}
    and edge_forbidden_23
    == (
        edge_target_minus_one_23
        | {(-value) % 22 for value in edge_target_minus_one_23}
    ),
)
report(
    "R=23 edge-log safe multiset classification",
    edge_safe_multisets_23[3]
    == {
        (1, 1, 1),
        (1, 1, 21),
        (1, 21, 21),
        (7, 7, 7),
        (7, 7, 15),
        (7, 15, 15),
        (15, 15, 15),
        (21, 21, 21),
    }
    and edge_safe_multisets_23[4] == set(),
)
report(
    "R=23 edge-log empty-shell patterns",
    all(r23_edge_pattern_rows),
)
report(
    "R=23 edge-log two-adic survivor form",
    all(r23_edge_two_adic_rows),
)
report(
    "R=23 edge-survivor adjacent-shell isolation",
    bool(r23_edge_adjacent_isolation_rows)
    and all(r23_edge_adjacent_isolation_rows),
)
report(
    "R=23 edge first-six intersection",
    bool(r23_edge_first_six_rows)
    and all(r23_edge_first_six_rows),
)
report(
    "automatic factor-3 R=11 families",
    all(factor_three_r11_rows),
)
report(
    "R=23 signed powers of two",
    factor_three_r23_power_one
    == {7, 10, 11, 15, 17, 19, 20, 21, 22}
    and factor_three_r23_power_two == factor_three_r23_nonresidues
    and len(factor_three_r23_power_two) == 11,
)
report(
    "automatic factor-3 R=23 two-power families",
    all(factor_three_r23_two_power_rows),
)
report(
    "R=23 signed factor-three packet",
    factor_three_r23_factor_three == {5, 14, 15, 20, 22},
)
report(
    "automatic R=23 factor-three families",
    all(factor_three_r23_factor_three_rows),
)
report(
    "R=23 signed factor-seventeen packet",
    factor_three_r23_factor_seventeen
    == {2, 4, 6, 9, 12, 15, 18, 20, 22},
)
report(
    "automatic R=23 factor-seventeen families",
    all(factor_three_r23_factor_seventeen_rows),
)

automatic_admissible = [
    residue
    for residue in range(9240)
    if residue % 12 == 1 and gcd(residue, 9240) == 1
]
automatic_certified = [
    residue
    for residue in automatic_admissible
    if (
        residue % 24 == 13
        or residue % 168 in {73, 97, 145}
        or residue % 120 in {73, 97}
        or residue % 132 in {73, 85, 109}
    )
]
automatic_uncovered = set(automatic_admissible) - set(automatic_certified)
report(
    "combined factor-2 and factor-3 automatic residue sieve",
    len(automatic_admissible) == 480
    and len(automatic_certified) == 438
    and len(automatic_uncovered) == 42
    and all(
        residue % 24 == 1
        and residue % 5 in {1, 4}
        and residue % 7 in {1, 2, 4}
        and residue % 11 in {1, 2, 3, 4, 5, 6, 9}
        for residue in automatic_uncovered
    ),
)

refined_admissible = [
    residue
    for residue in range(425040)
    if residue % 12 == 1 and gcd(residue, 425040) == 1
]


def old_automatic_carrier(residue):
    return (
        residue % 24 == 13
        or residue % 168 in {73, 97, 145}
        or residue % 120 in {73, 97}
        or residue % 132 in {73, 85, 109}
    )


def r23_two_power_carrier(residue):
    return (
        residue % 48 == 1
        and residue % 23 in factor_three_r23_power_one
    ) or (
        residue % 48 == 25
        and residue % 23 in factor_three_r23_power_two
    )


refined_certified = [
    residue
    for residue in refined_admissible
    if old_automatic_carrier(residue) or r23_two_power_carrier(residue)
]
refined_uncovered = set(refined_admissible) - set(refined_certified)
report(
    "R=23 refinement of the automatic residue sieve",
    len(refined_admissible) == 21120
    and len(refined_certified) == 20112
    and len(refined_uncovered) == 1008
    and all(
        residue % 24 == 1
        and residue % 5 in {1, 4}
        and residue % 7 in {1, 2, 4}
        and residue % 11 in {1, 2, 3, 4, 5, 6, 9}
        and (
            (
                residue % 48 == 1
                and residue % 23 not in factor_three_r23_power_one
            )
            or (
                residue % 48 == 25
                and residue % 23 not in factor_three_r23_power_two
            )
        )
        for residue in refined_uncovered
    ),
)

factor_three_refined_admissible = [
    residue
    for residue in range(1275120)
    if residue % 12 == 1 and gcd(residue, 1275120) == 1
]


def r23_factor_three_carrier(residue):
    return residue % 144 == 49 and residue % 23 in {5, 14}


factor_three_refined_certified = [
    residue
    for residue in factor_three_refined_admissible
    if (
        old_automatic_carrier(residue)
        or r23_two_power_carrier(residue)
        or r23_factor_three_carrier(residue)
    )
]
report(
    "R=23 factor-three refinement of the automatic residue sieve",
    len(factor_three_refined_admissible) == 63360
    and len(factor_three_refined_certified) == 60420
    and (
        len(factor_three_refined_admissible)
        - len(factor_three_refined_certified)
    )
    == 2940,
)

factor_three_refined_certified_set = set(
    factor_three_refined_certified
)
factor_seventeen_lift_total = 0
factor_seventeen_lift_certified = 0
factor_seventeen_new_count = 0
factor_seventeen_new_residues = set()
for base_residue in factor_three_refined_admissible:
    for lift_index in range(17):
        lifted_residue = base_residue + 1275120 * lift_index
        if lifted_residue % 17 == 0:
            continue
        factor_seventeen_lift_total += 1
        old_value = (
            base_residue in factor_three_refined_certified_set
        )
        new_value = (
            lifted_residue % 17 == 11
            and lifted_residue % 23
            in factor_three_r23_factor_seventeen
        )
        factor_seventeen_lift_certified += old_value or new_value
        if new_value and not old_value:
            factor_seventeen_new_count += 1
            factor_seventeen_new_residues.add(
                lifted_residue % 23
            )

report(
    "R=23 factor-seventeen refinement of the automatic residue sieve",
    factor_seventeen_lift_total == 1013760
    and factor_seventeen_new_count == 1512
    and factor_seventeen_lift_certified == 968232
    and (
        factor_seventeen_lift_total
        - factor_seventeen_lift_certified
    )
    == 45528
    and factor_seventeen_new_residues
    == {2, 4, 6, 9, 12, 18},
)

print(f"R=11 bounded reduced states checked: {state_counts[11]}")
print(f"R=23 bounded reduced states checked: {state_counts[23]}")
print(f"affine primes checked per residual: {prime_count}")
print(f"affine residual checks: {len(prime_rows)}")
print(f"universal forced-3 residuals checked: {len(range(11, 12000, 12))}")
print(
    "prime-twisted unit residues checked: "
    f"{prime_twisted_residues_checked}"
)
print(f"divisor-count primes checked: {divisor_count_primes}")
print(f"divisor-count shells checked: {divisor_count_shells}")
print(f"factor-2 affine primes checked: {factor_two_affine_primes}")
print(f"factor-2 affine shells checked: {factor_two_affine_shells}")
print(
    "factor-2 generic unit residues checked: "
    f"{factor_two_generic_units_checked}"
)

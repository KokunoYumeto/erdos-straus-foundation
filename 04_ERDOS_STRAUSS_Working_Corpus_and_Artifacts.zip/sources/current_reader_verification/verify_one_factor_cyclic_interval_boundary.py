from fractions import Fraction
from math import gcd


ORDER_LIMIT = 160


def support_interval(order, exponent):
    return {
        residue % order
        for residue in range(-exponent, exponent + 1)
    }


def support_stabilizer(order, support):
    return {
        shift
        for shift in range(order)
        if {
            (value + shift) % order
            for value in support
        }
        == support
    }


def displacement_orbits(order, displacement):
    unseen = set(range(order))
    orbits = []
    while unseen:
        start = min(unseen)
        orbit = []
        value = start
        while value not in orbit:
            orbit.append(value)
            value = (value + displacement) % order
        if value != start:
            raise AssertionError("displacement orbit did not close at its start")
        unseen.difference_update(orbit)
        orbits.append(tuple(orbit))
    return tuple(orbits)


interval_checks = 0
boundary_checks = 0

for order in range(2, ORDER_LIMIT + 1):
    for exponent in range((order - 2) // 2 + 1):
        length = 2 * exponent + 1
        if not length < order:
            continue
        support = support_interval(order, exponent)
        if len(support) != length:
            raise AssertionError("proper cyclic interval lost a residue")
        if support_stabilizer(order, support) != {0}:
            raise AssertionError("proper cyclic interval has a period")
        interval_checks += 1

        for displacement in range(1, order):
            divisor = gcd(order, displacement)
            orbit_order = order // divisor
            orbits = displacement_orbits(order, displacement)
            if len(orbits) != divisor:
                raise AssertionError("wrong number of displacement orbits")
            if any(len(orbit) != orbit_order for orbit in orbits):
                raise AssertionError("wrong displacement orbit length")

            support_counts = tuple(
                len(set(orbit) & support)
                for orbit in orbits
            )
            quotient, remainder = divmod(length, divisor)
            expected_counts = tuple(
                sorted(
                    (quotient + 1,) * remainder
                    + (quotient,) * (divisor - remainder)
                )
            )
            if tuple(sorted(support_counts)) != expected_counts:
                raise AssertionError(
                    "cyclic interval orbit-count distribution failed"
                )

            direct_boundary = sum(
                Fraction(
                    count * (orbit_order - count),
                    orbit_order,
                )
                for count in support_counts
            )
            formula_boundary = Fraction(
                remainder
                * (quotient + 1)
                * (orbit_order - quotient - 1)
                + (divisor - remainder)
                * quotient
                * (orbit_order - quotient),
                orbit_order,
            )
            if direct_boundary != formula_boundary:
                raise AssertionError(
                    "one-factor support-boundary formula failed"
                )
            boundary_checks += 1


p13_order = 6
p13_exponent = 1
p13_displacement = 3
p13_support = support_interval(p13_order, p13_exponent)
p13_orbits = displacement_orbits(p13_order, p13_displacement)
p13_boundary = sum(
    Fraction(
        len(set(orbit) & p13_support)
        * (len(orbit) - len(set(orbit) & p13_support)),
        len(orbit),
    )
    for orbit in p13_orbits
)
assert p13_support == {0, 1, 5}
assert p13_orbits == ((0, 3), (1, 4), (2, 5))
assert p13_boundary == Fraction(3, 2)

print("PASS: one-factor cyclic-interval support-boundary formula")
print(f"cyclic orders checked: 2..{ORDER_LIMIT}")
print(f"proper centered intervals checked: {interval_checks}")
print(f"interval/displacement triples checked: {boundary_checks}")
print(f"(n,L,r)=(6,3,3) support: {tuple(sorted(p13_support))}")
print(f"(n,L,r)=(6,3,3) orbits: {p13_orbits}")
print(f"(n,L,r)=(6,3,3) boundary energy: {p13_boundary}")

from collections import Counter
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


DEFAULT_LIMIT = 100_000
GENERAL_RESIDUAL_LIMIT = 2_000


def prime_sieve(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            start = prime * prime
            sieve[start : limit + 1 : prime] = (
                b"\x00" * (((limit - start) // prime) + 1)
            )
    return sieve


def factor_integer(value, trial_primes):
    factors = []
    remainder = value
    for prime in trial_primes:
        if prime * prime > remainder:
            break
        if remainder % prime:
            continue
        exponent = 0
        while remainder % prime == 0:
            remainder //= prime
            exponent += 1
        factors.append((prime, exponent))
    if remainder > 1:
        factors.append((remainder, 1))
    return tuple(factors)


def divisors_from_factorization(factors):
    values = [1]
    for prime, exponent in factors:
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    values.sort()
    return values


def coupled_shell_witness(p, residual, trial_primes):
    a = (p + residual) // 4
    factors = factor_integer(a, trial_primes)
    square_factors = tuple((prime, 2 * exponent) for prime, exponent in factors)
    target = (-a) % residual
    for divisor in divisors_from_factorization(square_factors):
        if divisor % residual == target:
            return a, divisor, factors
    return None


def complete_shell_witnesses(p, residual, trial_primes):
    if residual >= 2 * p:
        return None
    a = (p + residual) // 4
    factors = factor_integer(a, trial_primes)
    square_factors = tuple((prime, 2 * exponent) for prime, exponent in factors)
    exterior = None
    middle = None
    for divisor in divisors_from_factorization(square_factors):
        if exterior is None and (4 * divisor + 1) % residual == 0:
            exterior = divisor
        if middle is None and (divisor + a) % residual == 0:
            middle = divisor
        if exterior is not None and middle is not None:
            break
    return a, exterior, middle, factors


def scan(limit):
    sieve = prime_sieve(limit)
    trial_sieve = prime_sieve(isqrt(limit) + 1)
    trial_primes = [
        value for value in range(2, len(trial_sieve)) if trial_sieve[value]
    ]

    relevant = 0
    covered = 0
    uncovered = []
    least_residual_counts = Counter()
    largest_least_residual = (0, 0, 0, 0)
    witness_checks = 0
    first_general_counts = Counter()
    first_general_channel_counts = Counter()
    first_general_channel_residual_counts = Counter()
    first_general_channel_examples = {
        "both": [],
        "exterior": [],
        "middle": [],
    }
    first_general_data = []
    no_general_shell = []

    for p in range(13, limit + 1, 12):
        if not sieve[p]:
            continue
        relevant += 1
        p_minus_one_factors = factor_integer(p - 1, trial_primes)
        residuals = [
            divisor
            for divisor in divisors_from_factorization(p_minus_one_factors)
            if divisor % 4 == 3
        ]

        first = None
        for residual in residuals:
            witness_checks += 1
            witness = coupled_shell_witness(p, residual, trial_primes)
            if witness is not None:
                first = (residual, *witness[:2])
                break

        if first is None:
            uncovered.append((p, tuple(residuals), p_minus_one_factors))
            continue

        covered += 1
        residual, a, divisor = first
        least_residual_counts[residual] += 1
        if residual > largest_least_residual[0]:
            largest_least_residual = (residual, p, a, divisor)

    for p, residuals, p_minus_one_factors in uncovered:
        first_general = None
        for residual in range(3, min(GENERAL_RESIDUAL_LIMIT, 2 * p), 4):
            data = complete_shell_witnesses(p, residual, trial_primes)
            if data is None:
                continue
            a, exterior, middle, factors = data
            if exterior is not None or middle is not None:
                first_general = (residual, a, exterior, middle, factors)
                break
        if first_general is None:
            no_general_shell.append(p)
            continue
        residual, a, exterior, middle, factors = first_general
        if (p - 1) % residual == 0:
            raise AssertionError(
                f"p={p} has a coupled shell after coupled-shell failure"
            )
        channel = (
            "both"
            if exterior is not None and middle is not None
            else "exterior"
            if exterior is not None
            else "middle"
        )
        first_general_counts[residual] += 1
        first_general_channel_counts[channel] += 1
        first_general_channel_residual_counts[(channel, residual)] += 1
        first_general_channel_examples[channel].append(
            (p, residual, a, exterior, middle, factors)
        )
        first_general_data.append(
            (p, residual, a, exterior, middle, factors)
        )

    print("coupled-shell complete divisor-section coverage scan")
    print(f"limit: {limit}")
    print(f"relevant primes p == 1 (mod 12): {relevant}")
    print(f"covered by at least one coupled shell: {covered}")
    print(f"uncovered by every coupled shell: {len(uncovered)}")
    print(f"coupled shell witness tests: {witness_checks}")
    print(
        "largest least occupied coupled residual: "
        f"R={largest_least_residual[0]}, p={largest_least_residual[1]}, "
        f"a={largest_least_residual[2]}, u={largest_least_residual[3]}"
    )
    print("least occupied coupled residual counts:")
    for residual, count in sorted(least_residual_counts.items()):
        print(f"  R={residual}: {count}")
    print("first uncovered primes:")
    for p, residuals, factors in uncovered[:12]:
        print(f"  p={p}; p-1 factors={factors}; coupled residuals={residuals}")
    print(
        "first occupied general-shell residual counts among coupled failures:"
    )
    for residual, count in sorted(first_general_counts.items()):
        print(f"  R={residual}: {count}")
    print("first occupied general-shell channel counts:")
    for channel, count in sorted(first_general_channel_counts.items()):
        print(f"  {channel}: {count}")
    print("first occupied general-shell residual-by-channel counts:")
    for (channel, residual), count in sorted(
        first_general_channel_residual_counts.items(),
        key=lambda item: (item[0][1], item[0][0]),
    ):
        print(f"  R={residual}, {channel}: {count}")
    for channel in ("exterior", "middle"):
        print(f"first {channel}-only general-shell witnesses:")
        for p, residual, a, exterior, middle, factors in (
            first_general_channel_examples[channel][:6]
        ):
            print(
                f"  p={p}; R={residual}; a={a}; "
                f"exterior u={exterior}; middle u={middle}; a factors={factors}"
            )
    print("first general-shell witnesses for coupled failures:")
    for p, residual, a, exterior, middle, factors in first_general_data[:12]:
        print(
            f"  p={p}; R={residual}; a={a}; "
            f"exterior u={exterior}; middle u={middle}; a factors={factors}"
        )
    print(
        "coupled failures with no occupied general shell below "
        f"R={GENERAL_RESIDUAL_LIMIT}: {len(no_general_shell)}"
    )
    if no_general_shell:
        print(f"  primes: {tuple(no_general_shell[:40])}")
    return no_general_shell


if __name__ == "__main__":
    bound = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_LIMIT
    missing = scan(bound)
    raise SystemExit(1 if missing else 0)

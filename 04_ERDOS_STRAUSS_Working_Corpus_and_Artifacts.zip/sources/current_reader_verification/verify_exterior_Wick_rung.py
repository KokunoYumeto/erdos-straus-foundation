from sympy import Matrix, Rational, sqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


for m in range(3, 6):
    identity = Matrix.eye(m)
    j = Matrix.ones(m, 1)
    u = j / sqrt(m)
    projector = identity - Rational(1, m) * j * j.T
    lorentz = identity - Rational(2, m) * j * j.T

    report(f"rank {m} centered carrier dimension", projector.rank() == m - 1)
    report(f"rank {m} temporal unit vector", (u.T * u)[0] == 1)
    report(f"rank {m} temporal eigenvalue", lorentz * u == -u)
    report(
        f"rank {m} Lorentz spectrum",
        lorentz.eigenvals() == {-1: 1, 1: m - 1},
    )

    singleton_gram = projector.T * projector
    report(
        f"rank {m} singleton Gram diagonal",
        all(singleton_gram[a, a] == Rational(m - 1, m) for a in range(m)),
    )
    report(
        f"rank {m} singleton Gram off diagonal",
        all(
            singleton_gram[a, b] == -Rational(1, m)
            for a in range(m)
            for b in range(m)
            if a != b
        ),
    )

    contracted_coefficients = tuple(
        Rational((-1) ** k, 1) / sqrt(m) for k in range(m)
    )
    report(
        f"rank {m} contracted covolume has unit norm",
        sum(coefficient ** 2 for coefficient in contracted_coefficients) == 1,
    )

    spatial_columns = []
    for a in range(m - 1):
        column = Matrix.zeros(m, 1)
        column[a, 0] = 1
        column[m - 1, 0] = -1
        spatial_columns.append(column)
    oriented_frame = Matrix.hstack(u, *spatial_columns)
    report(
        f"rank {m} contracted covolume is nonzero on the spatial carrier",
        oriented_frame.det() == (-1) ** (m - 1) * sqrt(m),
    )

    expected_signature = (m - 1, 1)
    expected_internal_group = f"SU({m})"
    report(
        f"rank {m} dimension table",
        expected_signature[0] == projector.rank()
        and expected_signature[1] == 1
        and expected_internal_group == f"SU({m})",
    )

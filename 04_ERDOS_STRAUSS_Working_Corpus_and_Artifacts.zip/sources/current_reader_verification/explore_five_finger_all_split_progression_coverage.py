from math import gcd, isqrt


BOUND = 100_000_000
CLASS_MODULUS = 35_420


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")

SPLIT = {
    3: {1},
    7: {1, 2, 4},
    11: {1, 3, 4, 5, 9},
    15: {1, 2, 4, 8},
    19: {1, 4, 5, 6, 7, 9, 11, 16, 17},
}

FAMILIES = (
    ("A", 3_985, 6_372),
    ("B", 889, 936),
    ("C", 2_509, 11_412),
    ("D", 1_393, 4_464),
    ("E", 1_825, 2_088),
    ("F", 39_697, 58_032),
    ("G", 25_405, 31_212),
    ("H", 4_129, 22_320),
)


def prime_table(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for value in range(2, isqrt(limit) + 1):
        if sieve[value]:
            start = value * value
            sieve[start : limit + 1 : value] = b"\x00" * (
                (limit - start) // value + 1
            )
    return tuple(index for index, flag in enumerate(sieve) if flag)


PRIMES = prime_table(isqrt(BOUND) + 1)


def is_prime(value):
    if value < 2:
        return False
    for prime in PRIMES:
        if prime * prime > value:
            return True
        if value % prime == 0:
            return value == prime
    return True


def factorization(value):
    factors = {}
    for prime in PRIMES:
        if prime * prime > value:
            break
        while value % prime == 0:
            factors[prime] = factors.get(prime, 0) + 1
            value //= prime
    if value > 1:
        factors[value] = factors.get(value, 0) + 1
    return factors


def divisors_of_square(value):
    divisors = [1]
    for prime, exponent in factorization(value).items():
        divisors = [
            divisor * prime**power
            for divisor in divisors
            for power in range(2 * exponent + 1)
        ]
    return divisors


def shell_sets(prime, residual):
    denominator = (prime + residual) // 4
    exterior = []
    middle = []
    for value in divisors_of_square(denominator):
        if (4 * value + 1) % residual == 0:
            exterior.append(value)
        if (value + denominator) % residual == 0:
            middle.append(value)
    return denominator, tuple(sorted(exterior)), tuple(sorted(middle))


def occupied(prime, residual):
    _, exterior, middle = shell_sets(prime, residual)
    return bool(exterior or middle)


def split_supported(value, residual):
    return all(
        prime % residual in SPLIT[residual]
        for prime in factorization(value)
    )


def first_occupied_after_23(prime, ceiling=403):
    for residual in range(27, ceiling + 1, 4):
        if occupied(prime, residual):
            return residual
    return None


def family_names(prime):
    return tuple(
        name
        for name, residue, modulus in FAMILIES
        if prime % modulus == residue
    )


classes = [
    d
    for d in range(CLASS_MODULUS)
    if d % 4 == 3
    and d % 23 in {3, 9}
    and d % 7 in {1, 5, 6}
    and d % 11 in {1, 3, 4, 5, 9}
    and d % 5 in {0, 2}
]

empty_r23_rows = 0
all_five_rows = []

for residue_class in classes:
    d = residue_class if residue_class > 0 else CLASS_MODULUS
    while True:
        prime = 36 * d - 11
        if prime >= BOUND:
            break
        if is_prime(prime) and not occupied(prime, 23):
            empty_r23_rows += 1
            fingers = (
                9 * d - 2,
                (9 * d - 1) // 2,
                d,
                (9 * d + 1) // 2,
                9 * d + 2,
            )
            if all(
                split_supported(value, residual)
                for value, residual in zip(
                    fingers,
                    (3, 7, 11, 15, 19),
                )
            ):
                all_five_rows.append(
                    (
                        prime,
                        d,
                        first_occupied_after_23(prime),
                        family_names(prime),
                    )
                )
        d += CLASS_MODULUS

covered = [row for row in all_five_rows if row[3]]
uncovered = [row for row in all_five_rows if not row[3]]

first_uncovered = min(uncovered)
first_prime, first_d, first_residual, _ = first_uncovered
first_a, first_exterior, first_middle = shell_sets(
    first_prime,
    first_residual,
)

report("extended candidate-class count", len(classes) == 60)
report("extended empty residual-twenty-three count", empty_r23_rows == 519)
report("extended all-five row count", len(all_five_rows) == 29)
report("extended A--H covered count", len(covered) == 13)
report("extended A--H uncovered count", len(uncovered) == 16)
report(
    "least row outside A--H",
    first_uncovered == (25_371_889, 704_775, 27, ()),
)
report(
    "least uncovered prime Pocklington certificate",
    first_prime - 1 == 2**4 * 3 * 17**2 * 31 * 59
    and pow(46, first_prime - 1, first_prime) == 1
    and tuple(
        pow(46, (first_prime - 1) // divisor, first_prime)
        for divisor in (2, 3, 17, 31, 59)
    )
    == (25_371_888, 14_684_078, 7_058_867, 22_442_215, 19_278_722)
    and all(
        gcd(
            pow(46, (first_prime - 1) // divisor, first_prime) - 1,
            first_prime,
        )
        == 1
        for divisor in (2, 3, 17, 31, 59)
    ),
)
report(
    "least uncovered residual-twenty-seven endpoint sets",
    first_a == 6_342_979
    and factorization(first_a) == {19: 1, 47: 1, 7_103: 1}
    and first_exterior == (47, 2_564_183)
    and first_middle == (),
)

new_family_checks = []
for step in range(5):
    prime = 349 + 1_692 * step
    denominator = (prime + 27) // 4
    b = prime * (7 * prime + 1) // 4
    c = (prime + 27) * (7 * prime + 1) // 752
    new_family_checks.extend(
        (
            prime % 36 == 25,
            denominator % 47 == 0,
            (4 * 47 + 1) % 27 == 0,
            4 * denominator * b * c
            == prime * (
                denominator * b
                + denominator * c
                + b * c
            ),
        )
    )
report("new exterior-47 progression checks", all(new_family_checks))
report(
    "least uncovered row belongs to exterior-47 progression",
    first_prime == 349 + 1_692 * 14_995,
)

print(f"bound={BOUND}")
print(f"candidate classes={len(classes)}")
print(f"empty R=23 rows={empty_r23_rows}")
print(f"all-five rows={len(all_five_rows)}")
print(f"covered by A--H={len(covered)}")
print(f"uncovered by A--H={len(uncovered)}")
print("all-five rows:")
for row in sorted(all_five_rows):
    print(row)
print("least first-shell endpoints outside A--H:")
for prime, d, residual, names in sorted(uncovered):
    denominator, exterior, middle = shell_sets(prime, residual)
    print(
        (
            prime,
            d,
            residual,
            denominator,
            tuple(sorted(factorization(denominator).items())),
            len(exterior),
            exterior[0] if exterior else None,
            len(middle),
            middle[0] if middle else None,
        )
    )

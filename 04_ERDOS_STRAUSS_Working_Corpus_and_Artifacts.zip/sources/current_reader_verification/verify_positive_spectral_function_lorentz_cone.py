from __future__ import annotations

from itertools import product

import sympy as sp


def require(statement: bool, message: str) -> None:
    if not statement:
        raise AssertionError(message)
    print(f"PASS {message}")


def characteristic(values: list[sp.Expr], variable: sp.Symbol) -> sp.Expr:
    return sp.prod(variable - value for value in values)


# Independent rational orbit amplitudes for the carrier and cone checks.
type_02 = [sp.Rational(2, 7), sp.Rational(5, 11)]
type_11 = [sp.Rational(3, 13)]
orbits = [("02", index, value) for index, value in enumerate(type_02)]
orbits += [("11", index, value) for index, value in enumerate(type_11)]

# The source basis is (orbit, C3, C2); the target basis is (orbit, C2, C3).
source = [(kind, index, m, epsilon) for kind, index, _ in orbits
          for m, epsilon in product(range(3), range(2))]
target = [(kind, index, epsilon, m) for kind, index, _ in orbits
          for epsilon, m in product(range(2), range(3))]
source_index = {label: position for position, label in enumerate(source)}
target_index = {label: position for position, label in enumerate(target)}
amplitude = {(kind, index): value for kind, index, value in orbits}

permutation = sp.zeros(len(source), len(source))
for source_label, column in source_index.items():
    kind, index, m, epsilon = source_label
    row = target_index[(kind, index, epsilon, m)]
    permutation[row, column] = 1

source_operator = sp.diag(*[
    amplitude[(kind, index)] for kind, index, _, _ in source
])
target_operator = sp.diag(*[
    amplitude[(kind, index)] for kind, index, _, _ in target
])

require(
    permutation.T * permutation == sp.eye(len(source)),
    "the explicit stable tensor flip is unitary",
)
require(
    permutation * source_operator * permutation.T == target_operator,
    "the stable tensor flip preserves every orbit type and amplitude",
)

# Typewise spectral measures, traces, and characteristic polynomials.
t = sp.symbols("t")
for kind, values in (("02", type_02), ("11", type_11)):
    path_values = [value for value in values for _ in range(3)]
    divisor_values = [value for value in values for _ in range(2)]
    require(
        all(path_values.count(value) == 3 and divisor_values.count(value) == 2
            for value in values),
        f"type {kind} has path multiplicity three and divisor multiplicity two",
    )
    require(
        sp.expand(characteristic(path_values, t) ** 2
                  - characteristic(divisor_values, t) ** 3) == 0,
        f"type {kind} satisfies the squared-path cubed-divisor characteristic identity",
    )
    for degree in range(7):
        path_trace = sum(value ** degree for value in path_values)
        divisor_trace = sum(value ** degree for value in divisor_values)
        require(
            sp.factor(2 * path_trace - 3 * divisor_trace) == 0,
            f"type {kind} moment degree {degree} obeys the exact 2:3 transfer",
        )

# Generic positive-function Lorentz matrix.
u_1, u_2, v_1 = sp.symbols("u_1 u_2 v_1", nonnegative=True)
eta_02 = u_1 + u_2
eta_11 = v_1
lambda_plus = eta_02 + eta_11
lambda_minus = eta_02 - eta_11
lorentz = sp.Matrix([[lambda_plus, lambda_minus],
                     [lambda_minus, lambda_plus]])
v_plus = sp.Matrix([1, 1])
v_minus = sp.Matrix([1, -1])

require(
    lorentz * v_plus == 2 * eta_02 * v_plus
    and lorentz * v_minus == 2 * eta_11 * v_minus,
    "the two typewise masses are the exact Lorentz eigenvalues divided by two",
)
require(
    sp.factor(lorentz.det() - 4 * eta_02 * eta_11) == 0,
    "the positive-function Lorentz determinant is four times the type-mass product",
)

# Linearity of the cone map on independent spectral-function values.
r, s = sp.symbols("r s", nonnegative=True)
x_1, x_2, y_1 = sp.symbols("x_1 x_2 y_1", nonnegative=True)


def cone_matrix(values_02: list[sp.Expr], values_11: list[sp.Expr]) -> sp.Matrix:
    left = sum(values_02, sp.S.Zero)
    right = sum(values_11, sp.S.Zero)
    return sp.Matrix([[left + right, left - right],
                      [left - right, left + right]])


linearity_difference = (
    cone_matrix([r * u_1 + s * x_1, r * u_2 + s * x_2],
                [r * v_1 + s * y_1])
    - r * cone_matrix([u_1, u_2], [v_1])
    - s * cone_matrix([x_1, x_2], [y_1])
)
require(
    all(sp.expand(entry) == 0 for entry in linearity_difference),
    "the positive-function Lorentz construction is linear",
)

# Exact 12289 orbit classification and the linear spectral function.
N = sp.Integer(12289 * 3075)
lower_02 = [sp.Integer(615), sp.Integer(5125), sp.Integer(230625)]
lower_11 = [sp.Integer(61445), sp.Integer(2765025), sp.Integer(23041875)]


def orbit_weight(lower: sp.Integer) -> sp.Rational:
    return sp.Rational(4 * N * lower, (N + lower) ** 2)


exact_02 = [orbit_weight(lower) for lower in lower_02]
exact_11 = [orbit_weight(lower) for lower in lower_11]
quoted_spectrum = {
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(615, 94864),
    sp.Rational(921675, 38217124),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
}
require(
    set(exact_02 + exact_11) == quoted_spectrum,
    "the ordered 12289 type representatives recover the quoted six-point spectrum",
)

alpha_2 = sum(exact_02, sp.S.Zero)
alpha_1_over_2 = sum(exact_11, sp.S.Zero)
exact_lambda_plus = sp.factor(alpha_2 + alpha_1_over_2)
exact_lambda_minus = sp.factor(alpha_2 - alpha_1_over_2)
require(
    exact_lambda_plus
    == sp.Rational(128395625711903946059, 104678602125586545672)
    and exact_lambda_minus
    == -sp.Rational(14143643992119252, 12015450198070081),
    "the linear spectral function recovers the exact 12289 target-character vector",
)
require(
    sp.factor((exact_lambda_plus ** 2 - exact_lambda_minus ** 2)
              - 4 * alpha_2 * alpha_1_over_2) == 0,
    "the exact 12289 Lorentz norm equals four times the two type masses",
)

# Exact resolvent and formal heat checks on the 12289 spectrum.
z = sp.Integer(2)
for kind, values in (("02", exact_02), ("11", exact_11)):
    path_values = [value for value in values for _ in range(3)]
    divisor_values = [value for value in values for _ in range(2)]
    path_resolvent = sum(1 / (z - value) for value in path_values)
    divisor_resolvent = sum(1 / (z - value) for value in divisor_values)
    require(
        sp.factor(2 * path_resolvent - 3 * divisor_resolvent) == 0,
        f"type {kind} exact resolvent at z=2 obeys the 2:3 transfer",
    )

beta = sp.symbols("beta", nonnegative=True)
for kind, values in (("02", exact_02), ("11", exact_11)):
    path_heat = 3 * sum(sp.exp(-beta * value) for value in values)
    divisor_heat = 2 * sum(sp.exp(-beta * value) for value in values)
    require(
        sp.expand(2 * path_heat - 3 * divisor_heat) == 0,
        f"type {kind} exact heat trace obeys the 2:3 transfer",
    )

print("PASS all positive spectral-function cone checks completed")

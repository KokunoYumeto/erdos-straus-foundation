from math import gcd, lcm, isqrt


def report(label, condition):
    if not condition:
        raise AssertionError(label)
    print(f"{label}: PASS")


def squarefree_coordinates(value):
    squarefree = 1
    root = 1
    remainder = value
    prime = 2
    while prime * prime <= remainder:
        exponent = 0
        while remainder % prime == 0:
            remainder //= prime
            exponent += 1
        if exponent % 2:
            squarefree *= prime
        root *= prime ** (exponent // 2)
        prime += 1
    if remainder > 1:
        squarefree *= remainder
    return squarefree, root


def residue_set(residual, carrier):
    squarefree, branch = squarefree_coordinates(carrier)
    modulus = lcm(residual, 9)
    target = (residual + 25) // 4
    return tuple(
        value
        for value in range(modulus)
        if (4 * squarefree * value * value + 1) % residual == 0
        and (squarefree * branch * value - target) % 9 == 0
    )


def reconstruct(residual, squarefree, branch, parameter):
    prime = 4 * squarefree * branch * parameter - residual
    first = squarefree * branch * parameter
    endpoint = squarefree * parameter * parameter
    carrier = squarefree * branch * branch
    numerator = prime * first

    endpoint_b = prime * squarefree * parameter * (
        branch + prime * parameter
    ) // residual
    endpoint_c = squarefree * branch * (
        prime * parameter + branch
    ) // residual

    origin_b = (numerator + carrier) // residual
    origin_c = (
        numerator + prime * prime * first * first // carrier
    ) // residual

    return {
        "p": prime,
        "a": first,
        "u": endpoint,
        "v": carrier,
        "b2": endpoint_b,
        "c2": endpoint_c,
        "b0": origin_b,
        "c0": origin_c,
    }


def validate(data, residual):
    prime = data["p"]
    first = data["a"]
    endpoint = data["u"]
    carrier = data["v"]
    endpoint_b = data["b2"]
    endpoint_c = data["c2"]
    origin_b = data["b0"]
    origin_c = data["c0"]

    conditions = (
        prime == 4 * first - residual,
        endpoint * carrier == first * first,
        (4 * endpoint + 1) % residual == 0,
        endpoint_b == origin_c,
        endpoint_c == origin_b,
        all(
            value > 0
            for value in (
                prime,
                first,
                endpoint,
                carrier,
                endpoint_b,
                endpoint_c,
            )
        ),
        4 * first * endpoint_b * endpoint_c
        == prime
        * (
            endpoint_b * endpoint_c
            + first * endpoint_c
            + first * endpoint_b
        ),
    )
    return all(conditions)


report(
    "carrier 251 squarefree coordinates",
    squarefree_coordinates(251) == (251, 1),
)
report(
    "carrier 2878829 squarefree coordinates",
    squarefree_coordinates(2_878_829) == (149, 139),
)
report(
    "carrier 251 exact residue set",
    residue_set(27, 251) == (23,),
)
report(
    "carrier 2878829 exact residue set",
    residue_set(27, 2_878_829) == (11,),
)

first_family = []
for step in range(5):
    parameter = 23 + 27 * step
    data = reconstruct(27, 251, 1, parameter)
    first_family.extend(
        (
            data["p"] == 23_065 + 27_108 * step,
            data["p"] % 36 == 25,
            validate(data, 27),
        )
    )
report("carrier 251 five exact progression checks", all(first_family))

second_family = []
for step in range(5):
    parameter = 11 + 27 * step
    data = reconstruct(27, 149, 139, parameter)
    second_family.extend(
        (
            data["p"] == 911_257 + 2_236_788 * step,
            data["p"] % 36 == 25,
            validate(data, 27),
        )
    )
report(
    "carrier 2878829 five exact progression checks",
    all(second_family),
)

row_251 = reconstruct(27, 251, 1, 25_457)
report(
    "prime 25558801 exact endpoint-origin transpose",
    row_251
    == {
        "p": 25_558_801,
        "a": 6_389_707,
        "u": 162_662_771_099,
        "v": 251,
        "b2": 3_935_549_286_554_136_428_490_178,
        "c2": 6_048_638_876_354,
        "b0": 6_048_638_876_354,
        "c0": 3_935_549_286_554_136_428_490_178,
    }
    and 25_558_801 == 23_065 + 27_108 * 942,
)

row_2878829 = reconstruct(27, 149, 139, 497)
report(
    "prime 41173441 exact endpoint-origin transpose",
    row_2878829
    == {
        "p": 41_173_441,
        "a": 10_293_367,
        "u": 36_804_341,
        "v": 2_878_829,
        "b2": 2_310_838_595_737_973_730_884,
        "c2": 15_696_790_434_988,
        "b0": 15_696_790_434_988,
        "c0": 2_310_838_595_737_973_730_884,
    }
    and 41_173_441 == 911_257 + 2_236_788 * 18,
)

report(
    "quadratic-character equivalence for both residue classes",
    all(
        (
            (4 * squarefree * parameter * parameter + 1) % 27 == 0
        )
        == (
            ((2 * squarefree * parameter) ** 2 + squarefree) % 27
            == 0
        )
        for squarefree, parameter in ((251, 23), (149, 11))
    ),
)


def universal_residual_progression(residual, squarefree, branch):
    modulus = lcm(residual, 9)
    initial = 4 * squarefree * branch - residual
    step = 4 * squarefree * branch * modulus
    target = (residual + 25) // 4
    return {
        "R": residual,
        "s": squarefree,
        "m": branch,
        "L": modulus,
        "p0": initial,
        "M": step,
        "root": (4 * squarefree + 1) % residual == 0,
        "branch": (squarefree * branch - target) % 9 == 0,
        "carrier_coprime": gcd(squarefree * branch, residual) == 1,
        "primitive": gcd(initial, step) == 1,
        "prime_class": initial % 36 == 25,
    }


universal_examples = tuple(
    universal_residual_progression(residual, squarefree, branch)
    for residual, squarefree, branch in (
        (27, 47, 2),
        (31, 23, 1),
        (35, 61, 6),
        (39, 29, 8),
        (55, 41, 4),
    )
)
report(
    "five universal-residual constructor examples",
    all(
        row["root"]
        and row["branch"]
        and row["carrier_coprime"]
        and row["primitive"]
        and row["prime_class"]
        for row in universal_examples
    ),
)
report(
    "five universal-residual progression constants",
    tuple((row["R"], row["p0"], row["M"]) for row in universal_examples)
    == (
        (27, 349, 10_152),
        (31, 61, 25_668),
        (35, 1_429, 461_160),
        (39, 889, 108_576),
        (55, 601, 324_720),
    ),
)

print(
    "carrier 251 row=",
    (
        row_251["p"],
        row_251["a"],
        row_251["u"],
        row_251["v"],
        row_251["b0"],
        row_251["c0"],
    ),
)
print(
    "carrier 2878829 row=",
    (
        row_2878829["p"],
        row_2878829["a"],
        row_2878829["u"],
        row_2878829["v"],
        row_2878829["b0"],
        row_2878829["c0"],
    ),
)
print(
    "universal residual progressions=",
    tuple(
        (row["R"], row["s"], row["m"], row["p0"], row["M"])
        for row in universal_examples
    ),
)

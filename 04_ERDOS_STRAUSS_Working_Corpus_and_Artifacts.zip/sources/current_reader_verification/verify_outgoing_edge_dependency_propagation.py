from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "es_fable_c123_preprint.tex"
text = SOURCE.read_text(encoding="utf-8")


def window(anchor: str, radius: int = 2400) -> str:
    index = text.find(anchor)
    assert index >= 0, f"missing anchor: {anchor}"
    lo = max(0, index - radius)
    hi = min(len(text), index + len(anchor) + radius)
    return text[lo:hi]


selection = r"cor:R107-outgoing-Boolean-blade-selection"
assert text.count(r"\label{" + selection + "}") == 1

boundary = r"thm:endpoint-support-boundary-commutator"
assert text.count(r"\label{" + boundary + "}") == 1

abstract = text[text.index(r"\begin{abstract}") : text.index(r"\end{abstract}")]
assert r"endpoint word is \(010\)" in abstract
assert r"C_{-0}=E_{12}" in abstract
assert r"outgoing cell \(C_{0+}\)" in abstract
assert r"\(\mathrm{ES}(p)\iff Q_p>0\)" in abstract
assert r"commutator-square polar term" in abstract
assert r"anticommutator-square timelike term" in abstract
assert r"exact \(C_4\) full adder" in abstract
assert r"\widehat c=\operatorname{rank}\mathsf G" in abstract
assert r"\mathscr C_p^{C_4}" in abstract
assert r"\log_2\operatorname{Vol}^{\det}_p" in abstract
assert r"\inf_{p\equiv1\ (12)}\mathscr C_p^{C_4}\ge3" in abstract
assert r"character-cancellation identities" in abstract
assert r"Elementary-abelian \(2\)-primary" in abstract
assert r"supported face has exact altitude \(1/4\)" in abstract
assert r"order-eight and order-sixteen calculations classify" in abstract
assert r"uniform arithmetic theorem" in abstract
assert r"nonzero marked shell class" in abstract
"""
The full order-eight and order-sixteen inventory is checked in its extended
overview and theorem windows below; the abstract deliberately records only
the principal theorem chain.
"""

root_coefficient = window(r"\label{prop:directed-blade-target}")
assert selection in root_coefficient
assert r"outgoing cell \(C_{0+}\)" in root_coefficient
assert r"incoming cell" in root_coefficient
assert boundary in root_coefficient
assert r"nonzero \(E_{21}\) entry as an exit" in root_coefficient

mixer = window(r"\label{thm:mixer-projectors-ordered-blade-channels}")
assert selection in mixer
assert r"identified with the outgoing" in mixer
assert r"exit-boundary cell" in mixer

quarter = window(r"\label{eq:ordered-quarter-reciprocal-spectra}")
assert selection in quarter
assert r"outgoing exit-boundary \(E_{21}\) channel" in quarter

champion = window(r"\label{eq:champion-divisor-orbit-to-blade-matrix}")
assert selection in champion
assert r"2q_{107,p_\ast}C_{0+}" in champion
assert r"outgoing edge \(r_0\to r_1\)" in champion
assert r"r_0\in\partial_T^{\mathrm{out}}" in champion
assert r"exit-boundary lift" in champion

branch = window(r"\label{eq:champion-orbit-degree-quarter}")
assert selection in branch
assert r"outgoing exit-boundary lift" in branch

parity = window(r"\label{cor:R107-exact-parity-sheets}")
assert selection in parity
assert r"2C_{0+}=2E_{21}=\mathcal M(53)" in parity
assert r"C_{-0}=E_{12}" in parity
assert boundary in parity
assert r"exit-boundary cell" in parity

first_shell = window(r"\label{comp:first-residual-107-coefficient-only-shell}", 5000)
assert selection in first_shell
assert r"(b_{-1},b_0,b_1)=(0,1,0)" in first_shell
assert r"C_{-0}=E_{12}" in first_shell
assert r"C_{0+}=E_{21}" in first_shell
assert r"2q_{107,8803369}C_{0+}" in first_shell
assert r"r_{-1}\in\partial_T^{\mathrm{in}}S" in first_shell
assert r"r_0\in\partial_T^{\mathrm{out}}S" in first_shell
assert r"outgoing exit-boundary edge" in first_shell

crosswalk = window(r"\label{rem:completed-history-12289-crosswalk-scope}")
assert selection in crosswalk
assert r"outgoing exit-boundary edge" in crosswalk
assert r"r_0\to r_1" in crosswalk
assert r"does not supply the still-open" in crosswalk

boundary_theorem = window(r"\label{" + boundary + "}", 7000)
assert r"\partial_T^{\mathrm{out}}S" in boundary_theorem
assert r"\partial_T^{\mathrm{in}}S" in boundary_theorem
assert r"K:=J\circ T" in boundary_theorem
assert r"[J_{\mathrm B},C_T(r)]" in boundary_theorem
assert r"2\nabla_Tb(r)\,C_T(r)" in boundary_theorem
assert r"[D,C_T(r)]" in boundary_theorem
assert r"12\nabla_Tb(r)\,C_T(r)" in boundary_theorem
assert r"\mathcal M(53)" in boundary_theorem
assert r"r_0\in\partial_T^{\mathrm{out}}S_{107,2200869}" in boundary_theorem

split_zero = window(r"\label{thm:split-zero-directed-blade-support}", 6200)
assert boundary in split_zero
assert r"source state \(b=1\), target state \(b=0\)" in split_zero
assert r"absence of the target divisor" in split_zero
assert r"rather than disappearance of the matrix coefficient" in split_zero

lorentz = window(r"\label{thm:four-blade-cell-Lorentz-table}", 12000)
assert boundary in lorentz
assert r"\label{eq:four-cell-boundary-Lorentz-coordinate}" in lorentz
assert r"-\nabla_{\epsilon\lambda}\frac{m^2+1}{2}" in lorentz
assert r"\label{eq:four-cell-boundary-commutator-norm}" in lorentz
assert r"\frac14" in lorentz and r"\frac1{144}" in lorentz
assert r"squared support-boundary commutator cost" in lorentz

modular = window(r"\label{eq:12289-star-kneser-ordered-blade-eigenvalues}", 2400)
assert boundary in modular
assert r"exit-boundary eigenline" in modular
assert r"entry-boundary line" in modular

energy = window(
    r"\label{cor:endpoint-support-boundary-Dirichlet-energy}",
    12000,
)
assert boundary in energy
assert r"\label{eq:endpoint-support-boundary-energy-identities}" in energy
assert r"\bigl|S\mathbin{\triangle}T^{-1}(S)\bigr|" in energy
assert r"2\bigl|\partial_T^{\mathrm{out}}S\bigr|" in energy
assert r"\label{eq:endpoint-zero-energy-stabilizer}" in energy
assert r"\label{eq:endpoint-support-boundary-Lorentz-sum}" in energy
assert r"\label{eq:endpoint-labelled-energy-classification}" in energy
assert r"\mathscr E^\partial_{107,8803369}=20" in energy
assert r"\mathscr E^{\mathrm{lab}}_{107,8803369}=2" in energy

roadmap = window(r"\subsection{Road map and relation to complexity geometry}", 18000)
assert r"\mathscr E^\partial_{R,p}" in roadmap
assert r"\bigl|S\mathbin{\triangle}T^{-1}(S)\bigr|" in roadmap
assert r"\mathscr E^{\mathrm{lab}}_p" in roadmap
assert r"2\Xi_p" in roadmap
assert r"\frac{\log\operatorname{Vol}^{\det}_p}{3\log2}" in roadmap
assert r"(b_0,b_1)=(\beta_1,\beta_2)" in roadmap
assert r"\{\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}\}" in roadmap
assert r"\lVert V_{\partial,0+}\rVert_{\mathrm{HS}}^2" in roadmap
assert r"\widehat c_{p,a}" in roadmap
assert r"\operatorname{rank}\mathsf G_{p,a}" in roadmap
assert r"\sum_{a\in\mathscr A_p}3q_{R,p}\widehat c_{p,a}>0" in roadmap
assert r"Q_p=\mathsf N_p^\partial+\mathsf T_p^\partial" in roadmap
assert r"\frac{\mathscr C_p^{C_4}}3" in roadmap
assert r"q_P(u)=\kappa_P(u,u)\pmod2" in roadmap
assert r"\bigl|\{u:q_P(u)=1\}\bigr|" in roadmap
assert r"\mathfrak T_{p,a}(\mu)" in roadmap
assert r"\mu\notin\ker\mathfrak T_{p,a}" in roadmap
assert r"\mu_{p,a}\in\ker\mathfrak T_{p,a}" in roadmap
assert r"\operatorname{rank}\mathcal V_p^\partial\ge3" in roadmap
assert r"\mathbf v_{p,a}(\chi)" in roadmap
assert r"negative of the principal mass" in roadmap
assert r"K=\operatorname{Stab}(B)" in roadmap
assert r"\widehat\mu(q^\vee\psi)\psi(u)" in roadmap
assert r"nonpositive-surplus quotients" in roadmap

squarefree = window(
    r"\label{cor:squarefree-coordinate-complexity-volume}",
    9000,
)
assert r"\label{eq:squarefree-primewise-direction-count}" in squarefree
assert r"\mathscr A_p^{\mathrm{ext}}" in squarefree
assert r"\mathscr A_p^{\mathrm{mid}}" in squarefree
assert r"\mathbin{\triangle}" in squarefree
assert r"\boxed{0\le\Xi_p\le\Theta_p=Q_p.}" in squarefree
assert r"\label{eq:squarefree-rank-direction-bound}" in squarefree

primewise_energy = window(
    r"\label{cor:primewise-directional-energy-bound}",
    9000,
)
assert r"\label{eq:primewise-directional-energy-complexity-volume}" in primewise_energy
assert r"\label{eq:primewise-one-sided-squarefree-identification}" in primewise_energy
assert r"2\Xi_p" in primewise_energy
assert r"2\bigl|\mathscr A_p^{\mathrm{one}}\bigr|" in primewise_energy
assert r"\frac{1}{3\log2}" in primewise_energy
assert r"\frac{2}{51}L_{H,p}^2" in primewise_energy
assert r"\frac{4}{75}L_{K,p}^2" in primewise_energy
assert r"\label{eq:primewise-directional-energy-equality-case}" in primewise_energy
assert r"\label{eq:primewise-directional-energy-implies-ES}" in primewise_energy

four_time = window(
    r"\label{thm:arithmetic-four-Time-multiplicity-carrier}",
    10000,
)
assert r"\label{eq:primewise-four-Time-directional-energy}" in four_time
assert r"2\Xi_p" in four_time
assert r"\frac12\dim_{\mathbb C}\mathscr V^{\mathrm{Time}}_p" in four_time
assert r"\frac13\log_2\operatorname{Vol}^{\det}_p" in four_time

selected_amplitude = window(
    r"\label{cor:endpoint-selected-amplitude-carrier}",
    13000,
)
assert r"\label{eq:endpoint-selected-amplitude-status-table}" in selected_amplitude
assert r"\text{exterior only}&E_{12}&\mathcal N_{12}^{p,a}" in selected_amplitude
assert r"\text{middle only}&E_{21}&\mathcal N_{21}^{p,a}" in selected_amplitude
assert r"\text{both}&E_{11}&2H_{p,a}P_{p,a}\otimes F_{22}" in selected_amplitude
assert r"\label{eq:endpoint-selected-amplitude-source}" in selected_amplitude
assert r"\label{eq:endpoint-selected-amplitude-range}" in selected_amplitude
assert r"2(b_1-b_0)\mathcal N_{0+}^{p,a}" in selected_amplitude
assert r"2\alpha^\Sigma_{p,a}\mathscr E^{\mathrm{lab}}_{R,p}" in selected_amplitude
assert r"\label{eq:global-endpoint-selected-amplitude-ES}" in selected_amplitude

selected_path = window(
    r"\label{cor:endpoint-selected-weighted-123-carrier}",
    18000,
)
assert r"\label{eq:endpoint-sheet-order-isomorphism}" in selected_path
assert r"\varpi_O(0)=x_O^-" in selected_path
assert r"\varpi_O(1)=x_O^+" in selected_path
assert r"\text{exterior only}&(0,1)&\mathcal W_{-,+}" in selected_path
assert r"\text{middle only}&(1,0)&\mathcal W_{+,-}" in selected_path
assert r"\text{both}&(1,1)&2\mathcal D_>^{1/2}" in selected_path
assert r"\label{eq:endpoint-selected-weighted-123-source}" in selected_path
assert r"\label{eq:endpoint-selected-weighted-123-range}" in selected_path
assert r"2(b_1-b_0)\mathcal W_{\partial,0+}^{p,a}" in selected_path
assert r"3\alpha^\Sigma_{p,a}\mathscr E^{\mathrm{lab}}_{R,p}" in selected_path
assert r"\frac32\mathscr E^{\mathrm{amp}}_{p,a}" in selected_path
assert r"\label{eq:endpoint-selected-path-divisor-multiplicity}" in selected_path

energy_volume = window(
    r"\label{cor:endpoint-energy-volume-control}",
    7500,
)
assert r"\label{eq:endpoint-energy-volume-control}" in energy_volume
assert r"6q" in energy_volume
assert r"\left(\operatorname{Vol}^{\det,\alpha}_{p,a}\right)^{1/(6q)}" in energy_volume
assert r"\frac{12\sqrt q}{\sqrt{51}}\,L_{H,\alpha}" in energy_volume
assert r"12\sqrt{\frac{2q}{75}}\,L_{K,\alpha}" in energy_volume
assert r"exactly when all orbit" in energy_volume

selected_spectral = window(
    r"\label{cor:endpoint-selected-stable-spectral-transfer}",
    30000,
)
assert r"\label{eq:endpoint-selected-source-modulus}" in selected_spectral
assert r"\label{eq:endpoint-selected-range-modulus}" in selected_spectral
assert r"\label{eq:endpoint-selected-sheet-factorization}" in selected_spectral
assert r"\label{eq:endpoint-selected-stable-intertwiner}" in selected_spectral
assert r"\label{eq:endpoint-selected-polar-isometry}" in selected_spectral
assert r"2(b_1-b_0)V_{\partial,0+}" in selected_spectral
assert r"2\mu_{\partial,j}^{\mathrm{path}}=3\mu^{\mathrm{div}}" in selected_spectral
assert r"\label{eq:endpoint-selected-characteristic-polynomial-transfer}" in selected_spectral
assert r"identical positive amplitude data" in selected_spectral
assert r"ordered endpoint direction is retained" in selected_spectral
assert r"\label{cor:endpoint-selected-polar-rank-direction}" in selected_spectral
assert r"\mathscr E^{\mathrm{pol},123}_{p,a}" in selected_spectral
assert r"3q(b_1-b_0)^2" in selected_spectral
assert r"\label{eq:endpoint-selected-polar-rank-classification}" in selected_spectral
assert r"\label{cor:primewise-polar-rank-direction}" in selected_spectral
assert r"3\Xi_p" in selected_spectral
assert r"\frac1{17}L_{H,p}^2" in selected_spectral
assert r"\frac2{25}L_{K,p}^2" in selected_spectral
assert r"\Delta_{\partial,j}^{\mathrm{path}}" in selected_spectral
assert r"\nu_{\partial,j}^{\mathrm{path}}" in selected_spectral
assert r"both the selected source and the" in selected_spectral

polar_lorentz = window(
    r"\label{cor:polar-direction-target-Lorentz-boundary}",
    9500,
)
assert r"\label{eq:polar-energy-target-Lorentz-rank}" in polar_lorentz
assert r"3q_{R,p}\,r_{p,a}(2-r_{p,a})" in polar_lorentz
assert r"\label{eq:polar-energy-nonzero-null-boundary}" in polar_lorentz
assert r"\mathsf G_{p,a}\ne0" in polar_lorentz
assert r"\label{eq:polar-direction-null-ray-sign}" in polar_lorentz
assert r"\frac{\lambda_-}{\lambda_+}" in polar_lorentz
assert r"\lambda_-=\lambda_+>0" in polar_lorentz
assert r"\lambda_-=-\lambda_+<0" in polar_lorentz

positive_spectral_direction = window(
    r"\label{cor:positive-spectral-polar-null-direction}",
    13000,
)
assert r"\label{eq:positive-spectral-rank-preservation}" in positive_spectral_direction
assert r"\label{eq:positive-spectral-polar-rank-formula}" in positive_spectral_direction
assert r"\label{eq:positive-spectral-polar-null-sign}" in positive_spectral_direction
assert r"\label{eq:moment-heat-resolvent-polar-null-sign}" in positive_spectral_direction
assert r"do not alter the shellwise" in positive_spectral_direction

signed_resolvent_direction = window(
    r"\label{thm:signed-resolvent-character-blade-circle}",
    15000,
)
assert r"\label{eq:signed-resolvent-polar-null-ray}" in signed_resolvent_direction
assert r"\Xi(z)=(b_1-b_0)\Pi(z)" in signed_resolvent_direction
assert r"positive null ray" in signed_resolvent_direction
assert r"negative null ray" in signed_resolvent_direction

split_zero_rank = window(
    r"\label{cor:split-zero-polar-timelike-rank-decomposition}",
    15000,
)
assert r"\label{eq:split-zero-endpoint-direction-identification}" in split_zero_rank
assert r"(b_0,b_1)=(\beta_1,\beta_2)" in split_zero_rank
assert r"d_{\partial,p,a}=\beta_2-\beta_1" in split_zero_rank
assert r"\label{eq:split-zero-polar-timelike-coefficient-table}" in split_zero_rank
assert r"\label{eq:split-zero-timelike-rank}" in split_zero_rank
assert r"\{\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}\}" in split_zero_rank
assert r"\label{eq:split-zero-commutator-anticommutator-exhaustion}" in split_zero_rank
assert r"\lVert V_{\partial,0+}\rVert_{\mathrm{HS}}^2" in split_zero_rank
assert r"\label{eq:split-zero-path-rank-decomposition}" in split_zero_rank
assert r"\mathscr E^{\mathrm{tim},123}_{p,a}" in split_zero_rank
assert r"\label{eq:primewise-polar-timelike-complexity-volume}" in split_zero_rank
assert r"\mathscr E_p^{\mathrm{pol},123}" in split_zero_rank
assert r"\mathscr E_p^{\mathrm{tim},123}" in split_zero_rank
assert r"\label{eq:primewise-ES-polar-timelike-rank}" in split_zero_rank

convolution_modular_polar = window(
    r"\label{thm:convolution-modular-polar-factorization}",
    19000,
)
assert r"\label{eq:two-target-convolution-extraction-map}" in convolution_modular_polar
assert r"\label{eq:convolution-target-vector-orbit-rank}" in convolution_modular_polar
assert r"\label{eq:convolution-target-support-endpoint-bits}" in convolution_modular_polar
assert r"\label{eq:origin-divisor-complement-orbit-identification}" in convolution_modular_polar
assert r"\label{eq:modular-amplification-equals-polar-transport}" in convolution_modular_polar
assert r"\operatorname{rank}V_{\partial,0+}" in convolution_modular_polar
assert r"3\operatorname{rank}P^{\mathrm{mod}}_{R,p}" in convolution_modular_polar
assert r"\label{eq:full-divisor-convolution-positive-mass}" in convolution_modular_polar
assert r"\mu\notin\ker\mathfrak T_{p,a}" in convolution_modular_polar
assert r"\label{eq:primewise-simultaneous-target-kernel-obstruction}" in convolution_modular_polar
assert r"\label{eq:global-convolution-target-kernel-polar-rank-criterion}" in convolution_modular_polar

two_target_fourier = window(
    r"\label{thm:two-target-Fourier-kernel-factorization}",
    15000,
)
assert r"\label{eq:target-character-evaluation-with-zero-extension}" in two_target_fourier
assert r"\label{eq:local-divisor-Dirichlet-character-factor}" in two_target_fourier
assert r"\label{eq:two-target-Fourier-factorization}" in two_target_fourier
assert r"\label{eq:divisor-character-factor-reality}" in two_target_fourier
assert r"\label{eq:two-target-real-character-pairing}" in two_target_fourier
assert r"\label{eq:divisor-convolution-principal-character-mass}" in two_target_fourier
assert r"\label{eq:single-target-principal-mass-cancellation}" in two_target_fourier
assert r"\label{eq:12289-two-target-Fourier-extraction}" in two_target_fourier

cyclotomic_survivor = window(
    r"\label{thm:cyclotomic-survivor-binary-sheet-positivity}",
    18000,
)
assert r"\label{eq:local-divisor-kernel-cyclotomic-form}" in cyclotomic_survivor
assert r"\label{eq:local-divisor-kernel-zero-order-criterion}" in cyclotomic_survivor
assert r"\label{eq:divisor-convolution-cyclotomic-survivor-spectrum}" in cyclotomic_survivor
assert r"\label{eq:spectral-survivor-annihilator-periodicity}" in cyclotomic_survivor
assert r"\label{eq:binary-survivor-two-sheet-Fourier-form}" in cyclotomic_survivor
assert r"\label{eq:binary-survivor-local-amplitude}" in cyclotomic_survivor
assert r"\label{eq:binary-survivor-strict-principal-domination}" in cyclotomic_survivor
assert r"\label{eq:12289-principal-binary-survivor-spectrum}" in cyclotomic_survivor
assert r"\label{eq:12289-positive-binary-sheet-formula}" in cyclotomic_survivor
assert r"\label{comp:cyclotomic-survivor-binary-sheet-check}" in cyclotomic_survivor
assert r"\label{cor:first-purely-two-primary-obstruction}" in cyclotomic_survivor
assert r"\label{eq:first-purely-two-primary-obstruction-order}" in cyclotomic_survivor
assert r"\label{thm:elementary-abelian-two-primary-full-support}" in cyclotomic_survivor
assert r"\label{eq:elementary-abelian-two-primary-positive-bound}" in cyclotomic_survivor
assert r"\label{eq:elementary-abelian-two-primary-upstairs-bound}" in cyclotomic_survivor
assert r"\label{thm:order-four-two-primary-obstruction-classification}" in cyclotomic_survivor
assert r"\label{eq:Klein-four-two-primary-positive-gap}" in cyclotomic_survivor
assert r"\label{eq:C4-two-primary-amplitude-ratios}" in cyclotomic_survivor
assert r"\label{eq:C4-two-primary-total-amplitude-bound}" in cyclotomic_survivor
assert r"\label{eq:C4-two-primary-extremal-condition}" in cyclotomic_survivor
assert r"\label{eq:C4-two-primary-extremal-three-point-measure}" in cyclotomic_survivor
assert r"\label{cor:purely-two-primary-obstruction-dichotomy}" in cyclotomic_survivor
assert r"\label{comp:order-four-two-primary-classification-check}" in cyclotomic_survivor

c4_fable = window(
    r"\label{thm:exceptional-C4-Fable-tetrahedron-intertwiner}",
    12000,
)
assert r"\label{eq:exceptional-C4-face-cycle}" in c4_fable
assert r"\label{eq:exceptional-C4-face-reflection}" in c4_fable
assert r"\label{eq:exceptional-C4-Fable-vertex-map}" in c4_fable
assert r"\label{eq:exceptional-C4-Fable-D3-intertwining}" in c4_fable
assert r"\label{eq:exceptional-C4-Fable-measure-pushforward}" in c4_fable
assert r"\label{eq:exceptional-C4-Fable-quarter-sign}" in c4_fable
assert r"\label{eq:exceptional-C4-Fable-quarter-altitude}" in c4_fable
assert r"\label{comp:exceptional-C4-Fable-tetrahedron-check}" in c4_fable

order_eight = window(
    r"\label{thm:order-eight-two-primary-support-classification}",
    26000,
)
assert r"\label{eq:C8-order-eight-nonfull-supports}" in order_eight
assert r"\label{eq:C4C2-order-eight-nonfull-supports}" in order_eight
assert r"\label{cor:purely-two-primary-obstruction-through-order-eight}" in order_eight
assert r"\label{thm:order-eight-support-eight-cell-intertwiner}" in order_eight
assert r"\label{eq:order-eight-two-sheet-four-cell-decomposition}" in order_eight
assert r"\label{eq:order-eight-eight-cell-coordinate-map}" in order_eight
assert r"\label{eq:order-eight-eight-cell-three-intertwinings}" in order_eight
assert r"\label{eq:order-eight-six-support-orbit-unitary}" in order_eight
assert r"\label{eq:order-eight-six-support-measure-factorization}" in order_eight
assert r"\label{eq:order-eight-six-support-phase-zero-mode}" in order_eight
assert r"\label{comp:order-eight-two-primary-support-check}" in order_eight
assert r"verification/OrderEightCarrierCertificate.lean" in order_eight
assert r"verification/OrderEightCarrierCertificate\_output.txt" in order_eight

order_sixteen = window(
    r"\label{thm:order-sixteen-two-primary-support-classification}",
    75000,
)
assert r"\label{eq:C16-complete-nonfull-support-table}" in order_sixteen
assert r"\label{eq:C8C2-complete-nonfull-support-table}" in order_sixteen
assert r"\label{eq:C4C4-complete-nonfull-support-table}" in order_sixteen
assert r"\label{eq:C4C2C2-complete-nonfull-support-table}" in order_sixteen
assert r"\label{thm:order-sixteen-four-sheet-carrier}" in order_sixteen
assert r"\label{eq:order-sixteen-four-sheet-carrier-map}" in order_sixteen
assert r"\label{eq:C16-four-sheet-carry}" in order_sixteen
assert r"\label{eq:C8C2-four-sheet-carry}" in order_sixteen
assert r"\label{eq:order-sixteen-four-sheet-cocycle-identity}" in order_sixteen
assert r"The first two cocycles are not coboundaries" in order_sixteen
assert r"\label{cor:order-sixteen-minimum-support-volume}" in order_sixteen
assert r"\label{eq:order-sixteen-minimum-support-volume}" in order_sixteen
assert r"\boxed{m(P)=3^a2^b.}" in order_sixteen
assert r"\label{cor:order-sixteen-minimum-support-carrier-location}" in order_sixteen
assert r"\label{eq:order-sixteen-minimum-carrier-correlation-table}" in order_sixteen
assert r"\label{eq:order-sixteen-carrier-complexity-volume-identity}" in order_sixteen
assert r"d_P&3&2&0&0" in order_sixteen
assert r"\label{thm:order-sixteen-carrier-inversion-mixer-blade}" in order_sixteen
assert r"\label{eq:order-sixteen-carrier-inversion-formula}" in order_sixteen
assert r"\label{eq:order-sixteen-full-inversion-spectrum}" in order_sixteen
assert r"\label{eq:order-sixteen-minimum-inversion-fixed-loci}" in order_sixteen
assert r"\label{eq:order-sixteen-carrier-blade-corners}" in order_sixteen
assert r"\label{eq:order-sixteen-minimum-blade-block-table}" in order_sixteen
assert r"\label{eq:order-sixteen-defect-blade-conservation}" in order_sixteen
assert r"\boxed{d_P+b_P=|C_4|=4.}" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_inversion\_blade.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_inversion\_blade\_output.txt" in order_sixteen
assert r"verification/OrderSixteenCarrierInversionBladeCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenCarrierInversionBladeCertificate\_output.txt" in order_sixteen
assert r"\label{thm:order-sixteen-carrier-dihedral-fourier}" in order_sixteen
assert r"\label{eq:order-sixteen-carrier-dihedral-relations}" in order_sixteen
assert r"\label{eq:order-sixteen-carrier-dihedral-orbits}" in order_sixteen
assert r"\label{eq:order-sixteen-carry-phased-Fourier-action}" in order_sixteen
assert r"\label{eq:order-sixteen-cell-Fourier-projectors}" in order_sixteen
assert r"\label{eq:order-sixteen-second-sector-sign-table}" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_dihedral\_fourier.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_dihedral\_fourier\_output.txt" in order_sixteen
assert r"verification/OrderSixteenCarrierDihedralFourierCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenCarrierDihedralFourierCertificate\_output.txt" in order_sixteen
assert r"\label{thm:order-sixteen-dihedral-irreducible-carry-criterion}" in order_sixteen
assert r"\label{eq:order-sixteen-dihedral-orbit-module-decomposition}" in order_sixteen
assert r"\label{eq:order-sixteen-dihedral-permutation-characters}" in order_sixteen
assert r"\label{eq:order-sixteen-dihedral-irreducible-multiplicities}" in order_sixteen
assert r"\label{eq:order-sixteen-dihedral-reflection-trace-identities}" in order_sixteen
assert r"\label{eq:order-sixteen-dihedral-spectral-carry-criterion}" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_dihedral\_irreducibles.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_carrier\_dihedral\_irreducibles\_output.txt" in order_sixteen
assert r"verification/OrderSixteenCarrierDihedralIrreducibleCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenCarrierDihedralIrreducibleCertificate\_output.txt" in order_sixteen
assert r"\label{thm:C4-carrier-two-torsion-carry-character}" in order_sixteen
assert r"\label{eq:C4-carrier-two-torsion-carry-character}" in order_sixteen
assert r"\label{eq:C4-carrier-two-torsion-spectral-weight}" in order_sixteen
assert r"\label{eq:C4-carrier-nonzero-character-half-weight}" in order_sixteen
assert r"\label{eq:order-sixteen-two-torsion-carry-table}" in order_sixteen
assert r"\label{comp:order-sixteen-two-torsion-carry-character-certificates}" in order_sixteen
assert r"verification/verify\_order\_sixteen\_two\_torsion\_carry\_character.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_two\_torsion\_carry\_character\_output.txt" in order_sixteen
assert r"verification/OrderSixteenTwoTorsionCarryCharacterCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenTwoTorsionCarryCharacterCertificate\_output.txt" in order_sixteen
assert r"\label{thm:C4-extension-detection-exact-sequence}" in order_sixteen
assert r"\label{eq:C4-extension-detection-map}" in order_sixteen
assert r"\label{eq:C4-extension-detection-coordinates}" in order_sixteen
assert r"\label{eq:C4-extension-detection-kernel}" in order_sixteen
assert r"\label{eq:order-four-marked-C4-extension-table}" in order_sixteen
assert r"\label{eq:C8C2-dual-marked-carriers}" in order_sixteen
assert r"\label{comp:marked-C4-extension-detection-certificates}" in order_sixteen
assert r"verification/verify\_marked\_C4\_extension\_detection.py" in order_sixteen
assert r"verification/verify\_marked\_C4\_extension\_detection\_output.txt" in order_sixteen
assert r"verification/MarkedC4ExtensionDetectionCertificate.lean" in order_sixteen
assert r"verification/MarkedC4ExtensionDetectionCertificate\_output.txt" in order_sixteen
assert r"\label{cor:C4-extension-visible-hidden-bit-coupling}" in order_sixteen
assert r"\label{eq:C4-extension-visible-hidden-bit-coordinate}" in order_sixteen
assert r"\label{eq:C4-extension-visible-hidden-bit-law}" in order_sixteen
assert r"\label{eq:C4-extension-detection-nonsplitting}" in order_sixteen
assert r"\label{eq:C4-cyclic-extension-bit-table}" in order_sixteen
assert r"\label{comp:C4-extension-visible-hidden-bit-certificates}" in order_sixteen
assert r"verification/verify\_marked\_C4\_visible\_hidden\_bits.py" in order_sixteen
assert r"verification/verify\_marked\_C4\_visible\_hidden\_bits\_output.txt" in order_sixteen
assert r"verification/MarkedC4VisibleHiddenBitsCertificate.lean" in order_sixteen
assert r"verification/MarkedC4VisibleHiddenBitsCertificate\_output.txt" in order_sixteen
assert r"\label{cor:split-zero-C4-full-adder-bridge}" in order_sixteen
assert r"\label{eq:split-zero-C4-full-adder-coordinate}" in order_sixteen
assert r"\label{eq:split-zero-C4-full-adder-identity}" in order_sixteen
assert r"\label{eq:split-zero-C4-coupled-visible-inputs}" in order_sixteen
assert r"\label{eq:split-zero-C4-energy-bit-recovery}" in order_sixteen
assert r"\label{eq:split-zero-C4-directional-lift}" in order_sixteen
assert r"\label{eq:split-zero-C4-class-direction-map}" in order_sixteen
assert r"\label{eq:split-zero-C4-class-direction-inverse}" in order_sixteen
assert r"\label{eq:split-zero-C4-full-adder-table}" in order_sixteen
assert r"\label{eq:split-zero-C4-local-image}" in order_sixteen
assert r"\label{eq:split-zero-C4-Baer-closure}" in order_sixteen
assert r"\label{comp:split-zero-C4-full-adder-certificates}" in order_sixteen
assert r"verification/verify\_split\_zero\_C4\_full\_adder\_bridge.py" in order_sixteen
assert r"verification/verify\_split\_zero\_C4\_full\_adder\_bridge\_output.txt" in order_sixteen
assert r"verification/SplitZeroC4FullAdderBridgeCertificate.lean" in order_sixteen
assert r"verification/SplitZeroC4FullAdderBridgeCertificate\_output.txt" in order_sixteen
assert r"\label{cor:split-zero-C4-rank-support-criterion}" in order_sixteen
assert r"\label{eq:split-zero-C4-local-integer-lift}" in order_sixteen
assert r"\label{eq:split-zero-C4-class-equals-Lorentz-rank}" in order_sixteen
assert r"\label{eq:split-zero-C4-weighted-energy-rank}" in order_sixteen
assert r"\label{eq:split-zero-C4-Lorentz-rank-table}" in order_sixteen
assert r"\label{eq:local-ES-marked-C4-support}" in order_sixteen
assert r"\label{eq:split-zero-C4-timelike-class}" in order_sixteen
assert r"\label{eq:primewise-marked-C4-rank-coordinate}" in order_sixteen
assert r"\label{eq:primewise-marked-C4-rank-energy}" in order_sixteen
assert r"\label{eq:primewise-ES-marked-C4-support}" in order_sixteen
assert r"\label{comp:split-zero-C4-rank-support-certificates}" in order_sixteen
assert r"verification/verify\_split\_zero\_C4\_rank\_support.py" in order_sixteen
assert r"verification/verify\_split\_zero\_C4\_rank\_support\_output.txt" in order_sixteen
assert r"verification/SplitZeroC4RankSupportCertificate.lean" in order_sixteen
assert r"verification/SplitZeroC4RankSupportCertificate\_output.txt" in order_sixteen
assert r"\label{cor:marked-C4-primewise-rank-volume}" in order_sixteen
assert r"\label{eq:primewise-C4-null-timelike-multiplicities}" in order_sixteen
assert r"\label{eq:primewise-C4-rank-reconstruction}" in order_sixteen
assert r"\label{eq:primewise-C4-rank-inverse}" in order_sixteen
assert r"\label{eq:primewise-C4-complexity-sandwich}" in order_sixteen
assert r"\label{eq:primewise-C4-volume-sandwich}" in order_sixteen
assert r"\label{eq:primewise-C4-weighted-mean-rank}" in order_sixteen
assert r"\label{eq:global-ES-marked-C4-gap}" in order_sixteen
assert r"\label{comp:marked-C4-primewise-rank-volume-certificates}" in order_sixteen
assert r"verification/verify\_marked\_C4\_primewise\_rank\_volume.py" in order_sixteen
assert r"verification/verify\_marked\_C4\_primewise\_rank\_volume\_output.txt" in order_sixteen
assert r"verification/MarkedC4PrimewiseRankVolumeCertificate.lean" in order_sixteen
assert r"verification/MarkedC4PrimewiseRankVolumeCertificate\_output.txt" in order_sixteen
assert r"\label{cor:order-sixteen-spectral-support-balance}" in order_sixteen
assert r"\label{eq:order-sixteen-spectral-support-balance-table}" in order_sixteen
assert r"\label{eq:order-sixteen-spectral-support-balance-law}" in order_sixteen
assert r"\label{eq:order-sixteen-spectral-support-phase-split}" in order_sixteen
assert r"\label{comp:order-sixteen-spectral-support-balance-certificates}" in order_sixteen
assert r"verification/verify\_order\_sixteen\_spectral\_support\_balance.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_spectral\_support\_balance\_output.txt" in order_sixteen
assert r"verification/OrderSixteenSpectralSupportBalanceCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenSpectralSupportBalanceCertificate\_output.txt" in order_sixteen
assert r"\label{cor:purely-two-primary-obstruction-through-order-sixteen}" in order_sixteen
assert r"order at least \(32\)" in order_sixteen
assert r"\label{comp:order-sixteen-two-primary-support-check}" in order_sixteen
assert r"verification/OrderSixteenSupportCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenSupportCertificate\_output.txt" in order_sixteen
assert r"verification/verify\_order\_sixteen\_four\_sheet\_carrier.py" in order_sixteen
assert r"verification/verify\_order\_sixteen\_four\_sheet\_carrier\_output.txt" in order_sixteen
assert r"verification/OrderSixteenFourSheetCarrierCertificate.lean" in order_sixteen
assert r"verification/OrderSixteenFourSheetCarrierCertificate\_output.txt" in order_sixteen

quotient_character = window(
    r"\label{thm:stabilizer-quotient-character-obstruction}",
    17000,
)
assert r"\label{eq:target-kernel-stabilizer-quotient-data}" in quotient_character
assert r"\label{eq:two-target-stabilizer-defect-decomposition}" in quotient_character
assert r"\label{eq:quotient-pushforward-local-character-factorization}" in quotient_character
assert r"\label{eq:quotient-target-principal-mass-cancellation}" in quotient_character
assert r"\label{eq:quotient-nonprincipal-mass-necessary-bound}" in quotient_character
assert r"\label{eq:strict-quotient-spectral-domination}" in quotient_character
assert r"\label{eq:quotient-Parseval-target-survival}" in quotient_character

quotient_lean = window(
    r"\label{comp:two-target-quotient-Lean-certificate}",
    4500,
)
assert r"verification/TwoTargetQuotientCertificate.lean" in quotient_lean
assert r"verification/TwoTargetQuotientCertificate\_output.txt" in quotient_lean
assert r"two nonnegative defect summands" in quotient_lean
assert r"principal/nonprincipal decomposition" in quotient_lean
assert r"strict Cauchy--Schwarz/Parseval domination" in quotient_lean

endpoint_lower_bound = window(
    r"\label{thm:endpoint-divisor-orbit-lower-bound}",
    11000,
)
assert r"\label{eq:endpoint-divisor-forces-two-target-survival}" in endpoint_lower_bound
assert r"\label{eq:endpoint-orbit-polar-operator-lower-bound}" in endpoint_lower_bound
assert r"\mu_{p,a_R}\notin\ker\mathfrak T_{p,a_R}" in endpoint_lower_bound

coupled_decomposition = window(
    r"\label{cor:primewise-coupled-coefficient-decomposition}",
    13000,
)
assert r"\label{eq:primewise-coupled-modular-polar-decomposition}" in coupled_decomposition
assert r"\label{eq:primewise-coupled-target-kernel-obstruction}" in coupled_decomposition
assert r"\mu_{p,a}\in\ker\mathfrak T_{p,a}" in coupled_decomposition

reference_count = text.count(r"\cref{" + selection + "}")
assert reference_count >= 8

boundary_reference_count = text.count(r"\cref{" + boundary + "}")
assert boundary_reference_count >= 8

print("PASS: outgoing-edge result propagated through dependency-bearing statements")
print(f"selection_cross_references={reference_count}")
print("abstract=010, outgoing E21, incoming E12 absent")
print("root coefficient=directed edge identified")
print("mixer and quarter channels=outgoing direction recorded")
print("champion and branch carriers=outgoing population lift recorded")
print("parity sheet and first-shell computations=complete directed cells recorded")
print("later crosswalk=direction fixed, ambient multiplication scope retained")
print(f"boundary_cross_references={boundary_reference_count}")
print("boundary theorem=crossed involution, entry/exit cells, exact commutators")
print("split zero=exit of divisor fibre, supported coefficient retained")
print("Lorentz=flow sign and squared commutator cost propagated")
print("modular=+12 entry and -12 exit eigenlines propagated")
print("energy=symmetric difference, stabilizer, Lorentz sum, labelled classification")
print("squarefree=Theta orbit rank and Xi one-sided direction count")
print("complexity-volume=primewise and four-Time directional-energy bounds")
print("polar amplitude=actual endpoint cell selects E23, E32, or E22 and retains the exact directional cost")
print("weighted path=order-forced endpoint lift and exact 3:2 rank, norm, and energy multiplicities")
print("weighted control=selected direction lies between determinant volume and both control lengths")
print("selected spectrum=source and range amplitudes coincide under stable C3:C2 transfer while the polar carrier retains direction")
print("polar rank direction=amplitude-free shell status classification and primewise complexity-volume bounds propagated")
print("polar Lorentz boundary=energy detects the nonzero null cone and the signed commutator selects its directed ray")
print("positive spectral calculus=moments, heat kernels, and resolvents preserve that rank and directed null ray")
print("split-zero mixer support=target bits equal the ordered endpoint bits")
print("split-zero operator rank=commutator XOR and anticommutator AND energies exhaust the selected path rank")
print("pre-certificate convolution=two target coefficients determine orbit rank, endpoint bits, modular rank, and polar transport")
print("global obstruction=every nonzero shell convolution lies in its two-target kernel")
print("Fourier obstruction=each in-subgroup missing target cancels the positive principal mass exactly")
print("cyclotomic survivor=odd kernels retain 2-primary modes and a lone binary mode keeps both sheets positive")
print("2-primary reduction=after odd-mode annihilation a missing coefficient requires quotient order at least four")
print("elementary-abelian exclusion=every C2-power quotient has a quantitative full-support bound")
print("order-four classification=Klein quotient is positive and the sole cyclic extremum is a three-point measure missing its antipode")
print("C4-Fable bridge=the missing antipode is the fixed negative apex and the supported face has exact quarter altitude")
print("order-eight classification=C8 has four supports, C4xC2 has two, and C2 cubed is positive")
print("order-eight carrier=both six-point types are the crossed six-path orbit and land in the phase-zero modular subspace")
print("order-eight boundary=A7 alone fails the inherited phase cycle")
print("order-sixteen classification=the four non-elementary groups have 17, 12, 4, and 3 nonfull generating support orbits")
print("order-sixteen support volume=the five minima are 3, 6, 9, 12, and 16, with exact law 3^a 2^b")
print("order-sixteen carrier=all four non-elementary groups use a 4-by-4 carrier; the first two carry classes are non-coboundaries")
print("order-sixteen carrier volume=the minimum sheet-cell correlation deficits are 3, 2, 0, and 0")
print("order-sixteen carrier inversion=the minimum supports contain 1, 2, 4, and 4 exact mixer-blade blocks")
print("order-sixteen deficit-blade conservation=correlation deficit plus blade-block count is four in every row")
print("order-sixteen dihedral Fourier=cell rotation and inversion act faithfully as D8 with four rank-four Fourier sectors")
print("order-sixteen carry phase=the k2 inversion signs detect precisely the two nonzero carry classes")
print("order-sixteen dihedral irreducibles=the four carrier multiplicity rows are 3-1-2-2-4, 4-0-2-2-4, 3-1-3-1-4, and 4-0-4-0-4")
print("order-sixteen spectral carry=non-coboundary carry is equivalent to positive trace RU and to m_mm greater than m_pm")
print("order-sixteen two-torsion carry=q is intrinsic, additive, and its weight equals the spectral defect")
print("order-sixteen nonzero carry weight=half of the two-torsion sheet group")
print("marked C4-extension detection=onto character map with exact kernel (2C4)^a")
print("marked C8xC2 carriers=binary sheets have weight 2 while cyclic sheets have nonsplit weight 0")
print("marked C4 visible-hidden law=quadratic carry q q-prime couples the two bit layers")
print("marked C4 detection splitting=additive section exists exactly with no long cyclic sheet")
print("split-zero C4 full adder=polar XOR is the visible digit, timelike AND is the hidden carry, and signed direction restores endpoint order")
print("split-zero C4 local closure=one endpoint pair realizes classes 0, 1, and 2, while Baer closure supplies class 3")
print("split-zero C4 Lorentz rank=the local marked-class lift equals rank G and classes 0, 1, 2 are zero, null, timelike")
print("split-zero C4 support=the carry-weighted primewise rank coordinate is positive exactly on a nonzero marked support class")
print("marked C4 multiplicities=Q and C/3 reconstruct the one-sided and timelike weighted shell counts")
print("marked C4 rank bounds=3Q <= C <= 6Q with exact null and timelike equality cases")
print("marked C4 volume bounds=C <= log2 volume <= 2C and global support gap C >= 3")
print("order-sixteen spectral-support balance=d+delta is 4e and b-delta is 4(1-e)")
print("two-primary boundary=elementary quotients are positive and the next unclassified order is 32")
print("quotient obstruction=the stabilizer annihilator alone cancels the principal mass at every missed target coset")
print("Lean certificate=quotient obstruction, binary gap, elementary-abelian bounds, order gap, order-four bounds, the Fable quarter, both order-eight D3 actions, and all one-hundred-sixty-two order-sixteen finite, carrier, inversion, blade-block, dihedral, Fourier, irreducible-spectrum, two-torsion-carry, marked-extension, visible-hidden-bit, full-adder, rank-support, rank-volume, and spectral-support claims checked")
print("endpoint families=explicit divisor orbits survive the two-target map and amplify by C3")
print("coupled decomposition=remainder target kernels and coupled group-ring coefficients separate the obstruction")
print("selected target data=both sheets carry the same coefficient and target-null mass")

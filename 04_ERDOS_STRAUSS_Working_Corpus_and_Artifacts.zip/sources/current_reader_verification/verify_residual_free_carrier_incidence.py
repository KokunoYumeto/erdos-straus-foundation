from fractions import Fraction
from math import isqrt


def report(label, condition):
    if not condition:
        raise AssertionError(label)
    print(f"{label}: PASS")


def is_prime(value):
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def prime_factors(value):
    factors = []
    divisor = 2
    remainder = value
    while divisor * divisor <= remainder:
        if remainder % divisor == 0:
            factors.append(divisor)
            while remainder % divisor == 0:
                remainder //= divisor
        divisor += 1
    if remainder > 1:
        factors.append(remainder)
    return tuple(factors)


def squarefree_divisors(value):
    result = [1]
    for prime in prime_factors(value):
        result.extend(tuple(prime * divisor for divisor in result))
    return tuple(sorted(result))


def divisors(value):
    lower = []
    upper = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            lower.append(divisor)
            if divisor * divisor != value:
                upper.append(value // divisor)
    return tuple(lower + upper[::-1])


def squarefree_coordinates(value):
    squarefree = 1
    root = 1
    remainder = value
    prime = 2
    while prime * prime <= remainder:
        exponent = 0
        while remainder % prime == 0:
            remainder //= prime
            exponent += 1
        if exponent % 2:
            squarefree *= prime
        root *= prime ** (exponent // 2)
        prime += 1
    if remainder > 1:
        squarefree *= remainder
    return squarefree, root


def matrix_product(left, right):
    return tuple(
        tuple(
            sum(left[row][index] * right[index][column]
                for index in range(2))
            for column in range(len(right[0]))
        )
        for row in range(len(left))
    )


def matrix_scale(scalar, matrix):
    return tuple(
        tuple(scalar * entry for entry in row)
        for row in matrix
    )


def matrix_add(left, right):
    return tuple(
        tuple(
            left[row][column] + right[row][column]
            for column in range(len(left[0]))
        )
        for row in range(len(left))
    )


def matrix_transpose(matrix):
    return tuple(zip(*matrix))


def matrix_determinant(matrix):
    return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]


def matrix_inverse(matrix):
    determinant = matrix_determinant(matrix)
    return (
        (
            Fraction(matrix[1][1], determinant),
            Fraction(-matrix[0][1], determinant),
        ),
        (
            Fraction(-matrix[1][0], determinant),
            Fraction(matrix[0][0], determinant),
        ),
    )


identity_matrix = ((1, 0), (0, 1))
zero_matrix = ((0, 0), (0, 0))
e_11 = ((1, 0), (0, 0))
e_22 = ((0, 0), (0, 1))
e_12 = ((0, 1), (0, 0))
e_21 = ((0, 0), (1, 0))
sign_matrix = ((1, 0), (0, -1))
sheet_exchange = ((0, 1), (1, 0))
sheet_exchange_matrix = ((0, 1), (1, 0))
hadamard_unscaled = ((1, 1), (1, -1))
mixer_plus_support = matrix_scale(
    Fraction(1, 2),
    matrix_add(identity_matrix, sheet_exchange),
)
mixer_minus_support = matrix_scale(
    Fraction(1, 2),
    matrix_add(identity_matrix, matrix_scale(-1, sheet_exchange)),
)


def carrier_blade_checks(matrix, expected_determinant):
    a, b = matrix[0]
    c, d = matrix[1]
    determinant = matrix_determinant(matrix)
    inverse = matrix_inverse(matrix)
    directed = matrix_scale(
        determinant,
        matrix_product(matrix_product(matrix, e_21), inverse),
    )
    reverse = matrix_scale(
        determinant,
        matrix_product(matrix_product(matrix, e_12), inverse),
    )
    plus_support = matrix_product(matrix_product(matrix, e_11), inverse)
    minus_support = matrix_product(matrix_product(matrix, e_22), inverse)
    transported_sign = matrix_product(
        matrix_product(matrix, sign_matrix), inverse
    )
    metric = matrix_product(matrix_transpose(inverse), inverse)
    metric_adjoint = matrix_product(
        matrix_product(
            matrix_inverse(metric),
            matrix_transpose(directed),
        ),
        metric,
    )
    first_column = ((a,), (c,))
    second_column = ((b,), (d,))
    return (
        determinant == expected_determinant,
        matrix_product(matrix, inverse) == identity_matrix,
        directed == ((b * d, -b * b), (d * d, -b * d)),
        reverse == ((-a * c, a * a), (-c * c, a * c)),
        matrix_product(transported_sign, directed)
        == matrix_scale(-1, directed),
        matrix_product(directed, transported_sign) == directed,
        matrix_product(transported_sign, reverse) == reverse,
        matrix_product(reverse, transported_sign)
        == matrix_scale(-1, reverse),
        matrix_product(
            matrix_product(minus_support, directed), plus_support
        )
        == directed,
        matrix_product(
            matrix_product(plus_support, reverse), minus_support
        )
        == reverse,
        matrix_product(directed, first_column)
        == matrix_scale(determinant, second_column),
        matrix_product(directed, second_column) == ((0,), (0,)),
        matrix_product(reverse, second_column)
        == matrix_scale(determinant, first_column),
        matrix_product(reverse, first_column) == ((0,), (0,)),
        metric_adjoint == reverse,
        matrix_transpose(directed) != reverse,
        matrix_product(matrix_transpose(matrix), matrix)
        != matrix_scale(determinant, identity_matrix),
        Fraction(d, b) - Fraction(c, a)
        == Fraction(determinant, a * b),
        Fraction(d, b) > Fraction(c, a),
    )


exterior_count = 0
middle_count = 0
coordinate_checks = []
exterior_intrinsic_checks = []
exterior_divisor_checks = []
exterior_matrix_checks = []
exterior_blade_checks = []
middle_intrinsic_checks = []
middle_divisor_checks = []
middle_matrix_checks = []
middle_blade_checks = []
overlap_count = 0
overlap_checks = []
overlap_examples = []
exterior_endpoints_by_shell = {}
middle_endpoints_by_shell = {}
overlap_coordinates_by_shell = {}

for prime in range(5, 1001):
    if prime % 4 != 1 or not is_prime(prime):
        continue
    quarter = (prime - 1) // 4
    for first in range(quarter + 1, 3 * quarter + 1):
        residual = 4 * first - prime
        shell_key = (prime, first, residual)
        for endpoint in divisors(first * first):
            squarefree, parameter = squarefree_coordinates(endpoint)
            branch = first // (squarefree * parameter)
            coordinate_checks.append(
                first == squarefree * parameter * branch
                and endpoint == squarefree * parameter * parameter
            )

            if (4 * endpoint + 1) % residual == 0:
                exterior_count += 1
                exterior_endpoints_by_shell.setdefault(
                    shell_key,
                    set(),
                ).add(endpoint)
                quotient = (4 * endpoint + 1) // residual
                third = quotient * branch - parameter
                exterior_intrinsic_checks.append(parameter < 2 * third)
                exterior_divisor_checks.extend(
                    (
                        (4 * squarefree * parameter * parameter + 1)
                        % quotient
                        == 0,
                        (4 * squarefree * parameter * parameter + 1)
                        // quotient
                        == residual,
                        (quotient * prime + 1)
                        % (4 * squarefree * parameter)
                        == 0,
                        (quotient * prime + 1)
                        // (4 * squarefree * parameter)
                        == third,
                        (parameter + third) % quotient == 0,
                        (parameter + third) // quotient == branch,
                        Fraction(1, squarefree * parameter * branch)
                        + Fraction(
                            1,
                            prime
                            * squarefree
                            * parameter
                            * third,
                        )
                        + Fraction(
                            1,
                            squarefree * branch * third,
                        )
                        == Fraction(4, prime),
                    )
                )
                exterior_matrix_checks.extend(
                    (
                        4
                        * squarefree
                        * parameter
                        * third
                        - quotient * prime
                        == 1,
                        quotient * residual
                        - 4
                        * squarefree
                        * parameter
                        * parameter
                        == 1,
                    )
                )
                exterior_blade_checks.extend(
                    carrier_blade_checks(
                        (
                            (4 * squarefree * parameter, quotient),
                            (prime, third),
                        ),
                        1,
                    )
                )
                exterior_blade_checks.extend(
                    carrier_blade_checks(
                        (
                            (quotient, 4 * squarefree * parameter),
                            (parameter, residual),
                        ),
                        1,
                    )
                )
                coordinate_checks.extend(
                    (
                        third > 0,
                        quotient * prime + 1
                        == 4 * squarefree * parameter * third,
                        (parameter + third) % quotient == 0,
                        (parameter + third) // quotient == branch,
                        quotient % 4 == 3,
                        4
                        * squarefree
                        * parameter
                        * (branch - parameter)
                        - 1
                        <= prime,
                        prime
                        < 4 * squarefree * parameter * branch
                        <= 3 * prime,
                    )
                )

            if (endpoint + first) % residual == 0:
                middle_count += 1
                middle_endpoints_by_shell.setdefault(
                    shell_key,
                    set(),
                ).add(endpoint)
                quotient = (parameter + branch) // residual
                factor = 4 * quotient * squarefree * parameter - 1
                middle_intrinsic_checks.extend(
                    (
                        residual <= prime,
                        4 * first <= 2 * prime,
                    )
                )
                middle_divisor_checks.extend(
                    (
                        factor > 0,
                        (prime + 4 * squarefree * parameter * parameter)
                        % factor
                        == 0,
                        (prime + 4 * squarefree * parameter * parameter)
                        // factor
                        == residual,
                        (quotient * prime + parameter) % factor == 0,
                        (quotient * prime + parameter) // factor == branch,
                    )
                )
                middle_matrix_checks.extend(
                    (
                        4
                        * squarefree
                        * parameter
                        * quotient
                        - factor
                        == 1,
                        factor * residual
                        - 4
                        * squarefree
                        * parameter
                        * parameter
                        == prime,
                        factor * branch - quotient * prime
                        == parameter,
                    )
                )
                middle_blade_checks.extend(
                    carrier_blade_checks(
                        (
                            (4 * squarefree * parameter, factor),
                            (1, quotient),
                        ),
                        1,
                    )
                )
                middle_blade_checks.extend(
                    carrier_blade_checks(
                        (
                            (factor, 4 * squarefree * parameter),
                            (parameter, residual),
                        ),
                        prime,
                    )
                )
                middle_blade_checks.extend(
                    carrier_blade_checks(
                        (
                            (factor, quotient),
                            (prime, branch),
                        ),
                        parameter,
                    )
                )
                coordinate_checks.extend(
                    (
                        quotient > 0,
                        parameter + branch == quotient * residual,
                        (
                            4 * quotient * squarefree * parameter - 1
                        )
                        * (
                            4 * quotient * squarefree * branch - 1
                        )
                        == 4
                        * quotient
                        * quotient
                        * squarefree
                        * prime
                        + 1,
                        4 * squarefree * parameter * branch
                        - parameter
                        - branch
                        <= prime,
                        prime
                        < 4 * squarefree * parameter * branch
                        <= 3 * prime,
                    )
                )

            if (
                (4 * endpoint + 1) % residual == 0
                and (endpoint + first) % residual == 0
            ):
                overlap_count += 1
                overlap_coordinates_by_shell.setdefault(
                    shell_key,
                    set(),
                ).add(
                    (
                        squarefree,
                        parameter,
                        branch,
                        endpoint,
                    )
                )
                exterior_quotient = (4 * endpoint + 1) // residual
                middle_factor = (
                    prime
                    + 4 * squarefree * parameter * parameter
                ) // residual
                column_entry = 4 * squarefree * parameter
                exterior_residual_flag = (
                    (exterior_quotient, column_entry),
                    (parameter, residual),
                )
                middle_prime_flag = (
                    (middle_factor, column_entry),
                    (parameter, residual),
                )
                directed_exterior = matrix_scale(
                    matrix_determinant(exterior_residual_flag),
                    matrix_product(
                        matrix_product(exterior_residual_flag, e_21),
                        matrix_inverse(exterior_residual_flag),
                    ),
                )
                directed_middle = matrix_scale(
                    matrix_determinant(middle_prime_flag),
                    matrix_product(
                        matrix_product(middle_prime_flag, e_21),
                        matrix_inverse(middle_prime_flag),
                    ),
                )
                reverse_exterior = matrix_scale(
                    matrix_determinant(exterior_residual_flag),
                    matrix_product(
                        matrix_product(exterior_residual_flag, e_12),
                        matrix_inverse(exterior_residual_flag),
                    ),
                )
                reverse_middle = matrix_scale(
                    matrix_determinant(middle_prime_flag),
                    matrix_product(
                        matrix_product(middle_prime_flag, e_12),
                        matrix_inverse(middle_prime_flag),
                    ),
                )
                defect = tuple(
                    tuple(
                        reverse_middle[row][column]
                        - reverse_exterior[row][column]
                        for column in range(2)
                    )
                    for row in range(2)
                )
                difference = middle_factor - exterior_quotient
                expected_defect = matrix_scale(
                    difference,
                    (
                        (
                            -parameter,
                            middle_factor + exterior_quotient,
                        ),
                        (0, parameter),
                    ),
                )
                positive_eigenvector = (
                    (middle_factor + exterior_quotient,),
                    (2 * parameter,),
                )
                theta = matrix_scale(
                    Fraction(1, difference * parameter),
                    defect,
                )
                negative_support = (
                    (
                        1,
                        Fraction(
                            -middle_factor - exterior_quotient,
                            2 * parameter,
                        ),
                    ),
                    (0, 0),
                )
                positive_support = (
                    (
                        0,
                        Fraction(
                            middle_factor + exterior_quotient,
                            2 * parameter,
                        ),
                    ),
                    (0, 1),
                )
                half_period_intertwiner = (
                    (0, Fraction(1, 2 * parameter)),
                    (
                        1,
                        Fraction(
                            -middle_factor - exterior_quotient,
                            2 * parameter,
                        ),
                    ),
                )
                mixer_intertwiner = matrix_product(
                    hadamard_unscaled,
                    half_period_intertwiner,
                )
                overlap_checks.extend(
                    (
                        (prime - 1) % residual == 0,
                        difference == (prime - 1) // residual,
                        matrix_determinant(exterior_residual_flag) == 1,
                        matrix_determinant(middle_prime_flag) == prime,
                        directed_exterior == directed_middle,
                        defect == expected_defect,
                        defect[0][0] + defect[1][1] == 0,
                        matrix_determinant(defect)
                        == -difference * difference
                        * parameter * parameter,
                        matrix_product(defect, defect)
                        == matrix_scale(
                            difference * difference
                            * parameter * parameter,
                            identity_matrix,
                        ),
                        matrix_product(defect, ((1,), (0,)))
                        == matrix_scale(
                            -difference * parameter,
                            ((1,), (0,)),
                        ),
                        matrix_product(defect, positive_eigenvector)
                        == matrix_scale(
                            difference * parameter,
                            positive_eigenvector,
                        ),
                        matrix_product(theta, theta) == identity_matrix,
                        matrix_product(
                            negative_support,
                            negative_support,
                        )
                        == negative_support,
                        matrix_product(
                            positive_support,
                            positive_support,
                        )
                        == positive_support,
                        matrix_product(
                            negative_support,
                            positive_support,
                        )
                        == zero_matrix,
                        matrix_product(
                            positive_support,
                            negative_support,
                        )
                        == zero_matrix,
                        matrix_add(
                            negative_support,
                            positive_support,
                        )
                        == identity_matrix,
                        defect
                        == matrix_scale(
                            difference * parameter,
                            matrix_add(
                                positive_support,
                                matrix_scale(-1, negative_support),
                            ),
                        ),
                        matrix_determinant(half_period_intertwiner)
                        == Fraction(-1, 2 * parameter),
                        matrix_product(
                            half_period_intertwiner,
                            theta,
                        )
                        == matrix_product(
                            sign_matrix,
                            half_period_intertwiner,
                        ),
                        matrix_product(
                            half_period_intertwiner,
                            negative_support,
                        )
                        == matrix_product(
                            e_22,
                            half_period_intertwiner,
                        ),
                        matrix_product(
                            half_period_intertwiner,
                            positive_support,
                        )
                        == matrix_product(
                            e_11,
                            half_period_intertwiner,
                        ),
                        matrix_product(
                            mixer_intertwiner,
                            theta,
                        )
                        == matrix_product(
                            sheet_exchange,
                            mixer_intertwiner,
                        ),
                        matrix_product(
                            mixer_intertwiner,
                            negative_support,
                        )
                        == matrix_product(
                            mixer_minus_support,
                            mixer_intertwiner,
                        ),
                        matrix_product(
                            mixer_intertwiner,
                            positive_support,
                        )
                        == matrix_product(
                            mixer_plus_support,
                            mixer_intertwiner,
                        ),
                        matrix_product(
                            matrix_product(
                                mixer_intertwiner,
                                defect,
                            ),
                            matrix_inverse(mixer_intertwiner),
                        )
                        == matrix_scale(
                            difference * parameter,
                            sheet_exchange,
                        ),
                    )
                )
                if len(overlap_examples) < 5:
                    overlap_examples.append(
                        (
                            prime,
                            first,
                            residual,
                            squarefree,
                            parameter,
                            branch,
                            exterior_quotient,
                            middle_factor,
                        )
                    )

coupled_sheet_checks = []
coupled_action_checks = []
coupled_carrier_checks = []
coupled_transition_checks = []
coupled_fixed_line_checks = []
coupled_fixed_line_examples = []
coupled_blade_height_checks = []
coupled_blade_height_examples = []
coupled_control_volume_checks = []
coupled_control_volume_examples = []
coupled_sum_gap_polynomial_checks = []
coupled_sum_gap_polynomial_examples = []
coupled_discriminant_checks = []
coupled_discriminant_examples = []
coupled_cover_checks = []
coupled_cover_examples = []
coupled_shell_examples = []
coupled_shell_keys = sorted(
    key
    for key in (
        set(exterior_endpoints_by_shell)
        | set(middle_endpoints_by_shell)
    )
    if (key[0] - 1) % key[2] == 0
)
for shell_key in coupled_shell_keys:
    prime, first, residual = shell_key
    exterior_endpoints = exterior_endpoints_by_shell.get(
        shell_key,
        set(),
    )
    middle_endpoints = middle_endpoints_by_shell.get(
        shell_key,
        set(),
    )
    overlap_coordinates = overlap_coordinates_by_shell.get(
        shell_key,
        set(),
    )
    overlap_endpoints = {
        endpoint
        for _, _, _, endpoint in overlap_coordinates
    }
    packets = {
        (squarefree, min(parameter, branch), max(parameter, branch))
        for squarefree, parameter, branch, _ in overlap_coordinates
    }
    packet_sum_gap_coefficients = {}
    for squarefree, left, right in packets:
        packet_sum = left + right
        packet_gap = right - left
        key = (packet_sum, packet_gap)
        packet_sum_gap_coefficients[key] = (
            packet_sum_gap_coefficients.get(key, 0) + 1
        )
    packet_sum_gap_support_from_criterion = set()
    shell_squarefree_divisors = set(squarefree_divisors(first))
    for packet_sum in range(2, first + 2):
        for packet_gap in range(1, packet_sum):
            if (packet_sum - packet_gap) % 2:
                continue
            denominator = (
                packet_sum * packet_sum
                - packet_gap * packet_gap
            )
            if (4 * first) % denominator:
                continue
            squarefree = 4 * first // denominator
            if squarefree not in shell_squarefree_divisors:
                continue
            if (
                squarefree
                * (packet_sum - packet_gap)
                * (packet_sum - packet_gap)
                + 1
            ) % residual:
                continue
            packet_sum_gap_support_from_criterion.add(
                (packet_sum, packet_gap)
            )
    packet_sum_gap_first_moment = sum(
        packet_gap
        for packet_sum, packet_gap
        in packet_sum_gap_coefficients
    )
    packet_sum_gap_second_moment = sum(
        packet_gap * packet_gap
        for packet_sum, packet_gap
        in packet_sum_gap_coefficients
    )
    coupled_sum_gap_polynomial_checks.extend(
        (
            all(
                coefficient == 1
                for coefficient
                in packet_sum_gap_coefficients.values()
            ),
            len(packet_sum_gap_coefficients) == len(packets),
            (
                set(packet_sum_gap_coefficients)
                == packet_sum_gap_support_from_criterion
            ),
            all(
                packet_sum % residual == 0
                for packet_sum, packet_gap
                in packet_sum_gap_coefficients
            ),
            sum(packet_sum_gap_coefficients.values()) == len(packets),
            2 * len(packet_sum_gap_coefficients)
            == len(exterior_endpoints),
            3 * len(packet_sum_gap_coefficients)
            == (
                len(exterior_endpoints)
                + len(middle_endpoints) // 2
            ),
            packet_sum_gap_first_moment
            == sum(
                2
                * packet_sum
                * Fraction(packet_gap, 2 * packet_sum)
                for packet_sum, packet_gap
                in packet_sum_gap_coefficients
            ),
            packet_sum_gap_second_moment
            == sum(
                4
                * packet_sum
                * packet_sum
                * Fraction(
                    packet_gap * packet_gap,
                    4 * packet_sum * packet_sum,
                )
                for packet_sum, packet_gap
                in packet_sum_gap_coefficients
            ),
            all(
                (
                    packet_gap * packet_gap
                    == packet_sum * packet_sum
                    - 4
                    * (
                        first
                        // (
                            4
                            * first
                            // (
                                packet_sum * packet_sum
                                - packet_gap * packet_gap
                            )
                        )
                    )
                )
                for packet_sum, packet_gap
                in packet_sum_gap_coefficients
            ),
        )
    )
    if len(coupled_sum_gap_polynomial_examples) < 5:
        coupled_sum_gap_polynomial_examples.append(
            (
                prime,
                first,
                residual,
                tuple(sorted(packet_sum_gap_coefficients)),
                len(packet_sum_gap_coefficients),
                packet_sum_gap_first_moment,
                packet_sum_gap_second_moment,
            )
        )
    packets_from_square_discriminants = set()
    for squarefree in squarefree_divisors(first):
        product = first // squarefree
        for ell_candidate in range(1, (product + 1) // residual + 1):
            total = ell_candidate * residual
            discriminant = total * total - 4 * product
            if discriminant <= 0:
                continue
            root = isqrt(discriminant)
            if root * root != discriminant:
                continue
            if (total - root) % 2 != 0:
                continue
            left_candidate = (total - root) // 2
            right_candidate = (total + root) // 2
            if left_candidate <= 0 or left_candidate == right_candidate:
                continue
            packets_from_square_discriminants.add(
                (
                    squarefree,
                    left_candidate,
                    right_candidate,
                )
            )
    coupled_discriminant_checks.append(
        packets_from_square_discriminants == packets
    )
    coupled_sheet_checks.extend(
        (
            exterior_endpoints == middle_endpoints,
            exterior_endpoints == overlap_endpoints,
            len(overlap_coordinates) == 2 * len(packets),
            len(exterior_endpoints) == 2 * len(packets),
            len(middle_endpoints) == 2 * len(packets),
            len(exterior_endpoints) + len(middle_endpoints) // 2
            == 3 * len(packets),
            len(packets) > 0,
        )
    )
    for squarefree, parameter, branch, endpoint in overlap_coordinates:
        complement = first * first // endpoint
        coupled_sheet_checks.extend(
            (
                parameter != branch,
                first == squarefree * parameter * branch,
                endpoint == squarefree * parameter * parameter,
                complement == squarefree * branch * branch,
                (
                    squarefree,
                    branch,
                    parameter,
                    complement,
                )
                in overlap_coordinates,
                (parameter + branch) % residual == 0,
            )
        )
    for squarefree, left, right in packets:
        endpoint = squarefree * left * left
        complement = squarefree * right * right
        k_left = (4 * squarefree * left * left + 1) // residual
        q_left = (prime + 4 * squarefree * left * left) // residual
        k_right = (4 * squarefree * right * right + 1) // residual
        q_right = (prime + 4 * squarefree * right * right) // residual
        h_left = k_left + q_left
        h_right = k_right + q_right
        h_total = h_left + h_right

        flag_left = (
            (0, Fraction(1, 2 * left)),
            (1, Fraction(-h_left, 2 * left)),
        )
        flag_right = (
            (0, Fraction(1, 2 * right)),
            (1, Fraction(-h_right, 2 * right)),
        )
        theta_left = (
            (-1, Fraction(h_left, left)),
            (0, 1),
        )
        theta_right = (
            (-1, Fraction(h_right, right)),
            (0, 1),
        )
        transition = (
            (-1, Fraction(h_total, 2 * left)),
            (0, Fraction(right, left)),
        )
        reverse_transition = (
            (-1, Fraction(h_total, 2 * right)),
            (0, Fraction(left, right)),
        )
        plus_left = matrix_scale(
            Fraction(1, 2),
            matrix_add(identity_matrix, theta_left),
        )
        minus_left = matrix_scale(
            Fraction(1, 2),
            matrix_add(
                identity_matrix,
                matrix_scale(-1, theta_left),
            ),
        )
        plus_right = matrix_scale(
            Fraction(1, 2),
            matrix_add(identity_matrix, theta_right),
        )
        minus_right = matrix_scale(
            Fraction(1, 2),
            matrix_add(
                identity_matrix,
                matrix_scale(-1, theta_right),
            ),
        )
        defect_left = matrix_scale(
            Fraction(prime - 1, residual),
            ((-left, h_left), (0, left)),
        )
        defect_right = matrix_scale(
            Fraction(prime - 1, residual),
            ((-right, h_right), (0, right)),
        )
        positive_transition_eigenvector = (
            (Fraction(h_total, 2 * (left + right)),),
            (1,),
        )
        delta = (prime - 1) // residual
        ell = (left + right) // residual
        gamma = Fraction(h_total, 2 * (left + right))
        intrinsic_gamma = (
            4 * squarefree * ell
            - Fraction(delta + 2, ell * residual)
        )
        oriented_mu = Fraction(
            (right - left) * (delta + 2),
            left + right,
        )
        packet_discriminant = (
            ell * ell * residual * residual
            - 4 * first // squarefree
        )
        packet_root = right - left
        packet_branch_coordinate = Fraction(left, left + right)
        packet_quarter_coordinate = Fraction(
            -left * right,
            (left + right) * (left + right),
        )
        packet_centered_coordinate = Fraction(
            left - right,
            left + right,
        )
        packet_cover_coordinate = Fraction(
            oriented_mu,
            delta + 2,
        )
        packet_cover_height = (
            packet_cover_coordinate * packet_cover_coordinate / 4
        )
        packet_interval_volume = abs(packet_cover_coordinate) / 2
        packet_sum = left + right
        packet_gap = abs(right - left)
        left_flag_image = matrix_product(
            flag_left,
            positive_transition_eigenvector,
        )
        right_flag_image = matrix_product(
            flag_right,
            positive_transition_eigenvector,
        )
        left_packet_coefficients = matrix_product(
            hadamard_unscaled,
            left_flag_image,
        )
        right_packet_coefficients = matrix_product(
            hadamard_unscaled,
            right_flag_image,
        )
        fixed_packet_vector = (
            (1 + oriented_mu,),
            (1 - oriented_mu,),
        )
        fixed_projection_denominator = 1 + oriented_mu * oriented_mu
        fixed_projection = (
            (
                Fraction(1, fixed_projection_denominator),
                Fraction(oriented_mu, fixed_projection_denominator),
            ),
            (
                Fraction(oriented_mu, fixed_projection_denominator),
                Fraction(
                    oriented_mu * oriented_mu,
                    fixed_projection_denominator,
                ),
            ),
        )
        fixed_projection_blade_expansion = matrix_scale(
            Fraction(1, fixed_projection_denominator),
            matrix_add(
                matrix_add(
                    e_11,
                    matrix_scale(
                        oriented_mu,
                        matrix_add(e_12, e_21),
                    ),
                ),
                matrix_scale(oriented_mu * oriented_mu, e_22),
            ),
        )
        fixed_projection_commutator = matrix_add(
            matrix_product(sign_matrix, fixed_projection),
            matrix_scale(
                -1,
                matrix_product(fixed_projection, sign_matrix),
            ),
        )
        parity_plus_weight = fixed_projection[0][0]
        parity_minus_weight = fixed_projection[1][1]
        commutator_hs_square = sum(
            entry * entry
            for row in fixed_projection_commutator
            for entry in row
        )
        lifted_plus_weight = 3 * parity_plus_weight
        lifted_minus_weight = 3 * parity_minus_weight
        lifted_commutator_hs_square = 3 * commutator_hs_square
        coupled_fixed_line_checks.extend(
            (
                (prime - 1) % residual == 0,
                (left + right) % residual == 0,
                q_left == 4 * squarefree * ell * left - 1,
                q_right == 4 * squarefree * ell * right - 1,
                k_left == q_left - delta,
                k_right == q_right - delta,
                h_total
                == 2
                * (
                    4 * squarefree * ell * ell * residual
                    - delta
                    - 2
                ),
                gamma == intrinsic_gamma,
                gamma > 0,
                gamma < 4 * squarefree * ell,
                left_flag_image
                == (
                    (Fraction(1, 2 * left),),
                    (Fraction(oriented_mu, 2 * left),),
                ),
                right_flag_image
                == (
                    (Fraction(1, 2 * right),),
                    (Fraction(-oriented_mu, 2 * right),),
                ),
                matrix_scale(
                    2 * left,
                    left_packet_coefficients,
                )
                == fixed_packet_vector,
                matrix_scale(
                    2 * right,
                    matrix_product(
                        sheet_exchange_matrix,
                        right_packet_coefficients,
                    ),
                )
                == fixed_packet_vector,
                oriented_mu != 0,
                matrix_transpose(fixed_projection) == fixed_projection,
                matrix_product(fixed_projection, fixed_projection)
                == fixed_projection,
                fixed_projection[0][0] + fixed_projection[1][1] == 1,
                matrix_determinant(fixed_projection) == 0,
                fixed_projection == fixed_projection_blade_expansion,
                fixed_projection_commutator
                == matrix_scale(
                    Fraction(
                        2 * oriented_mu,
                        fixed_projection_denominator,
                    ),
                    matrix_add(e_12, matrix_scale(-1, e_21)),
                ),
            )
        )
        coupled_blade_height_checks.extend(
            (
                parity_plus_weight > 0,
                parity_minus_weight > 0,
                parity_plus_weight + parity_minus_weight == 1,
                parity_minus_weight / parity_plus_weight
                == oriented_mu * oriented_mu,
                commutator_hs_square
                == 8 * parity_plus_weight * parity_minus_weight,
                packet_cover_height
                == parity_minus_weight
                / (
                    4
                    * (delta + 2)
                    * (delta + 2)
                    * parity_plus_weight
                ),
                packet_cover_height
                == commutator_hs_square
                / (
                    32
                    * (delta + 2)
                    * (delta + 2)
                    * parity_plus_weight
                    * parity_plus_weight
                ),
                lifted_plus_weight == 3 * parity_plus_weight,
                lifted_minus_weight == 3 * parity_minus_weight,
                lifted_commutator_hs_square
                == Fraction(8, 3)
                * lifted_plus_weight
                * lifted_minus_weight,
                packet_cover_height
                == lifted_minus_weight
                / (
                    4
                    * (delta + 2)
                    * (delta + 2)
                    * lifted_plus_weight
                ),
                packet_cover_height
                == 3
                * lifted_commutator_hs_square
                / (
                    32
                    * (delta + 2)
                    * (delta + 2)
                    * lifted_plus_weight
                    * lifted_plus_weight
                ),
                packet_interval_volume * packet_interval_volume
                == packet_cover_height,
            )
        )
        if len(coupled_blade_height_examples) < 5:
            coupled_blade_height_examples.append(
                (
                    prime,
                    first,
                    residual,
                    squarefree,
                    left,
                    right,
                    parity_plus_weight,
                    parity_minus_weight,
                    commutator_hs_square,
                    packet_cover_height,
                    packet_interval_volume,
                )
            )
        coupled_control_volume_checks.extend(
            (
                2 * packet_sum * packet_interval_volume == packet_gap,
                {left, right}
                == {
                    Fraction(packet_sum - packet_gap, 2),
                    Fraction(packet_sum + packet_gap, 2),
                },
                left * right
                == packet_sum
                * packet_sum
                * (
                    Fraction(1, 4)
                    - packet_interval_volume * packet_interval_volume
                ),
                packet_discriminant == packet_gap * packet_gap,
                packet_gap > 0,
                packet_gap <= packet_sum - 2,
                (packet_gap - packet_sum) % 2 == 0,
                (
                    packet_interval_volume
                    >= (
                        Fraction(1, 2 * packet_sum)
                        if packet_sum % 2
                        else Fraction(1, packet_sum)
                    )
                ),
                packet_interval_volume
                <= Fraction(1, 2) - Fraction(1, packet_sum),
            )
        )
        if len(coupled_control_volume_examples) < 5:
            coupled_control_volume_examples.append(
                (
                    prime,
                    first,
                    residual,
                    squarefree,
                    left,
                    right,
                    packet_sum,
                    packet_gap,
                    packet_interval_volume,
                    left * right,
                    packet_discriminant,
                )
            )
        coupled_discriminant_checks.extend(
            (
                first // squarefree == left * right,
                packet_discriminant == packet_root * packet_root,
                left == (ell * residual - packet_root) // 2,
                right == (ell * residual + packet_root) // 2,
                ell * residual <= first // squarefree + 1,
                packet_branch_coordinate
                + Fraction(right, left + right)
                == 1,
                packet_quarter_coordinate
                == -packet_branch_coordinate
                * (1 - packet_branch_coordinate),
                packet_quarter_coordinate
                == Fraction(-1, 4)
                + packet_centered_coordinate
                * packet_centered_coordinate
                / 4,
                oriented_mu
                == -(delta + 2) * packet_centered_coordinate,
                packet_quarter_coordinate
                == Fraction(-1, 4)
                + oriented_mu * oriented_mu
                / (4 * (delta + 2) * (delta + 2)),
                Fraction(-1, 4) < packet_quarter_coordinate < 0,
            )
        )
        coupled_cover_checks.extend(
            (
                packet_cover_coordinate
                == Fraction(right - left, left + right),
                packet_cover_coordinate == -packet_centered_coordinate,
                packet_cover_coordinate != 0,
                packet_cover_coordinate * packet_cover_coordinate
                == 1 + 4 * packet_quarter_coordinate,
                packet_quarter_coordinate
                == Fraction(-1, 4) + packet_cover_height,
                Fraction(0) < packet_cover_height < Fraction(1, 4),
                {
                    packet_cover_coordinate,
                    -packet_cover_coordinate,
                }
                == {
                    Fraction(right - left, left + right),
                    Fraction(left - right, left + right),
                },
            )
        )
        if len(coupled_cover_examples) < 5:
            coupled_cover_examples.append(
                (
                    prime,
                    first,
                    residual,
                    squarefree,
                    left,
                    right,
                    packet_cover_coordinate,
                    packet_cover_height,
                    packet_quarter_coordinate,
                )
            )
        if len(coupled_discriminant_examples) < 5:
            coupled_discriminant_examples.append(
                (
                    prime,
                    first,
                    residual,
                    squarefree,
                    ell,
                    packet_discriminant,
                    packet_root,
                    packet_quarter_coordinate,
                    oriented_mu,
                )
            )
        if len(coupled_fixed_line_examples) < 5:
            coupled_fixed_line_examples.append(
                (
                    prime,
                    first,
                    residual,
                    squarefree,
                    left,
                    right,
                    ell,
                    delta,
                    gamma,
                    oriented_mu,
                )
            )
        coupled_transition_checks.extend(
            (
                matrix_product(
                    matrix_product(
                        matrix_inverse(flag_right),
                        sign_matrix,
                    ),
                    flag_left,
                )
                == transition,
                matrix_product(reverse_transition, transition)
                == identity_matrix,
                matrix_product(transition, reverse_transition)
                == identity_matrix,
                matrix_determinant(transition)
                == Fraction(-right, left),
                transition[0][0] + transition[1][1]
                == Fraction(right, left) - 1,
                matrix_product(transition, theta_left)
                == matrix_product(theta_right, transition),
                matrix_product(transition, plus_left)
                == matrix_product(plus_right, transition),
                matrix_product(transition, minus_left)
                == matrix_product(minus_right, transition),
                matrix_product(transition, defect_left)
                == matrix_scale(
                    Fraction(left, right),
                    matrix_product(defect_right, transition),
                ),
                matrix_product(transition, ((1,), (0,)))
                == ((-1,), (0,)),
                matrix_product(
                    transition,
                    positive_transition_eigenvector,
                )
                == matrix_scale(
                    Fraction(right, left),
                    positive_transition_eigenvector,
                ),
            )
        )
        cells = {
            (origin, value)
            for origin in range(3)
            for value in (endpoint, complement)
        }
        occupied_cells = {
            (2, endpoint),
            (0, complement),
            (2, complement),
            (0, endpoint),
            (1, endpoint),
            (1, complement),
        }

        def rotate(cell):
            origin, value = cell
            return ((origin + 1) % 3, value)

        def sheet_exchange(cell):
            origin, value = cell
            other = complement if value == endpoint else endpoint
            return (origin, other)

        def arithmetic_complement(cell):
            origin, value = cell
            other = complement if value == endpoint else endpoint
            return ((2 - origin) % 3, other)

        carrier_pairs = tuple(
            (origin, sheet)
            for origin in range(3)
            for sheet in range(2)
        )

        def carrier_to_cell(pair):
            origin, sheet = pair
            value = endpoint if sheet == 0 else complement
            return (origin, value)

        def commuting_product(left_pair, right_pair):
            left_origin, left_sheet = left_pair
            right_origin, right_sheet = right_pair
            return (
                (left_origin + right_origin) % 3,
                (left_sheet + right_sheet) % 2,
            )

        def reflected_product(left_pair, right_pair):
            left_origin, left_sheet = left_pair
            right_origin, right_sheet = right_pair
            sign = -1 if left_sheet else 1
            return (
                (left_origin + sign * right_origin) % 3,
                (left_sheet + right_sheet) % 2,
            )

        def rotation_power(cell, exponent):
            current = cell
            for _ in range(exponent % 3):
                current = rotate(current)
            return current

        def commuting_left_action(left_pair, cell):
            origin, sheet = left_pair
            current = sheet_exchange(cell) if sheet else cell
            return rotation_power(current, origin)

        def reflected_left_action(left_pair, cell):
            origin, sheet = left_pair
            current = cell
            if sheet:
                current = rotate(arithmetic_complement(current))
            return rotation_power(current, origin)

        for left_pair in carrier_pairs:
            for right_pair in carrier_pairs:
                right_cell = carrier_to_cell(right_pair)
                coupled_carrier_checks.extend(
                    (
                        carrier_to_cell(
                            commuting_product(left_pair, right_pair)
                        )
                        == commuting_left_action(left_pair, right_cell),
                        carrier_to_cell(
                            reflected_product(left_pair, right_pair)
                        )
                        == reflected_left_action(left_pair, right_cell),
                    )
                )

        for cell in cells:
            c6_orbit = []
            current = cell
            for _ in range(6):
                c6_orbit.append(current)
                current = rotate(sheet_exchange(current))
            d3_orbit = {
                ((cell[0] + exponent) % 3, cell[1])
                for exponent in range(3)
            } | {
                rotate_power
                for exponent in range(3)
                for rotate_power in (
                    (
                        (arithmetic_complement(cell)[0] + exponent) % 3,
                        arithmetic_complement(cell)[1],
                    ),
                )
            }
            coupled_action_checks.extend(
                (
                    occupied_cells == cells,
                    rotate(cell) in cells,
                    sheet_exchange(cell) in cells,
                    arithmetic_complement(cell) in cells,
                    sheet_exchange(rotate(cell))
                    == rotate(sheet_exchange(cell)),
                    arithmetic_complement(
                        rotate(arithmetic_complement(cell))
                    )
                    == ((cell[0] - 1) % 3, cell[1]),
                    len(set(c6_orbit)) == 6,
                    current == cell,
                    len(d3_orbit) == 6,
                )
            )
    if len(coupled_shell_examples) < 5:
        coupled_shell_examples.append(
            (
                prime,
                first,
                residual,
                len(overlap_coordinates),
                len(packets),
                len(exterior_endpoints) + len(middle_endpoints) // 2,
            )
            )

matrix_points = tuple(
    (origin, sheet)
    for sheet in range(2)
    for origin in range(3)
)
matrix_index = {
    point: index
    for index, point in enumerate(matrix_points)
}


def permutation_matrix(action):
    size = len(matrix_points)
    return tuple(
        tuple(
            int(row == matrix_index[action(matrix_points[column])])
            for column in range(size)
        )
        for row in range(size)
    )


def matrix_product(left, right):
    size = len(left)
    return tuple(
        tuple(
            sum(left[row][index] * right[index][column]
                for index in range(size))
            for column in range(size)
        )
        for row in range(size)
    )


def matrix_sum(left, right):
    return tuple(
        tuple(left[row][column] + right[row][column]
              for column in range(len(left)))
        for row in range(len(left))
    )


def matrix_difference(left, right):
    return tuple(
        tuple(left[row][column] - right[row][column]
              for column in range(len(left)))
        for row in range(len(left))
    )


def matrix_scale(scalar, matrix):
    return tuple(
        tuple(scalar * entry for entry in row)
        for row in matrix
    )


def matrix_power(matrix, exponent):
    size = len(matrix)
    result = tuple(
        tuple(int(row == column) for column in range(size))
        for row in range(size)
    )
    for _ in range(exponent):
        result = matrix_product(result, matrix)
    return result


def matrix_transpose(matrix):
    return tuple(zip(*matrix))


def sheet_tensor(two_by_two):
    return tuple(
        tuple(
            two_by_two[row_sheet][column_sheet]
            * int(row_origin == column_origin)
            for column_origin, column_sheet in matrix_points
        )
        for row_origin, row_sheet in matrix_points
    )


identity_six = tuple(
    tuple(int(row == column) for column in range(6))
    for row in range(6)
)
zero_six = matrix_scale(0, identity_six)
rotation_matrix = permutation_matrix(
    lambda point: ((point[0] + 1) % 3, point[1])
)
sheet_matrix = permutation_matrix(
    lambda point: (point[0], 1 - point[1])
)
complement_matrix = permutation_matrix(
    lambda point: ((2 - point[0]) % 3, 1 - point[1])
)
plus_twice = matrix_sum(identity_six, sheet_matrix)
minus_twice = matrix_difference(identity_six, sheet_matrix)
commuting_generator_matrix = matrix_product(
    rotation_matrix,
    sheet_matrix,
)
twice_minus_plus_blade = sheet_tensor(
    (
        (1, 1),
        (-1, -1),
    )
)
twice_plus_minus_blade = matrix_transpose(twice_minus_plus_blade)
coupled_carrier_checks.extend(
    (
        matrix_power(rotation_matrix, 3) == identity_six,
        matrix_power(sheet_matrix, 2) == identity_six,
        matrix_power(complement_matrix, 2) == identity_six,
        matrix_transpose(sheet_matrix) == sheet_matrix,
        matrix_product(sheet_matrix, rotation_matrix)
        == matrix_product(rotation_matrix, sheet_matrix),
        matrix_product(
            matrix_product(complement_matrix, rotation_matrix),
            complement_matrix,
        )
        == matrix_power(rotation_matrix, 2),
        matrix_product(sheet_matrix, complement_matrix)
        == matrix_product(complement_matrix, sheet_matrix),
        matrix_product(plus_twice, plus_twice)
        == matrix_scale(2, plus_twice),
        matrix_product(minus_twice, minus_twice)
        == matrix_scale(2, minus_twice),
        matrix_product(plus_twice, minus_twice) == zero_six,
        sum(plus_twice[index][index] for index in range(6)) == 6,
        sum(minus_twice[index][index] for index in range(6)) == 6,
        matrix_power(commuting_generator_matrix, 6) == identity_six,
        all(
            matrix_power(commuting_generator_matrix, exponent)
            != identity_six
            for exponent in range(1, 6)
        ),
    )
)
packet_blade_checks = (
    matrix_product(
        matrix_transpose(twice_minus_plus_blade),
        twice_minus_plus_blade,
    )
    == matrix_scale(2, plus_twice),
    matrix_product(
        twice_minus_plus_blade,
        matrix_transpose(twice_minus_plus_blade),
    )
    == matrix_scale(2, minus_twice),
    matrix_product(
        matrix_transpose(twice_plus_minus_blade),
        twice_plus_minus_blade,
    )
    == matrix_scale(2, minus_twice),
    matrix_product(
        twice_plus_minus_blade,
        matrix_transpose(twice_plus_minus_blade),
    )
    == matrix_scale(2, plus_twice),
    matrix_product(sheet_matrix, twice_minus_plus_blade)
    == matrix_scale(-1, twice_minus_plus_blade),
    matrix_product(twice_minus_plus_blade, sheet_matrix)
    == twice_minus_plus_blade,
    matrix_product(sheet_matrix, twice_plus_minus_blade)
    == twice_plus_minus_blade,
    matrix_product(twice_plus_minus_blade, sheet_matrix)
    == matrix_scale(-1, twice_plus_minus_blade),
    matrix_product(rotation_matrix, twice_minus_plus_blade)
    == matrix_product(twice_minus_plus_blade, rotation_matrix),
    matrix_product(rotation_matrix, twice_plus_minus_blade)
    == matrix_product(twice_plus_minus_blade, rotation_matrix),
)

report(
    "all shell coordinates through prime 1000",
    all(coordinate_checks),
)
report(
    "intrinsic exterior inequality through prime 1000",
    all(exterior_intrinsic_checks),
)
report(
    "exterior divisor-carrier parametrization through prime 1000",
    all(exterior_divisor_checks),
)
report(
    "exterior determinant flag through prime 1000",
    all(exterior_matrix_checks),
)
report(
    "exterior transported blade channels through prime 1000",
    all(exterior_blade_checks),
)
report(
    "intrinsic middle bounds through prime 1000",
    all(middle_intrinsic_checks),
)
report(
    "middle divisor-carrier parametrization through prime 1000",
    all(middle_divisor_checks),
)
report(
    "middle determinant flag through prime 1000",
    all(middle_matrix_checks),
)
report(
    "middle transported blade channels through prime 1000",
    all(middle_blade_checks),
)
report(
    "shared-column overlap and split reverse defect through prime 1000",
    overlap_count > 0 and all(overlap_checks),
)
report(
    "coupled two-sheet three-orbit rank through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_sheet_checks),
)
report(
    "coupled packet arithmetic C6 and D3 actions through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_action_checks),
)
report(
    "coupled carrier laws and sheet projection matrices through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_carrier_checks),
)
report(
    "packet sheet-parity blade tensor identities",
    all(packet_blade_checks),
)
report(
    "complementary packet flag transitions through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_transition_checks),
)
report(
    "unordered packet fixed line and oriented coordinate through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_fixed_line_checks),
)

report(
    "packet blade-coupling quarter height through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_blade_height_checks),
)

report(
    "packet control-volume arithmetic reconstruction through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_control_volume_checks),
)

report(
    "packet sum-gap polynomial and exact moments through prime 1000",
    (
        len(coupled_shell_keys) > 0
        and all(coupled_sum_gap_polynomial_checks)
    ),
)

report(
    "packet square discriminant and quarter coordinate through prime 1000",
    len(coupled_shell_keys) > 0 and all(coupled_discriminant_checks),
)


fable_cover_checks = []
fable_cover_data = []
for fable_x in (0, 1, -1):
    fable_height = Fraction(fable_x * fable_x, 4)
    fable_q = Fraction(-1, 4) + fable_height
    fable_first_output = Fraction(-1, 4)
    fable_cover_checks.extend(
        (
            fable_q - fable_first_output == fable_height,
            fable_height
            == (Fraction(0) if fable_x == 0 else Fraction(1, 4)),
        )
    )
    fable_cover_data.append(
        (fable_x, fable_height, fable_q, fable_first_output)
    )

report(
    "packet affine cover and Fable endpoint height through prime 1000",
    len(coupled_shell_keys) > 0
    and all(coupled_cover_checks)
    and all(fable_cover_checks),
)

exterior_example = {
    "p": 349,
    "k": 7,
    "s": 47,
    "t": 1,
    "h": 13,
}
exterior_example["m"] = (
    exterior_example["t"] + exterior_example["h"]
) // exterior_example["k"]
exterior_example["a"] = (
    exterior_example["s"]
    * exterior_example["t"]
    * exterior_example["m"]
)
exterior_example["R"] = 4 * exterior_example["a"] - exterior_example["p"]
report(
    "exterior converse example",
    exterior_example
    == {
        "p": 349,
        "k": 7,
        "s": 47,
        "t": 1,
        "h": 13,
        "m": 2,
        "a": 94,
        "R": 27,
    }
    and exterior_example["k"] * exterior_example["p"] + 1
    == 4
    * exterior_example["s"]
    * exterior_example["t"]
    * exterior_example["h"]
    and exterior_example["t"] < 2 * exterior_example["h"],
)

middle_example = {
    "p": 13,
    "ell": 1,
    "s": 2,
    "t": 1,
    "m": 2,
}
middle_example["a"] = (
    middle_example["s"] * middle_example["t"] * middle_example["m"]
)
middle_example["R"] = 4 * middle_example["a"] - middle_example["p"]
report(
    "middle converse example",
    middle_example
    == {
        "p": 13,
        "ell": 1,
        "s": 2,
        "t": 1,
        "m": 2,
        "a": 4,
        "R": 3,
    }
    and (
        4
        * middle_example["ell"]
        * middle_example["s"]
        * middle_example["t"]
        - 1
    )
    * (
        4
        * middle_example["ell"]
        * middle_example["s"]
        * middle_example["m"]
        - 1
    )
    == 4
    * middle_example["ell"]
    * middle_example["ell"]
    * middle_example["s"]
    * middle_example["p"]
    + 1
    and 0 < middle_example["R"] <= middle_example["p"]
    and 4 * middle_example["a"] <= 2 * middle_example["p"],
)

k_three_hard_count = 0
k_three_hit_count = 0
k_three_survivor_count = 0
k_three_checks = []

for prime in range(5, 100_001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    k_three_hard_count += 1
    target = (3 * prime + 1) // 4
    factors = prime_factors(target)
    inert = tuple(factor for factor in factors if factor % 3 == 2)
    if not inert:
        k_three_survivor_count += 1
        k_three_checks.append(all(factor % 3 == 1 for factor in factors))
        continue

    k_three_hit_count += 1
    squarefree = inert[0]
    third = target // squarefree
    branch = (third + 1) // 3
    first = squarefree * branch
    residual = 4 * first - prime
    endpoint_b_numerator = prime * (first + prime * squarefree)
    endpoint_c_numerator = prime * first + first * first // squarefree
    k_three_checks.extend(
        (
            third % 3 == 2,
            3 * prime + 1 == 4 * squarefree * third,
            residual == (4 * squarefree + 1) // 3,
            prime < 4 * first <= 3 * prime,
            (4 * squarefree + 1) % residual == 0,
            endpoint_b_numerator % residual == 0,
            endpoint_c_numerator % residual == 0,
        )
    )
    endpoint_b = endpoint_b_numerator // residual
    endpoint_c = endpoint_c_numerator // residual
    k_three_checks.append(
        4 * first * endpoint_b * endpoint_c
        == prime
        * (
            endpoint_b * endpoint_c
            + first * endpoint_c
            + first * endpoint_b
        )
    )

report(
    "k=3 split-prime obstruction through 100000",
    all(k_three_checks)
    and k_three_hard_count == 2_374
    and k_three_hit_count == 1_798
    and k_three_survivor_count == 576,
)
report(
    "prime 73 exact k=3 reconstruction",
    (
        Fraction(1, 20)
        + Fraction(1, 220)
        + Fraction(1, 4015)
    )
    == Fraction(4, 73)
    and (3 * 73 + 1) // 4 == 55,
)

one_leg_hits = {}
one_leg_survivors = []
one_leg_checks = []

for prime in range(5, 100_001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    hit = None
    for quotient in range(3, 256, 4):
        target = (quotient * prime + 1) // 4
        candidates = tuple(
            squarefree
            for squarefree in squarefree_divisors(target)
            if (4 * squarefree + 1) % quotient == 0
        )
        if not candidates:
            continue
        squarefree = candidates[0]
        third = target // squarefree
        branch = (third + 1) // quotient
        first = squarefree * branch
        residual = (4 * squarefree + 1) // quotient
        endpoint_b_numerator = prime * squarefree * (branch + prime)
        endpoint_c_numerator = squarefree * branch * (prime + branch)
        one_leg_checks.extend(
            (
                third % quotient == quotient - 1,
                quotient * prime + 1 == 4 * squarefree * third,
                branch > 0,
                residual == 4 * first - prime,
                0 < residual <= prime,
                prime < 4 * first <= 2 * prime,
                endpoint_b_numerator % residual == 0,
                endpoint_c_numerator % residual == 0,
            )
        )
        endpoint_b = endpoint_b_numerator // residual
        endpoint_c = endpoint_c_numerator // residual
        one_leg_checks.append(
            Fraction(1, first)
            + Fraction(1, endpoint_b)
            + Fraction(1, endpoint_c)
            == Fraction(4, prime)
        )
        hit = (quotient, squarefree)
        one_leg_hits[prime] = hit
        break
    if hit is None:
        one_leg_survivors.append(prime)

report(
    "one-leg factor-residue criterion through 100000 and k<=255",
    all(one_leg_checks)
    and len(one_leg_hits) == 2_369
    and tuple(one_leg_survivors)
    == (241, 1249, 6481, 21169, 43969),
)

middle_one_leg_hits = {}
middle_one_leg_checks = []

for prime in one_leg_survivors:
    hit = None
    for quotient in range(1, 25):
        for factor in divisors(quotient * prime + 1):
            if (factor + 1) % (4 * quotient) != 0:
                continue
            squarefree = (factor + 1) // (4 * quotient)
            if squarefree_coordinates(squarefree)[1] != 1:
                continue
            branch = (quotient * prime + 1) // factor
            residual = (prime + 4 * squarefree) // factor
            first = squarefree * branch
            middle_one_leg_checks.extend(
                (
                    factor == 4 * quotient * squarefree - 1,
                    factor * branch == quotient * prime + 1,
                    factor * residual == prime + 4 * squarefree,
                    branch == quotient * residual - 1,
                    residual == 4 * first - prime,
                    0 < residual <= prime,
                    prime < 4 * first <= 2 * prime,
                    (
                        4 * quotient * squarefree - 1
                    )
                    * (
                        4 * quotient * squarefree * branch - 1
                    )
                    == 4
                    * quotient
                    * quotient
                    * squarefree
                    * prime
                    + 1,
                    Fraction(1, first)
                    + Fraction(1, prime * quotient * squarefree)
                    + Fraction(
                        1,
                        prime * quotient * squarefree * branch,
                    )
                    == Fraction(4, prime),
                )
            )
            hit = (
                quotient,
                factor,
                squarefree,
                branch,
                residual,
                first,
            )
            middle_one_leg_hits[prime] = hit
            break
        if hit is not None:
            break

report(
    "middle one-leg closure of the five exterior survivors",
    all(middle_one_leg_checks)
    and middle_one_leg_hits
    == {
        241: (1, 11, 3, 22, 23, 66),
        1249: (2, 7, 1, 357, 179, 357),
        6481: (1, 7, 2, 926, 927, 1852),
        21169: (5, 39, 2, 2714, 543, 5428),
        43969: (24, 1631, 17, 647, 27, 10999),
    },
)

print("exterior coordinates checked=", exterior_count)
print("middle divisor coordinates checked=", middle_count)
print("shared-column overlap coordinates checked=", overlap_count)
print("first shared-column overlap data=", tuple(overlap_examples))
print("coupled shells checked=", len(coupled_shell_keys))
print("first coupled two-sheet rank data=", tuple(coupled_shell_examples))
print(
    "first unordered packet fixed-line data=",
    tuple(coupled_fixed_line_examples),
)
print(
    "first packet blade-height data=",
    tuple(coupled_blade_height_examples),
)
print(
    "first packet control-volume reconstruction data=",
    tuple(coupled_control_volume_examples),
)
print(
    "first packet sum-gap polynomial data=",
    tuple(coupled_sum_gap_polynomial_examples),
)
print(
    "first packet square-discriminant data=",
    tuple(coupled_discriminant_examples),
)
print(
    "first packet affine-cover data=",
    tuple(coupled_cover_examples),
)
print("Fable endpoint-height data=", tuple(fable_cover_data))
print("exterior converse data=", exterior_example)
print("middle converse data=", middle_example)
print(
    "k=3 hard, solved, surviving counts=",
    (k_three_hard_count, k_three_hit_count, k_three_survivor_count),
)
print(
    "one-leg hard, solved, surviving counts=",
    (k_three_hard_count, len(one_leg_hits), len(one_leg_survivors)),
)
print("one-leg survivors through k=255=", tuple(one_leg_survivors))
print("middle one-leg closure data=", middle_one_leg_hits)

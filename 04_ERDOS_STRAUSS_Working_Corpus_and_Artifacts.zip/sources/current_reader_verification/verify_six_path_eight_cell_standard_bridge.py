from sympy import I, Matrix, eye, kronecker_product, sqrt


def require_matrix_equal(left, right, message):
    difference = left - right
    if any(entry.expand() != 0 for entry in difference):
        raise AssertionError(f"{message}\n{difference}")


def basis_vector(dimension, index):
    vector = Matrix.zeros(dimension, 1)
    vector[index, 0] = 1
    return vector


def gamma_index(sheet, phase):
    return 3 * sheet + phase


# The regular D3 action on the six arithmetic path tensors.
R_gamma = Matrix.zeros(6, 6)
F_gamma = Matrix.zeros(6, 6)
for sheet in range(2):
    for phase in range(3):
        source = gamma_index(sheet, phase)
        R_gamma[gamma_index(sheet, (phase + 1) % 3), source] = 1
        F_gamma[gamma_index((sheet + 1) % 2, (-phase) % 3), source] = 1

# The eight-cell matrices, with coordinate zero in each four-cell sheet
# reserved for the fixed point and coordinates one through three for the
# three-state orbit.
C_3 = Matrix([[0, 1, 0], [0, 0, 1], [1, 0, 0]])
S_3 = Matrix([[0, 1, 0], [1, 0, 0], [0, 0, 1]])
P_L = Matrix.diag(Matrix([[1]]), C_3)
P_R = Matrix.diag(Matrix([[1]]), S_3)
X_2 = Matrix([[0, 1], [1, 0]])
Z_2 = Matrix([[1, 0], [0, -1]])
U_delta = kronecker_product(eye(2), P_L)
J_8 = kronecker_product(X_2, P_R)

# Xi sends gamma_(epsilon,m) to e_epsilon tensor g_(2-m).  The affine
# shift is forced by the chosen C_3 and S_3 matrices.
Xi = Matrix.zeros(8, 6)
for sheet in range(2):
    for phase in range(3):
        orbit_coordinate = (2 - phase) % 3
        Xi[4 * sheet + 1 + orbit_coordinate, gamma_index(sheet, phase)] = 1

orbit_projection = Matrix.diag(0, 1, 1, 1, 0, 1, 1, 1)
require_matrix_equal(Xi.H * Xi, eye(6), "the arithmetic orbit map is not isometric")
require_matrix_equal(Xi * Xi.H, orbit_projection, "the orbit range is incorrect")
require_matrix_equal(Xi * R_gamma, U_delta * Xi, "rotation intertwining fails")
require_matrix_equal(Xi * F_gamma, J_8 * Xi, "reflection intertwining fails")

# Reconstruct the standard-pair unitary Q from the preceding checker.
omega = (-1 + I * sqrt(3)) / 2
omega_squared = (-1 - I * sqrt(3)) / 2
e_plus = Matrix([1, 0])
e_minus = Matrix([0, 1])
f = Matrix([1, 0, 0, 0])
v_zero = Matrix([0, 1, 1, 1]) / sqrt(3)
v_plus = Matrix([0, 1, omega, omega_squared]) / sqrt(3)
v_minus = Matrix([0, 1, omega_squared, omega]) / sqrt(3)


def tensor(left, right):
    return kronecker_product(left, right)


Q = Matrix.hstack(
    (tensor(e_plus, f) + tensor(e_minus, f)) / sqrt(2),
    tensor(e_plus, v_plus),
    omega_squared * tensor(e_minus, v_plus),
    I * (tensor(e_plus, f) - tensor(e_minus, f)) / sqrt(2),
    (tensor(e_plus, v_zero) + tensor(e_minus, v_zero)) / sqrt(2),
    tensor(e_minus, v_minus),
    omega * tensor(e_plus, v_minus),
    I * (tensor(e_plus, v_zero) - tensor(e_minus, v_zero)) / sqrt(2),
)
require_matrix_equal(Q.H * Q, eye(8), "the standard-pair map is not unitary")

# Fourier modes in the arithmetic path basis, ordered as
# (sheet 0, zero), (sheet 1, zero), (sheet 0, plus),
# (sheet 1, plus), (sheet 0, minus), (sheet 1, minus).
Fourier = Matrix.zeros(6, 6)
for sheet in range(2):
    for phase in range(3):
        row = gamma_index(sheet, phase)
        Fourier[row, sheet] = 1 / sqrt(3)
        Fourier[row, 2 + sheet] = (
            omega_squared * [1, omega_squared, omega][phase] / sqrt(3)
        )
        Fourier[row, 4 + sheet] = (
            omega * [1, omega, omega_squared][phase] / sqrt(3)
        )
require_matrix_equal(Fourier.H * Fourier, eye(6), "the path Fourier basis is not unitary")

actual_placement = Q.H * Xi * Fourier
expected_placement = Matrix.zeros(8, 6)
expected_placement[:, 0] = (
    basis_vector(8, 4) - I * basis_vector(8, 7)
) / sqrt(2)
expected_placement[:, 1] = (
    basis_vector(8, 4) + I * basis_vector(8, 7)
) / sqrt(2)
expected_placement[:, 2] = basis_vector(8, 1)
expected_placement[:, 3] = omega * basis_vector(8, 2)
expected_placement[:, 4] = omega_squared * basis_vector(8, 6)
expected_placement[:, 5] = basis_vector(8, 5)
require_matrix_equal(
    actual_placement,
    expected_placement,
    "the six arithmetic Fourier modes occupy the wrong HS matrix units",
)

# The unique invariant path vector lands on E_11 of the second HS block.
gamma_invariant = Matrix.ones(6, 1) / sqrt(6)
second_block_E11 = basis_vector(8, 4)
require_matrix_equal(
    Q.H * Xi * gamma_invariant,
    second_block_E11,
    "the invariant arithmetic support line does not land on the second E_11",
)

K_HS = Matrix.diag(0, 1, -1, 0, 0, 1, -1, 0)
J_4 = Matrix([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
J_HS = Matrix.diag(J_4, J_4)
require_matrix_equal(K_HS * second_block_E11, Matrix.zeros(8, 1), "support is not fixed")
require_matrix_equal(
    J_HS * second_block_E11.conjugate(),
    second_block_E11,
    "support is not fixed by modular conjugation",
)

print("PASS: arithmetic six-path carrier inside the eight-cell standard pair")
print("the affine label m -> 2-m intertwines both exact D3 generators")
print("the six arithmetic paths are exactly the three-orbit sector of H8")
print("all six Fourier modes have explicit HS matrix-unit coordinates")
print("the unique D3-invariant arithmetic support vector maps to block-two E11")
print("that support line is fixed by the modular generator and conjugation")

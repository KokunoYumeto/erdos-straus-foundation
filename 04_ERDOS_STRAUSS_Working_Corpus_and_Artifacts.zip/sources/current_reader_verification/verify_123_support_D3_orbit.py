from fractions import Fraction


def unit(a, i, b, j):
    return (a, i, b, j)


def multiply(x, y):
    a, i, b, j = x
    c, k, d, ell = y
    if b != c or j != k:
        return None
    return unit(a, i, d, ell)


weights = {
    1: (Fraction(1),),
    2: (Fraction(2), Fraction(3)),
    3: (Fraction(5), Fraction(7), Fraction(11)),
}


def modular_weight(x):
    a, i, b, j = x
    return weights[a][i] / weights[b][j]


# Rank-one corner generators and their exact products.
u = {eps: unit(1, 0, 2, eps) for eps in range(2)}
v = {eps: unit(2, eps, 1, 0) for eps in range(2)}
p = {m: unit(1, 0, 3, m) for m in range(3)}
q = {m: unit(3, m, 1, 0) for m in range(3)}

for eps in range(2):
    for eps2 in range(2):
        assert multiply(v[eps], u[eps2]) == unit(2, eps, 2, eps2)
for m in range(3):
    for m2 in range(3):
        assert multiply(q[m], p[m2]) == unit(3, m, 3, m2)
for eps in range(2):
    for m in range(3):
        assert multiply(v[eps], p[m]) == unit(2, eps, 3, m)
        assert multiply(q[m], u[eps]) == unit(3, m, 2, eps)

blade_21 = multiply(v[1], u[0])
blade_12 = multiply(v[0], u[1])
assert blade_21 == unit(2, 1, 2, 0)
assert blade_12 == unit(2, 0, 2, 1)
assert modular_weight(blade_21) == Fraction(3, 2)
assert modular_weight(blade_12) == Fraction(2, 3)


# The six unbalanced path tensors remain distinct before multiplication.
paths = tuple((eps, m) for eps in range(2) for m in range(3))
for eps, m in paths:
    middle = multiply(v[eps], p[m])
    assert multiply(multiply(u[eps], middle), q[m]) == unit(1, 0, 1, 0)
assert len(paths) == 6
path_multiplication_rank = 1
path_multiplication_nullity = len(paths) - path_multiplication_rank
assert path_multiplication_nullity == 5


def r(label):
    eps, m = label
    return eps, (m + 1) % 3


def f(label):
    eps, m = label
    return (eps + 1) % 2, (-m) % 3


for label in paths:
    assert r(r(r(label))) == label
    assert f(f(label)) == label
    assert f(r(f(label))) == r(r(label))

orbit = set()
for m in range(3):
    for eps in range(2):
        x = (0, 0)
        if eps:
            x = f(x)
        for _ in range(m):
            x = r(x)
        orbit.add(x)
assert orbit == set(paths)


# Basis permutations representing W_r and W_f.
r_perm = (0, 1, 2, 4, 5, 3)
f_perm = (0, 2, 1, 3, 5, 4)


def compose(p1, p2):
    """Permutation for applying p2 and then p1."""
    return tuple(p1[p2[i]] for i in range(len(p1)))


identity = tuple(range(6))
assert compose(r_perm, compose(r_perm, r_perm)) == identity
assert compose(f_perm, f_perm) == identity
assert compose(f_perm, compose(r_perm, f_perm)) == compose(r_perm, r_perm)


def conjugate_diagonal(diagonal, perm):
    out = [None] * len(diagonal)
    for old_index, new_index in enumerate(perm):
        out[new_index] = diagonal[old_index]
    return tuple(out)


rho = (1, 2, 3, 5, 7, 11)


def density(m, eps):
    out = rho
    if eps:
        out = conjugate_diagonal(out, f_perm)
    for _ in range(m):
        out = conjugate_diagonal(out, r_perm)
    return out


ordered_labels = ((0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1))
densities = tuple(density(m, eps) for m, eps in ordered_labels)
expected_densities = (
    (1, 2, 3, 5, 7, 11),
    (1, 3, 2, 5, 11, 7),
    (1, 2, 3, 11, 5, 7),
    (1, 3, 2, 7, 5, 11),
    (1, 2, 3, 7, 11, 5),
    (1, 3, 2, 11, 7, 5),
)
assert densities == expected_densities
assert len(set(densities)) == 6

for m, eps in ordered_labels:
    assert conjugate_diagonal(density(m, eps), r_perm) == density((m + 1) % 3, eps)
    assert conjugate_diagonal(density(m, eps), f_perm) == density((-m) % 3, (eps + 1) % 2)


def matrix_rank(columns):
    matrix = [list(map(Fraction, row)) for row in zip(*columns)]
    rows = len(matrix)
    cols = len(matrix[0])
    pivot_row = 0
    for col in range(cols):
        pivot = next((i for i in range(pivot_row, rows) if matrix[i][col]), None)
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        scale = matrix[pivot_row][col]
        matrix[pivot_row] = [x / scale for x in matrix[pivot_row]]
        for i in range(rows):
            if i != pivot_row and matrix[i][col]:
                factor = matrix[i][col]
                matrix[i] = [x - factor * y for x, y in zip(matrix[i], matrix[pivot_row])]
        pivot_row += 1
        if pivot_row == rows:
            break
    return pivot_row


assert matrix_rank(densities) == 4
relation_one = (-3, -7, -5, 7, 8, 0)
relation_two = (7, -5, -7, -3, 0, 8)
for relation in (relation_one, relation_two):
    assert all(
        sum(relation[j] * densities[j][i] for j in range(6)) == 0
        for i in range(6)
    )


# Equality of inner automorphisms of M_6 would make the density quotient scalar.
# The first entry fixes that scalar to one, so the six distinct densities give six
# distinct modular operators.
assert all(d[0] == 1 for d in densities)

print("PASS all M2 and M3 matrix units factor through the C1 corner")
print("PASS ordered blade factors: E21=v1*u0 and E12=v0*u1")
print("PASS blade modular eigenvalues: 3/2 and 2/3")
print("PASS six path tensors collapse to E11 with rank 1 and nullity 5")
print("PASS D3 relations and regular action on C2 x C3 path labels")
print("PASS six density orbit elements are pairwise distinct")
print("PASS density-orbit span rank: 4")
print("PASS two exact density relations")
print("PASS rotation and reflection intertwine the six density blocks")

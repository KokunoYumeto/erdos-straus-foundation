#!/usr/bin/env python3
"""Exact coordinate checks for the regular-tetrahedron vector figure."""

import sympy as sp


sign_vectors = [
    sp.Matrix([1, 1, 1]),
    sp.Matrix([1, -1, -1]),
    sp.Matrix([-1, 1, -1]),
    sp.Matrix([-1, -1, 1]),
]
gram = sp.Matrix(
    4,
    4,
    lambda i, j: (sign_vectors[i].dot(sign_vectors[j])) / sp.Integer(3),
)
target = sp.Matrix(
    4,
    4,
    lambda i, j: sp.Integer(1) if i == j else -sp.Rational(1, 3),
)
assert gram == target

total = sum(sign_vectors, sp.zeros(3, 1))
assert total == sp.zeros(3, 1)

face_centroid = sum(sign_vectors[1:], sp.zeros(3, 1)) / 3
assert face_centroid == -sign_vectors[0] / 3

altitude = sign_vectors[0] - face_centroid
assert sp.simplify(altitude.dot(altitude) / 3) == sp.Rational(16, 9)

for i, j in [(1, 2), (2, 3), (3, 1)]:
    edge = sign_vectors[i] - sign_vectors[j]
    assert sp.simplify(edge.dot(edge) / 3) == sp.Rational(8, 3)

reflection_midpoint = (sign_vectors[2] + sign_vectors[3]) / 2
reflection_axis = reflection_midpoint - sign_vectors[1]
swapped_difference = sign_vectors[2] - sign_vectors[3]
assert reflection_axis.dot(swapped_difference) == 0

print("PASS displayed four vertices have Gram entries 1 and -1/3")
print("PASS displayed tetrahedron is centered at the origin")
print("PASS opposite-face centroid is -r_infinity/3")
print("PASS displayed altitude has squared length 16/9")
print("PASS every opposite-face edge has squared length 8/3")
print("PASS displayed reflection axis is orthogonal to the exchanged edge")


from collections import Counter
from itertools import product

import sympy as sp


p = 37
residual = 11
a = 12
factorization = ((2, 2), (3, 1))

x = sp.symbols("x")
cyclotomic = sp.Poly(sp.cyclotomic_poly(10, x), x, domain=sp.QQ)


def reduce_cyclotomic(expression):
    polynomial = sp.Poly(sp.expand(expression), x, domain=sp.QQ)
    return polynomial.rem(cyclotomic).as_expr()


def root_power(exponent):
    return x ** (exponent % 10)


def local_factor(character_index, prime_logarithm, exponent):
    return reduce_cyclotomic(
        sum(
            root_power(-character_index * prime_logarithm * beta)
            for beta in range(-exponent, exponent + 1)
        )
    )


sqrt_five_class = reduce_cyclotomic(2 * (x + x**9) - 1)
assert reduce_cyclotomic(sqrt_five_class**2 - 5) == 0

primitive_root = 2
power_table = tuple(pow(primitive_root, exponent, residual) for exponent in range(10))
assert power_table == (1, 2, 4, 8, 5, 10, 9, 7, 3, 6)
prime_logs = {2: 1, 3: 8}

centered_measure = Counter()
for beta_two, beta_three in product(range(-2, 3), range(-1, 2)):
    residue = (
        pow(2, beta_two, residual) * pow(3, beta_three, residual)
    ) % residual
    centered_measure[residue] += 1

assert sum(centered_measure.values()) == 15
assert set(centered_measure) == set(range(1, 10))
assert centered_measure[10] == 0

target_middle = (-1) % residual
target_exterior = (-pow(p, -1, residual)) % residual
assert (target_middle, target_exterior) == (10, 8)
assert centered_measure[target_middle] == 0
assert centered_measure[target_exterior] == 1

expected_transform = {
    0: 15,
    1: 3 + sqrt_five_class,
    2: 0,
    3: 3 - sqrt_five_class,
    4: 0,
    5: 3,
    6: 0,
    7: 3 - sqrt_five_class,
    8: 0,
    9: 3 + sqrt_five_class,
}

expected_filter_squared = {
    0: 1,
    1: ((1 + sqrt_five_class) / 4) ** 2,
    2: ((sqrt_five_class - 1) / 4) ** 2,
    3: ((sqrt_five_class - 1) / 4) ** 2,
    4: ((1 + sqrt_five_class) / 4) ** 2,
    5: 1,
    6: ((1 + sqrt_five_class) / 4) ** 2,
    7: ((sqrt_five_class - 1) / 4) ** 2,
    8: ((sqrt_five_class - 1) / 4) ** 2,
    9: ((1 + sqrt_five_class) / 4) ** 2,
}

rows = []
for character_index in range(10):
    factor_two = local_factor(character_index, prime_logs[2], 2)
    factor_three = local_factor(character_index, prime_logs[3], 1)
    transform = reduce_cyclotomic(factor_two * factor_three)
    assert reduce_cyclotomic(
        transform - expected_transform[character_index]
    ) == 0

    target_average = (
        root_power(5 * character_index)
        + root_power(3 * character_index)
    ) / 2
    target_average_conjugate = (
        root_power(-5 * character_index)
        + root_power(-3 * character_index)
    ) / 2
    filter_squared = reduce_cyclotomic(
        target_average * target_average_conjugate
    )
    assert reduce_cyclotomic(
        filter_squared - expected_filter_squared[character_index]
    ) == 0
    rows.append(
        (
            character_index,
            factor_two,
            factor_three,
            transform,
            filter_squared,
        )
    )

sqrt_five = sp.sqrt(5)
unweighted_mass = sp.expand(
    2 * (3 + sqrt_five) + 2 * (3 - sqrt_five) + 3
)
filtered_mass = sp.expand(
    2 * (3 + sqrt_five) * (1 + sqrt_five) / 4
    + 2 * (3 - sqrt_five) * (sqrt_five - 1) / 4
    + 3
)
assert unweighted_mass == 15
assert filtered_mass == 3 + 4 * sqrt_five
assert sp.ask(sp.Q.lt(filtered_mass, 15)) is True
assert sp.expand(15 - filtered_mass) == 12 - 4 * sqrt_five
assert sp.ask(sp.Q.positive(12 - 4 * sqrt_five)) is True

print("PASS: exact (p,R,a)=(37,11,12) target-averaged character certificate")
print(f"primitive-root powers modulo 11: {power_table}")
print(f"centered multiplicity measure: {tuple(sorted(centered_measure.items()))}")
print(f"targets (middle, exterior): {(target_middle, target_exterior)}")
print("character table in Q[zeta_10]/(Phi_10):")
for (
    character_index,
    factor_two,
    factor_three,
    transform,
    filter_squared,
) in rows:
    print(
        f"  j={character_index}: "
        f"D_2={factor_two}, D_3={factor_three}, "
        f"hat_mu={transform}, |A_U|^2={filter_squared}"
    )
print(f"principal mass M: 15")
print(f"unweighted nonprincipal mass S: {unweighted_mass}")
print(f"target-averaged mass S_A: {filtered_mass}")
print(f"strict gap M-S_A: {sp.expand(15-filtered_mass)}")

"""Minimal local certificates for the bounded post-R23 escape census.

For R = 27,31,...,59, remove the forced prime factors supplied by the
consecutive affine packet.  The certificate degree is the least number
of remaining prime-factor occurrences whose residue multiset, together
with the forced factors, already occupies the shell.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import hashlib
from math import gcd

from scan_prime_cofactor_post23_escape import (
    multiplicative_reach,
    scan,
)


SKELETON_FACTORS = {
    27: {},
    31: {2: 1},
    35: {3: 1},
    39: {2: 1, 5: 1},
    43: {},
    47: {2: 1, 3: 1},
    51: {},
    55: {2: 1},
    59: {3: 1, 5: 1},
}

EXPECTED_DEGREE_ONE_TRIGGERS = {
    27: (20, 26),
    31: (15, 23, 27, 29, 30),
    35: (23, 26, 32, 34),
    39: (17, 19, 23, 29, 31, 34, 35, 37, 38),
    43: (32, 42),
    47: (15, 22, 23, 30, 31, 35, 39, 41, 43, 44, 45, 46),
    51: (38, 50),
    55: (24, 27, 41, 48, 53, 54),
    59: (18, 23, 39, 44, 47, 54, 55, 56, 58),
}

EXPECTED_RESIDUAL_DEGREES = {
    (27, 1): 261,
    (27, 2): 251,
    (27, 3): 42,
    (27, 4): 2,
    (31, 1): 280,
    (31, 2): 281,
    (31, 3): 13,
    (35, 1): 108,
    (35, 2): 108,
    (35, 3): 14,
    (35, 4): 4,
    (39, 1): 118,
    (39, 2): 26,
    (43, 1): 2,
    (43, 2): 5,
    (43, 3): 3,
    (47, 1): 5,
    (47, 2): 5,
    (51, 2): 1,
    (55, 3): 2,
    (59, 1): 2,
    (59, 2): 1,
}

EXPECTED_GLOBAL_DEGREES = {1: 776, 2: 678, 3: 74, 4: 6}
EXPECTED_CERTIFICATE_HASH = (
    "28f6c4432217a0df53d2f1c0b13433cdbff60d853f80407b00c3324b09f736fe"
)


def occupied(residual: int, factors: dict[int, int]) -> bool:
    exterior = multiplicative_reach(residual, factors, "exterior")
    middle = multiplicative_reach(residual, factors, "middle")
    quarter = -pow(4, -1, residual) % residual
    return quarter in exterior or residual - 1 in middle


def units(residual: int) -> tuple[int, ...]:
    return tuple(value for value in range(1, residual) if gcd(value, residual) == 1)


def add_occurrences(
    base: dict[int, int],
    occurrences: tuple[int, ...],
) -> dict[int, int]:
    factors = dict(base)
    for residue in occurrences:
        factors[residue] = factors.get(residue, 0) + 1
    return factors


def degree_one_triggers(residual: int) -> tuple[int, ...]:
    base = SKELETON_FACTORS[residual]
    assert not occupied(residual, base)
    return tuple(
        residue
        for residue in units(residual)
        if occupied(residual, add_occurrences(base, (residue,)))
    )


def cofactor_occurrences(row) -> tuple[int, ...]:
    factors = dict(row.factors)
    for prime, exponent in SKELETON_FACTORS[row.residual].items():
        assert factors.get(prime, 0) >= exponent
        factors[prime] -= exponent
        if factors[prime] == 0:
            del factors[prime]
    return tuple(
        sorted(
            prime % row.residual
            for prime, exponent in factors.items()
            for _ in range(exponent)
        )
    )


def minimal_certificate(row) -> tuple[int, tuple[int, ...]]:
    base = SKELETON_FACTORS[row.residual]
    occurrences = cofactor_occurrences(row)
    for degree in range(len(occurrences) + 1):
        hits = set()
        for indices in combinations(range(len(occurrences)), degree):
            candidate = tuple(sorted(occurrences[index] for index in indices))
            if candidate in hits:
                continue
            if occupied(row.residual, add_occurrences(base, candidate)):
                hits.add(candidate)
        if hits:
            return degree, min(hits)
    raise AssertionError("occupied row has no certificate")


def main() -> None:
    triggers = {
        residual: degree_one_triggers(residual)
        for residual in SKELETON_FACTORS
    }
    assert triggers == EXPECTED_DEGREE_ONE_TRIGGERS

    _, escapes, unresolved = scan(10_000_000, 203)
    assert not unresolved
    degree_counts = Counter()
    serialized = []
    for row in escapes:
        degree, certificate = minimal_certificate(row)
        degree_counts[(row.residual, degree)] += 1
        serialized.append(
            f"{row.source.ell}|{row.source.p}|{row.residual}|"
            f"{degree}|{certificate}"
        )

    global_counts = Counter()
    for (residual, degree), count in degree_counts.items():
        global_counts[degree] += count

    digest = hashlib.sha256("\n".join(serialized).encode("ascii")).hexdigest()
    assert dict(sorted(degree_counts.items())) == EXPECTED_RESIDUAL_DEGREES
    assert dict(sorted(global_counts.items())) == EXPECTED_GLOBAL_DEGREES
    assert digest == EXPECTED_CERTIFICATE_HASH

    print("PASS: minimal post-R23 escape-certificate complexity")
    print("degree-one trigger classes:")
    for residual, classes in triggers.items():
        print(f"  R={residual}: {classes}")
    print(
        "residual / certificate-degree counts: "
        + repr(dict(sorted(degree_counts.items())))
    )
    print("global certificate-degree counts: " + repr(dict(sorted(global_counts.items()))))
    print("certificate-row SHA-256: " + digest)


if __name__ == "__main__":
    main()

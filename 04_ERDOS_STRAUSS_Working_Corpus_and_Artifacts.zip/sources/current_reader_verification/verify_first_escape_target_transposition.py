"""Exact target-incidence certificate for the first escape through R=39."""

from itertools import product
from math import prod


P = 118801
FACTORS = {
    3: (7, 4243),
    7: (2, 14851),
    11: (3, 9901),
    15: (2, 2, 2, 47, 79),
    19: (5, 13, 457),
    23: (2, 3, 4951),
    27: (61, 487),
    31: (2, 2, 7, 1061),
    35: (3, 3, 3301),
    39: (2, 5, 2971),
    43: (11, 37, 73),
    47: (2, 2, 2, 2, 3, 619),
    51: (43, 691),
    55: (2, 83, 179),
    59: (3, 5, 7, 283),
}

EXPECTED = {
    3: ((1, 1), 1, 1, False, False),
    7: ((2, 4), 3, 3, False, False),
    11: ((1, 3), 3, 3, False, False),
    15: ((2, 2, 2, 2, 4), 4, 4, False, False),
    19: ((1, 5, 13), 9, 9, False, False),
    23: ((2, 3, 6), 11, 11, False, False),
    27: ((1, 7), 3, 3, False, False),
    31: ((2, 2, 7, 7), 15, 15, False, False),
    35: ((3, 3, 11), 12, 12, False, False),
    39: ((2, 5, 7), 20, 20, False, False),
    43: ((11, 30, 37), 23, 23, False, False),
    47: ((2, 2, 2, 2, 3, 8), 23, 23, False, False),
    51: ((28, 43), 7, 7, False, False),
    55: ((2, 14, 28), 9, 9, False, False),
    59: ((3, 5, 7, 47), 54, 54, True, True),
}

EXPECTED_INCIDENCE = {
    3: ((0, 0), (0, 0)),
    7: ((0, 0), (0, 0)),
    11: ((0, 0), (0, 0)),
    15: ((0, 0), (0, 0)),
    19: ((0, 0), (1, 0)),
    23: ((0, 0), (0, 0)),
    27: ((0, 0), (0, 0)),
    31: ((0, 0), (0, 0)),
    35: ((0, 0), (0, 0)),
    39: ((0, 1), (1, 0)),
    43: ((0, 0), (0, 0)),
    47: ((0, 0), (0, 0)),
    51: ((0, 0), (0, 0)),
    55: ((0, 0), (0, 0)),
    59: ((1, 1), (1, 1)),
}


def reachability(modulus, residues, alphabet):
    values = {}
    for exponents in product(alphabet, repeat=len(residues)):
        value = 1
        for residue, exponent in zip(residues, exponents):
            value = value * pow(residue, exponent, modulus) % modulus
        values.setdefault(value, []).append(exponents)
    return values


def incidence(modulus, exterior, middle):
    t = -pow(4, -1, modulus) % modulus
    s = -1 % modulus
    return ((int(t in exterior), int(s in exterior)),
            (int(t in middle), int(s in middle)))


def matmul(left, right):
    return tuple(
        tuple(sum(left[i][k] * right[k][j] for k in range(2))
              for j in range(2))
        for i in range(2)
    )


for index, (R, factors) in enumerate(FACTORS.items(), start=1):
    a = 29700 + index
    assert a == (P + R) // 4
    assert prod(factors) == a
    residues = tuple(sorted(q % R for q in factors))
    exterior = reachability(R, residues, (0, 1, 2))
    middle = reachability(R, residues, (-1, 0, 1))
    target_t = -pow(4, -1, R) % R
    target_s = -1 % R
    expected = EXPECTED[R]
    assert residues == expected[0]
    assert len(exterior) == expected[1]
    assert len(middle) == expected[2]
    assert (target_t in exterior) is expected[3]
    assert (target_s in middle) is expected[4]
    assert incidence(R, exterior, middle) == EXPECTED_INCIDENCE[R]

R = 19
residues = EXPECTED[R][0]
exterior = reachability(R, residues, (0, 1, 2))
middle = reachability(R, residues, (-1, 0, 1))
assert sorted(exterior) == [1, 2, 5, 6, 7, 8, 9, 13, 17]
assert sorted(middle) == [1, 3, 4, 5, 8, 12, 13, 14, 15]
assert middle[14] == [(-1, -1, 1), (0, -1, 1), (1, -1, 1)]
assert incidence(R, exterior, middle) == ((0, 0), (1, 0))
assert 13 * pow(5, -1, 19) % 19 == 14
assert 4 * 13 + 5 == 3 * 19
assert 13 + 5 + 1 == 19

R = 39
residues = EXPECTED[R][0]
exterior = reachability(R, residues, (0, 1, 2))
middle = reachability(R, residues, (-1, 0, 1))
assert sorted(exterior) == [1, 2, 4, 5, 7, 10, 11, 14, 16, 19,
                            20, 22, 23, 25, 28, 31, 32, 35, 37, 38]
assert sorted(middle) == [1, 2, 4, 5, 7, 8, 10, 14, 16, 17,
                          19, 20, 22, 23, 28, 29, 31, 34, 35, 37]
assert exterior[38] == [(1, 2, 1)]
assert middle[29] == [(0, -1, -1)]
assert incidence(R, exterior, middle) == ((0, 1), (1, 0))
assert 350 % 39 == 38
assert 148550 % 39 == 38
assert 14855 % 39 == 35
assert (1 + 14855) % 39 == 36
assert (4 * 29 + 1) % 39 == 0

# With K=sqrt(2) H, the exact integral identity K S K^T=2J
# is equivalent to H S H^T=J.
K = ((1, 1), (1, -1))
S = ((0, 1), (1, 0))
KT = tuple(zip(*K))
assert matmul(matmul(K, S), KT) == ((2, 0), (0, -2))
E21 = ((0, 0), (1, 0))
assert matmul(matmul(K, E21), KT) == ((1, 1), (-1, -1))

R = 59
residues = EXPECTED[R][0]
exterior = reachability(R, residues, (0, 1, 2))
middle = reachability(R, residues, (-1, 0, 1))
assert incidence(R, exterior, middle) == ((1, 1), (1, 1))

# Coordinatewise reduction of the exact Fable collision to F_19.
def fable_mod_19(x, y, z):
    unit = (1 + x * y) % 19
    return (
        (unit**3 * z + y**2 * unit * (4 + 3 * x * y)) % 19,
        (y + 3 * x * unit**2 * z + 3 * x * y**2 * (4 + 3 * x * y)) % 19,
        (2 * x - 3 * x**2 * y - x**3 * z) % 19,
    )


fable_inputs_mod_19 = ((0, 0, 14), (1, 8, 16), (18, 11, 16))
for point in fable_inputs_mod_19:
    assert fable_mod_19(*point) == (14, 0, 0)
assert 14 == -pow(4, -1, 19) % 19 == 13 * pow(5, -1, 19) % 19
assert 21225 % 59 == 44 == -pow(4, -1, 59) % 59
assert 1415 % 59 == 58 == -1 % 59
assert (1 + 1415) % 59 == 0

# The occupied R=39 shell at p=3361 is the all-incidence contrast.
R = 39
residues = (2, 5, 5, 17)
exterior = reachability(R, residues, (0, 1, 2))
middle = reachability(R, residues, (-1, 0, 1))
assert incidence(R, exterior, middle) == ((1, 1), (1, 1))

print("PASS: first R=39 escape has exact transposed target incidence")
print("p=118801 incidence path: 0, E21 at R=19, S at R=39, I+S at R=59")
print("R=19: 13/5=14=-1/4, 4*13+5=3*19, 13+5+1=19")
print("Fable collision mod 19: three inputs map to (14,0,0)")
print("p=118801, R=39: Xi=((0,1),(1,0))=S")
print("R=39 exterior target 38 witness exponents: (1,2,1)")
print("R=39 middle target 29 witness exponents: (0,-1,-1)")
print("R=39 correct-target diagonal: (0,0)")
print("K S K^T=2J, equivalently H S H^T=J")
print("p=118801, R=59: Xi=((1,1),(1,1))")
print("p=3361, R=39: Xi=((1,1),(1,1))")

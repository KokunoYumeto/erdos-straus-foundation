from pathlib import Path

import sympy as sp


def zero(expr):
    return sp.cancel(sp.expand(expr)) == 0


def assert_zero(expr, label):
    if not zero(expr):
        raise AssertionError(f"{label}: {sp.factor(expr)}")


def assert_matrix_zero(matrix, label):
    for index, entry in enumerate(matrix):
        assert_zero(entry, f"{label} entry {index}")


delta = sp.symbols("delta", real=True)
sqrt3 = sp.sqrt(3)

R_perp = sp.Matrix(
    [
        [-sp.Rational(1, 2), sqrt3 / 2],
        [-sqrt3 / 2, -sp.Rational(1, 2)],
    ]
)
R_L = sp.diag(1, 1, 1, 1)
R_L[1:3, 1:3] = R_perp
J_L = sp.diag(1, -1, 1, 1)
eta = sp.diag(-1, 1, 1, 1)

assert_matrix_zero(R_perp**3 - sp.eye(2), "transverse order three")
assert_matrix_zero(J_L * R_L * J_L - R_L**2, "D3 reflection relation")


def U(parameter, m):
    transverse = R_perp**m * sp.Matrix(
        [parameter / 2, (1 - parameter**2) / 4]
    )
    return sp.Matrix(
        [
            5 * (1 + parameter**2) / 16,
            transverse[0],
            transverse[1],
            3 * (1 + parameter**2) / 16,
        ]
    )


points = [U(delta, m) for m in range(3)]
for m, point in enumerate(points):
    assert_zero((point.T * eta * point)[0], f"arc {m} Lorentz nullity")
    assert_matrix_zero(R_L * point - U(delta, m + 1), f"arc {m} rotation")
    assert_matrix_zero(
        J_L * point - U(-delta, -m), f"arc {m} reflection"
    )

# Rotated parabolic coordinates and the three explicit global equations.
z = sp.Matrix(sp.symbols("X Y", real=True))
X, Y = z
for m in range(3):
    xi = (R_perp**m * sp.Matrix([1, 0])).dot(z)
    eta_m = (R_perp**m * sp.Matrix([0, 1])).dot(z)
    transverse = sp.Matrix([points[m][1], points[m][2]])
    assert_zero(xi.subs({X: transverse[0], Y: transverse[1]}) - delta / 2,
                f"arc {m} xi parameter")
    assert_zero(
        eta_m.subs({X: transverse[0], Y: transverse[1]})
        - (1 - delta**2) / 4,
        f"arc {m} eta parameter",
    )
    assert_zero(
        xi.subs({X: transverse[0], Y: transverse[1]}) ** 2
        + eta_m.subs({X: transverse[0], Y: transverse[1]})
        - sp.Rational(1, 4),
        f"arc {m} parabolic equation",
    )

explicit_equations = [
    X**2 + Y - sp.Rational(1, 4),
    (X + sqrt3 * Y) ** 2 + 2 * sqrt3 * X - 2 * Y - 1,
    (X - sqrt3 * Y) ** 2 - 2 * sqrt3 * X - 2 * Y - 1,
]
for m, equation in enumerate(explicit_equations):
    transverse = {X: points[m][1], Y: points[m][2]}
    assert_zero(equation.subs(transverse), f"explicit arc {m} equation")

# Cyclic triangle, barycentre, transverse radius, and Gram matrix.
barycentre = sum(points, sp.zeros(4, 1)) / 3
expected_barycentre = sp.Matrix(
    [5 * (1 + delta**2) / 16, 0, 0, 3 * (1 + delta**2) / 16]
)
assert_matrix_zero(barycentre - expected_barycentre, "cyclic barycentre")

radius_sq = (1 + delta**2) ** 2 / 16
assert_zero((barycentre.T * eta * barycentre)[0] + radius_sq,
            "barycentre square")
for i in range(3):
    for j in range(3):
        inner = (points[i].T * eta * points[j])[0]
        expected = 0 if i == j else -sp.Rational(3, 2) * radius_sq
        assert_zero(inner - expected, f"cyclic Gram ({i},{j})")

# Exact pairwise intersections.
c = sqrt3 / 3
w01 = U(c, 0)
w02 = U(-c, 0)
w12 = U(c, 1)
assert_matrix_zero(w01 - U(-c, 1), "intersection A0 A1")
assert_matrix_zero(w02 - U(c, 2), "intersection A0 A2")
assert_matrix_zero(w12 - U(-c, 2), "intersection A1 A2")

expected_intersections = [
    sp.Matrix([sp.Rational(5, 12), sqrt3 / 6, sp.Rational(1, 6), sp.Rational(1, 4)]),
    sp.Matrix([sp.Rational(5, 12), -sqrt3 / 6, sp.Rational(1, 6), sp.Rational(1, 4)]),
    sp.Matrix([sp.Rational(5, 12), 0, -sp.Rational(1, 3), sp.Rational(1, 4)]),
]
for index, (actual, expected) in enumerate(zip([w01, w02, w12], expected_intersections)):
    assert_matrix_zero(actual - expected, f"intersection coordinates {index}")
    assert_zero((actual.T * eta * actual)[0], f"intersection nullity {index}")

for i in range(3):
    for j in range(i + 1, 3):
        assert_zero(
            (expected_intersections[i].T * eta * expected_intersections[j])[0]
            + sp.Rational(1, 6),
            f"intersection Gram ({i},{j})",
        )

intersection_barycentre = sum(expected_intersections, sp.zeros(4, 1)) / 3
q6 = sp.Matrix([sp.Rational(5, 8), 0, 0, sp.Rational(3, 8)])
assert_matrix_zero(
    intersection_barycentre - sp.Rational(2, 3) * q6,
    "intersection barycentre",
)

# The two systems used in the proof have the claimed common roots.
poly_11 = sqrt3 * delta**2 + 2 * delta - sqrt3
poly_12 = 3 * delta**2 + 2 * sqrt3 * delta - 3
for root in [1 / sqrt3, -sqrt3]:
    assert_zero(poly_11.subs(delta, root), "k=1 first intersection polynomial")
    assert_zero(poly_12.subs(delta, root), "k=1 second intersection polynomial")
if (1 / sqrt3).is_rational is not False:
    raise AssertionError("intersection parameter must be irrational")

# Arc endpoints reproduce the exact six Lorentz-null hexagon vertices.
hexagon = [
    sp.Matrix([sp.Rational(5, 8), sp.Rational(1, 2), 0, sp.Rational(3, 8)]),
    sp.Matrix([sp.Rational(5, 8), -sp.Rational(1, 2), 0, sp.Rational(3, 8)]),
    sp.Matrix([sp.Rational(5, 8), -sp.Rational(1, 4), -sqrt3 / 4, sp.Rational(3, 8)]),
    sp.Matrix([sp.Rational(5, 8), sp.Rational(1, 4), sqrt3 / 4, sp.Rational(3, 8)]),
    sp.Matrix([sp.Rational(5, 8), -sp.Rational(1, 4), sqrt3 / 4, sp.Rational(3, 8)]),
    sp.Matrix([sp.Rational(5, 8), sp.Rational(1, 4), -sqrt3 / 4, sp.Rational(3, 8)]),
]
for m in range(3):
    assert_matrix_zero(U(1, m) - hexagon[2 * m], f"positive endpoint {m}")
    assert_matrix_zero(U(-1, m) - hexagon[2 * m + 1], f"negative endpoint {m}")

# Exact arithmetic orbit for the recorded p=12289 divisor and its complement.
delta0 = -sp.Rational(307, 308)
delta1 = -delta0
arithmetic_orbit = [U(value, m) for value in [delta0, delta1] for m in range(3)]
keys = {tuple(sp.simplify(entry) for entry in point) for point in arithmetic_orbit}
if len(keys) != 6:
    raise AssertionError("12289 complementary D3 orbit must have six points")

lines = [
    "PASS: ordered reduced-divisor D3 three-arc closure",
    "three rotated parabolic equations verified",
    "cyclic triangle barycentre = ((1+delta^2)/2) q6",
    "cyclic Gram off-diagonal = -3(1+delta^2)^2/32",
    "pairwise crossings: delta = +/-1/sqrt(3), alpha = 2/3",
    "intersection triangle Gram off-diagonal = -1/6",
    "intersection triangle barycentre = (2/3) q6",
    "six arc endpoints = six Lorentz-null hexagon vertices",
    "arithmetic divisor parameters are rational and avoid all crossings",
    "12289 complementary D3 orbit has six distinct points",
]

output = Path(__file__).with_name(
    "verify_ordered_divisor_D3_three_arc_closure_output.txt"
)
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

from fractions import Fraction
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    yield 2
    for candidate in range(3, limit + 1, 2):
        if all(candidate % divisor for divisor in range(3, isqrt(candidate) + 1, 2)):
            yield candidate


def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return sorted(result)


def square_divisor_hull(value):
    remaining = value
    hull = 1
    prime = 2
    while prime * prime <= remaining:
        exponent = 0
        while remaining % prime == 0:
            exponent += 1
            remaining //= prime
        if exponent:
            hull *= prime ** ((exponent + 1) // 2)
        prime += 1
    if remaining > 1:
        hull *= remaining
    return hull


primes = list(primes_up_to(20000))
tested_lifts = 0

for u in range(1, 301):
    hull = square_divisor_hull(u)
    if (hull * hull) % u:
        raise AssertionError(f"hull square fails at u={u}")
    for candidate in range(1, 4 * hull + 1):
        if (candidate * candidate) % u == 0 and candidate % hull:
            raise AssertionError(f"hull divisibility criterion fails at u={u}, a={candidate}")

    for R in divisors(4 * u + 1):
        if R % 4 != 3:
            continue
        modulus = 4 * hull
        for p in primes:
            if (p + R) % modulus or R > 2 * p - 3:
                continue

            a = (p + R) // 4
            if u > a * a or (a * a) % u:
                raise AssertionError(f"lifted divisor fails for p={p}, R={R}, u={u}")
            if (4 * u + 1) % R:
                raise AssertionError(f"exterior congruence fails for p={p}, R={R}, u={u}")

            N = p * a
            d = p * p * u
            if (d + N) % R or (N * N // d + N) % R:
                raise AssertionError(f"certificate integrality fails for p={p}, R={R}, u={u}")
            b = (N + d) // R
            c = (N + N * N // d) // R
            if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                raise AssertionError(f"lifted identity fails for p={p}, R={R}, u={u}")
            tested_lifts += 1


for p in primes:
    if p % 20 == 13:
        a = (p + 7) // 4
        b = p * (3 * p + 1) // 4
        c = (p + 7) * (3 * p + 1) // 80
        if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
            raise AssertionError(f"13 mod 20 identity fails at p={p}")

    if p % 20 == 17:
        a = (p + 3) // 4
        b = p * (7 * p + 1) // 4
        c = (p + 3) * (7 * p + 1) // 80
        if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
            raise AssertionError(f"17 mod 20 identity fails at p={p}")


if not tested_lifts:
    raise AssertionError("no exterior residue lifts were tested")

print("PASS: exterior residue-lift families")
print("the square-divisor hull h is characterized by u dividing a^2 exactly when h divides a")
print("R dividing 4u+1 and p=-R mod 4h produce an occupied exterior shell")
print("the reconstructed denominators give exact unit-fraction identities")
print("the classes 13 mod 20 and 17 mod 20 are the u=5 lifts with R=7 and R=3")
print("all lifted tests through p=20000 passed")

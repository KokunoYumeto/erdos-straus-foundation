#!/usr/bin/env python3
"""Exact visible/hidden bit law for marked C4-extension coordinates."""

from __future__ import annotations

import itertools


def bits(value: int) -> tuple[int, int]:
    assert 0 <= value < 4
    return value % 2, value // 2


def from_bits(visible: int, hidden: int) -> int:
    assert visible in (0, 1)
    assert hidden in (0, 1)
    return visible + 2 * hidden


def coupled_add(
    left: tuple[int, int], right: tuple[int, int]
) -> tuple[int, int]:
    visible, hidden = left
    other_visible, other_hidden = right
    return (
        (visible + other_visible) % 2,
        (
            hidden
            + other_hidden
            + visible * other_visible
        )
        % 2,
    )


def additive_sections() -> list[tuple[int, int]]:
    sections: list[tuple[int, int]] = []
    for image_zero, image_one in itertools.product(range(4), repeat=2):
        image = (image_zero, image_one)
        if image_zero != 0:
            continue
        if any(bits(image[value])[0] != value for value in range(2)):
            continue
        if all(
            image[(left + right) % 2]
            == (image[left] + image[right]) % 4
            for left in range(2)
            for right in range(2)
        ):
            sections.append(image)
    return sections


def main() -> None:
    table = []
    group_type = {
        0: "C4xC4",
        1: "C16",
        2: "C8xC2",
        3: "C16",
    }
    split = {0: True, 1: False, 2: False, 3: False}

    for value in range(4):
        visible, hidden = bits(value)
        assert from_bits(visible, hidden) == value
        table.append(
            (
                value,
                visible,
                hidden,
                group_type[value],
                split[value],
            )
        )

    for left, right in itertools.product(range(4), repeat=2):
        assert bits((left + right) % 4) == coupled_add(
            bits(left), bits(right)
        )

    bit_pairs = tuple(itertools.product(range(2), repeat=2))
    for first, second, third in itertools.product(
        bit_pairs, repeat=3
    ):
        assert coupled_add(coupled_add(first, second), third) == (
            coupled_add(first, coupled_add(second, third))
        )

    assert additive_sections() == []
    assert bits(2) == (0, 1)

    for value, visible, hidden, total_group, is_split in table:
        print(
            f"class={value}: visible={visible}, hidden={hidden}, "
            f"group={total_group}, split={is_split}"
        )
    print("additive sections of C4 -> C2 detection map: 0")
    print(
        "PASS: visible/hidden C4 bits obey the forced coupled addition law"
    )


if __name__ == "__main__":
    main()

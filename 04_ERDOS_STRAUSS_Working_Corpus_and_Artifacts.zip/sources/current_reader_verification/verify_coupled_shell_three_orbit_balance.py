from functools import lru_cache
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


def is_squarefree(value):
    for prime in range(2, isqrt(value) + 1):
        if value % (prime * prime) == 0:
            return False
    return True


@lru_cache(maxsize=None)
def coordinates(a):
    return tuple(
        (s, t, a // (s * t))
        for s in divisors(a)
        if is_squarefree(s)
        for t in divisors(a // s)
    )


shell_count = 0
coupled_shell_count = 0
occupied_coupled_shell_count = 0
packet_count = 0
divisor_section_count = 0

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue

    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        R = 4 * a - p
        if R <= 0 or R % 4 != 3:
            continue
        shell_count += 1

        coordinate_set = coordinates(a)
        coupled = (p - 1) % R == 0
        if coupled:
            coupled_shell_count += 1

        exterior = {
            (s, t, m)
            for s, t, m in coordinate_set
            if (4 * s * t * t + 1) % R == 0
        }
        middle_ordered = {
            (s, t, m)
            for s, t, m in coordinate_set
            if (t + m) % R == 0
        }

        for s, t, m in coordinate_set:
            exterior_here = (4 * s * t * t + 1) % R == 0
            middle_here = (t + m) % R == 0
            if exterior_here and middle_here and not coupled:
                raise AssertionError(
                    f"shared coordinate without R|(p-1) at p={p}, a={a}, R={R}"
                )
            if coupled and exterior_here != middle_here:
                raise AssertionError(
                    f"coupled channel equivalence fails at p={p}, a={a}, R={R}"
                )

        if not coupled:
            continue

        exterior_divisors = {
            divisor
            for divisor in divisors(a * a)
            if (4 * divisor + 1) % R == 0
        }
        middle_divisors = {
            divisor
            for divisor in divisors(a * a)
            if (divisor + a) % R == 0
        }
        if exterior_divisors != middle_divisors:
            raise AssertionError(
                f"coupled divisor sections differ at p={p}, a={a}, R={R}"
            )
        divisor_section_count += 1

        if exterior != middle_ordered:
            raise AssertionError(
                f"coupled ordered channels differ at p={p}, a={a}, R={R}"
            )
        for s, t, m in exterior:
            if (s, m, t) not in exterior:
                raise AssertionError(
                    f"coupled exterior complement fails at p={p}, a={a}, R={R}"
                )

        packets = {
            (s, min(t, m), max(t, m))
            for s, t, m in exterior
        }
        if any(t == m for _, t, m in packets):
            raise AssertionError(
                f"coupled packet has a fixed point at p={p}, a={a}, R={R}"
            )
        if len(exterior) != 2 * len(packets):
            raise AssertionError(
                f"coupled packet lacks two orientations at p={p}, a={a}, R={R}"
            )

        middle_orbits = {
            (s, min(t, m), max(t, m))
            for s, t, m in middle_ordered
        }
        q = len(exterior) + len(middle_orbits)
        if middle_orbits != packets or q != 3 * len(packets):
            raise AssertionError(
                f"coupled three-orbit count fails at p={p}, a={a}, R={R}"
            )

        if packets:
            occupied_coupled_shell_count += 1
            packet_count += len(packets)


if not shell_count or not coupled_shell_count:
    raise AssertionError("the tested shell family was empty")
if not occupied_coupled_shell_count or not packet_count:
    raise AssertionError("no occupied coupled shell was tested")

print("PASS: coupled-shell three-orbit balance")
print("a shared exterior-middle coordinate implies R divides p-1")
print("when R divides p-1, the exterior and middle coordinate tests are equivalent")
print("the complete exterior and middle divisor sections are identical")
print("complement exchange preserves exterior occupancy in every coupled shell")
print("each occupied coupled packet has two exterior orientations and one middle orbit")
print("q_R,p equals three times the packet count in every coupled shell")
print(f"identical divisor sections checked: {divisor_section_count}")
print("all admissible shells through p=5000 passed")

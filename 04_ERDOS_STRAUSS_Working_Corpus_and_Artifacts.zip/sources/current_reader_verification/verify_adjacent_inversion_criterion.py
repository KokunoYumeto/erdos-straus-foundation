#!/usr/bin/env python3
"""Exact CRT and factor-support criterion for the R=31 to R=27 inversion."""

from math import gcd, isqrt


LIMIT = 500_000
MODULUS = 4 * 31 * 27
K31 = {1, 2, 4, 8, 16}
K27 = {1, 10, 19}
G31 = 3
G27 = 5
EXPECTED_CLASSES = (
    65, 353, 389, 533, 1109, 1181, 1469, 1505, 1649,
    2225, 2297, 2585, 2621, 2765, 3341,
)
EXPECTED_A_CLASSES = (
    6, 24, 96, 105, 141, 285, 303, 375, 384,
    420, 564, 582, 654, 663, 699,
)
EXACT_FIVE_RESIDUES = {13, 33, 53, 93}
EXPECTED_QUOTIENT_HITS = (
    353, 6113, 10433, 28433, 55793, 89633, 99713, 111593,
    300593, 340913, 368633, 379433, 490313, 497153,
)
EXPECTED_HITS = (
    353, 6113, 10433, 28433, 55793, 99713,
    300593, 340913, 368633, 379433, 497153,
)
EXPECTED_BINARY_PRIME_COFACTOR_HITS = (
    353, 6113, 10433, 28433, 55793, 99713,
    300593, 340913, 368633, 497153,
)
EXPECTED_T_CLASSES = (0, 6, 9, 57, 81)
EXPECTED_U_CLASSES = (0, 1, 17, 25, 29)


def prime_sieve(limit):
    flags = bytearray(b"\x01") * (limit + 1)
    flags[0:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if flags[prime]:
            flags[prime * prime:limit + 1:prime] = b"\x00" * (
                (limit - prime * prime) // prime + 1
            )
    return flags


def factorization(n):
    factors = {}
    divisor = 2
    while divisor * divisor <= n:
        while n % divisor == 0:
            factors[divisor] = factors.get(divisor, 0) + 1
            n //= divisor
        divisor = 3 if divisor == 2 else divisor + 2
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def is_prime(n):
    return n >= 2 and factorization(n) == {n: 1}


def divisors_from_factorization(factors):
    values = {1}
    for prime, exponent in factors.items():
        values = {
            value * prime ** power
            for value in values
            for power in range(exponent + 1)
        }
    return values


def coset(x, subgroup, modulus):
    return frozenset((x * k) % modulus for k in subgroup)


def quotient_log(x, generator, subgroup, modulus):
    target = coset(x, subgroup, modulus)
    value = 1
    for exponent in range(6):
        if coset(value, subgroup, modulus) == target:
            return exponent
        value = value * generator % modulus
    raise AssertionError((x, generator, subgroup, modulus))


def internal_log(x, generator, subgroup, modulus):
    target = x % modulus
    value = 1
    for exponent in range(len(subgroup)):
        if value == target:
            return exponent
        value = value * generator % modulus
    raise AssertionError((x, generator, subgroup, modulus))


def product_set(left, right, modulus):
    return {(x * y) % modulus for x in left for y in right}


def ordered_target_logs(p, modulus, generator, subgroup):
    return tuple(
        quotient_log(value, generator, subgroup, modulus)
        for value in (
            (-p) % modulus,
            (-1) % modulus,
            (-pow(p, -1, modulus)) % modulus,
        )
    )


def target_condition(p):
    return (
        p % 4 == 1
        and p % 31 in {(3 * k) % 31 for k in K31}
        and p % 27 in {(2 * k) % 27 for k in K27}
    )


def quotient_factor_condition(p):
    if not target_condition(p):
        return False
    a31 = (p + 31) // 4
    a27 = (p + 27) // 4
    factors31 = factorization(a31)
    factors27 = factorization(a27)
    return (
        factors31.get(3) == 1
        and all(prime == 3 or prime % 31 in K31 for prime in factors31)
        and factors27.get(5) == 1
        and all(prime == 5 or prime % 27 in K27 for prime in factors27)
    )


def consecutive_factor_condition(p):
    if not target_condition(p):
        return False
    a_value = (p + 31) // 4
    factors_a = factorization(a_value)
    factors_previous = factorization(a_value - 1)
    return (
        factors_a.get(3) == 1
        and all(prime == 3 or prime % 31 in K31 for prime in factors_a)
        and factors_previous.get(5) == 1
        and all(
            prime == 5 or prime % 27 in K27
            for prime in factors_previous
        )
    )


def kernel_generation_condition(p):
    for modulus, distinguished, subgroup in ((31, 3, K31), (27, 5, K27)):
        a_value = (p + modulus) // 4
        factors = factorization(a_value)
        kernel_carrier = {1}
        for prime, width in factors.items():
            if prime == distinguished:
                continue
            local_set = {
                pow(prime, exponent, modulus)
                for exponent in range(-width, width + 1)
            }
            kernel_carrier = product_set(kernel_carrier, local_set, modulus)
        if kernel_carrier != subgroup:
            return False
    return True


def kernel_internal_weight(p, modulus, distinguished, subgroup, generator):
    a_value = (p + modulus) // 4
    factors = factorization(a_value)
    return sum(
        exponent
        for prime, exponent in factors.items()
        if prime != distinguished
        and internal_log(prime, generator, subgroup, modulus) != 0
    )


def kernel_weight_condition(p):
    if not quotient_factor_condition(p):
        return False
    return (
        kernel_internal_weight(p, 31, 3, K31, 2) >= 2
        and kernel_internal_weight(p, 27, 5, K27, 10) >= 1
    )


def residue_factor_weight(p, modulus):
    a_value = (p + modulus) // 4
    nontrivial_residues = (
        {2, 4, 8, 16} if modulus == 31 else {10, 19}
    )
    return sum(
        exponent
        for prime, exponent in factorization(a_value).items()
        if prime % modulus in nontrivial_residues
    )


def full_support_condition(p):
    return quotient_factor_condition(p) and kernel_generation_condition(p)


def binary_prime_cofactor_condition(p):
    if not is_prime(p) or (p + 31) % 4:
        return False
    a_value = (p + 31) // 4
    if a_value % 3 or (a_value - 1) % 5:
        return False
    odd_cofactor = a_value // 3
    two_weight = 0
    while odd_cofactor % 2 == 0:
        odd_cofactor //= 2
        two_weight += 1
    q_value = (a_value - 1) // 5
    return (
        two_weight >= 1
        and (odd_cofactor == 1 or is_prime(odd_cofactor))
        and odd_cofactor % 31 in K31
        and two_weight + int(odd_cofactor % 31 in {2, 4, 8, 16}) >= 2
        and is_prime(q_value)
        and q_value % 27 in {10, 19}
    )


def diophantine_cofactor_condition(p):
    if p < 2 or (p + 7) % 60:
        return False
    t_value = (p + 7) // 60
    if t_value < 1:
        return False
    b_value = 5 * t_value + 2
    c_value = 3 * t_value + 1
    return (
        p == 60 * t_value - 7
        and all(prime % 31 in K31 for prime in factorization(b_value))
        and all(prime % 27 in K27 for prime in factorization(c_value))
    )


def diophantine_cofactor_weights(p):
    assert diophantine_cofactor_condition(p)
    t_value = (p + 7) // 60
    b_value = 5 * t_value + 2
    c_value = 3 * t_value + 1
    return (
        sum(
            exponent
            for prime, exponent in factorization(b_value).items()
            if prime % 31 in {2, 4, 8, 16}
        ),
        sum(
            exponent
            for prime, exponent in factorization(c_value).items()
            if prime % 27 in {10, 19}
        ),
    )


def check_shell(p, modulus, distinguished, subgroup, generator, expected_target):
    a_value = (p + modulus) // 4
    factors_a = factorization(a_value)
    local_sets = tuple(
        {pow(prime, exponent, modulus) for exponent in range(-width, width + 1)}
        for prime, width in factors_a.items()
    )
    carrier = {1}
    for local_set in local_sets:
        carrier = product_set(carrier, local_set, modulus)
    units = {x for x in range(1, modulus) if gcd(x, modulus) == 1}
    stabilizer = {
        h for h in units
        if {(h * x) % modulus for x in carrier} == carrier
    }
    assert stabilizer == subgroup
    carrier_logs = {
        quotient_log(value, generator, subgroup, modulus)
        for value in carrier
    }
    target_logs = ordered_target_logs(p, modulus, generator, subgroup)
    assert carrier_logs == {0, 1, 5}
    assert target_logs == expected_target
    assert carrier_logs.isdisjoint(target_logs)

    assert factors_a[distinguished] == 1
    assert a_value * distinguished * (a_value // distinguished) == a_value * a_value

    n_value = p * a_value
    factors_n_squared = {
        prime: 2 * exponent for prime, exponent in factors_a.items()
    }
    factors_n_squared[p] = factors_n_squared.get(p, 0) + 2
    candidates = {
        divisor
        for divisor in divisors_from_factorization(factors_n_squared)
        if divisor % modulus == (-n_value) % modulus
    }
    assert candidates == set()
    return a_value, tuple(factors_a.items())


if __name__ == "__main__":
    classes = tuple(
        residue
        for residue in range(1, MODULUS)
        if target_condition(residue)
    )
    assert classes == EXPECTED_CLASSES
    assert all(gcd(residue, MODULUS) == 1 for residue in classes)

    a_classes = tuple(
        a_value
        for a_value in range(837)
        if target_condition(4 * a_value - 31)
    )
    assert a_classes == EXPECTED_A_CLASSES
    t_classes = tuple(
        t_value
        for t_value in range(93)
        if target_condition(60 * t_value - 7)
    )
    assert t_classes == EXPECTED_T_CLASSES
    u_classes = tuple(
        u_value
        for u_value in range(31)
        if target_condition(360 * u_value - 7)
    )
    assert u_classes == EXPECTED_U_CLASSES

    flags = prime_sieve(LIMIT)
    target_primes = tuple(
        prime for prime in range(2, LIMIT + 1)
        if flags[prime] and target_condition(prime)
    )
    quotient_hits = tuple(
        prime for prime in target_primes if quotient_factor_condition(prime)
    )
    hits = tuple(prime for prime in quotient_hits if full_support_condition(prime))
    weight_hits = tuple(
        prime for prime in quotient_hits if kernel_weight_condition(prime)
    )
    assert len(target_primes) == 566
    assert all(
        ((prime + 31) // 4) % 9 == 6
        and factorization((prime + 31) // 4).get(3) == 1
        for prime in target_primes
    )
    assert all(
        (
            factorization((prime + 27) // 4).get(5) == 1
        )
        == (prime % 100 in EXACT_FIVE_RESIDUES)
        for prime in target_primes
    )
    assert all(
        quotient_factor_condition(prime)
        == consecutive_factor_condition(prime)
        for prime in target_primes
    )
    assert all(
        quotient_factor_condition(prime)
        == diophantine_cofactor_condition(prime)
        for prime in target_primes
    )
    assert quotient_hits == EXPECTED_QUOTIENT_HITS
    assert hits == EXPECTED_HITS
    assert weight_hits == EXPECTED_HITS
    assert all(prime % 360 == 353 for prime in quotient_hits)
    binary_prime_cofactor_hits = tuple(
        prime for prime in hits if binary_prime_cofactor_condition(prime)
    )
    assert binary_prime_cofactor_hits == EXPECTED_BINARY_PRIME_COFACTOR_HITS
    remaining_full_hits = tuple(
        prime for prime in hits if prime not in binary_prime_cofactor_hits
    )
    assert remaining_full_hits == (379433,)
    assert factorization(((379433 + 31) // 4) // 3) == {
        2: 1,
        97: 1,
        163: 1,
    }
    assert all(
        kernel_generation_condition(prime) == kernel_weight_condition(prime)
        for prime in quotient_hits
    )
    assert all(
        residue_factor_weight(prime, 31)
        == kernel_internal_weight(prime, 31, 3, K31, 2)
        and residue_factor_weight(prime, 27)
        == kernel_internal_weight(prime, 27, 5, K27, 10)
        for prime in quotient_hits
    )
    assert all(
        diophantine_cofactor_weights(prime)
        == (
            kernel_internal_weight(prime, 31, 3, K31, 2),
            kernel_internal_weight(prime, 27, 5, K27, 10),
        )
        for prime in quotient_hits
    )

    failures = tuple(
        (
            prime,
            kernel_internal_weight(prime, 31, 3, K31, 2),
            kernel_internal_weight(prime, 27, 5, K27, 10),
        )
        for prime in quotient_hits
        if prime not in hits
    )
    assert failures == (
        (89633, 5, 0),
        (111593, 1, 1),
        (490313, 2, 0),
    )

    receipts = []
    for prime in hits:
        upper = check_shell(prime, 31, 3, K31, G31, (4, 3, 2))
        lower = check_shell(prime, 27, 5, K27, G27, (2, 3, 4))
        receipts.append((prime, upper, lower))

    print("PASS ordered-target CRT classes modulo 3348 =", classes)
    print("PASS consecutive a classes modulo 837 =", a_classes)
    print("PASS Diophantine t classes modulo 93 =", t_classes)
    print("PASS sixfold u classes modulo 31 =", u_classes)
    print("PASS target-compatible primes through 500000 =", len(target_primes))
    print("PASS quotient-factor hits through 500000 =", quotient_hits)
    print("PASS full adjacent support hits through 500000 =", hits)
    print(
        "PASS kernel internal-log thresholds =",
        ((31, 2, 2), (27, 10, 1)),
    )
    print(
        "PASS residue-factor weight classes =",
        ((31, (2, 4, 8, 16), 2), (27, (10, 19), 1)),
    )
    print(
        "PASS exact distinguished-factor congruences =",
        ((3, 6, 9), (5, tuple(sorted(EXACT_FIVE_RESIDUES)), 100)),
    )
    print(
        "PASS consecutive-factor criterion matches through 500000 =",
        len(target_primes),
    )
    print(
        "PASS Diophantine t-parameter criterion matches through 500000 =",
        len(target_primes),
    )
    print(
        "PASS full-support t parameters =",
        tuple((prime + 7) // 60 for prime in hits),
    )
    print(
        "PASS full-support u parameters =",
        tuple((prime + 7) // 360 for prime in hits),
    )
    print("PASS failed full-support weights =", failures)
    print(
        "PASS binary-prime cofactor sufficient-family hits =",
        binary_prime_cofactor_hits,
    )
    print(
        "PASS remaining full-support cofactor factorization =",
        (379433, ((2, 1), (97, 1), (163, 1))),
    )
    print("PASS exact arithmetic shell pairs =", len(receipts))

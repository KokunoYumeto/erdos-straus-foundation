from itertools import product
from math import gcd


def cyclic_convolution(order, local_data):
    values = [0] * order
    for exponents in product(
        *[range(-exponent, exponent + 1)
          for exponent, _ in local_data]
    ):
        residue = sum(
            beta * step
            for beta, (_, step) in zip(exponents, local_data)
        ) % order
        values[residue] += 1
    return values


def root_order(order, character, step):
    exponent = character * step
    return order // gcd(order, exponent)


def local_factor_vanishes(order, exponent, step, character):
    value_order = root_order(order, character, step)
    length = 2 * exponent + 1
    return value_order > 1 and length % value_order == 0


def survivor_characters(order, local_data):
    return [
        character
        for character in range(order)
        if not any(
            local_factor_vanishes(
                order, exponent, step, character
            )
            for exponent, step in local_data
        )
    ]


def binary_coefficient(values):
    return sum(
        value * ((-1) ** h)
        for h, value in enumerate(values)
    )


def binary_local_factor(exponent, step):
    if step % 2 == 0:
        return 2 * exponent + 1
    return (-1) ** exponent


for order in (2, 4, 8, 16):
    local_data = [(1, 1), (2, 3), (1, 2)]
    for character in range(order):
        for exponent, step in local_data:
            if local_factor_vanishes(
                order, exponent, step, character
            ):
                raise AssertionError(
                    "an odd local length killed a 2-primary character"
                )


for odd_order in (3, 5, 7, 9, 11):
    order = 2 * odd_order
    local_data = [((odd_order - 1) // 2, 2), (1, 1)]
    values = cyclic_convolution(order, local_data)
    survivors = survivor_characters(order, local_data)
    if survivors != [0, odd_order]:
        raise AssertionError("the two-sheet survivor set failed")

    principal_mass = sum(values)
    binary_amplitude = binary_coefficient(values)
    local_binary_product = 1
    for exponent, step in local_data:
        local_binary_product *= binary_local_factor(exponent, step)
    if binary_amplitude != local_binary_product:
        raise AssertionError("the binary local product failed")
    if not abs(binary_amplitude) < principal_mass:
        raise AssertionError("the binary amplitude is not subprincipal")
    expected = [
        (
            principal_mass
            + binary_amplitude * ((-1) ** h)
        ) // order
        for h in range(order)
    ]
    if values != expected or values != [
        1 if h % 2 == 0 else 2 for h in range(order)
    ]:
        raise AssertionError("the positive two-sheet formula failed")


order = 10
local_data = [(1, 8), (2, 4), (1, 3)]
values = cyclic_convolution(order, local_data)
survivors = survivor_characters(order, local_data)
if survivors != [0, 5]:
    raise AssertionError("the 12289 survivor spectrum failed")

principal_mass = sum(values)
binary_amplitude = binary_coefficient(values)
if principal_mass != 45:
    raise AssertionError("the 12289 principal mass failed")
if binary_amplitude != -15:
    raise AssertionError("the 12289 binary amplitude failed")
local_binary_product = 1
for exponent, step in local_data:
    local_binary_product *= binary_local_factor(exponent, step)
if binary_amplitude != local_binary_product:
    raise AssertionError("the 12289 binary local product failed")
for h in range(order):
    reconstructed = (
        principal_mass + binary_amplitude * ((-1) ** h)
    ) // order
    if reconstructed != values[h]:
        raise AssertionError("the 12289 two-sheet reconstruction failed")
if values != [3, 6, 3, 6, 3, 6, 3, 6, 3, 6]:
    raise AssertionError("the 12289 positive sheet values failed")

print("PASS: cyclotomic survivor and two-sheet positivity")
print("odd local lengths preserve every tested 2-primary character")
print("five exact C2-coupled families have only principal and binary survivors")
print("their binary amplitude is strictly smaller than the principal mass")
print("the 12289 spectrum is (45,0,0,0,0,-15,0,0,0,0)")
print("Fourier inversion gives the positive sheet values (3,6,3,6,3,6,3,6,3,6)")

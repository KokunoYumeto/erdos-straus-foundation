#!/usr/bin/env python3
"""Exact certificate for the endpoint norm and Fable cubic invariant."""

from fractions import Fraction as Q


def require(label, assertion):
    if not assertion:
        raise AssertionError(label)
    print(f"{label}: PASS")


def matrix_multiply(left, right):
    return [
        [
            sum((left[i][k] * right[k][j] for k in range(2)), Q(0))
            for j in range(2)
        ]
        for i in range(2)
    ]


rho_matrix = [
    [Q(-1, 2), Q(0)],
    [Q(1), Q(1, 2)],
]
identity = [[Q(1), Q(0)], [Q(0), Q(1)]]
rho_square = matrix_multiply(rho_matrix, rho_matrix)
quarter_identity = [[entry * Q(1, 4) for entry in row] for row in identity]

trace = rho_matrix[0][0] + rho_matrix[1][1]
norm = rho_matrix[0][0] * rho_matrix[1][1] - rho_matrix[0][1] * rho_matrix[1][0]


def u_from_s(s):
    return (3 * s - 1) / 2


def s_from_u(u):
    return (2 * u + 1) / 3


def rho_from_u(u):
    return (4 * u - 1) / 6


require("endpoint zero maps to the first equalizer sheet", u_from_s(Q(0)) == Q(-1, 2))
require("endpoint one maps to the second equalizer sheet", u_from_s(Q(1)) == Q(1))
require("the equalizer inverse recovers both endpoints", s_from_u(Q(-1, 2)) == 0 and s_from_u(Q(1)) == 1)
require("transported rho has the ordered endpoint values", rho_from_u(Q(-1, 2)) == Q(-1, 2) and rho_from_u(Q(1)) == Q(1, 2))

require("multiplication by rho squares to one quarter", rho_square == quarter_identity)
require("endpoint algebra trace of rho is zero", trace == 0)
require("endpoint algebra norm of rho is -1/4", norm == Q(-1, 4))
require(
    "endpoint-value product equals the algebra norm",
    Q(-1, 2) * Q(1, 2) == norm,
)

a, b, c, d = Q(0), Q(1), Q(0), norm
discriminant = (
    b * b * c * c
    - 4 * a * c**3
    - 4 * b**3 * d
    - 27 * a * a * d * d
    + 18 * a * b * c * d
)
require("binary cubic discriminant is -4 times the norm", discriminant == -4 * norm)
require("common Fable cubic has discriminant one", discriminant == 1)
require("common Fable fibre scalar is the endpoint norm", norm == Q(-1, 4))
require("Fable Jacobian scalar is four times rho at zero", 4 * Q(-1, 2) == -2)
require("Fable Jacobian scalar is eight times the endpoint norm", 8 * norm == -2)

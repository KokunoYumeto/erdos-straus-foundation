#!/usr/bin/env python3
"""Exact checks for the ordered blade and D3 pullback to simplex support."""

import sympy as sp


def helmert_support(n):
    rows = []
    for k in range(1, n + 1):
        row = [sp.Integer(0)] * (n + 1)
        denominator = sp.sqrt(k * (k + 1))
        for j in range(k):
            row[j] = 1 / denominator
        row[k] = -sp.Rational(k, 1) / denominator
        rows.append(row)
    unitary = sp.Matrix(rows)
    ones = sp.ones(n + 1, 1)
    projection = sp.eye(n + 1) - sp.Rational(1, n + 1) * ones * ones.T
    assert sp.simplify(unitary.T * unitary) == projection
    assert sp.simplify(unitary * unitary.T) == sp.eye(n)
    return unitary, projection


u1, p1 = helmert_support(1)
u2, p2 = helmert_support(2)
u3, p3 = helmert_support(3)

e21 = sp.Matrix([[0, 0], [1, 0]])
e12 = sp.Matrix([[0, 1], [0, 0]])

blade_minus_plus = sp.simplify(u2.T * (2 * e21) * u2)
blade_plus_minus = sp.simplify(u2.T * e12 * u2)

expected_minus_plus = sp.Matrix(
    [[1, -1, 0], [1, -1, 0], [-2, 2, 0]]
) / sp.sqrt(3)
expected_plus_minus = sp.Matrix(
    [[1, 1, -2], [-1, -1, 2], [0, 0, 0]]
) / (2 * sp.sqrt(3))

assert sp.simplify(blade_minus_plus - expected_minus_plus) == sp.zeros(3)
assert sp.simplify(blade_plus_minus - expected_plus_minus) == sp.zeros(3)
assert sp.simplify(blade_minus_plus - 2 * blade_plus_minus.T) == sp.zeros(3)
assert blade_minus_plus != blade_plus_minus

eta0 = u2.T[:, 0]
eta1 = u2.T[:, 1]
assert sp.simplify(blade_minus_plus * blade_plus_minus - 2 * eta1 * eta1.T) == sp.zeros(3)
assert sp.simplify(blade_plus_minus * blade_minus_plus - 2 * eta0 * eta0.T) == sp.zeros(3)

d2 = sp.diag(2, 3)
pulled_d2 = sp.simplify(u2.T * d2 * u2)
pulled_d2_inverse = sp.simplify(u2.T * d2.inv() * u2)
assert pulled_d2 == sp.Matrix([[3, -1, -2], [-1, 3, -2], [-2, -2, 4]]) / 2
assert sp.simplify(
    pulled_d2 * blade_minus_plus * pulled_d2_inverse
    - sp.Rational(3, 2) * blade_minus_plus
) == sp.zeros(3)
assert sp.simplify(
    pulled_d2 * blade_plus_minus * pulled_d2_inverse
    - sp.Rational(2, 3) * blade_plus_minus
) == sp.zeros(3)

s2 = sp.Matrix([[0, 1], [1, 0]])
r3 = sp.Matrix([[0, 0, 1], [1, 0, 0], [0, 1, 0]])
f3 = sp.Matrix([[1, 0, 0], [0, 0, 1], [0, 1, 0]])

support_s2 = sp.simplify(u2.T * s2 * u2)
support_r3 = sp.simplify(u3.T * r3 * u3)
support_f3 = sp.simplify(u3.T * f3 * u3)

assert sp.simplify(support_s2**2 - p2) == sp.zeros(3)
assert sp.simplify(support_r3**3 - p3) == sp.zeros(4)
assert sp.simplify(support_f3**2 - p3) == sp.zeros(4)
assert sp.simplify(support_f3 * support_r3 * support_f3 - support_r3.T) == sp.zeros(4)

support_wr = sp.diag(p1, p2, support_r3)
support_wf = sp.diag(p1, support_s2, support_f3)
full_support = sp.diag(p1, p2, p3)

assert sp.simplify(support_wr**3 - full_support) == sp.zeros(9)
assert sp.simplify(support_wf**2 - full_support) == sp.zeros(9)
assert sp.simplify(
    support_wf * support_wr * support_wf - support_wr.T
) == sp.zeros(9)

print("PASS ordered 2E21 and E12 blades have the stated distinct 3-by-3 support matrices")
print("PASS the two pulled blades obey B_minus_plus = 2 B_plus_minus^*")
print("PASS ordered blade products retain the two distinct rank-one support targets")
print("PASS pulled density diag(2,3) gives modular weights 3/2 and 2/3")
print("PASS pulled C2 and C3 generators satisfy the support-corner D3 relations")
print("PASS the full 1-2-3 support action is intertwined with the existing D3 action")

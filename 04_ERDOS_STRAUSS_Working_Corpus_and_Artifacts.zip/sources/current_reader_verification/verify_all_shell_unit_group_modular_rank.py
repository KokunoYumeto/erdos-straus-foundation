from collections import defaultdict
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def unit_group_coefficients(a, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(a):
        local = defaultdict(int)
        local[1] += 1
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] += 1
            local[pow(residue, -1, modulus)] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left * right) % modulus] += left_count * right_count
        coefficients = dict(product)
    return coefficients


shell_count = 0
occupied_shell_count = 0
primewise_exterior_count = defaultdict(int)
primewise_coefficient_count = defaultdict(int)
primewise_orbit_count = defaultdict(int)
primewise_direct_orbit_count = defaultdict(int)

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue
    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        R = 4 * a - p
        if R <= 0 or R % 4 != 3 or gcd(R, a) != 1:
            raise AssertionError(f"invalid all-shell data at p={p}, a={a}, R={R}")
        shell_count += 1
        a_squared_divisors = divisors(a * a)
        exterior = [u for u in a_squared_divisors if (4 * u + 1) % R == 0]
        middle = [u for u in a_squared_divisors if (u + a) % R == 0]
        coefficient = unit_group_coefficients(a, R).get(R - 1, 0)
        if coefficient != len(middle):
            raise AssertionError(
                f"all-shell coefficient formula fails at p={p}, a={a}, R={R}"
            )
        if coefficient % 2:
            raise AssertionError(
                f"odd all-shell coefficient at p={p}, a={a}, R={R}"
            )
        q_shell = len(exterior) + coefficient // 2
        direct_orbits = len(exterior) + len(
            {tuple(sorted((u, a * a // u))) for u in middle}
        )
        if q_shell != direct_orbits:
            raise AssertionError(
                f"all-shell modular rank fails at p={p}, a={a}, R={R}"
            )
        if 6 * q_shell != 6 * len(exterior) + 3 * coefficient:
            raise AssertionError(
                f"all-shell volume exponent fails at p={p}, a={a}, R={R}"
            )
        if q_shell:
            occupied_shell_count += 1
        primewise_exterior_count[p] += len(exterior)
        primewise_coefficient_count[p] += coefficient
        primewise_orbit_count[p] += q_shell
        primewise_direct_orbit_count[p] += direct_orbits


for p in primewise_orbit_count:
    exterior_count = primewise_exterior_count[p]
    coefficient_count = primewise_coefficient_count[p]
    orbit_count = primewise_orbit_count[p]
    if coefficient_count % 2:
        raise AssertionError(f"odd primewise coefficient total at p={p}")
    if orbit_count != exterior_count + coefficient_count // 2:
        raise AssertionError(f"primewise coefficient formula fails at p={p}")
    if orbit_count != primewise_direct_orbit_count[p]:
        raise AssertionError(f"primewise direct orbit formula fails at p={p}")
    if 6 * orbit_count != 6 * exterior_count + 3 * coefficient_count:
        raise AssertionError(f"primewise volume exponent fails at p={p}")


prime_modulus_count = 0
for R in primes_up_to(199):
    if R % 4 != 3:
        continue
    prime_modulus_count += 1
    n = (R - 1) // 2
    units = range(1, R)
    two_part = {unit for unit in units if pow(unit, 2, R) == 1}
    n_part = {unit for unit in units if pow(unit, n, R) == 1}
    theta = {unit: (pow(unit, n, R), pow(unit, n + 1, R)) for unit in units}
    if len(two_part) != 2 or len(n_part) != n or len(set(theta.values())) != 2 * n:
        raise AssertionError(f"intrinsic product cardinality fails at R={R}")
    for unit, pair in theta.items():
        if pair[0] not in two_part or pair[1] not in n_part:
            raise AssertionError(f"intrinsic product range fails at R={R}")
        if pair[0] * pair[1] % R != unit:
            raise AssertionError(f"intrinsic product inverse fails at R={R}")
    if theta[R - 1] != (R - 1, 1):
        raise AssertionError(f"intrinsic minus-one target fails at R={R}")


p, R, a = 12289, 11, 3075
a_squared_divisors = divisors(a * a)
exterior_12289 = [u for u in a_squared_divisors if (4 * u + 1) % R == 0]
middle_12289 = sorted(
    {tuple(sorted((u, a * a // u))) for u in a_squared_divisors if (u + a) % R == 0}
)
coefficient_12289 = unit_group_coefficients(a, R).get(R - 1, 0)
ordered_12289 = [
    (x, y)
    for x in divisors(a)
    for y in divisors(a)
    if gcd(x, y) == 1 and a % (x * y) == 0 and (x + y) % R == 0
]


def theta_11(unit):
    return (pow(unit, 5, 11), pow(unit, 6, 11))


u11_five_part = {unit for unit in range(1, 11) if pow(unit, 5, 11) == 1}
factor_3_product = [
    theta_11(1),
    theta_11(3),
    theta_11(pow(3, -1, 11)),
]
factor_5_product = [
    theta_11(1),
    theta_11(5),
    theta_11(pow(5, -1, 11)),
    theta_11(pow(5, 2, 11)),
    theta_11(pow(pow(5, 2, 11), -1, 11)),
]
factor_41_product = [
    theta_11(1),
    theta_11(41 % 11),
    theta_11(pow(41, -1, 11)),
]
target_product_count = sum(
    1
    for left in factor_3_product
    for middle in factor_5_product
    for right in factor_41_product
    if (
        left[0] * middle[0] * right[0] % 11,
        left[1] * middle[1] * right[1] % 11,
    )
    == (10, 1)
)

if factorization(a) != ((3, 1), (5, 2), (41, 1)):
    raise AssertionError("12289 shell factorization fails")
if coefficient_12289 != 6:
    raise AssertionError("12289 unit-group coefficient fails")
if u11_five_part != {1, 3, 4, 5, 9}:
    raise AssertionError("12289 C5 factor fails")
if factor_3_product != [(1, 1), (1, 3), (1, 4)]:
    raise AssertionError("12289 prime-3 product coordinates fail")
if factor_5_product != [(1, 1), (1, 5), (1, 9), (1, 3), (1, 4)]:
    raise AssertionError("12289 prime-5 product coordinates fail")
if factor_41_product != [(1, 1), (10, 3), (10, 4)]:
    raise AssertionError("12289 prime-41 product coordinates fail")
if target_product_count != 6:
    raise AssertionError("12289 C2 x C5 target count fails")
if exterior_12289 != [41, 1845, 15375]:
    raise AssertionError("12289 exterior divisor set fails")
if middle_12289 != [(5, 1891125), (225, 42025), (1875, 5043)]:
    raise AssertionError("12289 middle complement orbits fail")
if ordered_12289 != [
    (1, 615),
    (3, 41),
    (25, 41),
    (41, 3),
    (41, 25),
    (615, 1),
]:
    raise AssertionError("12289 ordered coprime-factor list fails")
if len(exterior_12289) + coefficient_12289 // 2 != 6:
    raise AssertionError("12289 modular support rank fails")


if not shell_count or not occupied_shell_count or not prime_modulus_count:
    raise AssertionError("the all-shell verification families were not present")

print("PASS: all-shell unit-group and modular-rank formula")
print("c_R,a equals the number of middle divisors in every shell")
print("rank P_mod equals the exterior count plus one half of c_R,a")
print("the primewise rank is the total exterior count plus one half of all coefficients")
print("prime R=3 mod 4 has the intrinsic product U_R[2] x U_R[(R-1)/2]")
print("minus one maps to the C2-odd and higher-factor-neutral target")
print("the 12289 shell has exterior count 3, coefficient 6, and modular rank 6")
print("the 12289 C2 x C5 factorization has exactly 3 x 2 target terms")
print("all arithmetic shells through p=5000 and prime moduli through R=199 passed")

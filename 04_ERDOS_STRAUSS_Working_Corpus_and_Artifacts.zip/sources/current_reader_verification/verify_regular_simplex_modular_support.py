#!/usr/bin/env python3
"""Exact finite-dimensional checks for the simplex support modular sector."""

import sympy as sp


for n in range(2, 10):
    ones = sp.ones(n + 1, 1)
    projection = sp.eye(n + 1) - sp.Rational(1, n + 1) * (ones * ones.T)
    state = projection / n
    support_inverse = n * projection

    assert projection.T == projection
    assert projection * projection == projection
    assert projection.rank() == n
    assert projection * ones == sp.zeros(n + 1, 1)
    assert state.eigenvals() == {
        sp.Integer(0): 1,
        sp.Rational(1, n): n,
    }

    support_basis = []
    for i in range(n):
        vector = sp.zeros(n + 1, 1)
        vector[i, 0] = 1
        vector[n, 0] = -1
        assert projection * vector == vector
        support_basis.append(vector)

    for u in support_basis:
        for v in support_basis:
            matrix_unit = u * v.T
            assert projection * matrix_unit * projection == matrix_unit
            modular_image = state * matrix_unit * support_inverse
            assert modular_image == matrix_unit
            density_commutator = projection * matrix_unit - matrix_unit * projection
            assert density_commutator == sp.zeros(n + 1)

print("PASS simplex support projection is self-adjoint idempotent of rank n")
print("PASS simplex support kernel is the all-one label line")
print("PASS trace-one simplex state is faithful on the support corner")
print("PASS finite modular operator acts as the identity on every support matrix unit")
print("PASS logarithmic density generator is central on the support corner")
print("PASS n=4 support state has eigenvalue 1/4 with multiplicity four")

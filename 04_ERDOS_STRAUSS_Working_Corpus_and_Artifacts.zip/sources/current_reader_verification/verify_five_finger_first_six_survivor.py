from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(value):
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    trial = 3
    while trial <= isqrt(value):
        if value % trial == 0:
            return False
        trial += 2
    return True


def factorization(value):
    factors = {}
    trial = 2
    while trial * trial <= value:
        while value % trial == 0:
            factors[trial] = factors.get(trial, 0) + 1
            value //= trial
        trial = 3 if trial == 2 else trial + 2
    if value > 1:
        factors[value] = factors.get(value, 0) + 1
    return factors


def divisors_from_factorization(factors):
    divisors = [1]
    for prime, exponent in factors.items():
        divisors = [
            divisor * prime**power
            for divisor in divisors
            for power in range(exponent + 1)
        ]
    return sorted(divisors)


def shell_sets(prime, residual):
    denominator = (prime + residual) // 4
    divisors = divisors_from_factorization(factorization(denominator**2))
    exterior = [value for value in divisors if (4 * value + 1) % residual == 0]
    middle = [value for value in divisors if (value + denominator) % residual == 0]
    return denominator, exterior, middle


p = 415_969
d = 11_555
fingers = (
    103_993,
    51_997,
    11_555,
    51_998,
    103_997,
)
expected_factorizations = (
    {103_993: 1},
    {11: 1, 29: 1, 163: 1},
    {5: 1, 2_311: 1},
    {2: 1, 25_999: 1},
    {103_997: 1},
)

report("survivor prime", is_prime(p))
report(
    "survivor Pocklington certificate",
    p - 1 == 2**5 * 3 * 7 * 619
    and is_prime(619)
    and pow(13, p - 1, p) == 1
    and tuple(pow(13, (p - 1) // q, p) for q in (2, 3, 7, 619))
    == (415_968, 32_421, 190_698, 191_070)
    and all(
        gcd(pow(13, (p - 1) // q, p) - 1, p) == 1
        for q in (2, 3, 7, 619)
    ),
)
report("five-Finger affine parameter", p == 36 * d - 11)
report(
    "five-Finger coordinates",
    fingers
    == (
        9 * d - 2,
        (9 * d - 1) // 2,
        d,
        (9 * d + 1) // 2,
        9 * d + 2,
    ),
)
report(
    "five-Finger factorizations",
    tuple(factorization(value) for value in fingers) == expected_factorizations,
)

empty_residuals = (3, 7, 11, 15, 19, 23, 27)
empty_data = {}
for residual in empty_residuals:
    denominator, exterior, middle = shell_sets(p, residual)
    empty_data[residual] = (denominator, exterior, middle)

report(
    "residual shells three through twenty-seven empty",
    all(not exterior and not middle for _, exterior, middle in empty_data.values()),
)

R = 31
a, exterior_31, middle_31 = shell_sets(p, R)
expected_exterior_31 = [5_200, 166_400, 650_000, 20_800_000]
expected_middle_31 = [
    5,
    160,
    625,
    5_120,
    16_900,
    20_000,
    540_800,
    640_000,
    2_112_500,
    17_305_600,
    67_600_000,
    2_163_200_000,
]

report("residual-thirty-one denominator", a == 104_000)
report("residual-thirty-one exterior set", exterior_31 == expected_exterior_31)
report("residual-thirty-one middle set", middle_31 == expected_middle_31)
report(
    "residual-thirty-one orbit count",
    len(exterior_31) + len(middle_31) // 2 == 10,
)

u = 5_200
N = p * a
D = p**2 * u
complement = N**2 // D
b = (N + D) // R
c = (N + complement) // R

report("exterior seed", (4 * u + 1) % R == 0 and a * a % u == 0)
report("origin-two divisor", N * N % D == 0 and (D + N) % R == 0)
report("complement divisor", complement == a * a // u == 2_080_000)
report(
    "reconstructed denominators",
    (N, D, b, c)
    == (
        43_260_776_000,
        899_757_086_597_200,
        29_025_817_657_200,
        1_395_576_000,
    ),
)
report(
    "Erdos-Straus identity by cross multiplication",
    4 * a * b * c == p * (b * c + a * c + a * b),
)
report(
    "residual-thirty-one exterior progression",
    d % 620 == 395
    and p % 22_320 == 14_209
    and u == a // 20
    and b == p * (p + 31) * (p + 20) // 2_480
    and c == (p + 31) * (p + 20) // 124,
)

print(f"p={p}")
print(f"d={d}")
print(f"Fingers={fingers}")
print(f"empty residuals={empty_residuals}")
print(f"R=31 exterior={exterior_31}")
print(f"R=31 middle={middle_31}")
print(f"N={N}")
print(f"D={D}")
print(f"N^2/D={complement}")
print(f"(a,b,c)=({a},{b},{c})")

from collections import Counter
from itertools import product
from pathlib import Path


p = 12289
R = 11
a = 3075
v = (3, 6, 3)
U_matrix = (
    (0, 0, 1),
    (1, 0, 0),
    (0, 1, 0),
)
S0_matrix = (
    (0, 0, 1),
    (0, 1, 0),
    (1, 0, 0),
)
K0_matrix = (
    (1, 0, 0),
    (0, 0, 1),
    (0, 1, 0),
)


def matmul(left, right):
    return tuple(
        tuple(
            sum(left[row][inner] * right[inner][column] for inner in range(3))
            for column in range(3)
        )
        for row in range(3)
    )


def matvec(matrix, vector):
    return tuple(
        sum(matrix[row][column] * vector[column] for column in range(3))
        for row in range(3)
    )


def determinant(matrix):
    return (
        matrix[0][0]
        * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1]
        * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2]
        * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
    )


I3 = (
    (1, 0, 0),
    (0, 1, 0),
    (0, 0, 1),
)


def generated_matrix_group(generators):
    group = {I3}
    frontier = [I3]
    while frontier:
        current = frontier.pop()
        for generator in generators:
            candidate = matmul(current, generator)
            if candidate not in group:
                group.add(candidate)
                frontier.append(candidate)
    return group


def matrix_order(matrix):
    power = I3
    for order in range(1, 13):
        power = matmul(power, matrix)
        if power == I3:
            return order
    raise AssertionError("matrix order exceeds the exact search bound")


finite_carrier = tuple(product(range(3), range(2)))
finite_identity = (0, 0)


def commuting_product(left, right):
    return ((left[0] + right[0]) % 3, (left[1] + right[1]) % 2)


def reflected_product(left, right):
    return (
        (left[0] + (-1) ** left[1] * right[0]) % 3,
        (left[1] + right[1]) % 2,
    )


def finite_order(element, multiplication):
    power = finite_identity
    for order in range(1, 13):
        power = multiplication(power, element)
        if power == finite_identity:
            return order
    raise AssertionError("finite-carrier order exceeds the exact search bound")


commuting_orders = Counter(
    finite_order(element, commuting_product) for element in finite_carrier
)
reflected_orders = Counter(
    finite_order(element, reflected_product) for element in finite_carrier
)
if commuting_orders != Counter({6: 2, 3: 2, 2: 1, 1: 1}):
    raise AssertionError(f"commuting C3-by-C2 element orders: {commuting_orders}")
if reflected_orders != Counter({2: 3, 3: 2, 1: 1}):
    raise AssertionError(f"reflected C3-by-C2 element orders: {reflected_orders}")
if finite_order((1, 1), commuting_product) != 6:
    raise AssertionError("the commuting carrier lacks its order-six generator")
if any(
    reflected_product(left, right) != reflected_product(right, left)
    for left in finite_carrier
    for right in finite_carrier
) is False:
    raise AssertionError("the reflected carrier must be noncommutative")


Uv = matvec(U_matrix, v)
U2v = matvec(U_matrix, Uv)
M = tuple(tuple(column[row] for column in (v, Uv, U2v)) for row in range(3))
if M != ((3, 3, 6), (6, 3, 3), (3, 6, 3)):
    raise AssertionError(f"orbit matrix: {M}")
if determinant(M) != 108:
    raise AssertionError(f"orbit-matrix determinant: {determinant(M)}")
if matmul(U_matrix, M) != matmul(M, U_matrix):
    raise AssertionError("U M differs from M U")
if matmul(S0_matrix, M) != matmul(M, K0_matrix):
    raise AssertionError("S0 M differs from M K0")

ambient_group = generated_matrix_group((U_matrix, S0_matrix))
ambient_orders = Counter(matrix_order(matrix) for matrix in ambient_group)
if len(ambient_group) != 6:
    raise AssertionError(f"ambient group cardinality: {len(ambient_group)}")
if ambient_orders != Counter({2: 3, 3: 2, 1: 1}):
    raise AssertionError(f"ambient element orders: {ambient_orders}")
if matmul(S0_matrix, matmul(U_matrix, S0_matrix)) != matmul(
    U_matrix, U_matrix
):
    raise AssertionError("ambient reflection does not invert the rotation")


def target(j):
    if j == 0:
        return (-p) % R
    if j == 1:
        return (-1) % R
    if j == 2:
        return (-pow(p, -1, R)) % R
    raise ValueError(j)


divisors = sorted(
    3**e3 * 5**e5 * 41**e41
    for e3, e5, e41 in product(range(3), range(5), range(3))
)
a_inverse = pow(a, -1, R)
X = tuple(
    (j, u)
    for j in range(3)
    for u in divisors
    if (u * a_inverse) % R == target(j)
)
if len(X) != 12:
    raise AssertionError(f"certificate-set cardinality: {len(X)}")


def iota(x):
    j, u = x
    return (2 - j, a * a // u)


if any(iota(x) == x for x in X):
    raise AssertionError("the arithmetic involution must be fixed-point-free")

O = (v, Uv, U2v)
O_index = {point: index for index, point in enumerate(O)}
X_index = {point: index for index, point in enumerate(X)}


def U_point(point):
    return matvec(U_matrix, point)


def S0_point(point):
    return matvec(S0_matrix, point)


def product_r(pair):
    x, point = pair
    return (x, U_point(point))


def product_s(pair):
    x, point = pair
    return (iota(x), S0_point(point))


product_basis = tuple((x, point) for x in X for point in O)
if len(product_basis) != 36:
    raise AssertionError("product basis must have 36 elements")


def cycle_lengths(permutation, basis):
    unseen = set(basis)
    lengths = []
    while unseen:
        start = next(iter(unseen))
        current = start
        length = 0
        while True:
            unseen.remove(current)
            length += 1
            current = permutation(current)
            if current == start:
                break
        lengths.append(length)
    return tuple(sorted(lengths))


rotation_cycles = cycle_lengths(product_r, product_basis)
reflection_cycles = cycle_lengths(product_s, product_basis)
if rotation_cycles != (3,) * 12:
    raise AssertionError(f"rotation cycles: {rotation_cycles}")
if reflection_cycles != (2,) * 18:
    raise AssertionError(f"reflection cycles: {reflection_cycles}")

arithmetic_basis = X
coordinate_basis = O
arithmetic_rotation_cycles = cycle_lengths(lambda x: x, arithmetic_basis)
arithmetic_reflection_cycles = cycle_lengths(iota, arithmetic_basis)
coordinate_rotation_cycles = cycle_lengths(U_point, coordinate_basis)
coordinate_reflection_cycles = cycle_lengths(S0_point, coordinate_basis)
if arithmetic_rotation_cycles != (1,) * 12:
    raise AssertionError("arithmetic rotation must act identically")
if arithmetic_reflection_cycles != (2,) * 6:
    raise AssertionError("arithmetic reflection must have six transpositions")
if coordinate_rotation_cycles != (3,):
    raise AssertionError("coordinate rotation must be one three-cycle")
if coordinate_reflection_cycles != (1, 2):
    raise AssertionError("coordinate reflection must fix one point")

chi_X = (12, 12, 0)
chi_O = (3, 0, 1)
chi_product = tuple(left * right for left, right in zip(chi_X, chi_O))
if chi_product != (36, 0, 0):
    raise AssertionError(f"product character: {chi_product}")

class_sizes = (1, 2, 3)
irreducibles = {
    "trivial": (1, 1, 1),
    "sign": (1, 1, -1),
    "standard": (2, -1, 0),
}
multiplicities = {}
for name, character in irreducibles.items():
    numerator = sum(
        size * value * irreducible_value
        for size, value, irreducible_value in zip(
            class_sizes, chi_product, character
        )
    )
    if numerator % 6:
        raise AssertionError(f"nonintegral multiplicity numerator for {name}")
    multiplicities[name] = numerator // 6
if multiplicities != {"trivial": 6, "sign": 6, "standard": 12}:
    raise AssertionError(f"irreducible multiplicities: {multiplicities}")

# Index-level verification of the two Kronecker actions.
for x, point in product_basis:
    x_index = X_index[x]
    point_index = O_index[point]
    r_image = product_r((x, point))
    expected_r_indices = (x_index, (point_index + 1) % 3)
    actual_r_indices = (X_index[r_image[0]], O_index[r_image[1]])
    if actual_r_indices != expected_r_indices:
        raise AssertionError("rotation differs from I_12 tensor U")

    s_image = product_s((x, point))
    expected_s_indices = (
        X_index[iota(x)],
        {0: 0, 1: 2, 2: 1}[point_index],
    )
    actual_s_indices = (X_index[s_image[0]], O_index[s_image[1]])
    if actual_s_indices != expected_s_indices:
        raise AssertionError("reflection differs from P_iota tensor K0")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{prop:C3-C2-two-couplings}",
    r"\label{eq:C3-C2-commuting-product}",
    r"\label{eq:C3-C2-reflected-product}",
    r"\label{eq:Tong-Standard-Model-Z6-generator}",
    r"\label{cor:12289-singular-orbit-six-element-action}",
    r"\label{eq:12289-singular-orbit-D3-relations}",
    r"\label{eq:12289-singular-orbit-D3-elements}",
    r"\label{eq:12289-singular-orbit-element-orders}",
    r"\label{thm:12289-synthetic-D3-permutation-representation}",
    r"\label{eq:12289-cover-rotation-Kronecker}",
    r"\label{eq:12289-cover-reflection-Kronecker}",
    r"\label{eq:12289-two-factor-permutation-actions}",
    r"\label{eq:12289-cover-regular-decomposition}",
    r"\label{eq:12289-product-permutation-characters}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact 36-dimensional D3 permutation representation",
            "S0 M_12289 = M_12289 K0 and det(M_12289) = 108",
            "ambient count-orbit group = D3 with element orders 1^1, 2^3, 3^2",
            "no ambient count-orbit element has order 6",
            "common C3-by-C2 carrier: commuting law = C6 with two order-six elements",
            "common C3-by-C2 carrier: inversion law = D3 with no order-six element",
            "rotation operator = I_12 tensor U with 12 three-cycles",
            "reflection operator = P_iota tensor K0 with 18 transpositions",
            "rotation characteristic polynomial = (t^3-1)^12",
            "reflection characteristic polynomial = (t^2-1)^18",
            "permutation character on (1, 3-cycles, reflections) = (36,0,0)",
            "irreducible multiplicities = 6 trivial + 6 sign + 12 standard",
            "representation = 6 copies of the regular D3 representation",
        )
    )
)

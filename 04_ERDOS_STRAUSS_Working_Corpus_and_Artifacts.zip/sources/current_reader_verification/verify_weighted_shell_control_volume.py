#!/usr/bin/env python3
"""Exact checks for the amplitude-weighted shell carrier."""

from fractions import Fraction
from math import prod


def check_weight_system(weights: tuple[Fraction, ...]) -> None:
    q = len(weights)
    assert q >= 1
    assert all(alpha > 0 for alpha in weights)

    spectrum: list[Fraction] = []
    scalar_spectrum: list[Fraction] = []
    for alpha in weights:
        spectrum.extend([4 * alpha] * 3)
        spectrum.extend([-alpha] * 3)
        scalar_spectrum.extend([Fraction(3, 2) * alpha] * 6)

    traceless_spectrum = [
        eigenvalue - scalar
        for eigenvalue, scalar in zip(spectrum, scalar_spectrum)
    ]
    expected_traceless: list[Fraction] = []
    for alpha in weights:
        expected_traceless.extend([Fraction(5, 2) * alpha] * 3)
        expected_traceless.extend([-Fraction(5, 2) * alpha] * 3)

    determinant_volume = prod(abs(value) for value in spectrum)
    expected_volume = Fraction(4 ** (3 * q), 1) * prod(
        alpha**6 for alpha in weights
    )
    second_moment = sum((alpha**2 for alpha in weights), Fraction(0, 1))
    hilbert_schmidt_sq = sum(
        (value**2 for value in spectrum), Fraction(0, 1)
    )
    traceless_hilbert_schmidt_sq = sum(
        (value**2 for value in traceless_spectrum), Fraction(0, 1)
    )

    assert len(spectrum) == 6 * q
    assert traceless_spectrum == expected_traceless
    assert sum(traceless_spectrum, Fraction(0, 1)) == 0
    assert determinant_volume == expected_volume
    assert hilbert_schmidt_sq == 51 * second_moment
    assert traceless_hilbert_schmidt_sq == Fraction(75, 2) * second_moment

    # This is the squared, q-th-power form of geometric mean <= RMS:
    # (prod alpha)^(2/q) <= (sum alpha^2)/q.
    assert prod(weights) ** 2 <= (second_moment / q) ** q


for q in range(1, 6):
    check_weight_system(
        tuple(Fraction(index + 1, q + 2) for index in range(q))
    )

weights_12289 = (
    Fraction(61445, 943902729),
    Fraction(184335, 339886096),
    Fraction(615, 94864),
    Fraction(921675, 38217124),
    Fraction(123, 484),
    Fraction(1025, 1089),
)
check_weight_system(weights_12289)

uniform = (Fraction(1, 1),) * 6
uniform_second_moment = sum((a * a for a in uniform), Fraction(0, 1))
assert prod(uniform) ** 2 == (uniform_second_moment / len(uniform)) ** len(
    uniform
)

print("PASS weighted spectrum is {(4 alpha_O)^[3], (-alpha_O)^[3]} orbitwise")
print("PASS determinant volume is 4^(3q) times product alpha_O^6")
print("PASS weighted Hilbert--Schmidt length squared is 51 sum alpha_O^2")
print("PASS orbitwise traceless length squared is (75/2) sum alpha_O^2")
print("PASS sharp determinant-volume bound is geometric mean <= RMS")
print("PASS equality holds for the uniform amplitude system")
print("PASS exact 12289 six-orbit amplitudes satisfy every identity")

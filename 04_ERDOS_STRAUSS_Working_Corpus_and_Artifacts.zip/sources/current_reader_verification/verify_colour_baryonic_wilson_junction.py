from itertools import permutations, product

from sympy import Matrix, expand, symbols


def epsilon(i, j, k):
    if len({i, j, k}) < 3:
        return 0
    values = (i, j, k)
    inversions = sum(
        values[a] > values[b] for a in range(3) for b in range(a + 1, 3)
    )
    return -1 if inversions % 2 else 1


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


nonzero_triples = {
    triple for triple in product(range(3), repeat=3) if epsilon(*triple)
}
report(
    "alternating tensor uses every Colour exactly once",
    nonzero_triples == set(permutations(range(3))),
)

g_symbols = symbols("g00:03 g10:13 g20:23")
g = Matrix(3, 3, g_symbols)
det_g = expand(g.det())

covariance_holds = True
for i, j, k in product(range(3), repeat=3):
    lhs = sum(
        epsilon(a, b, c) * g[i, a] * g[j, b] * g[k, c]
        for a, b, c in product(range(3), repeat=3)
    )
    rhs = det_g * epsilon(i, j, k)
    covariance_holds &= expand(lhs - rhs) == 0
report("generic determinant covariance of the Colour volume form", covariance_holds)


def baryonic_contraction(u1, u2, u3):
    total = 0
    for a, b, c, ap, bp, cp in product(range(3), repeat=6):
        total += (
            epsilon(a, b, c)
            * epsilon(ap, bp, cp)
            * u1[a, ap]
            * u2[b, bp]
            * u3[c, cp]
        )
    return total / 6


g_left = Matrix([[1, 2, -1], [0, 1, 3], [0, 0, 1]])
g_right = Matrix([[1, 0, 0], [-2, 1, 0], [1, 4, 1]])
u1 = Matrix([[2, 1, 0], [-1, 3, 2], [4, 0, 1]])
u2 = Matrix([[1, -2, 3], [0, 2, 1], [5, 1, -1]])
u3 = Matrix([[3, 0, 1], [2, -1, 4], [0, 5, 2]])

report("left gauge matrix has determinant one", g_left.det() == 1)
report("right gauge matrix has determinant one", g_right.det() == 1)

transformed = [
    g_left * u * g_right.inv()
    for u in (u1, u2, u3)
]
report(
    "exact baryonic Wilson contraction is endpoint-gauge invariant",
    baryonic_contraction(*transformed) == baryonic_contraction(u1, u2, u3),
)

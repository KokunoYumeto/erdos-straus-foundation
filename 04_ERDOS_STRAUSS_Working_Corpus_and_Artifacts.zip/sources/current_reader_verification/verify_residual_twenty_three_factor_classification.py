from collections import Counter
import hashlib
from itertools import combinations_with_replacement, product
from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


MODULUS = 22
EXTERIOR_TARGETS = (7, 13, 19)
MIDDLE_TARGETS = (5, 11, 17)
FULL_MASK = (1 << MODULUS) - 1
EXPECTED_LOW_DEGREE_PROFILE = {1: 6, 2: 44}
EXPECTED_LOW_DEGREE_HASH = (
    "3f9c363f28a56953fe396adb70d2fb17fdb03f70d0117c8e5bda6570bfe13bc2"
)
EXPECTED_MIXED_SAFE_COUNT = 82
EXPECTED_MIXED_MAXIMAL_COUNT = 25
EXPECTED_MIXED_MAXIMAL_HASH = (
    "c854a92934205485e9ff4ff440ff2cb107f1fc0666ded9d8a554fead9e3393a8"
)
EXPECTED_DEGREE_TWO = {
    (1, 3), (1, 4), (1, 6), (1, 9), (1, 10), (1, 12),
    (1, 14), (1, 16), (1, 18), (1, 20), (2, 3), (2, 9),
    (2, 15), (3, 4), (3, 8), (3, 10), (3, 14), (3, 16),
    (3, 20), (4, 9), (4, 15), (4, 21), (6, 21), (8, 9),
    (8, 21), (9, 10), (9, 14), (9, 16), (9, 18), (9, 20),
    (9, 21), (10, 15), (10, 21), (12, 15), (12, 21),
    (14, 15), (14, 21), (15, 18), (15, 20), (15, 21),
    (16, 21), (18, 21), (20, 21), (21, 21),
}
EXPECTED_ODD_MAXIMAL = (
    (0, 0, 0, 6, 0),
    (0, 0, 1, 1, 0),
    (0, 1, 0, 0, 1),
    (0, 2, 2, 0, 0),
    (0, 3, 0, 1, 0),
    (0, 5, 1, 0, 0),
    (0, 8, 0, 0, 0),
    (1, 0, 0, 3, 0),
    (3, 0, 0, 0, 1),
)


def rotate(mask, shift):
    shift %= MODULUS
    if shift == 0:
        return mask
    return (
        (mask << shift)
        | (mask >> (MODULUS - shift))
    ) & FULL_MASK


reachability_cache = {(): (1, 1)}


def reachability(logs):
    cached = reachability_cache.get(logs)
    if cached is not None:
        return cached
    exterior, middle = reachability(logs[:-1])
    logarithm = logs[-1]
    result = (
        exterior
        | rotate(exterior, logarithm)
        | rotate(exterior, 2 * logarithm),
        rotate(middle, -logarithm)
        | middle
        | rotate(middle, logarithm),
    )
    reachability_cache[logs] = result
    return result


def hits(mask, targets):
    return any(mask & (1 << target) for target in targets)


def occupied_logs(logs):
    exterior, middle = reachability(logs)
    return (
        hits(exterior, EXTERIOR_TARGETS)
        or hits(middle, MIDDLE_TARGETS)
    )


def one_term_deletions(logs):
    return {
        logs[:index] + logs[index + 1 :]
        for index in range(len(logs))
    }


low_degree_minimal = set()
for degree in (1, 2):
    for logs in combinations_with_replacement(range(1, MODULUS), degree):
        if (
            occupied_logs(logs)
            and all(
                not occupied_logs(row)
                for row in one_term_deletions(logs)
            )
        ):
            low_degree_minimal.add(logs)


profile = Counter(map(len, low_degree_minimal))
canonical = "\n".join(
    ",".join(map(str, row))
    for row in sorted(
        low_degree_minimal,
        key=lambda row: (len(row), row),
    )
)
canonical_hash = hashlib.sha256(canonical.encode()).hexdigest()


POWER_RESIDUES = tuple(pow(5, exponent, 23) for exponent in range(1, 22))
LOG_OF_RESIDUE = {
    residue: exponent
    for exponent, residue in enumerate(POWER_RESIDUES, 1)
}


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for divisor in range(3, isqrt(n) + 1, 2):
        if n % divisor == 0:
            return False
    return True


def factorization(n):
    factors = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            n //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor += 1 if divisor == 2 else 2
    if n > 1:
        factors.append((n, 1))
    return tuple(factors)


def divisors_from_factorization(factors):
    values = [1]
    for prime, exponent in factors:
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(values)


def log_multiset(n):
    logs = []
    for prime, exponent in factorization(n):
        logarithm = LOG_OF_RESIDUE.get(prime % 23, 0)
        if logarithm:
            logs.extend([logarithm] * exponent)
    return tuple(sorted(logs))


def fixed_target_occupied(n):
    return occupied_logs(log_multiset(n))


def moving_target_occupied(n):
    logs = log_multiset(n)
    _, middle = reachability(logs)
    total_log = sum(logs) % MODULUS
    rho = (total_log - 2) % MODULUS
    moving_targets = set(MIDDLE_TARGETS)
    moving_targets.update(
        (target - rho) % MODULUS
        for target in MIDDLE_TARGETS
    )
    return hits(middle, moving_targets)


def exterior_count(n):
    square_factors = tuple(
        (prime, 2 * exponent)
        for prime, exponent in factorization(n)
    )
    return sum(
        (4 * divisor + 1) % 23 == 0
        for divisor in divisors_from_factorization(square_factors)
    )


def middle_coefficient(n):
    values = divisors_from_factorization(factorization(n))
    return sum(
        gcd(left, right) == 1
        and n % (left * right) == 0
        and (left + right) % 23 == 0
        for left in values
        for right in values
    )


report(
    "R=23 primitive logarithm",
    len(set(POWER_RESIDUES)) == 21
    and pow(5, 11, 23) == 22
    and LOG_OF_RESIDUE[2] == 2,
)

moving_rows = []
integer_rows = []
for value in range(1, 3001):
    if value % 23 == 0:
        continue
    fixed = fixed_target_occupied(value)
    moving_rows.append(fixed == moving_target_occupied(value))
    denominator = 3 * value
    actual = (
        exterior_count(denominator)
        + middle_coefficient(denominator) // 2
        > 0
    )
    integer_rows.append(actual == fixed)

report(
    "R=23 fixed and moving logarithmic targets",
    all(moving_rows),
)
report(
    "R=23 classification on coprime reduced coordinates",
    all(integer_rows),
)


prime_rows = []
for prime in range(13, 20001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    reduced = (prime + 23) // 12
    denominator = 3 * reduced
    actual = (
        exterior_count(denominator)
        + middle_coefficient(denominator) // 2
        > 0
    )
    prime_rows.append(actual == fixed_target_occupied(reduced))

report(
    "R=23 affine prime-shell classification",
    all(prime_rows),
)


degree_one = {
    row
    for row in low_degree_minimal
    if len(row) == 1
}
report(
    "R=23 degree-one carriers",
    degree_one == {
        (5,), (7,), (11,), (13,), (17,), (19,)
    },
)

degree_two = tuple(
    row
    for row in sorted(low_degree_minimal)
    if len(row) == 2
)
report(
    "R=23 degree-two carriers and low-degree hash",
    set(degree_two) == EXPECTED_DEGREE_TWO
    and dict(profile) == EXPECTED_LOW_DEGREE_PROFILE
    and canonical_hash == EXPECTED_LOW_DEGREE_HASH,
)

ODD_SAFE_LOGS = (1, 3, 9, 15, 21)
ODD_SAFE_LIMITS = (3, 8, 2, 6, 1)
odd_safe_vectors = []
for exponents in product(
    *(
        range(limit + 1)
        for limit in ODD_SAFE_LIMITS
    )
):
    logs = tuple(
        logarithm
        for logarithm, exponent in zip(ODD_SAFE_LOGS, exponents)
        for _ in range(exponent)
    )
    if not occupied_logs(logs):
        odd_safe_vectors.append(exponents)


def increment(vector, index):
    return tuple(
        value + (position == index)
        for position, value in enumerate(vector)
    )


odd_safe_set = set(odd_safe_vectors)
odd_maximal = tuple(
    vector
    for vector in sorted(odd_safe_vectors)
    if all(
        increment(vector, index) not in odd_safe_set
        for index in range(len(vector))
    )
)

report(
    "R=23 odd-sector maximal safe vectors",
    len(odd_safe_vectors) == 39
    and odd_maximal == EXPECTED_ODD_MAXIMAL,
)

NONZERO_EVEN_LOGS = tuple(range(2, MODULUS, 2))
even_coupling_rows = []
for odd_logarithm, first_forbidden_even_count in (
    (1, 3),
    (3, 4),
    (9, 3),
    (15, 3),
    (21, 3),
):
    even_coupling_rows.extend(
        occupied_logs(
            tuple(sorted((odd_logarithm,) + even_logs))
        )
        for even_logs in combinations_with_replacement(
            NONZERO_EVEN_LOGS,
            first_forbidden_even_count,
        )
    )

report(
    "R=23 odd-even coupling bounds",
    all(even_coupling_rows),
)

PROFILE_LOGS = ODD_SAFE_LOGS + NONZERO_EVEN_LOGS


def profile_logs(profile):
    return tuple(
        logarithm
        for logarithm, exponent in zip(PROFILE_LOGS, profile)
        for _ in range(exponent)
    )


even_profiles = []
for degree in range(4):
    for row in combinations_with_replacement(NONZERO_EVEN_LOGS, degree):
        counts = Counter(row)
        even_profiles.append(
            tuple(counts[logarithm] for logarithm in NONZERO_EVEN_LOGS)
        )

mixed_safe_vectors = []
for odd_profile in odd_safe_vectors:
    if not any(odd_profile):
        continue
    even_bound = (
        3
        if odd_profile[0] == odd_profile[2] == odd_profile[3]
        == odd_profile[4] == 0
        else 2
    )
    for even_profile in even_profiles:
        if sum(even_profile) > even_bound:
            continue
        full_profile = odd_profile + even_profile
        if not occupied_logs(profile_logs(full_profile)):
            mixed_safe_vectors.append(full_profile)

mixed_maximal = tuple(
    profile
    for profile in sorted(mixed_safe_vectors)
    if all(
        occupied_logs(profile_logs(increment(profile, index)))
        for index in range(len(profile))
    )
)
mixed_serialized = "\n".join(
    ",".join(str(value) for value in profile)
    for profile in mixed_maximal
)
mixed_hash = hashlib.sha256(mixed_serialized.encode("ascii")).hexdigest()
mixed_maximal_multisets = tuple(
    (
        tuple(
            logarithm
            for logarithm, exponent in zip(
                ODD_SAFE_LOGS,
                full_profile[:len(ODD_SAFE_LOGS)],
            )
            for _ in range(exponent)
        ),
        tuple(
            logarithm
            for logarithm, exponent in zip(
                NONZERO_EVEN_LOGS,
                full_profile[len(ODD_SAFE_LOGS):],
            )
            for _ in range(exponent)
        ),
    )
    for full_profile in mixed_maximal
)

report(
    "R=23 complete odd-bearing survivor down-set",
    len(mixed_safe_vectors) == EXPECTED_MIXED_SAFE_COUNT
    and len(mixed_maximal) == EXPECTED_MIXED_MAXIMAL_COUNT
    and mixed_hash == EXPECTED_MIXED_MAXIMAL_HASH,
)

print(f"odd-sector safe vectors: {len(odd_safe_vectors)}")
print(f"odd-sector maximal vectors: {odd_maximal}")
print(f"odd-bearing safe profiles: {len(mixed_safe_vectors)}")
print(f"odd-bearing maximal profiles: {len(mixed_maximal)}")
print(f"odd-bearing maximal multisets: {mixed_maximal_multisets}")
print(f"odd-bearing maximal SHA-256: {mixed_hash}")
print(f"low-degree minimal generators: {len(low_degree_minimal)}")
print(f"low-degree profile: {dict(sorted(profile.items()))}")
print(f"degree-two generators: {degree_two}")
print(f"low-degree canonical SHA-256: {canonical_hash}")
print(f"coprime reduced coordinates checked: {len(integer_rows)}")
print(f"affine prime shells checked: {len(prime_rows)}")

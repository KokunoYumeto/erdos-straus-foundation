from fractions import Fraction
from math import prod

import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


# Symbolic character, Lorentz mass, and rapidity identities.
alpha_1, alpha_2 = sp.symbols("alpha_1 alpha_2", positive=True)
lambda_plus = alpha_2 + alpha_1 / 2
lambda_minus = alpha_2 - alpha_1 / 2
require(
    sp.factor(lambda_plus**2 - lambda_minus**2 - 2 * alpha_1 * alpha_2)
    == 0,
    "target Lorentz mass",
)
require(
    sp.factor(
        (lambda_plus + lambda_minus) / (lambda_plus - lambda_minus)
        - 2 * alpha_2 / alpha_1
    )
    == 0,
    "target rapidity exponential",
)
require(
    sp.factor(lambda_minus - (2 * alpha_2 - alpha_1) / 2) == 0,
    "signed origin trace",
)

# The logarithmic-radius expression and monotonicity below N.
N, d = sp.symbols("N d", positive=True)
weight = 4 * N * d / (N + d) ** 2
x = sp.symbols("x", positive=True)
weight_in_square_root_ratio = sp.factor(weight.subs(d, N * x**2))
log_weight = 1 / sp.cosh(sp.log(x)) ** 2
require(
    sp.simplify(
        (log_weight - weight_in_square_root_ratio).rewrite(sp.exp)
    )
    == 0,
    "log-radius weight",
)
require(
    sp.factor(sp.diff(weight, d) - 4 * N * (N - d) / (N + d) ** 3) == 0,
    "weight derivative",
)
require(
    sp.factor(weight.subs(d, N**2 / d) - weight) == 0,
    "complement weight invariance",
)

# Exact 12289 orbit representatives and signed common denominator.
p_exact = 12289
a_exact = 3075
N_exact = p_exact * a_exact
exterior = [615, 5125, 230625]
middle = [61445, 2765025, 23041875]
require(
    all(e < h for e, h in zip(exterior, middle)),
    "12289 componentwise radial order",
)


def rational_weight(value):
    return Fraction(4 * N_exact * value, (N_exact + value) ** 2)


alpha_2_exact = sum((rational_weight(value) for value in exterior), Fraction())
half_alpha_1_exact = sum(
    (rational_weight(value) for value in middle), Fraction()
)
lambda_minus_exact = alpha_2_exact - half_alpha_1_exact
require(
    lambda_minus_exact
    == -Fraction(14143643992119252, 12015450198070081),
    "12289 signed trace",
)

representatives = exterior + middle
common_denominator = prod((N_exact + value) ** 2 for value in representatives)
signed_numerator = sum(
    (1 if value in exterior else -1)
    * 4
    * N_exact
    * value
    * (common_denominator // (N_exact + value) ** 2)
    for value in representatives
)
require(
    Fraction(signed_numerator, common_denominator) == lambda_minus_exact,
    "integer numerator criterion",
)
require(signed_numerator < 0, "12289 integer numerator sign")

rapidity_exponential = alpha_2_exact / half_alpha_1_exact
require(
    rapidity_exponential
    == Fraction(
        5176199252561022635,
        251615052171246869483,
    ),
    "12289 rapidity exponential",
)

lines = [
    "PASS: signed orbit trace and target rapidity",
    "lambda_minus is the C2-signed complement-orbit amplitude trace",
    "twice lambda_minus is the alternating three-origin amplitude trace",
    "each divisor weight is sech^2 of half its logarithmic radius",
    "the divisor weight is invariant under d -> N^2/d",
    "the divisor weight is strictly increasing below N",
    "the common-denominator integer has the sign of lambda_minus",
    "the target Lorentz mass squared is 2 alpha_1 alpha_2",
    "the rapidity exponential is 2 alpha_2/alpha_1",
    "the exact 12289 representatives are componentwise radially ordered",
    "the exact 12289 signed trace is negative",
    "the exact 12289 rapidity exponential is recorded",
]

print("\n".join(lines))

#!/usr/bin/env python3
"""Exact certificate for the endpoint/equalizer scheme isomorphism."""

from fractions import Fraction as Q


def trim(poly):
    result = list(poly)
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    return tuple(result)


def add(left, right):
    size = max(len(left), len(right))
    return trim(
        tuple(
            (left[i] if i < len(left) else Q(0))
            + (right[i] if i < len(right) else Q(0))
            for i in range(size)
        )
    )


def scale(poly, scalar):
    return trim(tuple(Q(scalar) * coefficient for coefficient in poly))


def multiply(left, right):
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            result[i + j] += a * b
    return trim(tuple(result))


def affine_compose(outer, inner):
    """Compose a0+a1*x with b0+b1*x."""
    a0, a1 = outer
    b0, b1 = inner
    return (a0 + a1 * b0, a1 * b1)


def reduce_endpoint(poly):
    """Reduce modulo s(s-1), hence s^k=s for every k >= 1."""
    return trim((poly[0], sum(poly[1:], Q(0))))


def require(label, assertion):
    if not assertion:
        raise AssertionError(label)
    print(f"{label}: PASS")


one = (Q(1),)
x = (Q(0), Q(1))
u_of_s = (Q(-1, 2), Q(3, 2))
s_of_u = (Q(1, 3), Q(2, 3))

u_minus_one = add(u_of_s, (Q(-1),))
two_u_plus_one = add(scale(u_of_s, 2), one)
s_relation = multiply(x, add(x, (Q(-1),)))
require(
    "endpoint relation maps to the equalizer relation",
    multiply(u_minus_one, two_u_plus_one) == scale(s_relation, Q(9, 2)),
)

s_minus_one = add(s_of_u, (Q(-1),))
u_relation = multiply(add(scale(x, 2), one), add(x, (Q(-1),)))
require(
    "equalizer relation maps to the endpoint relation",
    multiply(s_of_u, s_minus_one) == scale(u_relation, Q(2, 9)),
)
require(
    "the affine substitutions are inverse on s",
    affine_compose(s_of_u, u_of_s) == x,
)
require(
    "the affine substitutions are inverse on u",
    affine_compose(u_of_s, s_of_u) == x,
)

w_of_s = scale(multiply(u_of_s, add(one, u_of_s)), -1)
require(
    "the pulled-back common value is (1-9s^2)/4",
    w_of_s == (Q(1, 4), Q(0), Q(-9, 4)),
)
require(
    "the two representatives agree modulo s(s-1)",
    reduce_endpoint(w_of_s) == (Q(1, 4), Q(-9, 4)),
)

endpoint_chain = {
    Q(0): (Q(-1, 2), Q(1, 4)),
    Q(1): (Q(1), Q(-2)),
}
for endpoint, expected in endpoint_chain.items():
    u_value = Q(3 * endpoint - 1, 2)
    w_value = -u_value * (1 + u_value)
    require(
        f"endpoint {endpoint} has the stated component chain",
        (u_value, w_value) == expected,
    )

reflection = (Q(1), Q(-1))
require(
    "endpoint reflection transports to u -> 1/2-u",
    affine_compose(u_of_s, reflection) == add((Q(1, 2),), scale(u_of_s, -1)),
)

w_linear = reduce_endpoint(w_of_s)
require(
    "endpoint reflection transports to w -> -w-7/4",
    affine_compose(w_linear, reflection)
    == add((Q(-7, 4),), scale(w_linear, -1)),
)
require(
    "centered endpoint product is the oriented Fable quarter",
    Q(-1, 2) * Q(1, 2) == -Q(1, 4),
)

"""Bounded exact census of hidden target-incidence matrices.

The scan treats the hard prime locus p = 1 (mod 24).  For each shell
R = 3 (mod 4), the exterior and middle exponent alphabets give the
two-by-two target-incidence matrix Xi.  An empty shell has zero diagonal,
so its only possible matrices are 0, E12, E21, and S.
"""

from collections import Counter
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


LIMIT = 1_000_000
MAX_RESIDUAL = 107
RESIDUALS = tuple(range(3, MAX_RESIDUAL + 1, 4))

ZERO = ((0, 0), (0, 0))
E12 = ((0, 1), (0, 0))
E21 = ((0, 0), (1, 0))
S = ((0, 1), (1, 0))
EMPTY_NAMES = {ZERO: "0", E12: "E12", E21: "E21", S: "S"}


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return tuple(value for value in range(2, limit + 1) if sieve[value])


def smallest_prime_factors(limit):
    spf = list(range(limit + 1))
    if limit >= 1:
        spf[1] = 1
    for prime in range(2, isqrt(limit) + 1):
        if spf[prime] == prime:
            for value in range(prime * prime, limit + 1, prime):
                if spf[value] == value:
                    spf[value] = prime
    return spf


def factor_multiset(value, spf):
    factors = []
    while value > 1:
        prime = spf[value]
        factors.append(prime)
        value //= prime
    return tuple(factors)


def reachability(modulus, factors, alphabet):
    values = {1}
    for prime in factors:
        residue = prime % modulus
        local = tuple(pow(residue, exponent, modulus) for exponent in alphabet)
        values = {
            left * right % modulus
            for left in values
            for right in local
        }
    return frozenset(values)


def incidence(modulus, factors):
    exterior = reachability(modulus, factors, (0, 1, 2))
    middle = reachability(modulus, factors, (-1, 0, 1))
    quarter_target = -pow(4, -1, modulus) % modulus
    minus_target = modulus - 1
    return (
        (int(quarter_target in exterior), int(minus_target in exterior)),
        (int(quarter_target in middle), int(minus_target in middle)),
    )


def complete_divisor_incidence(modulus, denominator, factors):
    prime_exponents = Counter(factors)
    divisor_residues = {1}
    for prime, exponent in prime_exponents.items():
        local = tuple(pow(prime, power, modulus) for power in range(2 * exponent + 1))
        divisor_residues = {
            left * right % modulus
            for left in divisor_residues
            for right in local
        }
    relative_middle = {
        residue * pow(denominator, -1, modulus) % modulus
        for residue in divisor_residues
    }
    quarter_target = -pow(4, -1, modulus) % modulus
    minus_target = modulus - 1
    return (
        (int(quarter_target in divisor_residues), int(minus_target in divisor_residues)),
        (int(quarter_target in relative_middle), int(minus_target in relative_middle)),
    )


def integer_divisors(factors, doubled=False):
    prime_exponents = Counter(factors)
    values = [1]
    for prime, exponent in prime_exponents.items():
        if doubled:
            exponent *= 2
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(sorted(values))


def primitive_quarter_pairs(modulus, denominator, factors):
    divisors = integer_divisors(factors)
    target = -pow(4, -1, modulus) % modulus
    return tuple(
        (numerator, denominator_part)
        for numerator in divisors
        for denominator_part in divisors
        if gcd(numerator, denominator_part) == 1
        and denominator % (numerator * denominator_part) == 0
        and numerator * pow(denominator_part, -1, modulus) % modulus == target
    )


def occupied(matrix):
    return bool(matrix[0][0] or matrix[1][1])


primes = tuple(prime for prime in primes_up_to(LIMIT) if prime % 24 == 1)
spf = smallest_prime_factors((LIMIT + MAX_RESIDUAL) // 4)

all_empty = Counter()
pre_occupancy_empty = Counter()
first_hidden_kind = Counter()
first_hidden_residual = Counter()
first_occupied_residual = Counter()
hidden_to_occupied_gap = Counter()
nonzero_path = Counter()
first_example = {}
records = {}
first_occupied_matrix = Counter()
hidden_to_occupied_matrix = Counter()
quarter_pair_types = Counter()
minus_divisor_types = Counter()
quarter_witness_cases = []
minus_divisor_cases = []
all_positive_quarter_pairs = []
all_zero_quarter_pairs = []

for prime in primes:
    shell_path = []
    for residual in RESIDUALS:
        denominator = (prime + residual) // 4
        if 4 * denominator != prime + residual:
            raise AssertionError("nonintegral shell coordinate")
        if gcd(denominator, residual) != 1:
            raise AssertionError("shell coordinate is not a unit modulo R")
        factors = factor_multiset(denominator, spf)
        matrix = incidence(residual, factors)
        if not occupied(matrix):
            if matrix not in EMPTY_NAMES:
                raise AssertionError("empty shell has an unclassified matrix")
            all_empty[EMPTY_NAMES[matrix]] += 1
        shell_path.append((residual, denominator, factors, matrix))

    first_occupied_index = next(
        (index for index, item in enumerate(shell_path) if occupied(item[3])),
        None,
    )
    if first_occupied_index is None:
        raise AssertionError(f"no occupied shell through R=107 for p={prime}")

    occupied_item = shell_path[first_occupied_index]
    occupied_residual = occupied_item[0]
    first_occupied_residual[occupied_residual] += 1
    first_occupied_matrix[repr(occupied_item[3])] += 1

    prefix = shell_path[:first_occupied_index]
    for residual, denominator, factors, matrix in prefix:
        pre_occupancy_empty[EMPTY_NAMES[matrix]] += 1
        if matrix[1][0]:
            pairs = primitive_quarter_pairs(residual, denominator, factors)
            if not pairs:
                raise AssertionError("hidden middle-quarter entry has no factor pair")
            for pair_numerator, pair_denominator in pairs:
                pair_multiplier, pair_remainder = divmod(
                    4 * pair_numerator + pair_denominator, residual
                )
                if pair_remainder:
                    raise AssertionError("primitive quarter pair failed its congruence")
                pair_surplus = residual - pair_numerator - pair_denominator
                pair_record = (
                    prime,
                    residual,
                    EMPTY_NAMES[matrix],
                    pair_numerator,
                    pair_denominator,
                    pair_multiplier,
                    pair_surplus,
                )
                if pair_surplus > 0:
                    all_positive_quarter_pairs.append(pair_record)
                elif pair_surplus == 0:
                    all_zero_quarter_pairs.append(pair_record)
            numerator, denominator_part = min(
                pairs,
                key=lambda pair: (
                    pair[0] * pair[1], pair[0] + pair[1], pair[0], pair[1]
                ),
            )
            multiplier, remainder = divmod(
                4 * numerator + denominator_part, residual
            )
            if remainder:
                raise AssertionError("quarter pair does not give an integral multiple")
            quarter_pair_types[
                (
                    residual,
                    numerator,
                    denominator_part,
                    multiplier,
                    residual - numerator - denominator_part,
                )
            ] += 1
            quarter_witness_cases.append(
                (
                    prime,
                    residual,
                    EMPTY_NAMES[matrix],
                    numerator,
                    denominator_part,
                    multiplier,
                    residual - numerator - denominator_part,
                )
            )
        if matrix[0][1]:
            minus_divisors = tuple(
                divisor
                for divisor in integer_divisors(factors, doubled=True)
                if divisor % residual == residual - 1
            )
            if not minus_divisors:
                raise AssertionError("hidden exterior-minus entry has no divisor")
            least_divisor = min(minus_divisors)
            minus_divisor_types[
                (residual, least_divisor, (least_divisor + 1) // residual)
            ] += 1
            minus_divisor_cases.append(
                (
                    prime,
                    residual,
                    EMPTY_NAMES[matrix],
                    least_divisor,
                    (least_divisor + 1) // residual,
                )
            )

    hidden_prefix = tuple(
        (residual, EMPTY_NAMES[matrix])
        for residual, _, _, matrix in prefix
        if matrix != ZERO
    )
    nonzero_path[tuple(name for _, name in hidden_prefix)] += 1

    if hidden_prefix:
        hidden_residual, hidden_name = hidden_prefix[0]
        first_hidden_kind[hidden_name] += 1
        first_hidden_residual[hidden_residual] += 1
        gap = occupied_residual - hidden_residual
        hidden_to_occupied_gap[gap] += 1
        first_example.setdefault(
            hidden_name,
            (prime, hidden_residual, occupied_residual, gap),
        )
        hidden_to_occupied_matrix[repr(occupied_item[3])] += 1

    records[prime] = (shell_path, hidden_prefix, occupied_item)


# Replay every pre-occupancy shell and the first occupied shell from the
# complete divisor lattice rather than the exponent-alphabet recurrence.
divisor_replay_count = 0
for shell_path, _, occupied_item in records.values():
    first_occupied_index = next(
        index for index, item in enumerate(shell_path) if item is occupied_item
    )
    for residual, denominator, factors, matrix in shell_path[: first_occupied_index + 1]:
        assert complete_divisor_incidence(
            residual, denominator, factors
        ) == matrix
        divisor_replay_count += 1


def matrix_at(prime, residual):
    return next(
        matrix
        for current_residual, _, _, matrix in records[prime][0]
        if current_residual == residual
    )


assert matrix_at(118_801, 19) == E21
assert matrix_at(118_801, 39) == S
assert matrix_at(118_801, 59) == ((1, 1), (1, 1))
assert records[118_801][2][0] == 59
assert matrix_at(3_361, 39) == ((1, 1), (1, 1))

max_gap = max(hidden_to_occupied_gap, default=0)
max_gap_cases = tuple(
    (prime, hidden_prefix[0][0], occupied_item[0])
    for prime, (_, hidden_prefix, occupied_item) in records.items()
    if hidden_prefix and occupied_item[0] - hidden_prefix[0][0] == max_gap
)
multi_step_cases = tuple(
    (prime, hidden_prefix, occupied_item[0], occupied_item[3])
    for prime, (_, hidden_prefix, occupied_item) in records.items()
    if len(hidden_prefix) >= 2
)
e12_first_cases = tuple(
    (prime, hidden_prefix, occupied_item[0], occupied_item[3])
    for prime, (_, hidden_prefix, occupied_item) in records.items()
    if hidden_prefix and hidden_prefix[0][1] == "E12"
)
nonfull_after_hidden_cases = tuple(
    (prime, hidden_prefix, occupied_item[0], occupied_item[3])
    for prime, (_, hidden_prefix, occupied_item) in records.items()
    if hidden_prefix and occupied_item[3] != ((1, 1), (1, 1))
)
late_occupied_cases = tuple(
    (prime, hidden_prefix, occupied_item[0], occupied_item[3])
    for prime, (_, hidden_prefix, occupied_item) in records.items()
    if occupied_item[0] >= 35
)
quarter_by_residual = Counter(case[1] for case in quarter_witness_cases)
minus_by_residual = Counter(case[1] for case in minus_divisor_cases)
positive_surplus_quarter_cases = tuple(
    case + (records[case[0]][2][0],)
    for case in quarter_witness_cases
    if case[-1] > 0
)
zero_surplus_quarter_cases = tuple(
    case for case in quarter_witness_cases if case[-1] == 0
)
repeated_quarter_pair_types = {
    key: count for key, count in quarter_pair_types.items() if count > 1
}
repeated_minus_divisor_types = {
    key: count for key, count in minus_divisor_types.items() if count > 1
}

print("PASS: bounded hidden target-incidence census")
print(f"limit={LIMIT}; primes p=1 mod 24: {len(primes)}; residuals=3..{MAX_RESIDUAL}")
print(f"complete divisor-lattice replays through first occupation: {divisor_replay_count}")
print("all empty-shell matrices: " + ", ".join(
    f"{name}={all_empty[name]}" for name in ("0", "E12", "E21", "S")
))
print("pre-occupancy empty-shell matrices: " + ", ".join(
    f"{name}={pre_occupancy_empty[name]}" for name in ("0", "E12", "E21", "S")
))
print("first hidden kinds: " + ", ".join(
    f"{name}={first_hidden_kind[name]}" for name in ("E12", "E21", "S")
))
print(f"primes with a nonzero hidden matrix before occupation: {sum(first_hidden_kind.values())}")
print(f"maximum first-hidden to first-occupied residual gap: {max_gap}")
print("maximum-gap cases: " + repr(max_gap_cases))
print("multi-step hidden cases: " + repr(multi_step_cases))
print("E12-first cases: " + repr(e12_first_cases))
print("nonfull first occupation after a hidden prefix: " + repr(nonfull_after_hidden_cases))
print("late first-occupation cases (R>=35): " + repr(late_occupied_cases))
print("first examples: " + repr(dict(sorted(first_example.items()))))
print("first-hidden residual distribution: " + repr(dict(sorted(first_hidden_residual.items()))))
print("first-occupied residual distribution: " + repr(dict(sorted(first_occupied_residual.items()))))
print("first-occupied matrix distribution: " + repr(dict(sorted(first_occupied_matrix.items()))))
print("first-occupied matrices after a hidden prefix: " + repr(
    dict(sorted(hidden_to_occupied_matrix.items()))
))
print("hidden-to-occupied gap distribution: " + repr(dict(sorted(hidden_to_occupied_gap.items()))))
print("nonzero pre-occupancy path distribution: " + repr(dict(sorted(nonzero_path.items()))))
print(f"hidden middle-quarter witnesses: {len(quarter_witness_cases)}; by R: "
      + repr(dict(sorted(quarter_by_residual.items()))))
print("positive-surplus quarter cases (p,R,Xi,u,v,m,R-u-v,first occupied R): "
      + repr(positive_surplus_quarter_cases))
print("zero-surplus quarter cases: " + repr(zero_surplus_quarter_cases))
print("all positive-surplus primitive quarter pairs: "
      + repr(tuple(all_positive_quarter_pairs)))
print("all zero-surplus primitive quarter pairs: "
      + repr(tuple(all_zero_quarter_pairs)))
print("repeated quarter-pair types (R,u,v,m,R-u-v): "
      + repr(dict(sorted(repeated_quarter_pair_types.items()))))
print(f"hidden exterior-minus witnesses: {len(minus_divisor_cases)}; by R: "
      + repr(dict(sorted(minus_by_residual.items()))))
print("repeated least minus-divisor types (R,u,(u+1)/R): "
      + repr(dict(sorted(repeated_minus_divisor_types.items()))))
print("p=118801 path: E21 at R=19, S at R=39, occupied I+S at R=59")

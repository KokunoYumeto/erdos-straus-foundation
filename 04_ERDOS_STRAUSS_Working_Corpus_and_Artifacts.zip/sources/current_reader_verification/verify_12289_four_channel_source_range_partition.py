from itertools import product
from pathlib import Path


p = 12289
R = 11
a = 3075
N_arith = p * a


def zeros(rows, columns):
    return [[0 for _ in range(columns)] for _ in range(rows)]


def identity(size):
    result = zeros(size, size)
    for index in range(size):
        result[index][index] = 1
    return result


def add(*matrices):
    return [
        [
            sum(matrix[row][column] for matrix in matrices)
            for column in range(len(matrices[0][0]))
        ]
        for row in range(len(matrices[0]))
    ]


def scale(scalar, matrix):
    return [[scalar * entry for entry in row] for row in matrix]


def divide_exact(matrix, divisor):
    if any(entry % divisor for row in matrix for entry in row):
        raise AssertionError(f"matrix is not divisible entrywise by {divisor}")
    return [[entry // divisor for entry in row] for row in matrix]


def matmul(left, right):
    return [
        [
            sum(left[row][inner] * right[inner][column] for inner in range(len(right)))
            for column in range(len(right[0]))
        ]
        for row in range(len(left))
    ]


def transpose(matrix):
    return [list(column) for column in zip(*matrix)]


def kronecker(left, right):
    return [
        [
            left[i][j] * right[r][c]
            for j in range(len(left[0]))
            for c in range(len(right[0]))
        ]
        for i in range(len(left))
        for r in range(len(right))
    ]


def matrix_unit(size, row, column, coefficient=1):
    result = zeros(size, size)
    result[row][column] = coefficient
    return result


def trace(matrix):
    return sum(matrix[index][index] for index in range(len(matrix)))


def nonzero_entries(matrix):
    return [
        (row, column, entry)
        for row, values in enumerate(matrix)
        for column, entry in enumerate(values)
        if entry
    ]


def target(j):
    if j == 0:
        return (-p) % R
    if j == 1:
        return (-1) % R
    if j == 2:
        return (-pow(p, -1, R)) % R
    raise ValueError(j)


divisors = sorted(
    3**e3 * 5**e5 * 41**e41
    for e3, e5, e41 in product(range(3), range(5), range(3))
)
a_inverse = pow(a, -1, R)
X = tuple(
    (j, u)
    for j in range(3)
    for u in divisors
    if (u * a_inverse) % R == target(j)
)
X_index = {x: index for index, x in enumerate(X)}


def iota(x):
    j, u = x
    return (2 - j, a * a // u)


def d_value(x):
    j, u = x
    return p**j * u


X_low = tuple(x for x in X if d_value(x) < N_arith)
if len(X) != 12 or len(X_low) != 6:
    raise AssertionError(f"certificate counts: total={len(X)}, low={len(X_low)}")
if {x for low in X_low for x in (low, iota(low))} != set(X):
    raise AssertionError("the low representatives do not partition the cover")

A_minus = zeros(12, 12)
A_plus = zeros(12, 12)
Q_low = zeros(12, 12)
Q_high = zeros(12, 12)
P_iota = zeros(12, 12)
for x in X:
    P_iota[X_index[iota(x)]][X_index[x]] = 1
for x in X_low:
    low = X_index[x]
    high = X_index[iota(x)]
    A_minus[high][low] = 2
    A_plus[low][high] = 2
    Q_low[low][low] = 1
    Q_high[high][high] = 1

F11 = matrix_unit(3, 0, 0)
F22 = matrix_unit(3, 1, 1)
F33 = matrix_unit(3, 2, 2)
F32 = matrix_unit(3, 2, 1)
F23 = matrix_unit(3, 1, 2)
B_minus = scale(2, F32)
B_plus = scale(2, F23)
K0 = add(F11, F23, F32)

A = {"-": A_minus, "+": A_plus}
B = {"-": B_minus, "+": B_plus}
Q = {"<": Q_low, ">": Q_high}
channels = {
    sigma + upsilon: divide_exact(kronecker(A[sigma], B[upsilon]), 4)
    for sigma in ("-", "+")
    for upsilon in ("-", "+")
}

expected_sources = {
    "--": kronecker(Q_low, F22),
    "-+": kronecker(Q_low, F33),
    "+-": kronecker(Q_high, F22),
    "++": kronecker(Q_high, F33),
}
expected_ranges = {
    "--": kronecker(Q_high, F33),
    "-+": kronecker(Q_high, F22),
    "+-": kronecker(Q_low, F33),
    "++": kronecker(Q_low, F22),
}

zero36 = zeros(36, 36)
for signs, channel in channels.items():
    source = matmul(transpose(channel), channel)
    target_projector = matmul(channel, transpose(channel))
    if source != expected_sources[signs]:
        raise AssertionError(f"source projector failed for {signs}")
    if target_projector != expected_ranges[signs]:
        raise AssertionError(f"range projector failed for {signs}")
    if matmul(channel, channel) != zero36:
        raise AssertionError(f"channel {signs} is not square-zero")
    entries = nonzero_entries(channel)
    if len(entries) != 6 or any(entry != 1 for _, _, entry in entries):
        raise AssertionError(f"channel {signs} is not a six-entry incidence map")
    if trace(source) != 6 or trace(target_projector) != 6:
        raise AssertionError(f"channel {signs} does not have rank six")

signs = tuple(channels)
for left_index, left_signs in enumerate(signs):
    for right_signs in signs[left_index + 1 :]:
        if matmul(expected_sources[left_signs], expected_sources[right_signs]) != zero36:
            raise AssertionError("source projectors are not pairwise orthogonal")
        if matmul(expected_ranges[left_signs], expected_ranges[right_signs]) != zero36:
            raise AssertionError("range projectors are not pairwise orthogonal")

off_axis = kronecker(identity(12), add(F22, F33))
if add(*expected_sources.values()) != off_axis:
    raise AssertionError("source projectors do not partition the off-axis carrier")
if add(*expected_ranges.values()) != off_axis:
    raise AssertionError("range projectors do not partition the off-axis carrier")

if transpose(channels["--"]) != channels["++"]:
    raise AssertionError("-- and ++ are not transpose pairs")
if transpose(channels["-+"]) != channels["+-"]:
    raise AssertionError("-+ and +- are not transpose pairs")

joint_reflection = kronecker(P_iota, K0)
reflected_pairs = {"--": "++", "-+": "+-", "+-": "-+", "++": "--"}
for source_signs, target_signs in reflected_pairs.items():
    reflected = matmul(
        matmul(joint_reflection, channels[source_signs]), joint_reflection
    )
    if reflected != channels[target_signs]:
        raise AssertionError(f"joint reflection failed on {source_signs}")

V21 = add(channels["--"], channels["+-"])
V12 = add(channels["-+"], channels["++"])
if V21 != kronecker(P_iota, F32):
    raise AssertionError("complete E21 channel identity failed")
if V12 != kronecker(P_iota, F23) or V12 != transpose(V21):
    raise AssertionError("complete E12 channel identity failed")
if matmul(transpose(V21), V21) != kronecker(identity(12), F22):
    raise AssertionError("complete E21 source carrier failed")
if matmul(V21, transpose(V21)) != kronecker(identity(12), F33):
    raise AssertionError("complete E21 range carrier failed")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{thm:12289-four-channel-source-range-partition}",
    r"\label{eq:12289-four-channel-source-range-table}",
    r"\label{eq:12289-four-channel-complete-carrier-partition}",
    r"\label{eq:12289-complete-directed-target-channel}",
    r"\label{eq:12289-complete-directed-range-carrier}",
    r"\label{eq:12289-four-channel-Boolean-incidence}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact 12289 four-channel source/range partition",
            "all four ordered channels are rank-six square-zero partial isometries",
            "their source projectors are the four low/high by E22/E33 coordinate sectors",
            "their range projectors are the exact reflected four-sector permutation",
            "the four sources and four ranges each partition the full off-axis carrier",
            "transpose and the joint reflection retain the two ordered sign pairs",
            "the complete E21 channel is P_iota tensor E32 with source E22 and range E33",
            "E22 to E33 is exactly the embedded C1 carrier E11 to E22 over all 12 certificates",
        )
    )
)

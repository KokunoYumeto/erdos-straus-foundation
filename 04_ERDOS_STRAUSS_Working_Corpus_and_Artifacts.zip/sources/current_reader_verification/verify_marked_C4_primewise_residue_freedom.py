"""Exact finite residue audit for the primewise marked C4 coordinates."""

from collections import defaultdict
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


@lru_cache(maxsize=None)
def divisors(value):
    result = [1]
    for prime, exponent in factorization(value):
        old = tuple(result)
        power = 1
        for _ in range(exponent):
            power *= prime
            result.extend(divisor * power for divisor in old)
    return tuple(sorted(result))


def target_coefficient(a, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(a):
        local = defaultdict(int)
        local[1] += 1
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] += 1
            local[pow(residue, -1, modulus)] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left * right) % modulus] += left_count * right_count
        coefficients = dict(product)
    return coefficients.get(modulus - 1, 0)


rows = []
parity_examples = {}
for p in primes_up_to(9999):
    if p % 12 != 1:
        continue
    orbit_total = 0
    one_sided_total = 0
    timelike_total = 0
    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        residual = 4 * a - p
        if residual <= 0 or residual % 4 != 3 or gcd(residual, a) != 1:
            raise AssertionError((p, a, residual))

        exterior_count = sum(
            1
            for divisor in divisors(a * a)
            if (4 * divisor + 1) % residual == 0
        )
        coefficient = target_coefficient(a, residual)
        if coefficient % 2:
            raise AssertionError(("odd target coefficient", p, a, residual))
        middle_orbit_count = coefficient // 2
        shell_orbit_count = exterior_count + middle_orbit_count

        middle_bit = int(middle_orbit_count > 0)
        exterior_bit = int(exterior_count > 0)
        visible_bit = (middle_bit + exterior_bit) % 2
        hidden_bit = middle_bit * exterior_bit

        orbit_total += shell_orbit_count
        one_sided_total += shell_orbit_count * visible_bit
        timelike_total += shell_orbit_count * hidden_bit

    if orbit_total != one_sided_total + timelike_total:
        raise AssertionError(("rank reconstruction", p))
    marked_third = one_sided_total + 2 * timelike_total
    if marked_third != orbit_total + timelike_total:
        raise AssertionError(("marked rank identity", p))

    row = (p, orbit_total, one_sided_total, timelike_total, marked_third)
    rows.append(row)
    parity_key = tuple(value % 2 for value in row[1:])
    parity_examples.setdefault(parity_key, row)


if len(rows) != 300 or rows[0][0] != 13 or rows[-1][0] != 9973:
    raise AssertionError("unexpected resistant-prime range")

expected_parities = {
    (0, 0, 0, 0),
    (0, 1, 1, 1),
    (1, 0, 1, 0),
    (1, 1, 0, 1),
}
if set(parity_examples) != expected_parities:
    raise AssertionError("the four parity strata were not all realized")

for modulus in range(2, 9):
    expected = {
        (left, right)
        for left in range(modulus)
        for right in range(modulus)
    }
    null_timelike = {
        (one_sided % modulus, timelike % modulus)
        for _, _, one_sided, timelike, _ in rows
    }
    orbit_marked = {
        (orbit % modulus, marked_third % modulus)
        for _, orbit, _, _, marked_third in rows
    }
    if null_timelike != expected:
        raise AssertionError(("null-timelike residue gap", modulus))
    if orbit_marked != expected:
        raise AssertionError(("orbit-marked residue gap", modulus))

    for orbit in range(modulus):
        for marked_third in range(modulus):
            one_sided = (2 * orbit - marked_third) % modulus
            timelike = (marked_third - orbit) % modulus
            if (one_sided + timelike) % modulus != orbit:
                raise AssertionError(("forward inverse orbit", modulus))
            if (one_sided + 2 * timelike) % modulus != marked_third:
                raise AssertionError(("forward inverse marked", modulus))


if any(one_sided == 0 or timelike == 0 for _, _, one_sided, timelike, _ in rows):
    raise AssertionError("a tested prime missed one marked support type")


print("PASS: marked C4 primewise residue-freedom audit")
print("300 primes p < 10000 with p = 1 mod 12 were checked")
print("Q=N+T and C/3=N+2T were reconstructed from every arithmetic shell")
print("all four joint parity strata occur")
print("both joint coordinate pairs fill every residue pair modulo 2 through 8")
print("the inverse is N=2Q-C/3 and T=C/3-Q over every tested residue ring")
print("N and T are both positive for every tested prime")

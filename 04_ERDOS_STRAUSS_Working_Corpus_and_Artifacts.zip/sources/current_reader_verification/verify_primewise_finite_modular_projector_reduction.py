from fractions import Fraction
from math import gcd, isqrt


def primes_up_to(limit):
    for candidate in range(3, limit + 1, 2):
        if all(candidate % divisor for divisor in range(3, isqrt(candidate) + 1, 2)):
            yield candidate


for p in primes_up_to(5000):
    if p % 4 == 1:
        k = (p - 1) // 4
        admissible_a = list(range(k + 1, 3 * k + 1))
        admissible_R = [4 * a - p for a in admissible_a]

        if len(admissible_a) != (p - 1) // 2:
            raise AssertionError(f"wrong number of finite shells for p={p}")
        if admissible_R != list(range(3, 2 * p - 2, 4)):
            raise AssertionError(f"wrong residual moduli for p={p}")
        for a, R in zip(admissible_a, admissible_R):
            if not (Fraction(p, 4) < a <= Fraction(3 * p, 4)):
                raise AssertionError(f"denominator bound fails for p={p}, a={a}")
            if R <= 2 or gcd(R, p * a) != 1:
                raise AssertionError(f"free-shell hypotheses fail for p={p}, a={a}")

    if p % 4 == 3:
        a = (p + 1) // 4
        N = p * a
        b = N + 1
        c = N * (N + 1)
        if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
            raise AssertionError(f"the explicit R=1 identity fails for p={p}")

    if p % 12 == 5:
        a = (p + 3) // 4
        N = p * a
        d = a
        b = (N + d) // 3
        c = (N + N * N // d) // 3
        if 4 * a - p != 3:
            raise AssertionError(f"the endpoint shell is not R=3 for p={p}")
        if N * N % d or d % 3 != (-N) % 3:
            raise AssertionError(f"the R=3 divisor certificate fails for p={p}")
        if b != (p + 1) * (p + 3) // 12 or c != p * b:
            raise AssertionError(f"the R=3 reconstruction formulas fail for p={p}")
        if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
            raise AssertionError(f"the explicit R=3 identity fails for p={p}")

print("PASS: finite primewise modular-projector reduction")
print("a smallest denominator always satisfies p/4 < a <= 3p/4")
print("for p = 1 mod 4 the residual moduli are 3,7,...,2p-3")
print("there are exactly (p-1)/2 such free coprime shells")
print("the finite projector rank is one half the sum of their cover counts")
print("for p = 3 mod 4 the R=1 shell has an explicit three-term identity")
print("for p = 5 mod 12 the R=3 endpoint shell has an explicit divisor certificate")

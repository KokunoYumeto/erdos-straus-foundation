from math import isqrt


def primes_up_to(limit):
    for candidate in range(3, limit + 1, 2):
        if all(candidate % divisor for divisor in range(3, isqrt(candidate) + 1, 2)):
            yield candidate


prime_set = {2} | set(primes_up_to(5000))

for p in prime_set:
    if p % 4 != 1:
        continue

    for R in range(3, 2 * p - 2, 4):
        a = (p + R) // 4
        N = p * a
        base_u = (1, a, a * a)
        grid = {}

        for j in range(3):
            for u in base_u:
                original = (pow(p, j, R) * (u % R) + N) % R == 0
                endpoint = (4 * u + pow(p, 2 - j, R)) % R == 0
                if original != endpoint:
                    raise AssertionError(
                        f"endpoint target equation fails for p={p}, R={R}, j={j}, u={u}"
                    )
                grid[(j, u)] = original

        forbidden = (
            (0, 1),
            (2, a * a),
            (1, a),
            (0, a * a),
            (2, 1),
        )
        if any(grid[cell] for cell in forbidden):
            raise AssertionError(f"a universal base-cell exclusion fails for p={p}, R={R}")

        a_family = (p + 1) % R == 0
        p_family = (p + 4) % R == 0
        if grid[(0, a)] != a_family or grid[(2, a)] != a_family:
            raise AssertionError(f"d=a complement pair fails for p={p}, R={R}")
        if grid[(1, 1)] != p_family or grid[(1, a * a)] != p_family:
            raise AssertionError(f"d=p complement pair fails for p={p}, R={R}")

        if a in prime_set:
            occupied = any(grid.values())
            if occupied != (a_family or p_family):
                raise AssertionError(f"prime-a shell criterion fails for p={p}, R={R}")

print("PASS: endpoint three-target grid")
print("the origin equations become 4u = -p^(2-j) modulo R")
print("five of the nine base divisor cells are universally empty")
print("the other four cells are the two endpoint complement orbits")
print("a prime shell denominator is occupied exactly by an endpoint orbit")

from fractions import Fraction
from math import isqrt


def primes_up_to(limit):
    for candidate in range(3, limit + 1, 2):
        if all(candidate % divisor for divisor in range(3, isqrt(candidate) + 1, 2)):
            yield candidate


def prime_factors(value):
    factors = set()
    divisor = 2
    while divisor * divisor <= value:
        while value % divisor == 0:
            factors.add(divisor)
            value //= divisor
        divisor += 1
    if value > 1:
        factors.add(value)
    return factors


def divisors_of_square(value):
    factorization = []
    divisor = 2
    remaining = value
    while divisor * divisor <= remaining:
        exponent = 0
        while remaining % divisor == 0:
            exponent += 1
            remaining //= divisor
        if exponent:
            factorization.append((divisor, 2 * exponent))
        divisor += 1
    if remaining > 1:
        factorization.append((remaining, 2))

    divisors = [1]
    for prime, exponent in factorization:
        powers = [prime**j for j in range(exponent + 1)]
        divisors = [d * power for d in divisors for power in powers]
    return divisors


for p in primes_up_to(5000):
    if p % 4 != 1:
        continue

    has_a_orbit = False
    has_p_orbit = False
    a_orbit_count = 0
    p_orbit_count = 0
    endpoint_orbits = set()
    for R in range(3, 2 * p - 2, 4):
        a = (p + R) // 4
        N = p * a

        certificate_a = a % R == (-N) % R
        certificate_p = p % R == (-N) % R
        if certificate_a != ((p + 1) % R == 0):
            raise AssertionError(f"d=a criterion fails for p={p}, R={R}")
        if certificate_p != ((p + 4) % R == 0):
            raise AssertionError(f"d=p criterion fails for p={p}, R={R}")

        if certificate_a:
            has_a_orbit = True
            a_orbit_count += 1
            endpoint_orbits.add((R, *sorted((a, N * N // a))))
            b = a * (p + 1) // R
            c = p * b
            if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                raise AssertionError(f"d=a reconstruction fails for p={p}, R={R}")

        if certificate_p:
            has_p_orbit = True
            p_orbit_count += 1
            endpoint_orbits.add((R, *sorted((p, N * N // p))))
            b = p * (a + 1) // R
            c = a * b
            if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                raise AssertionError(f"d=p reconstruction fails for p={p}, R={R}")

        if certificate_a or certificate_p:
            inverse_a = pow(a, -1, R)
            target_1 = (-1) % R
            target_2 = (-pow(p, -1, R)) % R
            residues = [
                (u * inverse_a) % R
                for u in divisors_of_square(a)
            ]
            middle_count = sum(residue == target_1 for residue in residues)
            exterior_count = sum(residue == target_2 for residue in residues)
            if middle_count % 2:
                raise AssertionError(f"middle target parity fails for p={p}, R={R}")
            target_rank = exterior_count + middle_count // 2
            endpoint_rank = int(certificate_a) + int(certificate_p)
            if target_rank < endpoint_rank:
                raise AssertionError(
                    f"two-target survival bound fails for p={p}, R={R}"
                )
            if 3 * target_rank < 3 * endpoint_rank:
                raise AssertionError(
                    f"polar rank amplification fails for p={p}, R={R}"
                )

    expected_a_orbit = any(q % 4 == 3 for q in prime_factors((p + 1) // 2))
    expected_p_orbit = any(q % 4 == 3 for q in prime_factors(p + 4))
    if has_a_orbit != expected_a_orbit:
        raise AssertionError(f"factor criterion for p+1 fails at p={p}")
    if has_p_orbit != expected_p_orbit:
        raise AssertionError(f"factor criterion for p+4 fails at p={p}")
    if len(endpoint_orbits) != a_orbit_count + p_orbit_count:
        raise AssertionError(f"endpoint orbit collision at p={p}")
    if p % 12 == 5 and not has_a_orbit:
        raise AssertionError(f"R=3 family missing at p={p}")

print("PASS: endpoint divisor-orbit families")
print("the divisor d=a is a certificate exactly when R divides p+1")
print("the divisor d=p is a certificate exactly when R divides p+4")
print("both certificate families reconstruct exact three-term identities")
print("their divisor-complement orbits are pairwise distinct")
print("every endpoint family survives the two-target extraction")
print("three times the target rank bounds the C3-amplified polar rank contribution")
print("a remaining prime has no 3 mod 4 prime factor in either tested integer")
print("the R=3 family is the first member of the d=a orbit family")

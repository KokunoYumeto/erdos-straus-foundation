#!/usr/bin/env python3
"""Exact marked C4-extension classes and their two-torsion carry characters."""

from __future__ import annotations

import itertools
import math


def determinant(matrix: tuple[tuple[int, ...], ...]) -> int:
    if len(matrix) == 1:
        return matrix[0][0]
    total = 0
    for column, entry in enumerate(matrix[0]):
        minor = tuple(
            tuple(row[j] for j in range(len(matrix)) if j != column)
            for row in matrix[1:]
        )
        total += (-1) ** column * entry * determinant(minor)
    return total


def determinantal_divisor(
    matrix: tuple[tuple[int, ...], ...], size: int
) -> int:
    rows = range(len(matrix))
    columns = range(len(matrix[0]))
    values: list[int] = []
    for row_indices in itertools.combinations(rows, size):
        for column_indices in itertools.combinations(columns, size):
            minor = tuple(
                tuple(matrix[i][j] for j in column_indices)
                for i in row_indices
            )
            values.append(abs(determinant(minor)))
    return math.gcd(*values)


def smith_invariants(
    matrix: tuple[tuple[int, ...], ...]
) -> tuple[int, ...]:
    divisors = [
        determinantal_divisor(matrix, size)
        for size in range(1, len(matrix) + 1)
    ]
    invariants = [divisors[0]]
    invariants.extend(
        divisors[index] // divisors[index - 1]
        for index in range(1, len(divisors))
    )
    return tuple(value for value in invariants if value > 1)


GROUP_NAMES = {
    (16,): "C16",
    (2, 8): "C8xC2",
    (4, 4): "C4xC4",
    (2, 2, 4): "C4xC2xC2",
}


def cyclic_cocycle(class_value: int, left: int, right: int) -> int:
    return class_value * ((left + right) // 4) % 4


def binary_cocycle(
    class_value: tuple[int, int],
    left: tuple[int, int],
    right: tuple[int, int],
) -> int:
    return (
        class_value[0] * left[0] * right[0]
        + class_value[1] * left[1] * right[1]
    ) % 4


def is_coboundary(elements, add, cocycle) -> bool:
    zero = elements[0]
    others = elements[1:]
    for values in itertools.product(range(4), repeat=len(others)):
        cochain = {zero: 0}
        cochain.update(dict(zip(others, values)))
        if all(
            cocycle(left, right)
            == (
                cochain[left]
                + cochain[right]
                - cochain[add(left, right)]
            )
            % 4
            for left in elements
            for right in elements
        ):
            return True
    return False


def cyclic_rows() -> list[dict[str, object]]:
    elements = tuple(range(4))
    rows = []
    for class_value in range(4):
        matrix = ((4, -class_value), (0, 4))
        invariants = smith_invariants(matrix)
        q_values = (0, class_value % 2)
        coboundary = is_coboundary(
            elements,
            lambda left, right: (left + right) % 4,
            lambda left, right: cyclic_cocycle(
                class_value, left, right
            ),
        )
        assert coboundary == (class_value == 0)
        rows.append(
            {
                "class": class_value,
                "invariants": invariants,
                "group": GROUP_NAMES[invariants],
                "q": q_values,
                "weight": sum(q_values),
                "coboundary": coboundary,
            }
        )
    return rows


def binary_rows() -> list[dict[str, object]]:
    elements = tuple(itertools.product(range(2), repeat=2))
    rows = []
    for class_value in elements:
        first, second = class_value
        matrix = (
            (2, 0, -first),
            (0, 2, -second),
            (0, 0, 4),
        )
        invariants = smith_invariants(matrix)
        q_values = tuple(
            (first * epsilon + second * delta) % 2
            for epsilon, delta in elements
        )
        coboundary = is_coboundary(
            elements,
            lambda left, right: (
                (left[0] + right[0]) % 2,
                (left[1] + right[1]) % 2,
            ),
            lambda left, right: binary_cocycle(
                class_value, left, right
            ),
        )
        assert coboundary == (class_value == (0, 0))
        rows.append(
            {
                "class": class_value,
                "invariants": invariants,
                "group": GROUP_NAMES[invariants],
                "q": q_values,
                "weight": sum(q_values),
                "coboundary": coboundary,
            }
        )
    return rows


def verify_two_C8xC2_carriers() -> None:
    group_elements = tuple(itertools.product(range(8), range(2)))

    def group_add(left, right):
        return ((left[0] + right[0]) % 8, (left[1] + right[1]) % 2)

    binary_sheets = tuple(itertools.product(range(2), repeat=2))
    selected_theta = {
        (sheet, cell): (
            (sheet[0] + 2 * cell) % 8,
            sheet[1],
        )
        for sheet in binary_sheets
        for cell in range(4)
    }
    assert set(selected_theta.values()) == set(group_elements)
    selected_inverse = {
        point: coordinate for coordinate, point in selected_theta.items()
    }
    for left in binary_sheets:
        for right in binary_sheets:
            point = group_add(
                selected_theta[(left, 0)],
                selected_theta[(right, 0)],
            )
            target_sheet, carry = selected_inverse[point]
            assert target_sheet == (
                (left[0] + right[0]) % 2,
                (left[1] + right[1]) % 2,
            )
            assert carry == left[0] * right[0]

    cyclic_sheets = tuple(range(4))
    alternative_theta = {
        (sheet, cell): (
            (sheet + 2 * cell) % 8,
            cell % 2,
        )
        for sheet in cyclic_sheets
        for cell in range(4)
    }
    assert set(alternative_theta.values()) == set(group_elements)
    alternative_inverse = {
        point: coordinate for coordinate, point in alternative_theta.items()
    }
    for left in cyclic_sheets:
        for right in cyclic_sheets:
            point = group_add(
                alternative_theta[(left, 0)],
                alternative_theta[(right, 0)],
            )
            target_sheet, carry = alternative_inverse[point]
            assert target_sheet == (left + right) % 4
            assert carry == 2 * ((left + right) // 4)

    assert 2 * (2, 1)[0] % 8 == 4
    assert 2 * (2, 1)[1] % 2 == 0


def main() -> None:
    cyclic = cyclic_rows()
    binary = binary_rows()
    for row in cyclic:
        print(
            "C4 quotient "
            f"class={row['class']}: "
            f"group={row['group']}, "
            f"SNF={row['invariants']}, "
            f"q={row['q']}, "
            f"weight={row['weight']}, "
            f"coboundary={row['coboundary']}"
        )
    for row in binary:
        print(
            "C2xC2 quotient "
            f"class={row['class']}: "
            f"group={row['group']}, "
            f"SNF={row['invariants']}, "
            f"q={row['q']}, "
            f"weight={row['weight']}, "
            f"coboundary={row['coboundary']}"
        )

    assert [row["weight"] for row in cyclic] == [0, 1, 0, 1]
    assert [row["group"] for row in cyclic] == [
        "C4xC4",
        "C16",
        "C8xC2",
        "C16",
    ]
    assert [row["weight"] for row in binary] == [0, 2, 2, 2]
    assert [row["group"] for row in binary] == [
        "C4xC2xC2",
        "C8xC2",
        "C8xC2",
        "C8xC2",
    ]
    verify_two_C8xC2_carriers()
    print(
        "C8xC2 marked carriers: "
        "cyclic quotient class 2 has q-weight 0; "
        "binary quotient nonzero class has q-weight 2"
    )
    print(
        "PASS: marked C4-extension classification and exact detection kernel"
    )


if __name__ == "__main__":
    main()

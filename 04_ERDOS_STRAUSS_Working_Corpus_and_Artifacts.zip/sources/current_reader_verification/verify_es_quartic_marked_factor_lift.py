from sympy import Matrix, Rational, expand, eye, ones, symbols


U, V = symbols("U V")
a, b, c, d, e, f = symbols("a b c d e f")
lam = symbols("lam", nonzero=True)
p, s1, s2, s3 = symbols("p s1 s2 s3")

L = a * U + b * V
Q = c * U**3 + d * U**2 * V + e * U * V**2 + f * V**3
product = expand(L * Q)

expected_product = (
    a * c * U**4
    + (a * d + b * c) * U**3 * V
    + (a * e + b * d) * U**2 * V**2
    + (a * f + b * e) * U * V**3
    + b * f * V**4
)
assert expand(product - expected_product) == 0

resultant = expand(Q.subs({U: -b, V: a}))
expected_resultant = -b**3 * c + a * b**2 * d - a**2 * b * e + a**3 * f
assert expand(resultant - expected_resultant) == 0

es_form = 4 * a * f - b * e
es_monic = expand(es_form.subs({a: 1, b: -p, c: 1, d: -s1, e: s2, f: -s3}))
assert es_monic == p * s2 - 4 * s3

gauge_resultant = expand(
    expected_resultant.subs(
        {
            a: lam * a,
            b: lam * b,
            c: c / lam,
            d: d / lam,
            e: e / lam,
            f: f / lam,
        },
        simultaneous=True,
    )
)
gauge_es_form = expand(
    es_form.subs(
        {a: lam * a, b: lam * b, e: e / lam, f: f / lam},
        simultaneous=True,
    )
)
assert expand(gauge_resultant - lam**2 * expected_resultant) == 0
assert expand(gauge_es_form - es_form) == 0

rank_one_matrix = Matrix([[2 * a, b], [e, 2 * f]])
assert expand(rank_one_matrix.det() - es_form) == 0

# The c,e Jacobian minor of (resultant, es_form) is b^4.  On their
# common locus with resultant one, b cannot vanish: b=0 would give
# a^3 f=1 and 4af=0 simultaneously.
jacobian_minor = Matrix(
    [
        [expected_resultant.diff(c), expected_resultant.diff(e)],
        [es_form.diff(c), es_form.diff(e)],
    ]
).det()
assert expand(jacobian_minor - b**4) == 0


def centred_simplex_gram(vertex_count: int) -> Matrix:
    identity = eye(vertex_count)
    projector = identity - ones(vertex_count, vertex_count) / vertex_count
    return Rational(vertex_count, vertex_count - 1) * projector


# A regular four-simplex has five vertices and lives in dimension four.
G5 = centred_simplex_gram(5)
assert G5.rank() == 4
assert all(G5[i, i] == 1 for i in range(5))
assert all(G5[i, j] == -Rational(1, 4) for i in range(5) for j in range(5) if i != j)

# A regular five-simplex has six vertices and lives in dimension five.
G6 = centred_simplex_gram(6)
assert G6.rank() == 5
assert all(G6[i, i] == 1 for i in range(6))
assert all(G6[i, j] == -Rational(1, 5) for i in range(6) for j in range(6) if i != j)

# The Gram entries are the inner products of the unit simplex vertices.
# Orthogonal projection of any opposite-facet vertex v_i onto v_k^\perp
# removes <v_i,v_k>v_k=(-1/5)v_k.
for i in range(5):
    assert G6[i, 5] == -Rational(1, 5)
    hidden_displacement_coefficient = G6[i, 5] / G6[5, 5]
    assert hidden_displacement_coefficient == -Rational(1, 5)

# In the lower regular four-simplex, the opposite-face centroid is
# c_k=-(1/4)v_k.  The full-altitude coordinate is
# (4/5)<c_k,v_k>=-1/5 because v_k is a unit vector.
lower_face_centroid_coefficient = sum(G5[i, 4] for i in range(4)) / 4
lower_altitude_coordinate = Rational(4, 5) * lower_face_centroid_coefficient
assert lower_face_centroid_coefficient == -Rational(1, 4)
assert lower_altitude_coordinate == -Rational(1, 5)

print("PASS: quartic marked-factor product and resultant identities")
print("PASS: Erdos-Strauss is exactly 4af-be=0 on the split monic locus")
print("PASS: resultant has gauge weight two; the ES determinant is gauge invariant")
print("PASS: 4af-be is the determinant of [[2a,b],[e,2f]]")
print("PASS: the smoothness minor is b^4 and b is nonzero on the common locus")
print("PASS: dimensions are five for resultant-one and four after the ES cut")
print("PASS: the adjacent four/five-dimensional simplex reciprocal is -1/5")

from collections import Counter
from itertools import product
from pathlib import Path

import sympy as sp


POINTS = tuple(product(range(2), range(2), range(2)))
INDEX = {point: index for index, point in enumerate(POINTS)}
IDENTITY = tuple(range(len(POINTS)))

L = ((0, 1), (1, 1))
R = ((0, 1), (1, 0))


def matvec(matrix, vector):
    return (
        (matrix[0][0] * vector[0] + matrix[0][1] * vector[1]) % 2,
        (matrix[1][0] * vector[0] + matrix[1][1] * vector[1]) % 2,
    )


def add(left, right):
    return ((left[0] + right[0]) % 2, (left[1] + right[1]) % 2)


def permutation(action):
    return tuple(INDEX[action(point)] for point in POINTS)


def compose(left, right):
    return tuple(left[right[index]] for index in range(len(POINTS)))


def generated_group(generators):
    group = {IDENTITY}
    frontier = [IDENTITY]
    while frontier:
        element = frontier.pop()
        for generator in generators:
            candidate = compose(generator, element)
            if candidate not in group:
                group.add(candidate)
                frontier.append(candidate)
    return frozenset(group)


def translation(v_plus, v_minus):
    def action(point):
        sheet, x0, x1 = point
        vector = (x0, x1)
        shift = v_plus if sheet == 0 else v_minus
        image = add(vector, shift)
        return (sheet, image[0], image[1])

    return permutation(action)


def on_sheet(matrix, selected_sheet):
    def action(point):
        sheet, x0, x1 = point
        vector = (x0, x1)
        image = matvec(matrix, vector) if sheet == selected_sheet else vector
        return (sheet, image[0], image[1])

    return permutation(action)


def both_sheets(matrix):
    def action(point):
        sheet, x0, x1 = point
        image = matvec(matrix, (x0, x1))
        return (sheet, image[0], image[1])

    return permutation(action)


theta = permutation(lambda point: (1 - point[0], point[1], point[2]))
j_mirror = permutation(
    lambda point: (
        1 - point[0],
        *matvec(R, (point[1], point[2])),
    )
)
diagonal_R = both_sheets(R)

if compose(theta, j_mirror) != diagonal_R:
    raise AssertionError("pure exchange followed by the crossed mirror must be diagonal R")
if compose(j_mirror, theta) != diagonal_R:
    raise AssertionError("the crossed mirror must commute with pure exchange")

e0 = (1, 0)
e1 = (0, 1)
translations = (
    translation(e0, (0, 0)),
    translation(e1, (0, 0)),
    translation((0, 0), e0),
    translation((0, 0), e1),
)

L_plus = on_sheet(L, 0)
L_minus = on_sheet(L, 1)
R_plus = on_sheet(R, 0)
R_minus = on_sheet(R, 1)

group_orders = {
    "translations_with_pure_exchange": len(generated_group((*translations, theta))),
    "translations_with_crossed_mirror": len(
        generated_group((*translations, j_mirror))
    ),
    "translations_with_both_exchanges": len(
        generated_group((*translations, theta, j_mirror))
    ),
    "independent_reflection_sheets": len(
        generated_group((*translations, theta, R_plus, R_minus))
    ),
    "independent_oriented_tetrahedral_sheets": len(
        generated_group((*translations, theta, L_plus, L_minus))
    ),
    "oriented_sheets_with_diagonal_mirror": len(
        generated_group((*translations, theta, j_mirror, L_plus, L_minus))
    ),
    "independent_full_tetrahedral_sheets": len(
        generated_group(
            (*translations, theta, L_plus, L_minus, R_plus, R_minus)
        )
    ),
    "pure_phase_exchange": len(generated_group((L_plus, L_minus, theta))),
    "crossed_phase_exchange": len(generated_group((L_plus, L_minus, j_mirror))),
    "both_phase_exchanges": len(
        generated_group((L_plus, L_minus, theta, j_mirror))
    ),
}

expected_orders = {
    "translations_with_pure_exchange": 32,
    "translations_with_crossed_mirror": 32,
    "translations_with_both_exchanges": 64,
    "independent_reflection_sheets": 128,
    "independent_oriented_tetrahedral_sheets": 288,
    "oriented_sheets_with_diagonal_mirror": 576,
    "independent_full_tetrahedral_sheets": 1152,
    "pure_phase_exchange": 18,
    "crossed_phase_exchange": 18,
    "both_phase_exchanges": 36,
}
if group_orders != expected_orders:
    raise AssertionError(f"unexpected finite closures: {group_orders}")


def twisted_multiply(left, right):
    a, b, epsilon = left
    c, d, delta = right
    if epsilon:
        c, d = -d, -c
    return ((a + c) % 3, (b + d) % 3, (epsilon + delta) % 2)


def twisted_order(element):
    identity = (0, 0, 0)
    value = identity
    for order in range(1, 19):
        value = twisted_multiply(value, element)
        if value == identity:
            return order
    raise AssertionError("twisted phase order exceeds eighteen")


def assert_subgroup(elements):
    subset = set(elements)
    for left in subset:
        for right in subset:
            if twisted_multiply(left, right) not in subset:
                raise AssertionError("twisted phase subset is not closed")


twisted_diagonal = tuple((a, a, epsilon) for a in range(3) for epsilon in range(2))
twisted_antidiagonal = tuple(
    (a, (-a) % 3, epsilon) for a in range(3) for epsilon in range(2)
)
assert_subgroup(twisted_diagonal)
assert_subgroup(twisted_antidiagonal)

diagonal_orders = Counter(twisted_order(element) for element in twisted_diagonal)
antidiagonal_orders = Counter(
    twisted_order(element) for element in twisted_antidiagonal
)
if diagonal_orders != Counter({2: 3, 3: 2, 1: 1}):
    raise AssertionError(f"twisted diagonal orders: {diagonal_orders}")
if antidiagonal_orders != Counter({6: 2, 3: 2, 2: 1, 1: 1}):
    raise AssertionError(f"twisted antidiagonal orders: {antidiagonal_orders}")

# The sign/universe axis and the Cayley--Dickson blade axis are independent
# factors in the exact completed carrier.
blade_dimensions = (1, 2, 4, 8, 16, 32, 64)
sign_sheet_counts = (1, 2, 4, 8)
dimension_grid = tuple(
    tuple(sign_count * blade_dimension for blade_dimension in blade_dimensions)
    for sign_count in sign_sheet_counts
)
if tuple(row[4] for row in dimension_grid) != (16, 32, 64, 128):
    raise AssertionError("sedenion-row dimension tower failed")
if dimension_grid[-1][-1] != 512:
    raise AssertionError("two-axis dimension grid endpoint failed")

# Explicit four-sign and two-sheet matrices in the basis
# (++,+-,-+,--) on each sheet.
P_L = sp.Matrix(
    (
        (1, 0, 0, 0),
        (0, 0, 1, 0),
        (0, 0, 0, 1),
        (0, 1, 0, 0),
    )
)
P_R = sp.Matrix(
    (
        (1, 0, 0, 0),
        (0, 0, 1, 0),
        (0, 1, 0, 0),
        (0, 0, 0, 1),
    )
)
I4 = sp.eye(4)
Z4 = sp.zeros(4, 4)
THETA = Z4.row_join(I4).col_join(I4.row_join(Z4))
J_R_MATRIX = Z4.row_join(P_R).col_join(P_R.row_join(Z4))
R_HAT = P_R.row_join(Z4).col_join(Z4.row_join(P_R))
U_DIAGONAL = P_L.row_join(Z4).col_join(Z4.row_join(P_L))
U_ANTIDIAGONAL = P_L.row_join(Z4).col_join(
    Z4.row_join(P_L ** -1)
)

if P_L**3 != I4:
    raise AssertionError("explicit sign rotation is not order three")
if P_R**2 != I4:
    raise AssertionError("explicit internal mirror is not involutive")
if P_R * P_L * P_R != P_L**-1:
    raise AssertionError("explicit mirror does not invert the sign rotation")
if THETA * J_R_MATRIX != R_HAT or J_R_MATRIX * THETA != R_HAT:
    raise AssertionError("explicit exchange/mirror factorization failed")
if THETA * U_DIAGONAL != U_DIAGONAL * THETA:
    raise AssertionError("pure exchange must commute with diagonal phase")
if THETA * U_ANTIDIAGONAL * THETA != U_ANTIDIAGONAL**-1:
    raise AssertionError("pure exchange must invert antidiagonal phase")
if J_R_MATRIX * U_DIAGONAL * J_R_MATRIX != U_DIAGONAL**-1:
    raise AssertionError("crossed mirror must invert diagonal phase")
if J_R_MATRIX * U_ANTIDIAGONAL != U_ANTIDIAGONAL * J_R_MATRIX:
    raise AssertionError("crossed mirror must commute with antidiagonal phase")
if J_R_MATRIX.T != J_R_MATRIX or J_R_MATRIX**2 != sp.eye(8):
    raise AssertionError("crossed mirror coupling must be self-adjoint and square to I")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{thm:crossed-two-sheet-tetrahedral-granularity}",
    r"\label{eq:two-sheet-crossed-mirror}",
    r"\label{eq:two-sheet-translation-wreath-order}",
    r"\label{eq:two-sheet-translation-double-mirror-order}",
    r"\label{eq:two-sheet-independent-reflection-order}",
    r"\label{eq:two-sheet-oriented-tetrahedral-wreath-order}",
    r"\label{eq:two-sheet-oriented-tetrahedral-double-mirror-order}",
    r"\label{eq:two-sheet-full-tetrahedral-wreath-order}",
    r"\label{eq:two-sheet-crossed-phase-product}",
    r"\label{eq:two-sheet-crossed-diagonal-D3}",
    r"\label{eq:two-sheet-crossed-antidiagonal-C6}",
    r"\label{eq:completed-sign-crossed-mirror-product}",
    r"\label{eq:sign-sheet-Cayley-Dickson-dimension-grid}",
    r"\label{cor:explicit-crossed-mirror-eight-matrix}",
    r"\label{eq:explicit-four-sign-L-matrix}",
    r"\label{eq:explicit-four-sign-R-matrix}",
    r"\label{eq:explicit-two-sheet-exchange-matrices}",
    r"\label{eq:explicit-two-sheet-phase-matrices}",
    r"\label{eq:explicit-two-sheet-phase-exchange-relations}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact two-sheet tetrahedral granularity",
            "pure exchange and crossed mirror differ by diagonal R",
            "crossed mirror sends phase exponents (a,b) to (-b,-a)",
            "twisted diagonal phase subgroup = D3 and twisted antidiagonal = C6",
            "translation closures have orders 32, 64, and 128",
            "tetrahedral closures have orders 288, 576, and 1152",
            "phase closures have orders 18, 18, and 36",
            "sedenion-row carrier dimensions are 16, 32, 64, and 128",
            "the full sign-sheet/Cayley-Dickson dimension grid is exact",
            "explicit 8 by 8 matrices exchange the C6 and D3 phase assignments",
            "the crossed mirror matrix is self-adjoint and squares to the identity",
        )
    )
)

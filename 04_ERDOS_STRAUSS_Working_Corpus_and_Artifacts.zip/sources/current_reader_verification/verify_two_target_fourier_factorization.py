from itertools import product

import sympy as sp
from sympy.polys.numberfields import to_number_field


def cyclic_convolution(order, local_data):
    values = [0] * order
    for exponents in product(
        *[range(-exponent, exponent + 1) for exponent, _ in local_data]
    ):
        residue = sum(
            beta * step
            for beta, (_, step) in zip(exponents, local_data)
        ) % order
        values[residue] += 1
    return values


def exact_zero(expression):
    reduced = sp.simplify(sp.expand_complex(expression))
    if reduced == 0:
        return True
    return to_number_field(expression).as_expr() == 0


def verify_case(order, local_data, target_2, target_1):
    zeta = sp.exp(2 * sp.pi * sp.I / order)
    values = cyclic_convolution(order, local_data)
    transform = []

    for character in range(order):
        direct = sum(
            values[h] * zeta ** (-character * h)
            for h in range(order)
        )
        local_product = sp.Integer(1)
        for exponent, step in local_data:
            local_product *= sum(
                zeta ** (-character * step * beta)
                for beta in range(-exponent, exponent + 1)
            )
        if not exact_zero(direct - local_product):
            raise AssertionError(
                f"local character factorization failed for C_{order}, k={character}"
            )
        if not exact_zero(direct - sp.conjugate(direct)):
            raise AssertionError(
                f"character coefficient is not real for C_{order}, k={character}"
            )
        transform.append(direct)

    reconstructed = []
    for target in range(order):
        value = sum(
            transform[character] * zeta ** (character * target)
            for character in range(order)
        ) / order
        if not exact_zero(value - values[target]):
            raise AssertionError(
                f"Fourier inversion failed for C_{order}, target={target}"
            )
        reconstructed.append(value)

    target_vector = sp.Matrix(
        [reconstructed[target_2], reconstructed[target_1] / 2]
    )
    direct_vector = sp.Matrix(
        [values[target_2], sp.Rational(values[target_1], 2)]
    )
    if any(not exact_zero(entry) for entry in target_vector - direct_vector):
        raise AssertionError(f"two-target vector failed for C_{order}")

    principal_mass = sp.prod(2 * exponent + 1 for exponent, _ in local_data)
    if transform[0] != principal_mass:
        raise AssertionError(f"principal mass failed for C_{order}")

    for target in (target_1, target_2):
        nonprincipal = sum(
            transform[character] * zeta ** (character * target)
            for character in range(1, order)
        )
        cancellation = exact_zero(nonprincipal + principal_mass)
        if cancellation != (values[target] == 0):
            raise AssertionError(
                f"principal-mass cancellation failed for C_{order}, target={target}"
            )


def cyclic_stabilizer(order, support):
    return {
        shift
        for shift in range(order)
        if {(value + shift) % order for value in support} == support
    }


def quotient_order_from_stabilizer(order, stabilizer):
    if stabilizer == {0}:
        return order
    return min(value for value in stabilizer if value)


def verify_empty_quotient_certificate(order, local_data, targets):
    values = cyclic_convolution(order, local_data)
    support = {index for index, value in enumerate(values) if value}
    if support.intersection(targets):
        raise AssertionError("test target is not empty")

    stabilizer = cyclic_stabilizer(order, support)
    quotient_order = quotient_order_from_stabilizer(order, stabilizer)
    quotient_support = {value % quotient_order for value in support}
    quotient_targets = {value % quotient_order for value in targets}
    if quotient_support.intersection(quotient_targets):
        raise AssertionError("target quotient meets the support quotient")

    kappa = 1
    for exponent, step in local_data:
        local_support = {
            (beta * step) % quotient_order
            for beta in range(-exponent, exponent + 1)
        }
        kappa += len(local_support) - 1
    delta = quotient_order - len(quotient_support) - len(quotient_targets)
    epsilon = len(quotient_support) - kappa
    surplus = kappa + len(quotient_targets) - quotient_order
    if min(delta, epsilon) < 0 or -surplus != delta + epsilon:
        raise AssertionError("stabilizer defect decomposition failed")

    quotient_values = [0] * quotient_order
    for residue, value in enumerate(values):
        quotient_values[residue % quotient_order] += value

    zeta_q = sp.exp(2 * sp.pi * sp.I / quotient_order)
    quotient_transform = [
        sum(
            quotient_values[h] * zeta_q ** (-character * h)
            for h in range(quotient_order)
        )
        for character in range(quotient_order)
    ]

    zeta_h = sp.exp(2 * sp.pi * sp.I / order)
    stabilizer_order = len(stabilizer)
    full_transform_on_annihilator = [
        sum(
            values[h] * zeta_h ** (-character * stabilizer_order * h)
            for h in range(order)
        )
        for character in range(quotient_order)
    ]
    for left, right in zip(quotient_transform, full_transform_on_annihilator):
        if not exact_zero(left - right):
            raise AssertionError("quotient/annihilator transform identity failed")

    principal_mass = sum(values)
    for target in quotient_targets:
        nonprincipal = sum(
            quotient_transform[character] * zeta_q ** (character * target)
            for character in range(1, quotient_order)
        )
        if not exact_zero(nonprincipal + principal_mass):
            raise AssertionError("quotient principal-mass cancellation failed")

    parseval_remainder = (
        quotient_order * sum(value * value for value in quotient_values)
        - principal_mass * principal_mass
    )
    if (quotient_order - 1) * parseval_remainder < principal_mass * principal_mass:
        raise AssertionError("empty target passed the strict Parseval test")


cases = [
    (3, [(1, 1)], 1, 2),
    (4, [(1, 1), (1, 2)], 3, 2),
    (5, [(2, 1), (1, 2)], 4, 3),
    (6, [(1, 1), (2, 2)], 5, 3),
    (8, [(1, 1), (1, 3), (1, 4)], 6, 4),
    (10, [(1, 8), (2, 4), (1, 3)], 4, 5),
]

for case in cases:
    verify_case(*case)

mu_12289 = cyclic_convolution(10, [(1, 8), (2, 4), (1, 3)])
if mu_12289 != [3, 6, 3, 6, 3, 6, 3, 6, 3, 6]:
    raise AssertionError("12289 coefficient vector failed")

transform_12289 = [45, 0, 0, 0, 0, -15, 0, 0, 0, 0]
target_2 = sp.Rational(
    transform_12289[0] + transform_12289[5],
    10,
)
target_1_half = sp.Rational(
    transform_12289[0] - transform_12289[5],
    20,
)
if (target_2, target_1_half) != (3, 3):
    raise AssertionError("12289 two-target Fourier extraction failed")

verify_empty_quotient_certificate(
    7,
    [(1, 1)],
    {2, 3},
)
verify_empty_quotient_certificate(
    12,
    [(1, 4), (1, 1)],
    {2, 6},
)

print("PASS: exact two-target Fourier factorization")
print("six cyclic test families satisfy local factorization and Fourier inversion")
print("every tested missing target equals exact cancellation of the principal mass")
print("the 12289 transform extracts the ordered target vector (3,3)")
print("two empty shells satisfy the exact stabilizer-defect decomposition")
print("their quotient annihilator characters cancel the principal mass exactly")
print("neither empty shell passes the strict quotient Parseval survival test")

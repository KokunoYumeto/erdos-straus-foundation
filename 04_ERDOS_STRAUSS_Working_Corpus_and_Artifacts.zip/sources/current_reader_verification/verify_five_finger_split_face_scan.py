import contextlib
import io
from collections import Counter


with contextlib.redirect_stdout(io.StringIO()):
    from verify_forced_factor_target_packets import (
        factorization,
        is_prime,
        original_occupied,
    )


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


BOUND = 2_000_001
SPLIT = {
    3: {1},
    7: {1, 2, 4},
    11: {1, 3, 4, 5, 9},
    15: {1, 2, 4, 8},
    19: {1, 4, 5, 6, 7, 9, 11, 16, 17},
}


def split_supported(value, residual):
    return all(
        prime % residual in SPLIT[residual]
        for prime, _ in factorization(value)
    )


def first_occupied_after_23(prime, ceiling=403):
    for residual in range(27, ceiling + 1, 4):
        if original_occupied((prime + residual) // 4, residual):
            return residual
    return None


rows = []
for prime in range(49, BOUND, 48):
    if prime % 23 not in {5, 14} or not is_prime(prime):
        continue
    if original_occupied((prime + 23) // 4, 23):
        continue

    x = (prime + 23) // 24
    if x % 3 != 2:
        continue
    d = (2 * x - 1) // 3
    fingers = (
        9 * d - 2,
        (9 * d - 1) // 2,
        d,
        (9 * d + 1) // 2,
        9 * d + 2,
    )
    split_flags = tuple(
        split_supported(value, residual)
        for value, residual in zip(fingers, (3, 7, 11, 15, 19))
    )
    empty_flags = tuple(
        not original_occupied((prime + residual) // 4, residual)
        for residual in (3, 7, 11, 15, 19)
    )
    if split_flags[:4] != empty_flags[:4]:
        raise AssertionError(
            ("first-four split equivalence", prime, split_flags, empty_flags)
        )
    if split_flags[4] and not empty_flags[4]:
        raise AssertionError(
            ("residual-nineteen split safe face", prime, fingers[4])
        )
    rows.append((prime, d, fingers, split_flags, empty_flags))


first_four = [row for row in rows if all(row[3][:4])]
five_split = [row for row in first_four if row[3][4]]
status = Counter(
    (
        "split-safe" if row[3][4] else "not-split",
        "empty" if row[4][4] else "occupied",
    )
    for row in first_four
)
observed = [
    (
        prime,
        d,
        fingers,
        split_flags,
        empty_flags,
        factorization(fingers[4]),
        first_occupied_after_23(prime),
    )
    for prime, d, fingers, split_flags, empty_flags in first_four
]
expected = [
    (
        53_089,
        1_475,
        (13_273, 6_637, 1_475, 6_638, 13_277),
        (True, True, True, True, False),
        (True, True, True, True, False),
        [(11, 1), (17, 1), (71, 1)],
        31,
    ),
    (
        202_129,
        5_615,
        (50_533, 25_267, 5_615, 25_268, 50_537),
        (True, True, True, True, False),
        (True, True, True, True, False),
        [(97, 1), (521, 1)],
        39,
    ),
    (
        415_969,
        11_555,
        (103_993, 51_997, 11_555, 51_998, 103_997),
        (True, True, True, True, False),
        (True, True, True, True, True),
        [(103_997, 1)],
        31,
    ),
]

report("bounded three-adic empty-edge row count", len(rows) == 96)
report("bounded first-four split row count", len(first_four) == 3)
report("bounded five-split row count", len(five_split) == 0)
report(
    "bounded residual-nineteen status distribution",
    status
    == Counter(
        {
            ("not-split", "empty"): 1,
            ("not-split", "occupied"): 2,
        }
    ),
)
report("bounded first-four split rows", observed == expected)

print(f"bound={BOUND - 1}")
print(f"three-adic empty R=23 edge rows={len(rows)}")
print(f"first-four split-supported rows={len(first_four)}")
print(f"all-five split-supported rows={len(five_split)}")
for row in observed:
    print(row)

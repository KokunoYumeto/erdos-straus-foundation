import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def matrix_equal(left, right, label):
    require(left.shape == right.shape, f"{label}: shape")
    for entry in left - right:
        require(sp.factor(entry) == 0, f"{label}: {sp.factor(entry)}")


# Symbolic orbit-type pushforward and C2 character transform.
alpha_1, alpha_2 = sp.symbols("alpha_1 alpha_2", positive=True)
eta = sp.Matrix([alpha_2, alpha_1 / 2])
target = sp.Matrix([alpha_1, alpha_2])
target_map = sp.Matrix([[0, 2], [1, 0]])
matrix_equal(target_map * eta, target, "orbit-to-target amplitude map")

L_eta = sp.Matrix(
    [
        [alpha_2, alpha_1 / 2],
        [alpha_1 / 2, alpha_2],
    ]
)
sqrt2 = sp.sqrt(2)
U0 = sp.Matrix([[1, 1], [1, -1]]) / sqrt2
Pi0 = U0[:, 0] * U0[:, 0].T
fourier = sp.diag(alpha_2 + alpha_1 / 2, alpha_2 - alpha_1 / 2)
matrix_equal(U0.T * L_eta * U0, fourier, "orbit-amplitude Fourier spectrum")
matrix_equal(
    L_eta,
    (alpha_2 - alpha_1 / 2) * sp.eye(2) + alpha_1 * Pi0,
    "orbit-amplitude projector form",
)

E12 = sp.Matrix([[0, 1], [0, 0]])
E21 = sp.Matrix([[0, 0], [1, 0]])
require(
    fourier * E12 - E12 * fourier == alpha_1 * E12,
    "positive ordered blade eigenvalue",
)
require(
    fourier * E21 - E21 * fourier == -alpha_1 * E21,
    "negative ordered blade eigenvalue",
)
gap = sp.factor(fourier[0, 0] - fourier[1, 1])
mass = sp.factor(sum(eta))
require(gap == alpha_1, "symbolic amplitude gap")
require(
    sp.simplify(mass - (alpha_2 + alpha_1 / 2)) == 0,
    "symbolic quotient mass",
)
require(
    sp.factor(gap - mass - (alpha_1 / 2 - alpha_2)) == 0,
    "symbolic balance defect",
)
lambda_plus = fourier[0, 0]
lambda_minus = fourier[1, 1]
require(
    sp.simplify((lambda_plus - lambda_minus) - alpha_1) == 0,
    "middle amplitude reconstruction",
)
require(
    sp.simplify((lambda_plus + lambda_minus) / 2 - alpha_2) == 0,
    "exterior amplitude reconstruction",
)
require(
    sp.simplify(2 * lambda_plus - (alpha_1 + 2 * alpha_2)) == 0,
    "full amplitude reconstruction",
)


# Exact 12289 shell and its orbit-type classification.
p = 12289
a = 3075
R0 = 11
N0 = p * a
ainv = pow(a, -1, R0)
pinv = pow(p, -1, R0)
targets = {0: (-p) % R0, 1: (-1) % R0, 2: (-pinv) % R0}

certificate_by_d = {}
for j in range(3):
    for u in sp.divisors(a * a):
        u = int(u)
        if (u * ainv) % R0 == targets[j]:
            certificate_by_d[p**j * u] = (j, u)

divisors = sorted(certificate_by_d)
require(len(divisors) == 12, "12289 certificate count")

seen = set()
external = []
middle = []
for d in divisors:
    if d in seen:
        continue
    reflected = N0 * N0 // d
    seen.update((d, reflected))
    representative = min(d, reflected)
    orbit_alpha = sp.Rational(
        4 * N0 * representative,
        (N0 + representative) ** 2,
    )
    j = certificate_by_d[d][0]
    reflected_j = certificate_by_d[reflected][0]
    if {j, reflected_j} == {0, 2}:
        external.append(orbit_alpha)
    elif j == reflected_j == 1:
        middle.append(orbit_alpha)
    else:
        raise AssertionError("unexpected complement-orbit type")

expected_external = [
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(921675, 38217124),
]
expected_middle = [
    sp.Rational(615, 94864),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
]
require(sorted(external) == sorted(expected_external), "exterior orbit amplitudes")
require(sorted(middle) == sorted(expected_middle), "middle orbit amplitudes")

A02 = sp.factor(sum(external))
A11 = sp.factor(sum(middle))
require(
    A02 == sp.Rational(
        5176199252561022635,
        209357204251173091344,
    ),
    "exterior orbit mass",
)
require(
    A11 == sp.Rational(1026107, 853776),
    "middle orbit mass",
)

alpha1_exact = 2 * A11
alpha2_exact = A02
eta_exact = sp.Matrix([alpha2_exact, alpha1_exact / 2])
L_exact = L_eta.subs({alpha_1: alpha1_exact, alpha_2: alpha2_exact})
fourier_exact = sp.factor(U0.T * L_exact * U0)
matrix_equal(
    fourier_exact,
    sp.diag(
        alpha2_exact + alpha1_exact / 2,
        alpha2_exact - alpha1_exact / 2,
    ),
    "exact 12289 amplitude spectrum",
)
require(
    alpha1_exact == sp.Rational(1026107, 426888),
    "12289 amplitude gap",
)
require(
    sp.factor(sum(eta_exact))
    - sp.Rational(
        128395625711903946059,
        104678602125586545672,
    )
    == 0,
    "12289 quotient amplitude mass",
)
defect = sp.factor(alpha1_exact - 2 * alpha2_exact)
require(
    defect
    == sp.Rational(
        28287287984238504,
        12015450198070081,
    ),
    "12289 amplitude balance defect",
)
require(defect > 0, "positive 12289 amplitude balance defect")

m1 = 6
m2 = 3
c = sp.Matrix([m2, sp.Rational(m1, 2)])
L_c = sp.Matrix([[c[0], c[1]], [c[1], c[0]]])
matrix_equal(U0.T * L_c * U0, sp.diag(6, 0), "12289 count spectrum")
require(6 - 0 == m2 + sp.Rational(m1, 2), "12289 count balance")

lines = [
    "PASS: orbit-amplitude pushforward to the ordered two-character blade",
    "the orbit-type trace map sends exterior amplitudes to alpha_2",
    "the orbit-type trace map sends middle amplitudes to alpha_1/2",
    "the exact coordinate map recovers the established two-target amplitude branch",
    "the C2 Fourier eigenvalues are alpha_2+alpha_1/2 and alpha_2-alpha_1/2",
    "the ordered blade eigenvalues are +alpha_1 and -alpha_1",
    "the Fourier gap equals the quotient amplitude exactly when alpha_1=2alpha_2",
    "the 12289 count pushforward is (3,3) with Fourier spectrum (6,0)",
    "the exact exterior and middle 12289 amplitude masses match the theorem",
    "the 12289 amplitude balance defect is the stated positive rational number",
    "the two Fourier characters reconstruct both origin amplitudes exactly",
    "the trivial-character eigenvalue is one half of the full shell amplitude",
]

print("\n".join(lines))

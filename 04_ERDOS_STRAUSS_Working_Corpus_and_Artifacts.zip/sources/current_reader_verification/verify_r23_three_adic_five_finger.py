from itertools import combinations
from math import gcd


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    divisor = 3
    while divisor * divisor <= n:
        if n % divisor == 0:
            return False
        divisor += 2
    return True


def original_fingers(d):
    center = 9 * d
    return tuple(center + offset for offset in (-2, -1, 0, 1, 2))


def reduced_fingers(d):
    original = original_fingers(d)
    return (
        original[0],
        original[1] // 2,
        original[2] // 9,
        original[3] // 2,
        original[4],
    )


def vandermonde(values):
    product = 1
    for left, right in combinations(values, 2):
        product *= right - left
    return product


odd_rows = []
for d in range(1, 10000, 2):
    original = original_fingers(d)
    reduced = reduced_fingers(d)
    reassembled = tuple(
        factor * value
        for factor, value in zip((1, 2, 9, 2, 1), reduced)
    )
    odd_rows.append(
        reassembled == original
        and all(gcd(reduced[i], reduced[j]) == 1 for i, j in combinations(range(5), 2))
    )

report(
    "three-adic five-Finger consecutive carrier",
    all(odd_rows),
)
report(
    "five-Finger fixed Vandermonde volume",
    all(
        vandermonde(original_fingers(d)) == 288
        and vandermonde(original_fingers(d)) ** 2 == 82944
        for d in range(1, 10000, 2)
    ),
)


SHADOW_MODULUS = 4 * 23 * 7 * 11 * 5
shadow_classes = tuple(
    d
    for d in range(SHADOW_MODULUS)
    if d % 4 == 3
    and d % 23 in {3, 9}
    and d % 7 in {1, 5, 6}
    and d % 11 in {1, 3, 4, 5, 9}
    and d % 5 in {0, 2}
)
report(
    "five-Finger sixty-class congruence shadow",
    SHADOW_MODULUS == 35420
    and len(shadow_classes) == 60
    and len(
        {
            (36 * d - 11) % (36 * SHADOW_MODULUS)
            for d in shadow_classes
        }
    )
    == 60,
)
report(
    "five-Finger residual-nineteen shadow bijection",
    all(
        {(residue + SHADOW_MODULUS * k) % 19 for k in range(19)}
        == set(range(19))
        and {
            (9 * (residue + SHADOW_MODULUS * k) + 2) % 19
            for k in range(19)
        }
        == set(range(19))
        for residue in shadow_classes
    ),
)


prime_rows = []
for p in range(13, 20000):
    if p % 48 != 1 or p % 23 not in {5, 14} or not is_prime(p):
        continue
    x = (p + 23) // 24
    if x % 3 != 2:
        continue
    d = (2 * x - 1) // 3
    actual = tuple((p + residual) // 4 for residual in (3, 7, 11, 15, 19))
    prime_rows.append(
        d % 2 == 1
        and actual == original_fingers(d)
        and all(
            gcd(reduced_fingers(d)[i], reduced_fingers(d)[j]) == 1
            for i, j in combinations(range(5), 2)
        )
    )

report(
    "three-adic five-Finger affine edge specialization",
    bool(prime_rows) and all(prime_rows),
)

print(f"odd centers checked: {len(odd_rows)}")
print(f"applicable affine edge primes checked: {len(prime_rows)}")
print(f"congruence-shadow classes: {len(shadow_classes)} modulo {SHADOW_MODULUS}")

"""Exact certificate for the marked C4 rank and support criterion."""

from fractions import Fraction
from itertools import product


def visible(x: int, y: int) -> int:
    return (x + y) % 2


def hidden(x: int, y: int) -> int:
    return x * y


def class_lift(x: int, y: int) -> int:
    return visible(x, y) + 2 * hidden(x, y)


def polar_coefficient(x: int, y: int) -> int:
    return (y - x) ** 2


def timelike_coefficient(x: int, y: int) -> int:
    return x * y


def lorentz_matrix(x: int, y: int) -> tuple[tuple[Fraction, Fraction], ...]:
    xf = Fraction(x)
    yf = Fraction(y)
    return (
        (yf + xf / 2, yf - xf / 2),
        (yf - xf / 2, yf + xf / 2),
    )


def determinant(matrix: tuple[tuple[Fraction, Fraction], ...]) -> Fraction:
    return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]


def rank_two_by_two(matrix: tuple[tuple[Fraction, Fraction], ...]) -> int:
    if determinant(matrix) != 0:
        return 2
    if any(entry != 0 for row in matrix for entry in row):
        return 1
    return 0


rows = []
for x, y in product(range(2), repeat=2):
    ell = visible(x, y)
    carry = hidden(x, y)
    lift = class_lift(x, y)
    matrix = lorentz_matrix(x, y)
    det = determinant(matrix)
    rank = rank_two_by_two(matrix)
    polar = polar_coefficient(x, y)
    timelike = timelike_coefficient(x, y)

    assert lift == x + y
    assert rank == lift
    assert polar + 2 * timelike == lift
    assert (lift != 0) == (x == 1 or y == 1)
    assert (rank == 1) == ((x, y) in {(1, 0), (0, 1)})
    assert (rank == 2) == ((x, y) == (1, 1))
    assert (det > 0) == (lift == 2)
    assert (det == 0 and rank > 0) == (lift == 1)

    rows.append((x, y, lift, rank, det, polar, timelike))

for x, y, lift, rank, det, polar, timelike in rows:
    print(
        f"beta=({x},{y}): class_lift={lift}, rank={rank}, "
        f"det={det}, polar={polar}, timelike={timelike}"
    )

assert {lift for _, _, lift, _, _, _, _ in rows} == {0, 1, 2}
assert all((lift > 0) == (rank > 0) for _, _, lift, rank, _, _, _ in rows)

print("local marked classes: 0=zero, 1=null, 2=timelike")
print("PASS: the marked C4 lift is the Lorentz rank and detects local support")

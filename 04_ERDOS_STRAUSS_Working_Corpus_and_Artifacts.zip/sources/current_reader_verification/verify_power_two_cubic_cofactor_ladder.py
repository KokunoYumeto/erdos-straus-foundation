#!/usr/bin/env python3
"""Exact checks for the cubic-cofactor extension of the power-of-two ladder."""

from __future__ import annotations

from fractions import Fraction
from math import gcd

from sympy import factorint, isprime


RUNGS = [
    (1, 19),
    (2, 241),
    (3, 331),
    (4, 37),
    (4, 109),
    (5, 5419),
    (6, 97),
    (6, 673),
    (7, 87211),
    (8, 61),
    (8, 1321),
]

PRIME_CERTIFICATES = [
    (1, 19, 49, 373),
    (1, 19, 1141, 9109),
    (1, 19, 1939, 15493),
    (1, 19, 2629, 21013),
    (1, 19, 429, 3413),
    (1, 19, 805, 6421),
    (1, 19, 3801, 30389),
    (1, 19, 220, 1741),
    (1, 19, 286, 2269),
    (1, 19, 330, 2621),
    (3, 331, 29791, 952981),
    (4, 37, 9917, 634651),
    (4, 37, 36989, 2367259),
    (4, 37, 59987, 3839131),
    (4, 109, 303239, 19407187),
    (4, 109, 1059089, 67781587),
    (5, 5419, 16129, 2059093),
    (6, 97, 23729, 6074527),
    (8, 61, 22373, 22909891),
]


def multiplicative_order(value: int, modulus: int) -> int:
    if gcd(value, modulus) != 1:
        raise ValueError("the residue is not a unit")
    running = 1
    for order in range(1, modulus + 1):
        running = running * value % modulus
        if running == 1:
            return order
    raise AssertionError("finite multiplicative order was not found")


def centered_local_support(prime: int, exponent: int, modulus: int) -> set[int]:
    inverse = pow(prime, -1, modulus)
    return {
        pow(prime, k, modulus) if k >= 0 else pow(inverse, -k, modulus)
        for k in range(-exponent, exponent + 1)
    }


def product_set(left: set[int], right: set[int], modulus: int) -> set[int]:
    return {x * y % modulus for x in left for y in right}


def cofactor_support(cofactor: int, modulus: int) -> set[int]:
    support = {1}
    for prime, exponent in factorint(cofactor).items():
        support = product_set(
            support,
            centered_local_support(prime, exponent, modulus),
            modulus,
        )
    return support


def cyclic_stabilizer(carrier: set[int], group: set[int], modulus: int) -> set[int]:
    return {
        shift
        for shift in group
        if {shift * value % modulus for value in carrier} == carrier
    }


def choose_divisor(
    exponent: int,
    residual: int,
    omega: int,
    cofactor: int,
) -> tuple[int, str]:
    power = 2**exponent
    a = power * cofactor
    cofactor_class = cofactor % residual
    omega_square = omega * omega % residual

    if cofactor_class == omega:
        return a, "omega"
    if cofactor_class == omega_square:
        return power, "omega-square"
    if cofactor_class != 1:
        raise AssertionError("the cofactor class is outside the cubic subgroup")

    prime = next(
        prime
        for prime in sorted(factorint(cofactor))
        if prime % residual in {omega, omega_square}
    )
    if prime % residual == omega:
        return a // prime, "identity-via-omega"
    if prime % residual == omega_square:
        return a * prime, "identity-via-omega-square"
    raise AssertionError("the selected prime is outside the cubic subgroup")


def check_cofactor(
    exponent: int,
    residual: int,
    cofactor: int,
    p: int,
    require_prime: bool,
) -> tuple[int, str, tuple[int, int, int]]:
    quotient_order = 2 * exponent + 4
    full_order = 3 * quotient_order
    assert multiplicative_order(2, residual) == full_order
    assert residual % 8 in {1, 3, 5}
    assert residual % 8 != 7

    omega = pow(2, quotient_order, residual)
    omega_square = omega * omega % residual
    cubic = {1, omega, omega_square}
    assert pow(omega, 3, residual) == 1
    assert len(cubic) == 3

    factors = factorint(cofactor)
    assert cofactor % residual in cubic
    assert any(
        prime % residual in {omega, omega_square}
        for prime in factors
    )
    full_cofactor_support = cofactor_support(cofactor, residual)
    assert cubic <= full_cofactor_support

    assert p == 2 ** (exponent + 2) * cofactor - residual
    assert p > 0
    assert p % 8 == (-residual) % 8
    assert p % 8 in {3, 5, 7}
    assert p % 8 != 1
    if require_prime:
        assert isprime(p)

    full_group = {pow(2, k, residual) for k in range(full_order)}
    local_two = centered_local_support(2, exponent, residual)
    carrier = product_set(local_two, cubic, residual)
    full_carrier = product_set(local_two, full_cofactor_support, residual)
    actual_support = cofactor_support(
        2**exponent * cofactor,
        residual,
    )
    assert cyclic_stabilizer(carrier, full_group, residual) == cubic
    assert carrier <= full_carrier
    assert full_carrier == actual_support

    assert (-pow(2, exponent + 2, residual)) % residual == omega_square
    target_ratio = (-p) % residual
    assert target_ratio == omega_square * (cofactor % residual) % residual
    assert target_ratio in carrier

    power = 2**exponent
    a = power * cofactor
    assert p + residual == 4 * a
    divisor, branch = choose_divisor(
        exponent,
        residual,
        omega,
        cofactor,
    )
    assert a * a % divisor == 0
    assert divisor * pow(a, -1, residual) % residual == target_ratio
    assert (a * p + divisor) % residual == 0

    partner = a * a * p * p // divisor
    assert divisor * partner == a * a * p * p
    assert (a * p + partner) % residual == 0

    y = (a * p + divisor) // residual
    z = (a * p + partner) // residual
    assert a > 0 and y > 0 and z > 0
    assert Fraction(4, p) == Fraction(1, a) + Fraction(1, y) + Fraction(1, z)
    return divisor, branch, (a, y, z)


def first_prime_in_class(residue: int, modulus: int) -> int:
    candidate = residue
    if candidate < 2:
        candidate += modulus
    while not isprime(candidate):
        candidate += modulus
    return candidate


def abstract_support_checks() -> int:
    assertions = 0
    for exponent in range(1, 201):
        for residue in (1, 2):
            support = {
                residue * k % 3
                for k in range(-exponent, exponent + 1)
            }
            assert support == {0, 1, 2}
            assertions += 1
    return assertions


def rung_template_checks() -> tuple[int, list[tuple[int, int, int, int]]]:
    assertions = 0
    records: list[tuple[int, int, int, int]] = []
    for exponent, residual in RUNGS:
        quotient_order = 2 * exponent + 4
        omega = pow(2, quotient_order, residual)
        prime = first_prime_in_class(omega, residual)
        cofactor = prime * prime
        p = 2 ** (exponent + 2) * cofactor - residual
        check_cofactor(
            exponent,
            residual,
            cofactor,
            p,
            require_prime=False,
        )
        assertions += 1
        records.append((exponent, residual, cofactor, p))
    return assertions, records


def arithmetic_certificate_checks(
) -> tuple[int, list[tuple[int, int, int, int, int, str, tuple[int, int, int]]]]:
    assertions = 0
    records = []
    for exponent, residual, cofactor, p in PRIME_CERTIFICATES:
        divisor, branch, denominators = check_cofactor(
            exponent,
            residual,
            cofactor,
            p,
            require_prime=True,
        )
        assertions += 1
        records.append(
            (
                exponent,
                residual,
                cofactor,
                p,
                divisor,
                branch,
                denominators,
            )
        )
    return assertions, records


def main() -> None:
    support_assertions = abstract_support_checks()
    template_assertions, templates = rung_template_checks()
    certificate_assertions, certificates = arithmetic_certificate_checks()

    print("PASS: cubic-cofactor power-of-two ladder")
    print(f"abstract cubic-support assertions: {support_assertions}")
    print(f"exact rung templates: {template_assertions}")
    print(f"prime arithmetic certificates: {certificate_assertions}")
    print(
        "congruence exclusion: "
        "R mod 8 lies in {1,3,5}; p mod 8 lies in {7,5,3}"
    )
    for exponent, residual, cofactor, p in templates:
        print(
            "template "
            f"e={exponent}, R={residual}, b={cofactor}, p={p}"
        )
    for (
        exponent,
        residual,
        cofactor,
        p,
        divisor,
        branch,
        denominators,
    ) in certificates:
        print(
            "certificate "
            f"e={exponent}, R={residual}, b={cofactor}, p={p}, "
            f"u={divisor}, branch={branch}, denominators={denominators}"
        )


if __name__ == "__main__":
    main()

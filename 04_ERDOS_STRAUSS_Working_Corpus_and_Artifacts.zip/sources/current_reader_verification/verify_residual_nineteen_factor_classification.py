from collections import Counter
import hashlib
from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


MODULUS = 18
EXTERIOR_TARGET = 7
MIDDLE_TARGET = 9
FULL_MASK = (1 << MODULUS) - 1
EXPECTED_PROFILE = {
    1: 2,
    2: 32,
    3: 91,
    4: 30,
    5: 9,
    6: 5,
    7: 3,
    8: 1,
    9: 1,
}
EXPECTED_HASH = (
    "d2b4644e85c20abe36ad943b8e5b5bbd659d758f3ed1bbd9dc7307f418ae4d01"
)
EXPECTED_DEGREE_ONE = {(7,), (9,)}
EXPECTED_DEGREE_TWO = {
    (1, 3),
    (1, 5),
    (1, 6),
    (1, 8),
    (1, 10),
    (1, 12),
    (2, 3),
    (2, 5),
    (2, 11),
    (3, 4),
    (3, 6),
    (3, 11),
    (3, 12),
    (4, 5),
    (4, 13),
    (4, 17),
    (5, 10),
    (5, 14),
    (5, 15),
    (6, 13),
    (6, 15),
    (8, 17),
    (10, 15),
    (10, 17),
    (11, 14),
    (11, 16),
    (12, 13),
    (12, 15),
    (13, 14),
    (13, 15),
    (13, 17),
    (14, 15),
}


def rotate(mask, shift):
    shift %= MODULUS
    if shift == 0:
        return mask
    return (
        (mask << shift)
        | (mask >> (MODULUS - shift))
    ) & FULL_MASK


reachability_cache = {(): (1, 1)}


def reachability(logs):
    cached = reachability_cache.get(logs)
    if cached is not None:
        return cached
    exterior, middle = reachability(logs[:-1])
    logarithm = logs[-1]
    result = (
        exterior
        | rotate(exterior, logarithm)
        | rotate(exterior, 2 * logarithm),
        rotate(middle, -logarithm)
        | middle
        | rotate(middle, logarithm),
    )
    reachability_cache[logs] = result
    return result


def occupied_logs(logs):
    exterior, middle = reachability(logs)
    return bool(
        exterior & (1 << EXTERIOR_TARGET)
        or middle & (1 << MIDDLE_TARGET)
    )


def one_term_deletions(logs):
    return {
        logs[:index] + logs[index + 1 :]
        for index in range(len(logs))
    }


safe = {()}
minimal = set()
for degree in range(1, MODULUS):
    candidates = {
        prefix + (logarithm,)
        for prefix in safe
        for logarithm in range(prefix[-1] if prefix else 1, MODULUS)
    }
    next_safe = {logs for logs in candidates if not occupied_logs(logs)}
    minimal.update(
        logs
        for logs in candidates - next_safe
        if all(
            not occupied_logs(row)
            for row in one_term_deletions(logs)
        )
    )
    safe = next_safe


profile = Counter(map(len, minimal))
canonical = "\n".join(
    ",".join(map(str, row))
    for row in sorted(minimal, key=lambda row: (len(row), row))
)
canonical_hash = hashlib.sha256(canonical.encode()).hexdigest()

report(
    "R=19 minimal factor-log antichain",
    len(minimal) == 174
    and dict(profile) == EXPECTED_PROFILE
    and canonical_hash == EXPECTED_HASH,
)
report(
    "R=19 degree-one and degree-two carriers",
    {row for row in minimal if len(row) == 1} == EXPECTED_DEGREE_ONE
    and {row for row in minimal if len(row) == 2} == EXPECTED_DEGREE_TWO,
)


POWER_RESIDUES = tuple(pow(2, exponent, 19) for exponent in range(1, 18))
LOG_OF_RESIDUE = {
    residue: exponent
    for exponent, residue in enumerate(POWER_RESIDUES, 1)
}


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for divisor in range(3, isqrt(n) + 1, 2):
        if n % divisor == 0:
            return False
    return True


def factorization(n):
    factors = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            n //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor += 1 if divisor == 2 else 2
    if n > 1:
        factors.append((n, 1))
    return tuple(factors)


def divisors_from_factorization(factors):
    values = [1]
    for prime, exponent in factors:
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(values)


def log_multiset(n):
    logs = []
    for prime, exponent in factorization(n):
        logarithm = LOG_OF_RESIDUE.get(prime % 19, 0)
        if logarithm:
            logs.extend([logarithm] * exponent)
    return tuple(sorted(logs))


def contains_multiset(logs, pattern):
    available = Counter(logs)
    required = Counter(pattern)
    return all(available[value] >= count for value, count in required.items())


def predicted_occupied(n):
    logs = log_multiset(n)
    return any(contains_multiset(logs, pattern) for pattern in minimal)


def exterior_count(n):
    square_factors = tuple(
        (prime, 2 * exponent)
        for prime, exponent in factorization(n)
    )
    return sum(
        (4 * divisor + 1) % 19 == 0
        for divisor in divisors_from_factorization(square_factors)
    )


def middle_coefficient(n):
    values = divisors_from_factorization(factorization(n))
    return sum(
        gcd(left, right) == 1
        and n % (left * right) == 0
        and (left + right) % 19 == 0
        for left in values
        for right in values
    )


integer_rows = []
for value in range(1, 3001):
    if value % 19 == 0:
        continue
    actual = exterior_count(value) + middle_coefficient(value) // 2 > 0
    integer_rows.append(actual == predicted_occupied(value))

report(
    "R=19 classification on coprime integers",
    all(integer_rows),
)


prime_rows = []
for prime in range(13, 20001):
    if prime % 12 != 1 or not is_prime(prime):
        continue
    denominator = (prime + 19) // 4
    actual = (
        exterior_count(denominator)
        + middle_coefficient(denominator) // 2
        > 0
    )
    prime_rows.append(actual == predicted_occupied(denominator))

report(
    "R=19 affine prime-shell classification",
    all(prime_rows),
)


late_prime = 53089
late_denominator = (late_prime + 19) // 4
late_logs = log_multiset(late_denominator)
report(
    "R=19 late edge-survivor degree-one certificate",
    factorization((late_prime + 23) // 12) == ((2, 1), (2213, 1))
    and factorization(late_denominator) == ((11, 1), (17, 1), (71, 1))
    and 71 % 19 == 14
    and 7 in late_logs
    and predicted_occupied(late_denominator),
)


print(f"minimal generators: {len(minimal)}")
print(f"degree profile: {dict(sorted(profile.items()))}")
print(f"canonical SHA-256: {canonical_hash}")
print(f"coprime integers checked: {len(integer_rows)}")
print(f"affine prime shells checked: {len(prime_rows)}")

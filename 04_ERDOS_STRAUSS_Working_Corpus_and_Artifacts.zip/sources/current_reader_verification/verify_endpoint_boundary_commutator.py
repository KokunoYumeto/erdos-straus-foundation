from collections import Counter
from math import gcd
from pathlib import Path
import sys

from scan_coupled_shell_coverage import (
    divisors_from_factorization,
    factor_integer,
    prime_sieve,
)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


PRIME_LIMIT = 2_000

E11 = (1, 0, 0, 0)
E12 = (0, 1, 0, 0)
E21 = (0, 0, 1, 0)
E22 = (0, 0, 0, 1)
J_B = (1, 0, 0, -1)
D = (9, 0, 0, -3)


def add(left, right):
    return tuple(x + y for x, y in zip(left, right))


def scale(value, matrix):
    return tuple(value * entry for entry in matrix)


def multiply(left, right):
    a, b, c, d = left
    e, f, g, h = right
    return (
        a * e + b * g,
        a * f + b * h,
        c * e + d * g,
        c * f + d * h,
    )


def commutator(left, right):
    return add(multiply(left, right), scale(-1, multiply(right, left)))


def norm_squared(matrix):
    return sum(entry * entry for entry in matrix)


def cell(target_bit, source_bit):
    table = {
        (1, 1): E11,
        (1, 0): E12,
        (0, 1): E21,
        (0, 0): E22,
    }
    return table[(target_bit, source_bit)]


def audit_shell(p, residual, a, divisors):
    support = {divisor % residual for divisor in divisors}
    assert all(gcd(value, residual) == 1 for value in support)

    def rotation(value):
        return p * value % residual

    def reflection(value):
        return a * a * pow(value, -1, residual) % residual

    def crossed_reflection(value):
        return reflection(rotation(value))

    assert {reflection(value) for value in support} == support

    outgoing = {
        value
        for value in support
        if rotation(value) not in support
    }
    inverse_p = pow(p, -1, residual)
    incoming = {
        inverse_p * value % residual
        for value in support
        if inverse_p * value % residual not in support
    }
    preimage_support = {
        inverse_p * value % residual
        for value in support
    }
    assert incoming == preimage_support - support
    assert {crossed_reflection(value) for value in outgoing} == incoming
    assert {crossed_reflection(value) for value in incoming} == outgoing
    assert all(
        crossed_reflection(crossed_reflection(value)) == value
        for value in outgoing | incoming
    )
    assert all(
        value in support and rotation(value) not in support
        for value in outgoing
    )
    assert all(
        value not in support and rotation(value) in support
        for value in incoming
    )

    boundary_energy = len(support ^ preimage_support)
    boundary_vertices = support | preimage_support
    boolean_energy = sum(
        (
            int(rotation(value) in support)
            - int(value in support)
        )
        ** 2
        for value in boundary_vertices
    )
    jb_energy = sum(
        norm_squared(
            commutator(
                J_B,
                cell(
                    int(rotation(value) in support),
                    int(value in support),
                ),
            )
        )
        for value in boundary_vertices
    )
    d_energy = sum(
        norm_squared(
            commutator(
                D,
                cell(
                    int(rotation(value) in support),
                    int(value in support),
                ),
            )
        )
        for value in boundary_vertices
    )
    rotation_stable = {
        rotation(value) for value in support
    } == support
    assert boundary_energy == boolean_energy
    assert boundary_energy == len(outgoing) + len(incoming)
    assert boundary_energy == 2 * len(outgoing) == 2 * len(incoming)
    assert jb_energy == 4 * boundary_energy
    assert d_energy == 144 * boundary_energy
    assert (boundary_energy == 0) == rotation_stable
    assert boundary_energy % 2 == 0

    inverse_four = pow(4, -1, residual)
    exterior = (-inverse_four) % residual
    middle = (-a) % residual
    opposite = p * middle % residual
    assert middle == rotation(exterior)
    assert opposite == rotation(middle)

    endpoint_bits = tuple(
        int(value in support) for value in (exterior, middle, opposite)
    )
    incoming_edge = cell(endpoint_bits[1], endpoint_bits[0])
    outgoing_edge = cell(endpoint_bits[2], endpoint_bits[1])
    transition_counts = Counter()
    transition_counts[(endpoint_bits[0], endpoint_bits[1])] += 1
    transition_counts[(endpoint_bits[1], endpoint_bits[2])] += 1
    endpoint_pattern = {
        (0, 0, 0): "empty",
        (1, 0, 1): "exterior-only",
        (0, 1, 0): "middle-only",
        (1, 1, 1): "both",
    }[endpoint_bits]
    exterior_count = sum(
        (4 * divisor + 1) % residual == 0
        for divisor in divisors
    )
    middle_count = sum(
        (divisor + a) % residual == 0
        for divisor in divisors
    )
    assert middle_count % 2 == 0
    orbit_count = exterior_count + middle_count // 2
    assert (orbit_count > 0) == (endpoint_pattern != "empty")
    labelled_energy = (
        (endpoint_bits[1] - endpoint_bits[0]) ** 2
        + (endpoint_bits[2] - endpoint_bits[1]) ** 2
    )
    assert labelled_energy == (
        norm_squared(commutator(J_B, incoming_edge))
        + norm_squared(commutator(J_B, outgoing_edge))
    ) // 4

    if endpoint_pattern == "exterior-only":
        assert exterior in outgoing
        assert middle in incoming
        assert (incoming_edge, outgoing_edge) == (E21, E12)
        assert labelled_energy == 2
    elif endpoint_pattern == "middle-only":
        assert exterior in incoming
        assert middle in outgoing
        assert (incoming_edge, outgoing_edge) == (E12, E21)
        assert labelled_energy == 2
    else:
        assert incoming_edge == outgoing_edge
        assert labelled_energy == 0

    return (
        len(outgoing),
        len(incoming),
        endpoint_pattern,
        transition_counts,
        boundary_energy,
        labelled_energy,
        rotation_stable,
        orbit_count,
    )


sieve = prime_sieve(PRIME_LIMIT)
trial_primes = [value for value in range(2, PRIME_LIMIT + 1) if sieve[value]]
shell_count = 0
outgoing_count = 0
incoming_count = 0
pattern_counts = Counter()
transition_counts = Counter()
boundary_energy_total = 0
labelled_energy_total = 0
zero_energy_shell_count = 0
primewise_data = {}

for p in range(5, PRIME_LIMIT + 1, 4):
    if not sieve[p]:
        continue
    for residual in range(3, 2 * p, 4):
        a = (p + residual) // 4
        factors = factor_integer(a, trial_primes)
        divisors = divisors_from_factorization(
            tuple((prime, 2 * exponent) for prime, exponent in factors)
        )
        (
            outgoing,
            incoming,
            pattern,
            transitions,
            boundary_energy,
            labelled_energy,
            rotation_stable,
            orbit_count,
        ) = audit_shell(
            p, residual, a, divisors
        )
        shell_count += 1
        outgoing_count += outgoing
        incoming_count += incoming
        pattern_counts[pattern] += 1
        transition_counts.update(transitions)
        boundary_energy_total += boundary_energy
        labelled_energy_total += labelled_energy
        zero_energy_shell_count += int(rotation_stable)
        data = primewise_data.setdefault(
            p,
            {
                "Q": 0,
                "labelled_energy": 0,
                "one_sided": 0,
                "sharp": True,
            },
        )
        data["Q"] += orbit_count
        data["labelled_energy"] += labelled_energy
        if pattern in {"exterior-only", "middle-only"}:
            data["one_sided"] += 1
        if orbit_count > 0 and (
            pattern not in {"exterior-only", "middle-only"}
            or orbit_count != 1
        ):
            data["sharp"] = False

assert outgoing_count == incoming_count
assert boundary_energy_total == 2 * outgoing_count
assert labelled_energy_total == 2 * (
    pattern_counts["exterior-only"] + pattern_counts["middle-only"]
)
assert zero_energy_shell_count == 771
primewise_equality_count = 0
for data in primewise_data.values():
    assert data["labelled_energy"] == 2 * data["one_sided"]
    assert data["labelled_energy"] <= 2 * data["Q"]
    equality = data["labelled_energy"] == 2 * data["Q"]
    assert equality == data["sharp"]
    assert data["labelled_energy"] == 0 or data["Q"] > 0
    primewise_equality_count += int(equality)

for source_bit in (0, 1):
    for target_bit in (0, 1):
        derivative = target_bit - source_bit
        transition = cell(target_bit, source_bit)
        assert commutator(J_B, transition) == scale(
            2 * derivative, transition
        )
        assert commutator(D, transition) == scale(
            12 * derivative, transition
        )
assert cell(0, 1) == E21
assert cell(1, 0) == E12

p_107 = 8_803_369
r_107 = 107
a_107 = 2_200_869
divisors_107 = divisors_from_factorization(((3, 4), (11, 4), (43, 2), (47, 2)))
(
    out_107,
    in_107,
    pattern_107,
    _,
    boundary_energy_107,
    labelled_energy_107,
    rotation_stable_107,
    orbit_count_107,
) = audit_shell(
    p_107, r_107, a_107, divisors_107
)
assert pattern_107 == "middle-only"
support_107 = {value % r_107 for value in divisors_107}
exterior_107 = (-pow(4, -1, r_107)) % r_107
middle_107 = (-a_107) % r_107
opposite_107 = p_107 * middle_107 % r_107
assert tuple(
    int(value in support_107)
    for value in (exterior_107, middle_107, opposite_107)
) == (0, 1, 0)
assert cell(1, 0) == E12
assert cell(0, 1) == E21
assert commutator(D, E21) == scale(-12, E21)
assert boundary_energy_107 == 20
assert labelled_energy_107 == 2
assert not rotation_stable_107
assert orbit_count_107 == 1

print("PASS: endpoint boundary involution and blade commutator")
print(f"all admissible shells through p={PRIME_LIMIT}: {shell_count}")
print(f"outgoing boundary sources: {outgoing_count}")
print(f"incoming boundary sources: {incoming_count}")
print(f"total support-boundary energy: {boundary_energy_total}")
print(f"zero-energy rotation-stable shells: {zero_energy_shell_count}")
print(f"labelled endpoint energy: {labelled_energy_total}")
print(
    "primewise directional inequalities: "
    f"{len(primewise_data)}, equality cases: {primewise_equality_count}"
)
print("endpoint patterns:")
for pattern in ("empty", "exterior-only", "middle-only", "both"):
    print(f"  {pattern}: {pattern_counts[pattern]}")
print("labelled-endpoint transition counts:")
for bits in ((0, 0), (0, 1), (1, 0), (1, 1)):
    print(f"  {bits[0]}->{bits[1]}: {transition_counts[bits]}")
print(
    "R107: pattern=middle-only, incoming edge=E12, "
    "outgoing edge=E21, [D,E21]=-12E21, "
    "full energy=20, labelled energy=2"
)

from __future__ import annotations

import sympy as sp


def require(statement: bool, message: str) -> None:
    if not statement:
        raise AssertionError(message)
    print(f"PASS {message}")


z = sp.symbols("z")


def power_sums(poly: sp.Expr, count: int) -> list[sp.Expr]:
    polynomial = sp.Poly(poly, z).monic()
    degree = polynomial.degree()
    coefficients = polynomial.all_coeffs()[1:]
    moments: list[sp.Expr] = [sp.Integer(degree)]
    for k in range(1, count):
        if k <= degree:
            value = -sum(
                coefficients[j - 1] * moments[k - j]
                for j in range(1, k)
            ) - k * coefficients[k - 1]
        else:
            value = -sum(
                coefficients[j - 1] * moments[k - j]
                for j in range(1, degree + 1)
            )
        moments.append(sp.factor(value))
    return moments


def first_nonzero(values: list[sp.Expr]) -> int:
    for index, value in enumerate(values):
        if sp.factor(value) != 0:
            return index
    raise AssertionError("the tested signed-moment list is identically zero")


def check_degree_law(
    p_02: sp.Expr,
    p_11: sp.Expr,
    expected_order: int,
    message: str,
) -> None:
    p_02 = sp.Poly(p_02, z).monic().as_expr()
    p_11 = sp.Poly(p_11, z).monic().as_expr()
    common = sp.gcd(sp.Poly(p_02, z), sp.Poly(p_11, z)).monic().as_expr()
    a_poly = sp.cancel(p_02 / common)
    b_poly = sp.cancel(p_11 / common)
    reduced = sp.Poly(
        sp.expand(sp.diff(a_poly, z) * b_poly - sp.diff(b_poly, z) * a_poly),
        z,
    )
    unreduced = sp.Poly(
        sp.expand(sp.diff(p_02, z) * p_11 - sp.diff(p_11, z) * p_02),
        z,
    )
    signed_moments = [
        sp.factor(x - y)
        for x, y in zip(
            power_sums(p_02, 10),
            power_sums(p_11, 10),
            strict=True,
        )
    ]
    order = first_nonzero(signed_moments)
    reduced_degree = sp.degree(a_poly, z) + sp.degree(b_poly, z)
    total_degree = sp.degree(p_02, z) + sp.degree(p_11, z)
    require(order == expected_order, f"{message}: the first signed moment has the expected order")
    require(
        reduced.degree() == reduced_degree - order - 1,
        f"{message}: the reduced numerator has the defect-predicted degree",
    )
    require(
        sp.factor(reduced.LC() - signed_moments[order]) == 0,
        f"{message}: the reduced leading coefficient is the first signed moment",
    )
    require(
        unreduced.degree() == total_degree - order - 1,
        f"{message}: the unreduced numerator has the defect-predicted degree",
    )
    require(
        sp.factor(unreduced.LC() - signed_moments[order]) == 0,
        f"{message}: the unreduced leading coefficient is the first signed moment",
    )


# Cardinality, first-moment, second-moment, and third-moment strata.
check_degree_law((z - 1) * (z - 2), z - 4, 0, "cardinality stratum")
check_degree_law(
    z**3 + 2 * z**2 + 3 * z + 5,
    z**3 + 7 * z**2 + 11 * z + 13,
    1,
    "first-moment stratum",
)
check_degree_law(
    z**3 + 2 * z**2 + 3 * z + 5,
    z**3 + 2 * z**2 + 11 * z + 13,
    2,
    "second-moment stratum",
)
check_degree_law(
    z**3 + 2 * z**2 + 3 * z + 5,
    z**3 + 2 * z**2 + 3 * z + 13,
    3,
    "third-moment stratum",
)

# A shared quadratic factor checks the reduced and unreduced forms at once.
shared = (z - 2) * (z - 3)
check_degree_law(
    shared * (z - 5),
    shared * (z - 7),
    1,
    "common-factor stratum",
)

# Equality is equivalent to complete vanishing of the rational character.
identical = (z - 2) ** 2 * (z - 5)
identical_wronskian = sp.expand(
    sp.diff(identical, z) * identical - sp.diff(identical, z) * identical
)
require(identical_wronskian == 0, "equal type polynomials have zero signed numerator")
require(
    all(
        x - y == 0
        for x, y in zip(
            power_sums(identical, 8),
            power_sums(identical, 8),
            strict=True,
        )
    ),
    "equal type polynomials have zero signed moments",
)

# Newton identities and the first differing coefficient.
a1, a2, a3, b2, b3 = sp.symbols("a1 a2 a3 b2 b3")
p = z**3 + a1 * z**2 + a2 * z + a3
q_second = z**3 + a1 * z**2 + b2 * z + b3
q_third = z**3 + a1 * z**2 + a2 * z + b3
p_moments = power_sums(p, 4)
q_second_moments = power_sums(q_second, 4)
q_third_moments = power_sums(q_third, 4)
require(
    sp.factor(p_moments[1] - q_second_moments[1]) == 0
    and sp.factor(p_moments[2] - q_second_moments[2] - 2 * (b2 - a2)) == 0,
    "Newton identities give S2 = 2(b2-a2) at the second stratum",
)
require(
    sp.factor(p_moments[1] - q_third_moments[1]) == 0
    and sp.factor(p_moments[2] - q_third_moments[2]) == 0
    and sp.factor(p_moments[3] - q_third_moments[3] - 3 * (b3 - a3)) == 0,
    "Newton identities give S3 = 3(b3-a3) at the third stratum",
)

# Exact 12289 shell.
roots_02 = [
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(921675, 38217124),
]
roots_11 = [
    sp.Rational(615, 94864),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
]
p_12289_02 = sp.prod(z - value for value in roots_02)
p_12289_11 = sp.prod(z - value for value in roots_11)
moments_12289_02 = [sum(value**k for value in roots_02) for k in range(7)]
moments_12289_11 = [sum(value**k for value in roots_11) for k in range(7)]
signed_12289 = [
    sp.factor(x - y)
    for x, y in zip(moments_12289_02, moments_12289_11, strict=True)
]
lambda_minus = -sp.Rational(14143643992119252, 12015450198070081)
wronskian_12289 = sp.Poly(
    sp.expand(
        sp.diff(p_12289_02, z) * p_12289_11
        - sp.diff(p_12289_11, z) * p_12289_02
    ),
    z,
)
require(signed_12289[0] == 0, "the 12289 shell has zero cardinality defect")
require(signed_12289[1] == lambda_minus, "the 12289 first defect is the exact skew character")
require(wronskian_12289.degree() == 4, "the 12289 defect order forces a quartic numerator")
require(
    wronskian_12289.LC() == lambda_minus,
    "the 12289 quartic leading coefficient is the exact skew character",
)
coeff_02 = sp.Poly(p_12289_02, z).all_coeffs()[1]
coeff_11 = sp.Poly(p_12289_11, z).all_coeffs()[1]
require(
    sp.factor(coeff_11 - coeff_02 - lambda_minus) == 0,
    "the 12289 first coefficient difference is the exact skew character",
)

# Resolvent Lorentz splitting begins at the same order.
xi_12289 = sp.cancel(
    sp.diff(p_12289_02, z) / p_12289_02
    - sp.diff(p_12289_11, z) / p_12289_11
)
w = sp.symbols("w")
at_infinity = sp.series(xi_12289.subs(z, 1 / w), w, 0, 4).removeO()
require(
    sp.expand(at_infinity).coeff(w, 1) == 0
    and sp.expand(at_infinity).coeff(w, 2) == lambda_minus,
    "the 12289 Lorentz eigenvalue splitting begins at order z^-2",
)

print("PASS all signed-moment defect-filtration checks completed")

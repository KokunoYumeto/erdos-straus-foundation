from fractions import Fraction
from math import gcd


STEPS = 47_176_870
SCANNED_CELLS = 12_289
SHELL_GAP = 12


# A path with STEPS unit edges has STEPS + 1 ordered vertices and endpoint
# distance STEPS.  Distinctness of the configurations is proved in the
# manuscript from determinism and first halting time.
trajectory_vertices = STEPS + 1
trajectory_edges = trajectory_vertices - 1
endpoint_distance = trajectory_edges
trajectory_hausdorff_measure = trajectory_edges
if endpoint_distance != STEPS:
    raise AssertionError("trajectory endpoint distance")
if trajectory_hausdorff_measure != endpoint_distance:
    raise AssertionError("trajectory path-volume identity")

# Nearest-neighbour motion makes the scanned support an integer interval.
# Translation of that interval does not change its unit-cell measure.
left_endpoint = -4_321
scanned_indices = range(left_endpoint, left_endpoint + SCANNED_CELLS)
right_endpoint = scanned_indices.stop - 1
unit_cell_measure = (right_endpoint + 1) - left_endpoint
if unit_cell_measure != SCANNED_CELLS:
    raise AssertionError("scanned-support unit-cell measure")

if gcd(STEPS, SCANNED_CELLS) != 1:
    raise AssertionError("operation-length/tape-volume coprimality")
operation_volume_ratio = Fraction(STEPS, SCANNED_CELLS)
if operation_volume_ratio != Fraction(47_176_870, 12_289):
    raise AssertionError("operation-length/tape-volume ratio")

omega_11_of_tape_volume = sum((3, 6, 3))
if omega_11_of_tape_volume != SHELL_GAP:
    raise AssertionError("tape-volume-to-shell-gap carrier")

print("PASS: exact Busy-Beaver operation-length and tape-volume carrier")
print(f"trajectory vertices = {trajectory_vertices}")
print(
    "trajectory unit edges = endpoint distance = one-dimensional "
    f"Hausdorff measure = {endpoint_distance}"
)
print(f"scanned unit cells = one-dimensional measure = {unit_cell_measure}")
print(f"reduced operation/volume ratio = {operation_volume_ratio}")
print("Omega_11(tape volume 12289) = shell gap 12")

import sympy as sp


I2 = sp.eye(2)
sigma_z = sp.diag(1, -1)
D = sp.diag(9, -3)
D_hat = D - sp.trace(D) * I2 / 2

if D != 3 * I2 + 6 * sigma_z:
    raise AssertionError("central/traceless decomposition")
if D_hat != 6 * sigma_z:
    raise AssertionError("traceless Hamiltonian")

e12 = sp.Matrix([[0, 1], [0, 0]])
e21 = sp.Matrix([[0, 0], [1, 0]])
for blade, eigenvalue in ((e12, 12), (e21, -12)):
    if D_hat * blade - blade * D_hat != eigenvalue * blade:
        raise AssertionError("ordered blade eigenvalue")

pauli_path_length = sp.Integer(6)
shell_gap = sp.Integer(12)
if 2 * pauli_path_length != shell_gap:
    raise AssertionError("lifted length/shell-gap identity")

delta = 2 * sp.pi - 6
if not (0 < float(sp.N(delta, 30)) < 1):
    raise AssertionError("principal endpoint angle")

endpoint = sp.diag(sp.exp(-6 * sp.I), sp.exp(6 * sp.I))
one_gate_endpoint = sp.diag(sp.exp(sp.I * delta), sp.exp(-sp.I * delta))
for j in range(2):
    if sp.simplify(endpoint[j, j] / one_gate_endpoint[j, j] - 1) != 0:
        raise AssertionError("one-gate endpoint identity")

print("PASS: exact lifted Pauli-geometry carrier of the shell gap")
print("D = 3 I_2 + 6 sigma_z and D_hat = 6 sigma_z")
print("ordered blade eigenvalues of ad(D_hat) = (+12,-12)")
print("lifted torus path length = 6 = shell gap / 2")
print("endpoint fibre = 6 + 2*pi*Z")
print("principal endpoint distance = 2*pi - 6, with 0 < 2*pi - 6 < 1")
print("endpoint is one signed-Pauli rotation; exact gate count = 1")

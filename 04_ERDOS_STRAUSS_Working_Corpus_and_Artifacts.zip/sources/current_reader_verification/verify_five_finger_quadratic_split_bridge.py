from math import gcd


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def legendre_residue(value, prime):
    residue = value % prime
    if residue == 0:
        return 0
    power = pow(residue, (prime - 1) // 2, prime)
    return 1 if power == 1 else -1


def chi_minus_15(value):
    if gcd(value, 15) != 1:
        return 0
    return legendre_residue(value, 3) * legendre_residue(value, 5)


expected = {
    3: {1},
    7: {1, 2, 4},
    11: {1, 3, 4, 5, 9},
    15: {1, 2, 4, 8},
}

actual = {
    3: {a for a in range(1, 3) if gcd(a, 3) == 1 and legendre_residue(a, 3) == 1},
    7: {a for a in range(1, 7) if gcd(a, 7) == 1 and legendre_residue(a, 7) == 1},
    11: {
        a
        for a in range(1, 11)
        if gcd(a, 11) == 1 and legendre_residue(a, 11) == 1
    },
    15: {a for a in range(1, 15) if chi_minus_15(a) == 1},
}

report("first-four Finger quadratic character kernels", actual == expected)

split_19 = {pow(2, 2 * exponent, 19) for exponent in range(9)}
even_logs = {2 * exponent % 18 for exponent in range(9)}
report(
    "residual-nineteen split residue set",
    split_19 == {1, 4, 5, 6, 7, 9, 11, 16, 17}
    and even_logs == set(range(0, 18, 2)),
)

report(
    "residual-nineteen split-log parity obstruction",
    all(
        coefficient * logarithm % 2 == 0
        for logarithm in even_logs
        for coefficient in {-1, 0, 1, 2}
    )
    and 7 % 2 == 1
    and 9 % 2 == 1,
)

print("quadratic character tables checked: 4")
print(f"residual-nineteen split residues: {sorted(split_19)}")

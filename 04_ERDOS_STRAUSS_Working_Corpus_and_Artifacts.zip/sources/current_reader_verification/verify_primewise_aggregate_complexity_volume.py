from sympy import Matrix, Rational, diag, log


def block_for_orbits(q):
    return diag(*([4] * (3 * q) + [-1] * (3 * q))) if q else Matrix.zeros(0, 0)


orbit_lists = [[], [1], [2], [1, 2], [1, 3, 2], [6], [2, 0, 4]]
for orbit_counts in orbit_lists:
    total = sum(orbit_counts)
    blocks = [block_for_orbits(q) for q in orbit_counts if q]
    carrier = diag(*blocks) if blocks else Matrix.zeros(0, 0)

    if carrier.rows != 6 * total:
        raise AssertionError(f"wrong aggregate dimension for {orbit_counts}")
    determinant_volume = abs(carrier.det()) if total else 1
    if determinant_volume != 4 ** (3 * total):
        raise AssertionError(f"wrong determinant volume for {orbit_counts}")

    length_H_squared = (
        sum(entry ** 2 for entry in carrier.diagonal())
        if total
        else 0
    )
    if length_H_squared != 51 * total:
        raise AssertionError(f"wrong H control length for {orbit_counts}")

    if total:
        traceless = carrier - Rational(3, 2) * Matrix.eye(6 * total)
        length_K_squared = sum(entry ** 2 for entry in traceless.diagonal())
    else:
        length_K_squared = 0
    if length_K_squared != Rational(75, 2) * total:
        raise AssertionError(f"wrong traceless control length for {orbit_counts}")

    log_volume = 6 * total * log(2)
    if log_volume != Rational(2, 17) * log(2) * length_H_squared:
        raise AssertionError(f"first length-volume identity fails for {orbit_counts}")
    if log_volume != Rational(4, 25) * log(2) * length_K_squared:
        raise AssertionError(f"second length-volume identity fails for {orbit_counts}")

print("PASS: primewise aggregate complexity-volume identity")
print("the aggregate supported dimension is six times the projector rank")
print("the aggregate spectrum has 4 and -1 with equal multiplicity")
print("the determinant volume is 2 to the power six times the rank")
print("both squared control lengths are exact multiples of the rank")
print("projector occupancy, positive length, and volume greater than one agree")

#!/usr/bin/env python3
"""Exact ordered-origin maps for the adjacent R=31 and R=27 critical shells."""

from math import gcd, isqrt, prod


PRIMES = (353, 6113, 10433)
K31 = {1, 2, 4, 8, 16}
K27 = {1, 10, 19}
G31 = 3
G27 = 5

SHELL_DATA = {
    353: (
        (31, {2: 5, 3: 1}, K31, (1, 3)),
        (27, {5: 1, 19: 1}, K27, (3, 1)),
    ),
    6113: (
        (31, {2: 9, 3: 1}, K31, (1, 3)),
        (27, {5: 1, 307: 1}, K27, (3, 1)),
    ),
    10433: (
        (31, {2: 3, 3: 1, 109: 1}, K31, (1, 3, 1)),
        (27, {5: 1, 523: 1}, K27, (3, 1)),
    ),
}


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n) + 1, 2))


def coset(x, subgroup, modulus):
    return frozenset((x * k) % modulus for k in subgroup)


def product_set(left, right, modulus):
    return {(x * y) % modulus for x in left for y in right}


def quotient_image(values, subgroup, modulus):
    return {coset(x, subgroup, modulus) for x in values}


def divisors_from_factorization(factors):
    values = {1}
    for prime, exponent in factors.items():
        values = {
            value * prime ** power
            for value in values
            for power in range(exponent + 1)
        }
    return sorted(values)


def quotient_log(x, generator, subgroup, modulus):
    target = coset(x, subgroup, modulus)
    value = 1
    for exponent in range(6):
        if coset(value, subgroup, modulus) == target:
            return exponent
        value = value * generator % modulus
    raise AssertionError((x, generator, subgroup, modulus))


def ordered_target_logs(p, modulus, generator, subgroup):
    targets = ((-p) % modulus, (-1) % modulus, (-pow(p, -1, modulus)) % modulus)
    return tuple(
        quotient_log(target, generator, subgroup, modulus)
        for target in targets
    )


def quotient_order(generator, subgroup, modulus):
    return next(
        exponent
        for exponent in range(1, 7)
        if coset(pow(generator, exponent, modulus), subgroup, modulus)
        == coset(1, subgroup, modulus)
    )


def check_shell_pair(p):
    assert is_prime(p)
    assert quotient_order(G31, K31, 31) == 6
    assert quotient_order(G27, K27, 27) == 6

    shell_receipts = []
    ordered_logs = []
    distinguished_factors = []
    for modulus, factors_a, expected_stabilizer, expected_local_q in SHELL_DATA[p]:
        assert (p + modulus) % 4 == 0
        a = (p + modulus) // 4
        assert a == prod(prime ** exponent for prime, exponent in factors_a.items())

        local_sets = tuple(
            {pow(prime, exponent, modulus) for exponent in range(-width, width + 1)}
            for prime, width in factors_a.items()
        )
        carrier = {1}
        for local_set in local_sets:
            carrier = product_set(carrier, local_set, modulus)

        units = {x for x in range(1, modulus) if gcd(x, modulus) == 1}
        stabilizer = {
            h for h in units
            if {(h * x) % modulus for x in carrier} == carrier
        }
        assert stabilizer == expected_stabilizer

        generator = G31 if modulus == 31 else G27
        carrier_logs = {
            quotient_log(x, generator, stabilizer, modulus)
            for x in carrier
        }
        target_logs = ordered_target_logs(p, modulus, generator, stabilizer)
        assert carrier_logs == {0, 1, 5}
        assert set(target_logs) == {2, 3, 4}
        assert quotient_image(carrier, stabilizer, modulus).isdisjoint(
            quotient_image(
                {(-p) % modulus, (-1) % modulus, (-pow(p, -1, modulus)) % modulus},
                stabilizer,
                modulus,
            )
        )

        local_q = tuple(
            len(quotient_image(local_set, stabilizer, modulus))
            for local_set in local_sets
        )
        assert local_q == expected_local_q
        assert 1 + sum(size - 1 for size in local_q) == 3
        assert len(units) // len(stabilizer) == 6
        assert len(quotient_image(carrier, stabilizer, modulus)) == 3

        factors_n_squared = {
            prime: 2 * exponent for prime, exponent in factors_a.items()
        }
        factors_n_squared[p] = factors_n_squared.get(p, 0) + 2
        n_value = p * a
        candidates = tuple(
            divisor
            for divisor in divisors_from_factorization(factors_n_squared)
            if divisor % modulus == (-n_value) % modulus
        )
        assert candidates == ()

        contributors = tuple(
            prime
            for (prime, _), local_set in zip(factors_a.items(), local_sets)
            if {
                quotient_log(x, generator, stabilizer, modulus)
                for x in local_set
            } != {0}
        )
        expected_factor = 3 if modulus == 31 else 5
        assert contributors == (expected_factor,)
        assert factors_a[expected_factor] == 1
        u_plus = a * expected_factor
        u_minus = a // expected_factor
        assert (a * a) % u_plus == 0
        assert (a * a) % u_minus == 0
        assert u_plus * u_minus == a * a
        assert quotient_log(expected_factor, generator, stabilizer, modulus) == 1
        assert quotient_log(pow(expected_factor, -1, modulus), generator, stabilizer, modulus) == 5

        shell_receipts.append((modulus, a, n_value, local_q))
        ordered_logs.append(target_logs)
        distinguished_factors.append((expected_factor, u_plus, u_minus))

    upper_logs, lower_logs = ordered_logs
    assert upper_logs == (4, 3, 2)
    assert lower_logs == (2, 3, 4)

    admissible_signs = tuple(
        sign
        for sign in (1, -1)
        if tuple((sign * exponent) % 6 for exponent in upper_logs) == lower_logs
    )
    assert admissible_signs == (-1,)

    carrier = {0, 1, 5}
    target = {2, 3, 4}
    assert {(-exponent) % 6 for exponent in carrier} == carrier
    assert {(-exponent) % 6 for exponent in target} == target
    assert (-1) % 6 == 5
    assert (-5) % 6 == 1

    return (
        p,
        tuple(shell_receipts),
        tuple(distinguished_factors),
        upper_logs,
        lower_logs,
        admissible_signs[0],
    )


def check_linearized_channel():
    exchange = ((0, 1), (1, 0))
    plus = (1, 0)
    minus = (0, 1)

    def act(matrix, vector):
        return tuple(
            sum(matrix[row][column] * vector[column] for column in range(2))
            for row in range(2)
        )

    assert act(exchange, plus) == minus
    assert act(exchange, minus) == plus
    assert tuple(
        tuple(sum(exchange[i][k] * exchange[k][j] for k in range(2)) for j in range(2))
        for i in range(2)
    ) == ((1, 0), (0, 1))

    def multiply(left, right):
        return tuple(
            tuple(sum(left[i][k] * right[k][j] for k in range(2)) for j in range(2))
            for i in range(2)
        )

    arithmetic_sign = ((1, 0), (0, -1))
    blade_sign = ((-1, 0), (0, 1))
    theta = exchange
    assert multiply(blade_sign, theta) == multiply(theta, arithmetic_sign)
    assert multiply(theta, exchange) == multiply(exchange, theta)
    assert multiply(arithmetic_sign, exchange) == tuple(
        tuple(-entry for entry in row)
        for row in multiply(exchange, arithmetic_sign)
    )
    return exchange, theta


if __name__ == "__main__":
    receipts = tuple(check_shell_pair(p) for p in PRIMES)
    exchange, theta = check_linearized_channel()
    print("PASS adjacent ordered-origin inversions =", receipts)
    print("PASS linearized quotient channel matrix =", exchange)
    print("PASS blade channel permutation = E21 <-> E12")
    print("PASS logarithmic blade selector matrix =", theta)

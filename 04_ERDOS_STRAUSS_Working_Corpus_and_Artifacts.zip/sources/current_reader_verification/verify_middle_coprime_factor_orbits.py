from fractions import Fraction
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


shell_count = 0
middle_orbit_count = 0
balanced_orbit_count = 0

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue

    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        R = 4 * a - p
        if R <= 0 or R % 4 != 3:
            continue
        if gcd(R, a) != 1:
            raise AssertionError(f"shell coprimality fails at p={p}, a={a}, R={R}")

        shell_count += 1
        middle = [u for u in divisors(a * a) if (u + a) % R == 0]
        direct_orbits = {
            tuple(sorted((u, a * a // u)))
            for u in middle
        }
        if len(middle) != 2 * len(direct_orbits):
            raise AssertionError(f"middle fixed point occurs at p={p}, a={a}, R={R}")

        parameter_orbits = set()
        for u, v in direct_orbits:
            common = gcd(u, a)
            x = u // common
            y = a // common
            if common % x:
                raise AssertionError(
                    f"coprime-factor extraction fails at p={p}, a={a}, R={R}, u={u}"
                )
            h = common // x
            if not (
                gcd(x, y) == 1
                and u == h * x * x
                and v == h * y * y
                and a == h * x * y
                and (x + y) % R == 0
            ):
                raise AssertionError(
                    f"middle parameter equations fail at p={p}, a={a}, R={R}, u={u}"
                )
            parameter_orbits.add((min(x, y), max(x, y), h))

        expected_orbits = set()
        for x in divisors(a):
            for y in divisors(a // x):
                if x > y or gcd(x, y) != 1 or a % (x * y):
                    continue
                h = a // (x * y)
                if (x + y) % R == 0:
                    expected_orbits.add((x, y, h))

        if parameter_orbits != expected_orbits:
            raise AssertionError(
                f"middle orbit bijection fails at p={p}, a={a}, R={R}"
            )

        for u in middle:
            k = (u + a) // R
            if gcd(k, a) != gcd(u, a):
                raise AssertionError(
                    f"k-gcd identity fails at p={p}, a={a}, R={R}, u={u}"
                )
            if (gcd(k, a) == 1) != (u == 1):
                raise AssertionError(
                    f"coprime-k endpoint test fails at p={p}, a={a}, R={R}, u={u}"
                )
        if ((1 in middle) != ((p + 4) % R == 0)):
            raise AssertionError(
                f"middle endpoint-orbit criterion fails at p={p}, a={a}, R={R}"
            )

        balanced = [r for r in divisors(a) if (r + 1) % R == 0]
        for r in divisors(a):
            orbit = tuple(sorted((a // r, a * r)))
            if (orbit in direct_orbits) != ((r + 1) % R == 0):
                raise AssertionError(
                    f"balanced suborbit test fails at p={p}, a={a}, R={R}, r={r}"
                )

        middle_orbit_count += len(direct_orbits)
        balanced_orbit_count += len(balanced)


lift_count = 0
primes = primes_up_to(20000)
for x in range(1, 21):
    for y in range(x, 51):
        if gcd(x, y) != 1:
            continue
        product = x * y
        for R in divisors(x + y):
            if R % 4 != 3:
                continue
            for p in primes:
                if (p + R) % (4 * product) or R > 2 * p - 3:
                    continue
                h = (p + R) // (4 * product)
                a = h * x * y
                u = h * x * x
                v = h * y * y
                if not (
                    a == (p + R) // 4
                    and u * v == a * a
                    and (u + a) % R == 0
                    and (v + a) % R == 0
                ):
                    raise AssertionError(
                        f"middle residue lift fails at p={p}, R={R}, x={x}, y={y}"
                    )
                b = p * (a + u) // R
                c = p * (a + v) // R
                if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                    raise AssertionError(
                        f"middle lifted identity fails at p={p}, R={R}, x={x}, y={y}"
                    )
                lift_count += 1


if not shell_count or not middle_orbit_count or not balanced_orbit_count or not lift_count:
    raise AssertionError("a tested family was empty")

print("PASS: middle coprime-factor orbit classification")
print("every middle complement orbit is uniquely {h x^2,h y^2} with a=hxy and gcd(x,y)=1")
print("middle occupancy is exactly R dividing x+y")
print("q equals the exterior count plus the unordered coprime-factor count")
print("gcd(k,a)=gcd(u,a), so a coprime k gives exactly the endpoint u=1")
print("r maps to {a/r,ar} exactly when R divides r+1")
print("all shell tests through p=5000 and lifted tests through p=20000 passed")

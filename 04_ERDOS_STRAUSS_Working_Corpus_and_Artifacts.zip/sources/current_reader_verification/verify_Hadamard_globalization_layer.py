from pathlib import Path

import sympy as sp


sqrt2 = sp.sqrt(2)
H = sp.Matrix([[1, 1], [1, -1]]) / sqrt2
E21 = sp.Matrix([[0, 0], [1, 0]])
u_plus = sp.Matrix([1, 1]) / sqrt2
u_minus = sp.Matrix([1, -1]) / sqrt2
P_plus = u_plus * u_plus.T
P_minus = u_minus * u_minus.T
B_minus_plus = H * E21 * H.T
ones = sp.ones(2)


def incidence(matrix):
    return matrix.applyfunc(lambda entry: sp.Integer(0) if entry == 0 else sp.Integer(1))


checks = [
    ("Hadamard isometry", H * H.T == sp.eye(2)),
    ("directed blade factorization value", 2 * B_minus_plus == H * (2 * E21) * H.T),
    ("globalization mask remains E21 before reflection", E21 == sp.Matrix([[0, 0], [1, 0]])),
    ("minus-plus source projector", B_minus_plus.T * B_minus_plus == P_plus),
    ("minus-plus range projector", B_minus_plus * B_minus_plus.T == P_minus),
    ("Hadamard amplitude has full entry incidence", incidence(H) == ones),
    ("transformed blade has full entry incidence", incidence(2 * B_minus_plus) == ones),
    ("Hadamard is not monomial", all(sum(1 for value in H.row(i) if value != 0) == 2 for i in range(2))),
]

lines = []
for label, passed in checks:
    line = f"{label}: {'PASS' if passed else 'FAIL'}"
    print(line)
    lines.append(line)
    if not passed:
        raise SystemExit(1)

receipt = Path(__file__).with_name("verify_Hadamard_globalization_layer_output.txt")
receipt.write_text("\n".join(lines) + "\n", encoding="utf-8")

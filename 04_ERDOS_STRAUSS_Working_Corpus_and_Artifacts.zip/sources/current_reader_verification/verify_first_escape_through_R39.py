"""Exact finite certificate for the first prime empty through R=39."""

from fractions import Fraction
from math import gcd

from verify_first_hard_locus_R15_R19_R23 import (
    divisors,
    factorization,
    is_prime,
    shell_count,
)


EMPTY_RESIDUALS = tuple(range(3, 56, 4))
TESTED_THROUGH_39 = tuple(range(3, 40, 4))
EXPECTED_FACTORIZATIONS = {
    3: {7: 1, 4243: 1},
    7: {2: 1, 14851: 1},
    11: {3: 1, 9901: 1},
    15: {2: 3, 47: 1, 79: 1},
    19: {5: 1, 13: 1, 457: 1},
    23: {2: 1, 3: 1, 4951: 1},
    27: {61: 1, 487: 1},
    31: {2: 2, 7: 1, 1061: 1},
    35: {3: 2, 3301: 1},
    39: {2: 1, 5: 1, 2971: 1},
    43: {11: 1, 37: 1, 73: 1},
    47: {2: 4, 3: 1, 619: 1},
    51: {43: 1, 691: 1},
    55: {2: 1, 83: 1, 179: 1},
    59: {3: 1, 5: 1, 7: 1, 283: 1},
}


def witness_sets(residual: int, denominator: int):
    exterior = [
        u
        for u in divisors(denominator * denominator)
        if (4 * u + 1) % residual == 0
    ]
    middle = [
        (x, y)
        for x in divisors(denominator)
        for y in divisors(denominator)
        if gcd(x, y) == 1
        and denominator % (x * y) == 0
        and (x + y) % residual == 0
    ]
    return exterior, middle


def main() -> None:
    prime = 118801
    assert prime == 24 * 4950 + 1
    assert is_prime(prime)

    first_escapes = []
    eligible_primes = 0
    for candidate in range(13, prime + 1):
        if candidate % 24 != 1 or not is_prime(candidate):
            continue
        eligible_primes += 1
        if all(
            shell_count(residual, (candidate + residual) // 4) == 0
            for residual in TESTED_THROUGH_39
        ):
            first_escapes.append(candidate)
    assert first_escapes == [prime]

    coordinates = {}
    for residual in range(3, 60, 4):
        denominator = (prime + residual) // 4
        coordinates[residual] = denominator
        assert denominator == 29700 + (residual + 3) // 4
        assert factorization(denominator) == EXPECTED_FACTORIZATIONS[residual]

    for residual in EMPTY_RESIDUALS:
        denominator = coordinates[residual]
        exterior, middle = witness_sets(residual, denominator)
        assert exterior == []
        assert middle == []
        assert shell_count(residual, denominator) == 0

    residual = 59
    denominator = coordinates[residual]
    exterior, middle = witness_sets(residual, denominator)
    assert exterior == [21225]
    assert middle == [(1, 1415), (1415, 1)]
    assert shell_count(residual, denominator) == 2

    witness = 21225
    common = (denominator + prime * witness) // residual
    y = prime * common
    z = denominator * common // witness
    assert common == 42738660
    assert y == 5077395546660
    assert z == 59834124
    assert denominator + prime * witness == residual * common
    assert Fraction(4, prime) == (
        Fraction(1, denominator) + Fraction(1, y) + Fraction(1, z)
    )

    print("PASS: first prime empty through R=39 and its first occupied shell")
    print("eligible primes p=1 mod 24 through 118801:", eligible_primes)
    print("first primes empty through R=39:", first_escapes)
    print("p=118801 shells R=3,7,...,55: all empty")
    print("p=118801 first occupied shell: R=59, a=29715, q=2")
    print("R59 exterior witnesses:", exterior)
    print("R59 middle witnesses:", middle)
    print(
        "4/118801 = 1/29715 + 1/5077395546660 + 1/59834124"
    )


if __name__ == "__main__":
    main()

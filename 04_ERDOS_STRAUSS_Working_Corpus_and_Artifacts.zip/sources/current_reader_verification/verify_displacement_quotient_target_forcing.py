from itertools import product
from math import gcd


def sumset(left, right, modulus):
    return {(x + y) % modulus for x in left for y in right}


def stabilizer(subset, modulus):
    return {
        shift
        for shift in range(modulus)
        if {(x + shift) % modulus for x in subset} == subset
    }


def quotient_kneser_surplus(local_sets, target, modulus):
    carrier = {0}
    for local in local_sets:
        carrier = sumset(carrier, local, modulus)
    period = stabilizer(carrier, modulus)
    saturated_locals = [
        sumset(local, period, modulus) for local in local_sets
    ]
    saturated_target = sumset(target, period, modulus)
    lower = sum(len(local) for local in saturated_locals)
    lower -= (len(saturated_locals) - 1) * len(period)
    numerator = lower + len(saturated_target) - modulus
    assert numerator % len(period) == 0
    return carrier, period, numerator // len(period)


def exhaustive_cyclic_test():
    checks = 0
    positive_surpluses = 0
    for ambient_order in range(2, 9):
        nonempty_subsets = [
            {
                value
                for value in range(ambient_order)
                if mask & (1 << value)
            }
            for mask in range(1, 1 << ambient_order)
        ]
        for quotient_order in range(1, ambient_order + 1):
            if ambient_order % quotient_order:
                continue
            for left in nonempty_subsets:
                left_bar = {value % quotient_order for value in left}
                for right in nonempty_subsets:
                    right_bar = {
                        value % quotient_order for value in right
                    }
                    carrier_bar, period, _ = quotient_kneser_surplus(
                        [left_bar, right_bar],
                        {0},
                        quotient_order,
                    )
                    carrier = sumset(left, right, ambient_order)
                    direct_bar = {
                        value % quotient_order for value in carrier
                    }
                    assert carrier_bar == direct_bar
                    for target_bar in range(quotient_order):
                        target = {target_bar}
                        _, same_period, surplus = (
                            quotient_kneser_surplus(
                                [left_bar, right_bar],
                                target,
                                quotient_order,
                            )
                        )
                        assert same_period == period
                        target_fibre = {
                            value
                            for value in range(ambient_order)
                            if value % quotient_order == target_bar
                        }
                        projected_hit = target_bar in carrier_bar
                        actual_hit = bool(carrier & target_fibre)
                        assert projected_hit == actual_hit
                        if surplus > 0:
                            positive_surpluses += 1
                            assert projected_hit
                        checks += 1
    return checks, positive_surpluses


def multiplicative_subgroup(generators, modulus):
    subgroup = {1}
    changed = True
    while changed:
        changed = False
        for value in tuple(subgroup):
            for generator in generators:
                product_value = value * generator % modulus
                if product_value not in subgroup:
                    subgroup.add(product_value)
                    changed = True
    return subgroup


def quotient_group(group, subgroup, modulus):
    element_to_coset = {}
    cosets = {}
    for value in sorted(group):
        if value in element_to_coset:
            continue
        members = frozenset(value * k % modulus for k in subgroup)
        representative = min(members)
        cosets[representative] = members
        for member in members:
            element_to_coset[member] = representative

    representatives = tuple(sorted(cosets))

    def operation(left, right):
        return element_to_coset[left * right % modulus]

    return representatives, element_to_coset, operation


def divisors_from_factors(factors):
    divisors = [1]
    for prime, exponent in factors:
        divisors = [
            old * prime**power
            for old in divisors
            for power in range(exponent + 1)
        ]
    return divisors


def arithmetic_certificate(p, residual, a, factors):
    group = multiplicative_subgroup(
        [prime % residual for prime, _ in factors],
        residual,
    )
    centered_support = {
        divisor * pow(a, -1, residual) % residual
        for divisor in divisors_from_factors(
            [(prime, 2 * exponent) for prime, exponent in factors]
        )
    }
    support_stabilizer = {
        value
        for value in group
        if {
            value * support_value % residual
            for support_value in centered_support
        }
        == centered_support
    }
    elements, quotient_map, operation = quotient_group(
        group,
        support_stabilizer,
        residual,
    )
    quotient_identity = quotient_map[1]
    quotient_support = {
        quotient_map[value] for value in centered_support
    }
    targets = tuple(
        sorted(
            {
                quotient_map[(-1) % residual],
                quotient_map[
                    (-pow(p, -1, residual)) % residual
                ],
            }
        )
    )
    displacement = quotient_map[p % residual]
    displacement_group = []
    current = quotient_identity
    while current not in displacement_group:
        displacement_group.append(current)
        current = operation(current, displacement)

    orbits = []
    orbit_index = {}
    for value in elements:
        if value in orbit_index:
            continue
        orbit = []
        current = value
        for _ in displacement_group:
            orbit_index[current] = len(orbits)
            orbit.append(current)
            current = operation(current, displacement)
        orbits.append(tuple(orbit))

    projected_order = len(orbits)

    def projected_operation(left, right):
        return orbit_index[
            operation(orbits[left][0], orbits[right][0])
        ]

    projected_support = {
        orbit_index[value] for value in quotient_support
    }
    projected_locals = []
    for prime, exponent in factors:
        local = {
            quotient_map[pow(prime, beta, residual)]
            for beta in range(-exponent, exponent + 1)
        }
        projected_locals.append(
            {orbit_index[value] for value in local}
        )

    projected_carrier = {
        orbit_index[quotient_identity]
    }
    for local in projected_locals:
        projected_carrier = {
            projected_operation(left, right)
            for left in projected_carrier
            for right in local
        }
    assert projected_carrier == projected_support

    projected_period = {
        shift
        for shift in range(projected_order)
        if {
            projected_operation(shift, value)
            for value in projected_support
        }
        == projected_support
    }
    projected_target = {orbit_index[value] for value in targets}
    saturated_locals = [
        {
            projected_operation(value, period)
            for value in local
            for period in projected_period
        }
        for local in projected_locals
    ]
    saturated_target = {
        projected_operation(value, period)
        for value in projected_target
        for period in projected_period
    }
    lower = sum(len(local) for local in saturated_locals)
    lower -= (len(saturated_locals) - 1) * len(
        projected_period
    )
    numerator = lower + len(saturated_target) - projected_order
    assert numerator % len(projected_period) == 0
    surplus = numerator // len(projected_period)

    target_orbit = set(orbits[orbit_index[targets[0]]])
    assert target_orbit == set(targets)
    assert surplus == 1
    assert projected_support == set(range(projected_order))
    assert bool(centered_support & {
        (-1) % residual,
        (-pow(p, -1, residual)) % residual,
    })

    return {
        "H": tuple(sorted(group)),
        "K": tuple(sorted(support_stabilizer)),
        "Q": elements,
        "support": tuple(sorted(centered_support)),
        "quotient_support": tuple(sorted(quotient_support)),
        "targets": targets,
        "D": tuple(displacement_group),
        "orbits": tuple(orbits),
        "projected_locals": tuple(
            tuple(sorted(local)) for local in projected_locals
        ),
        "projected_support": tuple(sorted(projected_support)),
        "projected_period": tuple(sorted(projected_period)),
        "surplus": surplus,
    }


cyclic_checks, positive_surpluses = exhaustive_cyclic_test()
case_13 = arithmetic_certificate(13, 7, 5, [(5, 1)])
case_37 = arithmetic_certificate(37, 19, 14, [(2, 1), (7, 1)])

assert len(case_13["H"]) == 6
assert case_13["K"] == (1,)
assert case_13["Q"] == (1, 2, 3, 4, 5, 6)
assert case_13["targets"] == (1, 6)
assert case_13["D"] == (1, 6)
assert case_13["projected_locals"] == ((0, 1, 2),)

assert len(case_37["H"]) == 18
assert case_37["K"] == (1, 7, 11)
assert case_37["Q"] == (1, 2, 4, 5, 8, 10)
assert case_37["targets"] == (1, 8)
assert case_37["D"] == (1, 8)
assert case_37["projected_locals"] == ((0, 1, 2), (0,))

print("PASS: displacement-quotient complete-target-fibre forcing")
print(f"exhaustive cyclic assertions: {cyclic_checks}")
print(f"positive projected-surplus assertions: {positive_surpluses}")
print("(13,7,5):", case_13)
print("(37,19,14):", case_37)

from fractions import Fraction


sizes = (1, 2, 3)
weights = {
    1: (Fraction(1),),
    2: (Fraction(2), Fraction(3)),
    3: (Fraction(5), Fraction(7), Fraction(11)),
}


def unit(a, i, b, j):
    return (a, i, b, j)


def multiply(x, y):
    a, i, b, j = x
    c, k, d, ell = y
    if b != c or j != k:
        return None
    return unit(a, i, d, ell)


def modular_weight(x):
    a, i, b, j = x
    return weights[a][i - 1] / weights[b][j - 1]


dimension_matrix = tuple(
    tuple(sizes[a] * sizes[b] for b in range(3))
    for a in range(3)
)
assert dimension_matrix == ((1, 2, 3), (2, 4, 6), (3, 6, 9))
assert sum(sum(row) for row in dimension_matrix) == 36

forward_cycles = []
reverse_cycles = []
for j in range(1, 3):
    for k in range(1, 4):
        x12 = unit(1, 1, 2, j)
        x23 = unit(2, j, 3, k)
        x31 = unit(3, k, 1, 1)
        product = multiply(multiply(x12, x23), x31)
        assert product == unit(1, 1, 1, 1)
        cycle_weight = (
            modular_weight(x12)
            * modular_weight(x23)
            * modular_weight(x31)
        )
        assert cycle_weight == 1
        forward_cycles.append((j, k, cycle_weight))

        x13 = unit(1, 1, 3, k)
        x32 = unit(3, k, 2, j)
        x21 = unit(2, j, 1, 1)
        reverse_product = multiply(multiply(x13, x32), x21)
        assert reverse_product == unit(1, 1, 1, 1)
        reverse_weight = (
            modular_weight(x13)
            * modular_weight(x32)
            * modular_weight(x21)
        )
        assert reverse_weight == 1
        reverse_cycles.append((j, k, reverse_weight))

spec_12 = tuple(
    weights[1][0] / weights[2][j]
    for j in range(2)
)
spec_23 = tuple(
    weights[2][j] / weights[3][k]
    for j in range(2)
    for k in range(3)
)
spec_31 = tuple(
    weights[3][k] / weights[1][0]
    for k in range(3)
)

assert spec_12 == (Fraction(1, 2), Fraction(1, 3))
assert spec_23 == (
    Fraction(2, 5),
    Fraction(2, 7),
    Fraction(2, 11),
    Fraction(3, 5),
    Fraction(3, 7),
    Fraction(3, 11),
)
assert spec_31 == (Fraction(5), Fraction(7), Fraction(11))

for a in range(1, 4):
    for b in range(1, 4):
        for i in range(1, sizes[a - 1] + 1):
            for j in range(1, sizes[b - 1] + 1):
                x = unit(a, i, b, j)
                x_star = unit(b, j, a, i)
                assert modular_weight(x_star) == 1 / modular_weight(x)

central_ideal_dimensions = tuple(n * n for n in sizes)
assert central_ideal_dimensions == (1, 4, 9)
assert len(set(central_ideal_dimensions)) == 3

print("PASS dimension matrix:", dimension_matrix)
print("PASS total linking-algebra dimension: 36")
print("PASS forward closed paths:", len(forward_cycles))
print("PASS reverse closed paths:", len(reverse_cycles))
print("PASS every oriented cycle has modular weight 1")
print("PASS adjunction reverses every modular weight")
print("PASS Spec(L12):", spec_12)
print("PASS Spec(L23):", spec_23)
print("PASS Spec(L31):", spec_31)
print("PASS diagonal ideal dimensions:", central_ideal_dimensions)

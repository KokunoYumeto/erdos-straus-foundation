from fractions import Fraction

from sympy import isprime, primerange


MODULUS = 19
K_EXPECTED = {1, 7, 11}


def multiplicative_subgroup(generators, modulus):
    subgroup = {1}
    changed = True
    while changed:
        changed = False
        for value in tuple(subgroup):
            for generator in generators:
                new_value = value * generator % modulus
                if new_value not in subgroup:
                    subgroup.add(new_value)
                    changed = True
    return subgroup


def support_stabilizer(group, support, modulus):
    return {
        value
        for value in group
        if {
            value * support_value % modulus
            for support_value in support
        }
        == support
    }


def quotient_group(group, subgroup, modulus):
    quotient_map = {}
    cosets = {}
    for value in sorted(group):
        if value in quotient_map:
            continue
        members = frozenset(value * k % modulus for k in subgroup)
        representative = min(members)
        cosets[representative] = members
        for member in members:
            quotient_map[member] = representative

    representatives = tuple(sorted(cosets))

    def multiply(left, right):
        return quotient_map[left * right % modulus]

    return representatives, quotient_map, multiply


def divisors_of_two_q_squared(q):
    return {
        2**alpha * q**beta
        for alpha in range(3)
        for beta in range(3)
    }


def verify_pair(q):
    p = 8 * q - 19
    assert isprime(q)
    assert isprime(p)
    assert q % MODULUS in {7, 11}

    a = 2 * q
    group = multiplicative_subgroup([2, q % MODULUS], MODULUS)
    assert group == set(range(1, MODULUS))

    a_inverse = pow(a, -1, MODULUS)
    centered_support = {
        divisor * a_inverse % MODULUS
        for divisor in divisors_of_two_q_squared(q)
    }
    stabilizer = support_stabilizer(
        group,
        centered_support,
        MODULUS,
    )
    assert stabilizer == K_EXPECTED

    quotient, quotient_map, multiply = quotient_group(
        group,
        stabilizer,
        MODULUS,
    )
    assert quotient == (1, 2, 4, 5, 8, 10)
    quotient_support = {
        quotient_map[value] for value in centered_support
    }
    assert quotient_support == {1, 2, 10}

    targets = {
        quotient_map[-1 % MODULUS],
        quotient_map[-pow(p, -1, MODULUS) % MODULUS],
    }
    assert targets == {1, 8}

    displacement = quotient_map[p % MODULUS]
    assert displacement == 8
    displacement_group = {1, displacement}
    assert multiply(displacement, displacement) == 1

    displacement_orbits = (
        frozenset({1, 8}),
        frozenset({2, 5}),
        frozenset({4, 10}),
    )
    orbit_index = {
        value: index
        for index, orbit in enumerate(displacement_orbits)
        for value in orbit
    }
    local_two = {
        quotient_map[pow(2, beta, MODULUS)]
        for beta in range(-1, 2)
    }
    local_q = {
        quotient_map[pow(q, beta, MODULUS)]
        for beta in range(-1, 2)
    }
    projected_two = {orbit_index[value] for value in local_two}
    projected_q = {orbit_index[value] for value in local_q}
    assert projected_two == {0, 1, 2}
    assert projected_q == {0}
    assert {orbit_index[value] for value in targets} == {0}

    if q % MODULUS == 7:
        second = 2 * q * (p + 1) // MODULUS
        third = p * second
        assert 2 * q * (p + 1) % MODULUS == 0
        branch = 7
    else:
        second = 2 * (p * q + 1) // MODULUS
        third = p * q * second
        assert 2 * (p * q + 1) % MODULUS == 0
        branch = 11

    assert Fraction(4, p) == (
        Fraction(1, 2 * q)
        + Fraction(1, second)
        + Fraction(1, third)
    )
    return branch, p, second, third


assert pow(2, 9, MODULUS) == MODULUS - 1
assert multiplicative_subgroup([2], MODULUS) == set(
    range(1, MODULUS)
)
for residue in (7, 11):
    assert multiplicative_subgroup([residue], MODULUS) == K_EXPECTED
    assert 8 * residue % MODULUS in {12, 18}

rows = []
for q in primerange(2, 200_001):
    if q % MODULUS not in {7, 11}:
        continue
    p = 8 * q - 19
    if isprime(p):
        rows.append((q, *verify_pair(q)))

branch_seven = [row for row in rows if row[1] == 7]
branch_eleven = [row for row in rows if row[1] == 11]
assert branch_seven
assert branch_eleven
assert branch_seven[0][:3] == (7, 7, 37)
assert branch_eleven[0][:3] == (619, 11, 4933)

print("PASS: residual-nineteen complete-target-fibre prime-pair family")
print("prime-pair bound for q: 200000")
print(f"verified prime pairs: {len(rows)}")
print(f"residue-7 branch: {len(branch_seven)}")
print(f"residue-11 branch: {len(branch_eleven)}")
print("first residue-7 certificate:", branch_seven[0])
print("first residue-11 certificate:", branch_eleven[0])
print("last certificate:", rows[-1])

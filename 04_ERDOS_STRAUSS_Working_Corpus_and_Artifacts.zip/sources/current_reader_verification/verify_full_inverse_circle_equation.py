from __future__ import annotations

import sympy as sp


def require(statement: bool, message: str) -> None:
    if not statement:
        raise AssertionError(message)
    print(f"PASS {message}")


a, b0, b1, c = sp.symbols("a b0 b1 c")
A, B0, B1, C = sp.symbols("A B0 B1 C", nonzero=True)
x, y = sp.symbols("x y")

v = sp.Matrix([a, b0, b1, c])
matrix = sp.Matrix(
    [
        [B0**2 + B1**2, -2 * A * B0, -2 * A * B1, A**2],
        [B0 * C, B1**2 - B0**2 - A * C, -2 * B0 * B1, A * B0],
        [B1 * C, -2 * B0 * B1, B0**2 - B1**2 - A * C, A * B1],
        [C**2, -2 * C * B0, -2 * C * B1, B0**2 + B1**2],
    ]
) / A**2
image = sp.simplify(matrix * v)

expanded_coefficients = sp.Matrix(
    [
        (
            a * (B0**2 + B1**2)
            - 2 * A * (b0 * B0 + b1 * B1)
            + c * A**2
        )
        / A**2,
        (
            b0 * (B1**2 - B0**2 - A * C)
            + a * B0 * C
            - 2 * b1 * B0 * B1
            + c * A * B0
        )
        / A**2,
        (
            b1 * (B0**2 - B1**2 - A * C)
            + a * B1 * C
            - 2 * b0 * B0 * B1
            + c * A * B1
        )
        / A**2,
        (
            a * C**2
            - 2 * b0 * B0 * C
            - 2 * b1 * B1 * C
            + c * (B0**2 + B1**2)
        )
        / A**2,
    ]
)
require(
    all(sp.factor(entry) == 0 for entry in image - expanded_coefficients),
    "the supplied full equation is exactly the coefficient-matrix product",
)


def circle_value(coefficients: sp.Matrix, x_value: sp.Expr, y_value: sp.Expr) -> sp.Expr:
    qa, qb0, qb1, qc = coefficients
    return qa * (x_value**2 + y_value**2) + 2 * (
        qb0 * x_value - qb1 * y_value
    ) + qc


delta = B0**2 + B1**2 - A * C
origin_x = -B0 / A
origin_y = B1 / A
dx = x - origin_x
dy = y - origin_y
distance_squared = sp.expand(dx**2 + dy**2)
inverted_x = origin_x + delta * dx / (A**2 * distance_squared)
inverted_y = origin_y + delta * dy / (A**2 * distance_squared)
covariance_difference = sp.together(
    circle_value(image, x, y)
    - distance_squared * circle_value(v, inverted_x, inverted_y)
)
require(
    sp.factor(covariance_difference) == 0,
    "the full equation obeys exact inversion-evaluation covariance",
)

# The two ordered axial channels used later in the manuscript.
alpha = sp.symbols("alpha", nonzero=True)
ordered = sp.simplify(matrix.subs({A: 4, B0: 0, B1: 0, C: -4 * alpha}))
ordered_expected = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, alpha, 0, 0],
        [0, 0, alpha, 0],
        [alpha**2, 0, 0, 0],
    ]
)
require(ordered == ordered_expected, "the ordered axial channel has the stated coefficient matrix")
require(
    sp.expand(circle_value(ordered * v, x, y))
    == sp.expand(c * (x**2 + y**2) + 2 * alpha * (b0 * x - b1 * y) + alpha**2 * a),
    "the ordered axial full equation has the stated coefficient scales",
)

mirror = sp.simplify(matrix.subs({A: -4 * alpha, B0: 0, B1: 0, C: 4}))
mirror_expected = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, 1 / alpha, 0, 0],
        [0, 0, 1 / alpha, 0],
        [1 / alpha**2, 0, 0, 0],
    ]
)
require(mirror == mirror_expected, "the transposed axial channel has the stated coefficient matrix")
require(
    sp.expand(circle_value(mirror * v, x, y))
    == sp.expand(c * (x**2 + y**2) + 2 * (b0 * x - b1 * y) / alpha + a / alpha**2),
    "the transposed axial full equation has the reciprocal coefficient scales",
)

quarter = ordered.subs(alpha, sp.Rational(1, 4))
quarter_mirror = mirror.subs(alpha, sp.Rational(1, 4))
require(
    quarter.eigenvals() == {sp.Rational(1, 4): 3, -sp.Rational(1, 4): 1},
    "the full equation recovers the ordered quarter spectrum",
)
require(
    quarter_mirror.eigenvals() == {sp.Integer(4): 3, -sp.Integer(4): 1},
    "the full equation recovers the reciprocal mirror spectrum",
)

# Field closure is checked at the coefficient level over a rational test field.
rational_specialization = {
    a: sp.Rational(2, 3),
    b0: sp.Rational(3, 5),
    b1: sp.Rational(5, 7),
    c: sp.Rational(7, 11),
    A: sp.Rational(11, 13),
    B0: sp.Rational(13, 17),
    B1: sp.Rational(17, 19),
    C: sp.Rational(19, 23),
}
rational_image = image.subs(rational_specialization)
require(
    all(value.is_Rational for value in rational_image),
    "the expanded coefficient action closes over the rational field test",
)

print("PASS all full inverse-circle equation checks completed")

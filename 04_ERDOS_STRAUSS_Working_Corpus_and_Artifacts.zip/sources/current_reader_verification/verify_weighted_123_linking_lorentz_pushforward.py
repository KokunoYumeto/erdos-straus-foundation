from fractions import Fraction


def mat_zero(rows, cols):
    return [[Fraction(0) for _ in range(cols)] for _ in range(rows)]


def mat_identity(n):
    out = mat_zero(n, n)
    for i in range(n):
        out[i][i] = Fraction(1)
    return out


def mat_transpose(a):
    return [list(row) for row in zip(*a)]


def mat_mul(a, b):
    rows = len(a)
    inner = len(b)
    cols = len(b[0])
    return [
        [sum(a[i][k] * b[k][j] for k in range(inner)) for j in range(cols)]
        for i in range(rows)
    ]


def mat_rank(a):
    m = [row[:] for row in a]
    rows = len(m)
    cols = len(m[0]) if rows else 0
    pivot_row = 0
    for col in range(cols):
        pivot = next((i for i in range(pivot_row, rows) if m[i][col]), None)
        if pivot is None:
            continue
        m[pivot_row], m[pivot] = m[pivot], m[pivot_row]
        scale = m[pivot_row][col]
        m[pivot_row] = [x / scale for x in m[pivot_row]]
        for i in range(rows):
            if i != pivot_row and m[i][col]:
                factor = m[i][col]
                m[i] = [x - factor * y for x, y in zip(m[i], m[pivot_row])]
        pivot_row += 1
        if pivot_row == rows:
            break
    return pivot_row


def permutation_matrix(size, image):
    out = mat_zero(size, size)
    for old, new in enumerate(image):
        out[new][old] = Fraction(1)
    return out


def source_index(orbit, m, epsilon):
    return ((orbit * 3 + m) * 2) + epsilon


for roots in ([2], [2, 3], [2, 3, 5, 7, 11, 13]):
    q = len(roots)
    size = 6 * q
    alpha = [Fraction(h * h) for h in roots]

    r_image = [None] * size
    s_image = [None] * size
    for orbit in range(q):
        for m in range(3):
            for epsilon in range(2):
                old = source_index(orbit, m, epsilon)
                r_image[old] = source_index(orbit, (m + 1) % 3, epsilon)
                s_image[old] = source_index(orbit, (-m) % 3, 1 - epsilon)
    rotation = permutation_matrix(size, r_image)
    reflection = permutation_matrix(size, s_image)

    support = mat_zero(q, size)
    weighted_21 = mat_zero(size, size)
    polar_21 = mat_zero(size, size)
    absolute_low = mat_zero(size, size)
    amplitude_low = mat_zero(size, size)
    amplitude_high = mat_zero(size, size)
    for orbit, h in enumerate(roots):
        for m in range(3):
            low = source_index(orbit, m, 0)
            high = source_index(orbit, m, 1)
            support[orbit][low] = Fraction(h)
            support[orbit][high] = Fraction(h)
            weighted_21[high][low] = Fraction(2 * h)
            polar_21[high][low] = Fraction(1)
            absolute_low[low][low] = Fraction(2 * h)
            amplitude_low[low][low] = alpha[orbit]
            amplitude_high[high][high] = alpha[orbit]

    weighted_12 = mat_transpose(weighted_21)
    polar_12 = mat_transpose(polar_21)
    assert mat_rank(support) == q
    assert size - mat_rank(support) == 5 * q
    assert mat_mul(support, rotation) == support
    assert mat_mul(support, reflection) == support
    assert mat_mul(weighted_12, weighted_21) == [
        [4 * x for x in row] for row in amplitude_low
    ]
    assert mat_mul(weighted_21, weighted_12) == [
        [4 * x for x in row] for row in amplitude_high
    ]
    assert mat_mul(polar_21, absolute_low) == weighted_21
    assert mat_mul(mat_mul(reflection, weighted_21), reflection) == weighted_12
    assert mat_mul(mat_mul(rotation, weighted_21), mat_transpose(rotation)) == weighted_21
    assert mat_rank(weighted_21) == 3 * q
    assert mat_rank(polar_21) == 3 * q

    trace_orbit = sum(alpha, Fraction(0))
    support_hs2 = sum(x * x for row in support for x in row)
    blade_hs2 = sum(x * x for row in weighted_21 for x in row)
    assert support_hs2 == 6 * trace_orbit
    assert blade_hs2 == 12 * trace_orbit
    assert support_hs2 == 3 * (2 * trace_orbit)
    assert blade_hs2 == 6 * (2 * trace_orbit)


exterior = [
    Fraction(61445, 943902729),
    Fraction(184335, 339886096),
    Fraction(921675, 38217124),
]
middle = [
    Fraction(615, 94864),
    Fraction(123, 484),
    Fraction(1025, 1089),
]
weights = exterior + middle
pushforward = [
    [Fraction(1), Fraction(1), Fraction(1), Fraction(0), Fraction(0), Fraction(0)],
    [Fraction(0), Fraction(0), Fraction(0), Fraction(1), Fraction(1), Fraction(1)],
]
assert mat_rank(pushforward) == 2
assert len(weights) - mat_rank(pushforward) == 4
assert mat_mul(pushforward, [[x] for x in weights]) == [
    [sum(exterior, Fraction(0))],
    [sum(middle, Fraction(0))],
]

alpha_2 = sum(exterior, Fraction(0))
alpha_1_half = sum(middle, Fraction(0))
alpha_1 = 2 * alpha_1_half
lambda_plus = alpha_2 + alpha_1_half
lambda_minus = alpha_2 - alpha_1_half
alpha_sigma = 2 * lambda_plus

assert alpha_2 == Fraction(5176199252561022635, 209357204251173091344)
assert alpha_1_half == Fraction(1026107, 853776)
assert alpha_1 == Fraction(1026107, 426888)
assert lambda_plus == Fraction(128395625711903946059, 104678602125586545672)
assert lambda_minus == Fraction(-14143643992119252, 12015450198070081)

hadamard = [[Fraction(1), Fraction(1)], [Fraction(1), Fraction(-1)]]
assert mat_mul(hadamard, [[alpha_2], [alpha_1_half]]) == [
    [lambda_plus],
    [lambda_minus],
]
assert mat_mul(
    [[Fraction(1), Fraction(-1)], [Fraction(1), Fraction(1)]],
    [[lambda_plus], [lambda_minus]],
) == [[alpha_1], [2 * alpha_2]]

n_target = [Fraction(-1, 2), Fraction(0), Fraction(0), Fraction(1, 2)]
resolved_1 = [alpha_1 * x for x in n_target]
resolved_2 = [2 * alpha_2 * x for x in n_target]
assert [a + b for a, b in zip(resolved_1, resolved_2)] == [
    alpha_sigma * x for x in n_target
]
full_sarnak = [Fraction(2) - lambda_plus, Fraction(0), Fraction(0), Fraction(2) + lambda_plus]
assert full_sarnak[3] + full_sarnak[0] == Fraction(4)
assert full_sarnak[0] - full_sarnak[3] == -alpha_sigma

assert 6 * lambda_plus == Fraction(128395625711903946059, 17446433687597757612)
assert 12 * lambda_plus == Fraction(128395625711903946059, 8723216843798878806)

print("PASS weighted C1 support retains every orbit amplitude and has rank q")
print("PASS weighted low-to-high and high-to-low blades retain their order")
print("PASS weighted quarter products recover the orbit-amplitude operators on both sheets")
print("PASS polar partial isometries are the unweighted ordered blades divided by two")
print("PASS rotation preserves each weighted blade and reflection exchanges them")
print("PASS support and blade Hilbert--Schmidt norms equal 3 and 6 times alphaSigma")
print("PASS the 12289 orbit-type pushforward has rank two and kernel dimension four")
print("PASS the six exact 12289 amplitudes recover alpha2 and alpha1/2")
print("PASS the Hadamard transform recovers lambda+ and lambda-")
print("PASS the resolved Lorentz lift recovers alphaSigma times the target null ray")
print("PASS the full Sarnak point has null coordinates U=4 and V=-alphaSigma")

"""Exact finite-dimensional checks for the sectorial modular ladder."""

from sympy import I, Matrix, Rational, conjugate, eye, log, sqrt


def assert_zero_matrix(matrix: Matrix) -> None:
    assert all(entry.expand(complex=True) == 0 for entry in matrix)


def matrix_unit(n: int, i: int, j: int) -> Matrix:
    unit = Matrix.zeros(n)
    unit[i, j] = 1
    return unit


def projector(unitary: Matrix, root, k: int) -> Matrix:
    n = unitary.rows
    result = Matrix.zeros(n)
    for m in range(3):
        result += (root ** (-k * m)) * (unitary ** m)
    return result / 3


def antiunitary_conjugate(operator: Matrix, carrier: Matrix) -> Matrix:
    """Conjugation by carrier composed with entrywise conjugation."""
    return carrier * operator.conjugate() * carrier.T


def modular_action(rho: Matrix, value: Matrix) -> Matrix:
    return rho * value * rho.inv()


def modular_half_action(rho_half: Matrix, value: Matrix) -> Matrix:
    return rho_half * value * rho_half.inv()


def tomita_action(rho_half: Matrix, value: Matrix) -> Matrix:
    return rho_half.inv() * value.conjugate().T * rho_half


def modular_spectrum(radii: list[int]) -> list:
    return [Rational(radii[i], radii[j])
            for i in range(len(radii))
            for j in range(len(radii))]


def main() -> None:
    root_three = sqrt(3)
    omega = Rational(-1, 2) + I * root_three / 2
    unitary = Matrix.diag(1, omega, omega**2)
    swap = Matrix([[1, 0, 0], [0, 0, 1], [0, 1, 0]])
    projectors = [projector(unitary, omega, k) for k in range(3)]

    assert_zero_matrix(sum(projectors, Matrix.zeros(3)) - eye(3))
    for i in range(3):
        for j in range(3):
            target = projectors[i] if i == j else Matrix.zeros(3)
            assert_zero_matrix(projectors[i] * projectors[j] - target)

    # Entrywise conjugation K sends U to U^{-1} and fixes every P_k.
    assert_zero_matrix(unitary.conjugate() - unitary.inv())
    for k in range(3):
        assert_zero_matrix(projectors[k].conjugate() - projectors[k])

    # The antiunitary swap*K commutes with U and exchanges P_1 and P_2.
    assert_zero_matrix(antiunitary_conjugate(unitary, swap) - unitary)
    assert_zero_matrix(
        antiunitary_conjugate(projectors[1], swap) - projectors[2]
    )
    assert_zero_matrix(
        antiunitary_conjugate(projectors[2], swap) - projectors[1]
    )

    # The linear unitary swap sends U to U^{-1} and also exchanges P_1,P_2.
    assert_zero_matrix(swap * unitary * swap.T - unitary.inv())
    assert_zero_matrix(swap * projectors[1] * swap.T - projectors[2])
    assert_zero_matrix(swap * projectors[2] * swap.T - projectors[1])

    ladder = {
        1: [1],
        2: [2, 3],
        3: [5, 7, 11],
    }
    spectra = {}
    for n, radii in ladder.items():
        rho = Matrix.diag(*radii)
        rho_half = Matrix.diag(*[sqrt(value) for value in radii])
        spectra[n] = modular_spectrum(radii)
        for i in range(n):
            for j in range(n):
                unit = matrix_unit(n, i, j)
                ratio = Rational(radii[i], radii[j])
                assert_zero_matrix(modular_action(rho, unit) - ratio * unit)
                polar_value = modular_half_action(rho_half, unit)
                assert_zero_matrix(
                    polar_value.conjugate().T
                    - tomita_action(rho_half, unit)
                )

    # A concrete pair of standard forms exchanged by an antiunitary.
    rho_one = Matrix.diag(2, 3)
    rho_two = Matrix.diag(3, 2)
    sheet_swap = Matrix([[0, 1], [1, 0]])
    assert_zero_matrix(
        antiunitary_conjugate(rho_one, sheet_swap) - rho_two
    )
    for i in range(2):
        for j in range(2):
            unit = matrix_unit(2, i, j)
            c_unit = antiunitary_conjugate(unit, sheet_swap)
            lhs = antiunitary_conjugate(
                modular_action(rho_one, unit), sheet_swap
            )
            rhs = modular_action(rho_two, c_unit)
            assert_zero_matrix(lhs - rhs)

    print("All exact sectorial modular-ladder checks passed.")
    print("C3 antiunitary cases:")
    print("  K: U -> U^{-1}; P0,P1,P2 fixed")
    print("  swap*K: U -> U; P1 <-> P2")
    print("  linear swap: U -> U^{-1}; P1 <-> P2")
    print("Hilbert-Schmidt modular spectra:")
    for n, values in spectra.items():
        print(f"  n={n}: {values}")
    print("For K_n=-log(Delta_n), the E_ij eigenvalue is log(r_j/r_i).")


if __name__ == "__main__":
    main()

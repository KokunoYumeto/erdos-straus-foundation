#!/usr/bin/env python3
"""Exact matrix check of the Fable-face transport to the ES Lorentz slice."""

import sympy as sp


sqrt3 = sp.sqrt(3)

# Ordered Sarnak coordinates are (T,X,Y,W).
A = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
    ]
)
R_fable = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, -sp.Rational(1, 2), sqrt3 / 2, 0],
        [0, -sqrt3 / 2, -sp.Rational(1, 2), 0],
        [0, 0, 0, 1],
    ]
)
J_fable = sp.diag(1, -1, 1, 1)

R_face = sp.simplify(A.inv() * R_fable * A)
S_exchange = sp.simplify(A.inv() * J_fable * A)

R_expected = sp.Matrix(
    [
        [1, 0, 0, 0],
        [0, -sp.Rational(1, 2), 0, -sqrt3 / 2],
        [0, 0, 1, 0],
        [0, sqrt3 / 2, 0, -sp.Rational(1, 2)],
    ]
)
S_expected = sp.diag(1, 1, 1, -1)
assert R_face == R_expected
assert S_exchange == S_expected
assert R_face**3 == sp.eye(4)
assert S_exchange**2 == sp.eye(4)
assert sp.simplify(S_exchange * R_face * S_exchange - R_face.inv()) == sp.zeros(
    4
)

fable_rays = (
    sp.Matrix([1, 0, 1, 0]),
    sp.Matrix([1, sqrt3 / 2, -sp.Rational(1, 2), 0]),
    sp.Matrix([1, -sqrt3 / 2, -sp.Rational(1, 2), 0]),
)
es_rays = tuple(A.inv() * ray for ray in fable_rays)
expected_es_rays = (
    sp.Matrix([1, 1, 0, 0]),
    sp.Matrix([1, -sp.Rational(1, 2), 0, sqrt3 / 2]),
    sp.Matrix([1, -sp.Rational(1, 2), 0, -sqrt3 / 2]),
)
assert es_rays == expected_es_rays


def lorentz_norm(vector: sp.Matrix) -> sp.Expr:
    t, x, y, w = vector
    return sp.expand(x**2 + y**2 + w**2 - t**2)


def spatial_dot(left: sp.Matrix, right: sp.Matrix) -> sp.Expr:
    return sp.expand(left[1] * right[1] + left[2] * right[2] + left[3] * right[3])


assert all(lorentz_norm(ray) == 0 for ray in es_rays)
assert all(ray[0] == 1 and ray[2] == 0 for ray in es_rays)
assert all(spatial_dot(ray, ray) == 1 for ray in es_rays)
for i in range(3):
    for j in range(i + 1, 3):
        assert spatial_dot(es_rays[i], es_rays[j]) == -sp.Rational(1, 2)

assert R_face * es_rays[0] == es_rays[1]
assert R_face * es_rays[1] == es_rays[2]
assert R_face * es_rays[2] == es_rays[0]
assert S_exchange * es_rays[0] == es_rays[0]
assert S_exchange * es_rays[1] == es_rays[2]
assert S_exchange * es_rays[2] == es_rays[1]

print("PASS conjugated rotation is the exact 120-degree XW rotation")
print("PASS conjugated reflection is denominator exchange W -> -W")
print("PASS the two matrices satisfy the D3 presentation")
print("PASS transported rays are the stated ES-aligned coordinates")
print("PASS all three rays are null on the T=1, Y=0 section")
print("PASS their spatial points form a regular triangle")
print("PASS the cycle and reflection act on the three rays exactly")

from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for d in range(3, isqrt(n) + 1, 2):
        if n % d == 0:
            return False
    return True


def divisors(n):
    values = []
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            values.append(d)
            if d * d != n:
                values.append(n // d)
    return sorted(values)


def weak_compositions(total, parts, prefix=()):
    if parts == 1:
        yield prefix + (total,)
        return
    for value in range(total + 1):
        yield from weak_compositions(
            total - value,
            parts - 1,
            prefix + (value,),
        )


RESIDUES = (2, 4, 8, 14, 13, 11, 7)
COORDINATES = (
    (1, 0),
    (2, 0),
    (3, 0),
    (0, 1),
    (1, 1),
    (2, 1),
    (3, 1),
)
COORDINATE_OF_RESIDUE = dict(zip(RESIDUES, COORDINATES))


def add(left, right, coefficient):
    return (
        (left[0] + coefficient * right[0]) % 4,
        (left[1] + coefficient * right[1]) % 2,
    )


def residue_reachable(valuations, target, channel):
    reached = {(0, 0)}
    for coordinate, multiplicity in zip(COORDINATES, valuations):
        if channel == "exterior":
            coefficients = range(0, 2 * multiplicity + 1)
        else:
            coefficients = range(-multiplicity, multiplicity + 1)
        reached = {
            add(old, coordinate, coefficient)
            for old in reached
            for coefficient in coefficients
        }
    return target in reached


def minimal_elements(vectors):
    result = []
    for vector in sorted(set(vectors), key=lambda row: (sum(row), row)):
        if not any(
            all(lower[i] <= vector[i] for i in range(7))
            for lower in result
        ):
            result.append(vector)
    return result


EXPECTED_MINIMAL_STATES = {
    (0, 0, 0, 0, 0, 1, 0),
    (0, 0, 0, 1, 0, 0, 0),
    (0, 0, 1, 0, 0, 0, 1),
    (0, 0, 1, 0, 1, 0, 0),
    (1, 0, 0, 0, 0, 0, 1),
    (1, 0, 0, 0, 1, 0, 0),
}


occupied_bounded_states = []
bounded_state_count = 0
for total in range(1, 5):
    for valuations in weak_compositions(total, 7):
        bounded_state_count += 1
        exterior = residue_reachable(valuations, (2, 1), "exterior")
        middle = residue_reachable(valuations, (0, 1), "middle")
        if exterior or middle:
            occupied_bounded_states.append(valuations)

computed_minimal_states = set(minimal_elements(occupied_bounded_states))
report(
    "R=15 minimal factor-residue antichain",
    computed_minimal_states == EXPECTED_MINIMAL_STATES,
)


def valuation_vector(n):
    vector = [0] * 7
    ell = 2
    while ell * ell <= n:
        while n % ell == 0:
            coordinate = COORDINATE_OF_RESIDUE.get(ell % 15)
            if coordinate is not None:
                vector[COORDINATES.index(coordinate)] += 1
            n //= ell
        ell += 1
    if n > 1:
        coordinate = COORDINATE_OF_RESIDUE.get(n % 15)
        if coordinate is not None:
            vector[COORDINATES.index(coordinate)] += 1
    return tuple(vector)


def predicted_occupied(a):
    valuations = valuation_vector(a)
    return any(
        all(generator[i] <= valuations[i] for i in range(7))
        for generator in EXPECTED_MINIMAL_STATES
    )


def exterior_count(a):
    return sum(
        1
        for u in divisors(a * a)
        if (4 * u + 1) % 15 == 0
    )


def middle_coefficient(a):
    ds = divisors(a)
    return sum(
        1
        for x in ds
        for y in ds
        if gcd(x, y) == 1
        and a % (x * y) == 0
        and (x + y) % 15 == 0
    )


integer_rows = []
occupied_integer_count = 0
for a in range(1, 3001):
    if gcd(a, 15) != 1:
        continue
    exterior = exterior_count(a)
    middle = middle_coefficient(a)
    actual = exterior + middle // 2 > 0
    occupied_integer_count += int(actual)
    integer_rows.append(actual == predicted_occupied(a))

report(
    "R=15 classification on coprime integers",
    all(integer_rows),
)


prime_rows = []
occupied_prime_count = 0
primes = [
    p
    for p in range(13, 20001)
    if p % 12 == 1 and is_prime(p)
]
for p in primes:
    a = (p + 15) // 4
    exterior = exterior_count(a)
    middle = middle_coefficient(a)
    actual = exterior + middle // 2 > 0
    occupied_prime_count += int(actual)
    prime_rows.append(actual == predicted_occupied(a))

report(
    "R=15 affine prime-shell classification",
    all(prime_rows),
)

print(f"bounded valuation states checked: {bounded_state_count}")
print(f"minimal occupied states: {len(computed_minimal_states)}")
print(f"coprime integers checked: {len(integer_rows)}")
print(f"occupied coprime integers: {occupied_integer_count}")
print(f"affine prime shells checked: {len(prime_rows)}")
print(f"occupied affine prime shells: {occupied_prime_count}")

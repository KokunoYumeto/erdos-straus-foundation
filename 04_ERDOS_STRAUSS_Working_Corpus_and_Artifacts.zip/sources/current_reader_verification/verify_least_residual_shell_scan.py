from collections import Counter
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


LIMIT = 10_000_000
RESIDUAL_LIMIT = 2_000


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def divisors_from_factorization(factors):
    result = [1]
    for prime, exponent in factors:
        result = [
            divisor * prime**power
            for divisor in result
            for power in range(exponent + 1)
        ]
    return tuple(sorted(result))


@lru_cache(maxsize=None)
def divisors(value):
    return divisors_from_factorization(factorization(value))


@lru_cache(maxsize=None)
def square_divisors(value):
    return divisors_from_factorization(
        tuple((prime, 2 * exponent) for prime, exponent in factorization(value))
    )


def minus_one_coefficient(value, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(value):
        local = {1: 1}
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] = local.get(residue, 0) + 1
            inverse = pow(residue, -1, modulus)
            local[inverse] = local.get(inverse, 0) + 1
        product = {}
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                target = left * right % modulus
                product[target] = (
                    product.get(target, 0) + left_count * right_count
                )
        coefficients = product
    return coefficients.get(modulus - 1, 0)


def shell_data(prime, residual):
    if residual >= 2 * prime:
        return None
    denominator = (prime + residual) // 4
    exterior = tuple(
        divisor
        for divisor in square_divisors(denominator)
        if (4 * divisor + 1) % residual == 0
    )
    coefficient = minus_one_coefficient(denominator, residual)
    return denominator, exterior, coefficient, len(exterior) + coefficient // 2


residuals = tuple(range(3, RESIDUAL_LIMIT, 4))
first_residual_distribution = Counter()
first_residual_cases = {}
resistant_prime_count = 0

for prime in primes_up_to(LIMIT):
    if prime % 12 != 1:
        continue
    resistant_prime_count += 1
    first = None
    for residual in residuals:
        data = shell_data(prime, residual)
        if data is not None and data[3] > 0:
            first = (residual,) + data
            break
    if first is None:
        raise AssertionError(f"no occupied tested shell for p={prime}")
    first_residual_distribution[first[0]] += 1
    first_residual_cases.setdefault(first[0], []).append((prime,) + first[1:])


if resistant_prime_count != 166_011:
    raise AssertionError("unexpected resistant-prime count")
if max(first_residual_distribution) != 107:
    raise AssertionError("unexpected largest first residual")
if first_residual_distribution[107] != 1:
    raise AssertionError("the R=107 first-shell case is not unique")
if first_residual_cases[107] != [(8_803_369, 2_200_869, (), 2, 1)]:
    raise AssertionError("unexpected R=107 first-shell data")


p = 8_803_369
R = 107
a, exterior, coefficient, rank = shell_data(p, R)
earlier = tuple(
    (residual, shell_data(p, residual)[3])
    for residual in range(3, R, 4)
)
middle = tuple(
    divisor
    for divisor in square_divisors(a)
    if (divisor + a) % R == 0
)
ordered_pairs = tuple(
    (left, right)
    for left in divisors(a)
    for right in divisors(a)
    if gcd(left, right) == 1
    and a % (left * right) == 0
    and (left + right) % R == 0
)

if any(shell_rank for _, shell_rank in earlier):
    raise AssertionError("an earlier residual shell is occupied")
if factorization(a) != ((3, 2), (11, 2), (43, 1), (47, 1)):
    raise AssertionError("unexpected R=107 denominator factorization")
if exterior:
    raise AssertionError("the R=107 exterior channel is occupied")
if coefficient != 2 or rank != 1:
    raise AssertionError("unexpected R=107 coefficient or rank")
if middle != (121, 40_031_606_241):
    raise AssertionError("unexpected R=107 middle divisors")
if ordered_pairs != ((1, 18_189), (18_189, 1)):
    raise AssertionError("unexpected R=107 coefficient pairs")
if 18_189 % R != R - 1:
    raise AssertionError("the coefficient witness is not minus one")


print("PASS: least-residual shell scan")
print("166011 primes p=1 mod 12 below 10000000 were checked")
print("every checked prime has an occupied residual shell at R at most 107")
print("p=8803369 is the unique checked prime whose first occupied shell has R=107")
print("all residual shells R=3 mod 4 below 107 vanish for p=8803369")
print("at R=107 the exterior count is zero, the coefficient is two, and the rank is one")
print("the coefficient pairs are (1,18189) and (18189,1)")

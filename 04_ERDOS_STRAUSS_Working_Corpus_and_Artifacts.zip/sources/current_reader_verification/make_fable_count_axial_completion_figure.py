"""Draw the exact axial completion of the Fable-to-12289 count descent."""

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.gridspec import GridSpec
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


ROOT = Path(__file__).resolve().parents[1]
FIGURES = ROOT / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)

SQRT3 = np.sqrt(3.0)
SQRT6 = np.sqrt(6.0)

# Spatial coordinates are stored as (X,Y,W); the plot uses (X,W,Y).
p_star = np.array([0.0, 5.0 / 4.0, 0.0])
p_0 = np.array([2.0, 3.0 / 2.0, 0.0])
p_plus = np.array([-1.0, 3.0 / 2.0, SQRT3])
p_minus = np.array([-1.0, 3.0 / 2.0, -SQRT3])
p_bar = (p_0 + p_plus + p_minus) / 3.0

c = np.array([4.0, 4.0, 4.0])
v_0 = np.array([3.0, 6.0, 3.0])
v_plus = np.array([3.0, 3.0, 6.0])
v_minus = np.array([6.0, 3.0, 3.0])

D = np.array([[-1.0, -SQRT3], [2.0, 0.0], [-1.0, SQRT3]])
Q = D / SQRT6


def count_chart(v):
    """Orthonormal coordinates in the affine plane m_0+m_1+m_2=12."""

    return Q.T @ (v - c)


colors = {
    "0": "#d94841",
    "+": "#2ca25f",
    "-": "#3182bd",
    "apex": "#f28e2b",
    "centroid": "#111111",
}

fig = plt.figure(figsize=(13.2, 5.4))
gs = GridSpec(1, 3, width_ratios=[1.35, 0.72, 1.15], wspace=0.27)

# A. The actual transported tetrahedron.
ax3 = fig.add_subplot(gs[0, 0], projection="3d")
face = [np.array([p[0], p[2], p[1]]) for p in (p_0, p_plus, p_minus)]
apex_plot = np.array([p_star[0], p_star[2], p_star[1]])
centroid_plot = np.array([p_bar[0], p_bar[2], p_bar[1]])

poly = Poly3DCollection(
    [face],
    facecolors="#d9edf7",
    edgecolors="#333333",
    linewidths=1.1,
    alpha=0.48,
)
ax3.add_collection3d(poly)

for a, b in ((p_0, p_plus), (p_plus, p_minus), (p_minus, p_0)):
    ax3.plot([a[0], b[0]], [a[2], b[2]], [a[1], b[1]], color="#222222", lw=1.25)
for p in (p_0, p_plus, p_minus):
    ax3.plot(
        [p_star[0], p[0]],
        [p_star[2], p[2]],
        [p_star[1], p[1]],
        color="#7f7f7f",
        lw=1.0,
    )

for p, label, color in (
    (p_0, r"$p_0$", colors["0"]),
    (p_plus, r"$p_+$", colors["+"]),
    (p_minus, r"$p_-$", colors["-"]),
):
    ax3.scatter(p[0], p[2], p[1], s=44, color=color, depthshade=False, zorder=5)
    ax3.text(p[0], p[2], p[1] + 0.035, label, fontsize=10)

ax3.scatter(*apex_plot, s=68, marker="*", color=colors["apex"], depthshade=False)
ax3.scatter(
    *centroid_plot,
    s=30,
    marker="o",
    facecolor="white",
    edgecolor=colors["centroid"],
    depthshade=False,
)
ax3.plot(
    [apex_plot[0], centroid_plot[0]],
    [apex_plot[1], centroid_plot[1]],
    [apex_plot[2], centroid_plot[2]],
    ls="--",
    color=colors["apex"],
    lw=2.0,
)
ax3.set_xlabel(r"$X$", labelpad=4)
ax3.set_ylabel(r"$W$", labelpad=4)
ax3.set_zlabel(r"$Y$", labelpad=4)
ax3.set_title("A. Transported spatial tetrahedron", fontsize=11, pad=12)
ax3.set_xlim(-2.1, 2.1)
ax3.set_ylim(-2.1, 2.1)
ax3.set_zlim(1.18, 1.57)
ax3.set_box_aspect((4.2, 4.2, 0.39))
ax3.view_init(elev=22, azim=-56)
ax3.grid(alpha=0.2)

# B. The exact one-dimensional fibre erased by the count map.
axf = fig.add_subplot(gs[0, 1])
axf.set_title("B. Axial fibre", fontsize=11, pad=12)
axf.plot([0, 0], [5.0 / 4.0, 3.0 / 2.0], color=colors["apex"], lw=2.4)
axf.scatter([0], [5.0 / 4.0], s=85, marker="*", color=colors["apex"], zorder=4)
axf.scatter(
    [0],
    [3.0 / 2.0],
    s=48,
    facecolor="white",
    edgecolor=colors["centroid"],
    zorder=4,
)
axf.text(-0.08, 5.0 / 4.0, r"$p_\star$", ha="right", va="center", fontsize=10)
axf.text(-0.08, 3.0 / 2.0, r"$\bar p$", ha="right", va="center", fontsize=10)
axf.annotate(
    "",
    xy=(0.22, 3.0 / 2.0),
    xytext=(0.22, 5.0 / 4.0),
    arrowprops=dict(arrowstyle="<->", color="#333333", lw=1.2),
)
axf.text(0.27, 11.0 / 8.0, r"$\frac{1}{4}$", va="center", fontsize=12)
axf.scatter([1.0], [11.0 / 8.0], s=54, color="#111111", zorder=5)
axf.text(1.0, 11.0 / 8.0 - 0.035, r"$c=(4,4,4)$", ha="center", va="top", fontsize=9)
for y in (5.0 / 4.0, 3.0 / 2.0):
    axf.annotate(
        "",
        xy=(0.93, 11.0 / 8.0),
        xytext=(0.07, y),
        arrowprops=dict(arrowstyle="->", color="#666666", lw=1.1),
    )
axf.text(0.53, 1.52, r"$\Pi_{\rm cnt}$", ha="center", fontsize=10)
axf.text(
    0.50,
    1.205,
    r"$h_\triangle(\bar p)=0,\quad h_\triangle(p_\star)=\frac{1}{4}$",
    ha="center",
    fontsize=9,
)
axf.set_xlim(-0.40, 1.35)
axf.set_ylim(1.17, 1.57)
axf.set_xticks([])
axf.set_yticks([1.25, 1.50], [r"$5/4$", r"$3/2$"])
for spine in axf.spines.values():
    spine.set_visible(False)

# C. The count-plane image.
ax2 = fig.add_subplot(gs[0, 2])
ax2.set_title(r"C. Count plane $m_0+m_1+m_2=12$", fontsize=11, pad=12)
count_points = [
    (v_0, r"$v_0=(3,6,3)$", colors["0"]),
    (v_plus, r"$v_+=(3,3,6)$", colors["+"]),
    (v_minus, r"$v_-=(6,3,3)$", colors["-"]),
]
xy = [count_chart(v) for v, _, _ in count_points]
for i in range(3):
    j = (i + 1) % 3
    ax2.plot([xy[i][0], xy[j][0]], [xy[i][1], xy[j][1]], color="#222222", lw=1.25)
for (v, label, color), point in zip(count_points, xy):
    ax2.scatter(point[0], point[1], s=52, color=color, zorder=5)
    offset = {
        colors["0"]: (0.08, 0.11),
        colors["+"]: (-0.06, 0.14),
        colors["-"]: (-0.06, -0.25),
    }[color]
    ax2.text(point[0] + offset[0], point[1] + offset[1], label, fontsize=9)

center_xy = count_chart(c)
ax2.scatter(
    center_xy[0],
    center_xy[1],
    s=92,
    marker="*",
    color=colors["apex"],
    zorder=4,
    label=r"$p_\star$ image",
)
ax2.scatter(
    center_xy[0],
    center_xy[1],
    s=36,
    marker="o",
    facecolor="white",
    edgecolor=colors["centroid"],
    linewidth=1.3,
    zorder=5,
    label=r"$\bar p$ image",
)
ax2.annotate(
    r"$\Pi_{\rm cnt}(p_\star)=\Pi_{\rm cnt}(\bar p)=c$",
    xy=center_xy,
    xytext=(-2.9, -0.55),
    arrowprops=dict(arrowstyle="->", color="#444444", lw=1.0),
    fontsize=9,
)
ax2.axhline(0, color="#aaaaaa", lw=0.6)
ax2.axvline(0, color="#aaaaaa", lw=0.6)
ax2.set_aspect("equal")
ax2.set_xlim(-3.0, 3.0)
ax2.set_ylim(-2.75, 2.75)
ax2.set_xlabel(r"orthonormal count coordinate $\xi$")
ax2.set_ylabel(r"orthonormal count coordinate $\eta$")
ax2.grid(alpha=0.18)
ax2.legend(loc="upper right", fontsize=8, frameon=False)

fig.suptitle(
    "The 12289 count descent erases exactly the quarter-height coordinate",
    fontsize=14,
    fontweight="bold",
    y=0.985,
)
fig.text(
    0.5,
    0.025,
    r"$\ker K_{\rm cnt}=\mathrm{span}\{(0,1,0)\}$"
    r"$\qquad \bar p-p_\star=(0,\frac{1}{4},0)$"
    r"$\qquad \widehat K_{\rm cnt}^{T}\widehat K_{\rm cnt}"
    r"=\mathrm{diag}(\frac{3}{2},1,\frac{3}{2})$",
    ha="center",
    fontsize=11,
)
fig.subplots_adjust(top=0.88, bottom=0.12, left=0.045, right=0.98)

pdf_path = FIGURES / "fable_count_axial_completion.pdf"
png_path = FIGURES / "fable_count_axial_completion_qa.png"
fig.savefig(pdf_path, bbox_inches="tight")
fig.savefig(png_path, dpi=130, bbox_inches="tight")
plt.close(fig)

print(pdf_path)
print(png_path)

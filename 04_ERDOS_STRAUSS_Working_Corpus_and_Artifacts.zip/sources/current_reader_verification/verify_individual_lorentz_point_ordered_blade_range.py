from pathlib import Path

import sympy as sp


def zero(expr):
    return sp.cancel(sp.expand(expr)) == 0


def assert_zero(expr, label):
    if not zero(expr):
        raise AssertionError(f"{label}: {sp.factor(expr)}")


def assert_matrix_zero(matrix, label):
    for index, entry in enumerate(matrix):
        assert_zero(entry, f"{label} entry {index}")


delta = sp.symbols("delta", real=True)
h = sp.symbols("h", positive=True)
alpha = h**2
sqrt3 = sp.sqrt(3)

R_perp = sp.Matrix(
    [
        [-sp.Rational(1, 2), sqrt3 / 2],
        [-sqrt3 / 2, -sp.Rational(1, 2)],
    ]
)


def U(parameter, amplitude, m):
    transverse = R_perp**m * sp.Matrix([parameter / 2, amplitude / 4])
    return sp.Matrix(
        [
            5 * (2 - amplitude) / 16,
            transverse[0],
            transverse[1],
            3 * (2 - amplitude) / 16,
        ]
    )


Q_low = sp.diag(1, 0)
Q_high = sp.diag(0, 1)
E21 = sp.Matrix([[0, 0], [1, 0]])
E12 = E21.T
W21 = 2 * h * E21
W12 = W21.T

assert_matrix_zero(W12 * W21 / 4 - alpha * Q_low, "source quarter-product")
assert_matrix_zero(W21 * W12 / 4 - alpha * Q_high, "range quarter-product")
assert_matrix_zero(-W21 * W12 / 4 + alpha * Q_high, "signed range coefficient")
assert_matrix_zero(-W12 * W21 / 4 + alpha * Q_low, "signed source coefficient")

eta_value = alpha / 4
assert_zero(2 * h - 4 * sp.sqrt(eta_value), "blade modulus from arc height")
assert_matrix_zero(
    W12 * W21 / 16 - eta_value * Q_low,
    "source arc-height product",
)
assert_matrix_zero(
    W21 * W12 / 16 - eta_value * Q_high,
    "range arc-height product",
)

X, Y = sp.symbols("X Y", real=True)
z = sp.Matrix([X, Y])
for m in range(3):
    point = U(delta, alpha, m)
    transverse = {X: point[1], Y: point[2]}
    xi_m = (R_perp**m * sp.Matrix([1, 0])).dot(z)
    eta_m = (R_perp**m * sp.Matrix([0, 1])).dot(z)
    assert_zero(
        xi_m.subs(transverse) - delta / 2,
        f"rotated xi coordinate m={m}",
    )
    assert_zero(
        eta_m.subs(transverse) - alpha / 4,
        f"rotated eta coordinate m={m}",
    )

    rotated_back = R_perp ** (-m) * sp.Matrix([point[1], point[2]])
    descended = sp.Matrix(
        [2 - 2 * rotated_back[1], 0, 0, 2 + 2 * rotated_back[1]]
    )
    source = sp.Matrix([2, 0, 0, 2])
    n_target = sp.Matrix([-sp.Rational(1, 2), 0, 0, sp.Rational(1, 2)])
    assert_matrix_zero(
        descended - source - alpha * n_target,
        f"pointwise target-null descent m={m}",
    )

# The Lorentz-null equation is exact on the arithmetic relation
# delta^2 + alpha = 1.
eta_lorentz = sp.diag(-1, 1, 1, 1)
u0 = U(delta, alpha, 0)
lorentz_square = sp.factor((u0.T * eta_lorentz * u0)[0])
assert_zero(
    lorentz_square.subs(alpha, 1 - delta**2),
    "Lorentz nullity on delta-alpha circle",
)

# Complementation d -> N^2/d reverses delta and preserves alpha.
N, d = sp.symbols("N d", positive=True, nonzero=True)
e = N**2 / d
delta_d = (d - N) / (d + N)
alpha_d = 4 * N * d / (N + d) ** 2
delta_e = sp.cancel((e - N) / (e + N))
alpha_e = sp.cancel(4 * N * e / (N + e) ** 2)
assert_zero(delta_e + delta_d, "complement reverses delta")
assert_zero(alpha_e - alpha_d, "complement preserves alpha")
assert_zero(delta_d**2 + alpha_d - 1, "arithmetic delta-alpha circle")

# Exact receipt for all six orbit representatives in the 12289 shell.
N0 = 12289 * 3075
representatives = [
    (615, sp.Rational(61445, 943902729)),
    (5125, sp.Rational(184335, 339886096)),
    (230625, sp.Rational(921675, 38217124)),
    (61445, sp.Rational(615, 94864)),
    (2765025, sp.Rational(123, 484)),
    (23041875, sp.Rational(1025, 1089)),
]
for divisor, expected_alpha in representatives:
    actual_alpha = sp.Rational(4 * N0 * divisor, (N0 + divisor) ** 2)
    actual_delta = sp.Rational(divisor - N0, divisor + N0)
    if actual_alpha != expected_alpha:
        raise AssertionError(f"12289 amplitude at d={divisor}")
    assert_zero(
        actual_delta**2 + actual_alpha - 1,
        f"12289 delta-alpha circle at d={divisor}",
    )
    complement = N0 * N0 // divisor
    if divisor * complement != N0 * N0:
        raise AssertionError(f"12289 complement product at d={divisor}")
    complement_alpha = sp.Rational(
        4 * N0 * complement, (N0 + complement) ** 2
    )
    if complement_alpha != actual_alpha:
        raise AssertionError(f"12289 complement amplitude at d={divisor}")

lines = [
    "PASS individual Lorentz arc height equals alpha/4 on all three rotations",
    "PASS ordered low-to-high blade coefficient equals 4 sqrt(eta_m)",
    "PASS source and range quarter-products retain distinct sheet projectors",
    "PASS the signed low-to-high range product equals -alpha E22",
    "PASS the signed transposed range product equals -alpha E11",
    "PASS every sheetwise Lorentz descent equals source plus alpha times n_target",
    "PASS complementation reverses delta and preserves alpha",
    "PASS all six 12289 orbit representatives and complements retain their exact amplitudes",
]

output = Path(__file__).with_name(
    "verify_individual_lorentz_point_ordered_blade_range_output.txt"
)
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

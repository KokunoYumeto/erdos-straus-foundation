import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


s, m = sp.symbols("s m", positive=True)
t = (s + m) / 2
x = (s - m) / 2
require(sp.factor(t + x - s) == 0, "Hadamard inverse s")
require(sp.factor(t - x - m) == 0, "Hadamard inverse m")
require(sp.factor(t**2 - x**2 - s * m) == 0, "Hadamard quadratic identity")

alpha_1, alpha_2, m_1, m_2 = sp.symbols(
    "alpha_1 alpha_2 m_1 m_2",
    positive=True,
)
lambda_plus = alpha_2 + alpha_1 / 2
lambda_minus = alpha_2 - alpha_1 / 2
require(
    sp.factor(lambda_plus - (2 * alpha_2 + alpha_1) / 2) == 0,
    "amplitude Hadamard time",
)
require(
    sp.factor(lambda_minus - (2 * alpha_2 - alpha_1) / 2) == 0,
    "amplitude Hadamard space",
)

kappa_plus = m_2 + m_1 / 2
kappa_minus = m_2 - m_1 / 2
require(
    sp.factor(kappa_plus**2 - kappa_minus**2 - 2 * m_1 * m_2) == 0,
    "count Lorentz norm",
)

mean_02 = alpha_2 / m_2
mean_11 = alpha_1 / m_1
require(
    sp.factor(
        (2 * alpha_2 / alpha_1)
        / (2 * m_2 / m_1)
        - mean_02 / mean_11
    )
    == 0,
    "rapidity defect exponential",
)

m1_exact = sp.Integer(6)
m2_exact = sp.Integer(3)
require(
    (
        kappa_plus.subs({m_1: m1_exact, m_2: m2_exact}),
        kappa_minus.subs({m_1: m1_exact, m_2: m2_exact}),
    )
    == (6, 0),
    "12289 count rest frame",
)

alpha1_exact = sp.Rational(1026107, 426888)
alpha2_exact = sp.Rational(
    5176199252561022635,
    209357204251173091344,
)
rapidity_exponential = sp.factor(2 * alpha2_exact / alpha1_exact)
require(
    rapidity_exponential
    == sp.Rational(
        5176199252561022635,
        251615052171246869483,
    ),
    "12289 amplitude rapidity",
)
require(rapidity_exponential < 1, "12289 negative rapidity")

lines = [
    "PASS: three-origin Hadamard cone and rapidity defect",
    "the positive three-origin plane maps bijectively to the future cone",
    "the exact inverse coordinates are s=t+x and m=t-x",
    "the source product sm equals the Lorentz norm t^2-x^2",
    "the amplitude vector is the Hadamard image of (2 alpha_2,alpha_1)",
    "the count vector is the Hadamard image of (2 m_2,m_1)",
    "the count Lorentz norm is 2 m_1 m_2",
    "the amplitude Lorentz norm is 2 alpha_1 alpha_2",
    "the rapidity defect is the log ratio of mean orbit weights",
    "the exact 12289 count vector is (6,0)",
    "the exact 12289 count rapidity is zero",
    "the exact 12289 amplitude rapidity is negative",
]

print("\n".join(lines))

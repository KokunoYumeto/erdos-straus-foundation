"""Exact low-cost checks for the support-indexed modular family.

All entries lie in Q(omega), with omega^2 + omega + 1 = 0.  The cases
N=1 and N=2 use its rational subfield.
"""

from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations


@dataclass(frozen=True)
class Cyclotomic:
    """The element a + b*omega of Q(omega)."""

    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    @staticmethod
    def coerce(value):
        if isinstance(value, Cyclotomic):
            return value
        return Cyclotomic(Fraction(value), Fraction(0))

    def __add__(self, other):
        other = self.coerce(other)
        return Cyclotomic(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __neg__(self):
        return Cyclotomic(-self.a, -self.b)

    def __sub__(self, other):
        return self + (-self.coerce(other))

    def __rsub__(self, other):
        return self.coerce(other) - self

    def __mul__(self, other):
        other = self.coerce(other)
        # omega^2 = -1 - omega.
        return Cyclotomic(
            self.a * other.a - self.b * other.b,
            self.a * other.b + self.b * other.a - self.b * other.b,
        )

    __rmul__ = __mul__

    def conjugate(self):
        # conjugate(omega)=omega^2=-1-omega.
        return Cyclotomic(self.a - self.b, -self.b)

    def inverse(self):
        norm = self.a * self.a - self.a * self.b + self.b * self.b
        if norm == 0:
            raise ZeroDivisionError
        conjugate = self.conjugate()
        return Cyclotomic(conjugate.a / norm, conjugate.b / norm)

    def __truediv__(self, other):
        return self * self.coerce(other).inverse()

    def __pow__(self, exponent: int):
        if exponent < 0:
            return (self.inverse()) ** (-exponent)
        result = ONE
        factor = self
        while exponent:
            if exponent & 1:
                result *= factor
            factor *= factor
            exponent >>= 1
        return result


ZERO = Cyclotomic()
ONE = Cyclotomic(Fraction(1))
OMEGA = Cyclotomic(Fraction(0), Fraction(1))


def zero_matrix(rows: int, columns: int | None = None):
    columns = rows if columns is None else columns
    return [[ZERO for _ in range(columns)] for _ in range(rows)]


def identity_matrix(number: int):
    result = zero_matrix(number)
    for index in range(number):
        result[index][index] = ONE
    return result


def matrix_add(left, right):
    return [
        [left[i][j] + right[i][j] for j in range(len(left[0]))]
        for i in range(len(left))
    ]


def matrix_negate(value):
    return [[-entry for entry in row] for row in value]


def matrix_subtract(left, right):
    return matrix_add(left, matrix_negate(right))


def matrix_scale(scalar, value):
    scalar = Cyclotomic.coerce(scalar)
    return [[scalar * entry for entry in row] for row in value]


def matrix_multiply(left, right):
    rows = len(left)
    middle = len(right)
    columns = len(right[0])
    return [
        [
            sum(
                (left[i][k] * right[k][j] for k in range(middle)),
                ZERO,
            )
            for j in range(columns)
        ]
        for i in range(rows)
    ]


def conjugate_transpose(value):
    return [
        [value[i][j].conjugate() for i in range(len(value))]
        for j in range(len(value[0]))
    ]


def transpose(value):
    return [
        [value[i][j] for i in range(len(value))]
        for j in range(len(value[0]))
    ]


def entrywise_conjugate(value):
    return [[entry.conjugate() for entry in row] for row in value]


def matrix_power(value, exponent: int):
    result = identity_matrix(len(value))
    factor = value
    while exponent:
        if exponent & 1:
            result = matrix_multiply(result, factor)
        factor = matrix_multiply(factor, factor)
        exponent >>= 1
    return result


def matrix_rank(value) -> int:
    work = [row[:] for row in value]
    row_count = len(work)
    column_count = len(work[0])
    pivot_row = 0
    for column in range(column_count):
        pivot = next(
            (
                row
                for row in range(pivot_row, row_count)
                if work[row][column] != ZERO
            ),
            None,
        )
        if pivot is None:
            continue
        work[pivot_row], work[pivot] = work[pivot], work[pivot_row]
        inverse = work[pivot_row][column].inverse()
        work[pivot_row] = [inverse * entry for entry in work[pivot_row]]
        for row in range(row_count):
            if row == pivot_row:
                continue
            factor = work[row][column]
            if factor != ZERO:
                work[row] = [
                    work[row][j] - factor * work[pivot_row][j]
                    for j in range(column_count)
                ]
        pivot_row += 1
        if pivot_row == row_count:
            break
    return pivot_row


def root(number: int):
    if number == 1:
        return ONE
    if number == 2:
        return -ONE
    if number == 3:
        return OMEGA
    raise ValueError(number)


def fourier_vector(number: int, label: int):
    zeta = root(number)
    return [[zeta ** (label * index)] for index in range(number)]


def support_projection(number: int, support: tuple[int, ...]):
    result = zero_matrix(number)
    for label in support:
        vector = fourier_vector(number, label)
        outer_product = matrix_multiply(vector, conjugate_transpose(vector))
        result = matrix_add(result, outer_product)
    return matrix_scale(Fraction(1, number), result)


def subsets(number: int):
    for size in range(number + 1):
        yield from combinations(range(number), size)


def cyclic_shift(number: int):
    result = zero_matrix(number)
    for index in range(number):
        result[(index + 1) % number][index] = ONE
    return result


def character_projector(unitary, zeta, label: int):
    number = len(unitary)
    result = zero_matrix(number)
    for power in range(number):
        coefficient = zeta ** (-label * power)
        result = matrix_add(
            result,
            matrix_scale(coefficient, matrix_power(unitary, power)),
        )
    return matrix_scale(Fraction(1, number), result)


def antiunitary_conjugate(value, carrier):
    return matrix_multiply(
        matrix_multiply(carrier, entrywise_conjugate(value)),
        transpose(carrier),
    )


def main() -> None:
    lam = Cyclotomic(Fraction(2))
    receipts = []

    for number in (1, 2, 3):
        identity = identity_matrix(number)
        for support in subsets(number):
            projection = support_projection(number, support)
            complement = matrix_subtract(identity, projection)
            assert matrix_multiply(projection, projection) == projection
            assert conjugate_transpose(projection) == projection
            assert matrix_multiply(complement, complement) == complement
            assert matrix_multiply(projection, complement) == zero_matrix(number)
            assert matrix_rank(projection) == len(support)
            assert matrix_rank(complement) == number - len(support)

            rho = matrix_add(projection, matrix_scale(lam, complement))
            rho_inverse = matrix_add(
                projection,
                matrix_scale(lam.inverse(), complement),
            )
            assert matrix_multiply(rho, rho_inverse) == identity

            rank = len(support)
            off_diagonal_multiplicity = rank * (number - rank)
            assert (
                rank**2
                + 2 * off_diagonal_multiplicity
                + (number - rank) ** 2
                == number**2
            )

            for row in range(number):
                for column in range(number):
                    unit = zero_matrix(number)
                    unit[row][column] = ONE
                    channels = (
                        matrix_multiply(
                            matrix_multiply(projection, unit), projection
                        ),
                        matrix_multiply(
                            matrix_multiply(projection, unit), complement
                        ),
                        matrix_multiply(
                            matrix_multiply(complement, unit), projection
                        ),
                        matrix_multiply(
                            matrix_multiply(complement, unit), complement
                        ),
                    )
                    reconstructed = zero_matrix(number)
                    for channel in channels:
                        reconstructed = matrix_add(reconstructed, channel)
                    assert reconstructed == unit
                    factors = (ONE, lam.inverse(), lam, ONE)
                    for channel, factor in zip(channels, factors):
                        transformed = matrix_multiply(
                            matrix_multiply(rho, channel), rho_inverse
                        )
                        assert transformed == matrix_scale(factor, channel)

        rank = 1
        receipts.append(
            (
                number,
                rank**2 + (number - rank) ** 2,
                rank * (number - rank),
                rank * (number - rank),
            )
        )

    number = 3
    unitary = cyclic_shift(number)
    projectors = [
        character_projector(unitary, OMEGA, label)
        for label in range(number)
    ]
    for label in range(number):
        assert (
            support_projection(number, (label,))
            == projectors[(-label) % number]
        )

    identity = identity_matrix(number)
    assert antiunitary_conjugate(unitary, identity) == unitary
    for label in range(number):
        assert (
            antiunitary_conjugate(
                support_projection(number, (label,)), identity
            )
            == support_projection(number, ((-label) % number,))
        )

    reflection = zero_matrix(number)
    for label in range(number):
        reflection[(-label) % number][label] = ONE
    assert (
        antiunitary_conjugate(unitary, reflection)
        == transpose(unitary)
    )
    for label in range(number):
        assert (
            antiunitary_conjugate(
                support_projection(number, (label,)), reflection
            )
            == support_projection(number, (label,))
        )

    print("All exact support-indexed modular-family checks passed.")
    print("Singleton multiplicities (zero, plus log(lambda), minus log(lambda)):")
    for number, zero_mult, plus_mult, minus_mult in receipts:
        print(f"  N={number}: ({zero_mult}, {plus_mult}, {minus_mult})")
    print("C3 transport:")
    print("  entrywise conjugation: U -> U and A -> -A")
    print("  reflection*conjugation: U -> U^{-1} and A -> A")


if __name__ == "__main__":
    main()

from __future__ import annotations

import sympy as sp


def require(statement: bool, message: str) -> None:
    if not statement:
        raise AssertionError(message)
    print(f"PASS {message}")


z = sp.symbols("z")

# A generic multiplicity test, including one amplitude shared by both types.
a, b, c = sp.symbols("a b c", distinct=True)
p_02 = (z - a) ** 2 * (z - b)
p_11 = (z - a) * (z - c) ** 2
r_02 = sp.diff(p_02, z) / p_02
r_11 = sp.diff(p_11, z) / p_11
xi = sp.cancel(r_02 - r_11)
wronskian = sp.expand(sp.diff(p_02, z) * p_11 - sp.diff(p_11, z) * p_02)

require(
    sp.cancel(xi - wronskian / (p_02 * p_11)) == 0,
    "the signed resolvent is the type-polynomial Wronskian quotient",
)
gcd_polynomial = sp.gcd(sp.Poly(p_02, z), sp.Poly(p_11, z)).as_expr()
coprime_02 = sp.cancel(p_02 / gcd_polynomial)
coprime_11 = sp.cancel(p_11 / gcd_polynomial)
require(
    sp.cancel(
        xi
        - sp.diff(coprime_02, z) / coprime_02
        + sp.diff(coprime_11, z) / coprime_11
    ) == 0,
    "the common type-polynomial factor cancels exactly",
)

# Numeric specialization checks signed residue multiplicities directly.
numeric_xi = xi.subs({a: 1, b: 2, c: 3})
require(
    sp.residue(numeric_xi, z, 1) == 1
    and sp.residue(numeric_xi, z, 2) == 1
    and sp.residue(numeric_xi, z, 3) == -2,
    "signed residues equal the differences of orbit multiplicities",
)

# Generic Lorentz resolvent matrix.
r0, r1 = sp.symbols("r0 r1", positive=True)
pi_value = r0 + r1
xi_value = r0 - r1
lorentz = sp.Matrix([[pi_value, xi_value], [xi_value, pi_value]])
require(
    lorentz * sp.Matrix([1, 1]) == 2 * r0 * sp.Matrix([1, 1])
    and lorentz * sp.Matrix([1, -1]) == 2 * r1 * sp.Matrix([1, -1]),
    "the resolvent-character Lorentz eigenvalues are the two type masses",
)
require(
    sp.factor(lorentz.det() - 4 * r0 * r1) == 0,
    "the resolvent-character Lorentz determinant is four times the type product",
)

# Pointwise blade, target-line, arc-height, and target-null realizations.
alpha, eta = sp.symbols("alpha eta", positive=True)
range_projector = sp.Matrix([[0, 0], [0, 1]])
blade_range_product = alpha * range_projector
blade_resolvent = (
    range_projector
    * (z * sp.eye(2) - blade_range_product).inv()
    * range_projector
)
require(
    blade_resolvent == range_projector / (z - alpha),
    "the compressed ordered-blade resolvent equals the scalar orbit resolvent",
)
target_coefficient = -alpha * range_projector
target_line_inverse = range_projector / (z - alpha)
require(
    (z * range_projector + target_coefficient) * target_line_inverse
    == range_projector,
    "the arithmetic target-line inverse equals the orbit resolvent",
)
require(
    sp.cancel(1 / (z - alpha) - 1 / (z - 4 * eta)).subs(alpha, 4 * eta) == 0,
    "the rotated Lorentz arc height gives the same orbit resolvent",
)
n_target = sp.Matrix([1, 1, 0, 0])
circle_increment = alpha * n_target
require(
    circle_increment / (alpha * (z - alpha)) == n_target / (z - alpha),
    "the pointwise circle increment gives the target-null resolvent",
)

# Exact 12289 data.
exact_02 = [
    sp.Rational(61445, 943902729),
    sp.Rational(184335, 339886096),
    sp.Rational(921675, 38217124),
]
exact_11 = [
    sp.Rational(615, 94864),
    sp.Rational(123, 484),
    sp.Rational(1025, 1089),
]
P_02 = sp.prod(z - value for value in exact_02)
P_11 = sp.prod(z - value for value in exact_11)
W = sp.expand(sp.diff(P_02, z) * P_11 - sp.diff(P_11, z) * P_02)
primitive = (
    sp.Integer(43401481466401148947095343104) * z ** 4
    - sp.Integer(18209177424538142005968238080) * z ** 3
    + sp.Integer(395994243119213681673328400) * z ** 2
    - sp.Integer(2827184709924732899115000) * z
    + sp.Integer(831864914962023065625)
)
scale = -sp.Rational(347, 12794188948921747974357647576064)
require(
    sp.Poly(sp.expand(W - scale * primitive), z).is_zero,
    "the exact 12289 signed-resolvent numerator has the stated integer coefficients",
)

Xi = sp.cancel(sp.diff(P_02, z) / P_02 - sp.diff(P_11, z) / P_11)
require(
    all(sp.residue(Xi, z, value) == 1 for value in exact_02)
    and all(sp.residue(Xi, z, value) == -1 for value in exact_11),
    "the six exact 12289 poles have signed residues plus one and minus one",
)

lambda_minus = sp.factor(sum(exact_02) - sum(exact_11))
require(
    lambda_minus == -sp.Rational(14143643992119252, 12015450198070081),
    "the exact first-moment difference is the quoted skew target character",
)
require(
    sp.Poly(W, z).degree() == 4
    and sp.Poly(W, z).LC() == lambda_minus,
    "equal orbit cardinalities remove the degree-five term and expose the skew character",
)

# Laurent coefficients through degree six are the signed moment differences.
w = sp.symbols("w")
Xi_at_infinity = sp.cancel(Xi.subs(z, 1 / w))
series = sp.series(Xi_at_infinity, w, 0, 8).removeO().expand()
for degree in range(7):
    signed_moment = sum(value ** degree for value in exact_02)
    signed_moment -= sum(value ** degree for value in exact_11)
    require(
        sp.factor(series.coeff(w, degree + 1) - signed_moment) == 0,
        f"the 12289 Laurent coefficient {degree + 1} equals signed moment {degree}",
    )

# Stable path/divisor signed resolvent transfer at an exact external point.
evaluation_point = sp.Integer(2)
R_02 = sum(1 / (evaluation_point - value) for value in exact_02)
R_11 = sum(1 / (evaluation_point - value) for value in exact_11)
path_signed_trace = 3 * (R_02 - R_11)
divisor_signed_trace = 2 * (R_02 - R_11)
require(
    sp.factor(2 * path_signed_trace - 3 * divisor_signed_trace) == 0,
    "the exact signed resolvent character obeys the stable 2:3 carrier transfer",
)

print("PASS all signed resolvent, blade, and circle checks completed")

from math import gcd


S3 = 21
S4 = 107
S5 = 47_176_870
SIGMA5 = 4_098
SPACE5 = 12_289
R5 = 11
A5 = 3_075
ODD_S5 = S5 // 2

assert S5 == 2 * 5 * 13 * 17 * 21_347
assert S5 % 4 == 2
assert (4 * S3 * S3 * S5) % S4 == 1

target = (-S3 * S5) % S4
roots = [x for x in range(S4) if x * x % S4 == target]
assert roots == [11, 96]
assert [x for x in roots if x % 4 == 3] == [R5]

assert SPACE5 - 1 == 2**12 * 3
assert pow(11, SPACE5 - 1, SPACE5) == 1
assert pow(11, (SPACE5 - 1) // 2, SPACE5) == SPACE5 - 1
assert pow(11, (SPACE5 - 1) // 3, SPACE5) == 6_240
assert gcd(pow(11, (SPACE5 - 1) // 2, SPACE5) - 1, SPACE5) == 1
assert gcd(pow(11, (SPACE5 - 1) // 3, SPACE5) - 1, SPACE5) == 1

assert A5 == 3 * 5**2 * 41
assert (SPACE5 + R5) // 4 == A5
assert 4 * A5 - SPACE5 == R5

assert ODD_S5 == 5 * 13 * 17 * 21_347
required_x_mod_5 = pow((4 * (S4 % 5) ** 2) % 5, -1, 5)
assert required_x_mod_5 == 1
forced_square_target_mod_5 = (-S4 * required_x_mod_5) % 5
assert forced_square_target_mod_5 == 3
assert forced_square_target_mod_5 not in {x * x % 5 for x in range(5)}

assert [pow(2, k, 11) for k in (8, 4, 3)] == [3, 5, 8]
assert 41 % 11 == 8

print("PASS: four-to-five Busy-Beaver successor shell")
print("4*S(3)^2*S(5) is one modulo S(4)=107")
print("the square roots of -S(3)S(5) modulo 107 are 11 and 96")
print("11 is the unique least positive root congruent to three modulo four")
print("Space(5)=12289 has a Pocklington certificate with witness 11")
print("the successor shell is (p,a,R)=(12289,3075,11)")
print("S(5) is two modulo four and cannot be an odd residual")
print("the literal next-state system is impossible already modulo five")

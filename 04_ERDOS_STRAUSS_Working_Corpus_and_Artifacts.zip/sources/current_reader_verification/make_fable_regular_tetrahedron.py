#!/usr/bin/env python3
"""Render the exact regular-tetrahedral realization of the four Fable rays."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "figures" / "fable_regular_tetrahedron.pdf"

scale = np.sqrt(3.0)
vertices = {
    r"$r_\infty$": np.array([1.0, 1.0, 1.0]) / scale,
    r"$r_0$": np.array([1.0, -1.0, -1.0]) / scale,
    r"$r_+$": np.array([-1.0, 1.0, -1.0]) / scale,
    r"$r_-$": np.array([-1.0, -1.0, 1.0]) / scale,
}
labels = list(vertices)
points = np.vstack([vertices[label] for label in labels])

gram = points @ points.T
target = np.full((4, 4), -1.0 / 3.0)
np.fill_diagonal(target, 1.0)
assert np.allclose(gram, target)
assert np.allclose(points.sum(axis=0), np.zeros(3))

faces = [
    (1, 2, 3),
    (0, 1, 2),
    (0, 2, 3),
    (0, 3, 1),
]
face_colors = ["#8ecae6", "#ffd6a5", "#ffcad4", "#caffbf"]
vertex_colors = ["#f4a261", "#457b9d", "#2a9d8f", "#9b5de5"]

fig = plt.figure(figsize=(6.8, 5.7))
ax = fig.add_subplot(111, projection="3d")
ax.set_proj_type("ortho")

for face, color in zip(faces, face_colors):
    polygon = points[list(face)]
    collection = Poly3DCollection(
        [polygon],
        facecolors=color,
        edgecolors="#243447",
        linewidths=0.85,
        alpha=0.28 if face != faces[0] else 0.48,
    )
    ax.add_collection3d(collection)

edges = [(0, 1), (0, 2), (0, 3), (1, 2), (2, 3), (3, 1)]
for i, j in edges:
    segment = np.vstack([points[i], points[j]])
    ax.plot(
        segment[:, 0],
        segment[:, 1],
        segment[:, 2],
        color="#243447",
        linewidth=1.05,
        zorder=4,
    )

label_offsets = [
    np.array([0.10, 0.10, 0.10]),
    np.array([0.10, -0.10, -0.15]),
    np.array([0.18, 0.18, 0.02]),
    np.array([-0.10, -0.10, 0.10]),
]

for idx, (label, point) in enumerate(vertices.items()):
    ax.scatter(
        point[0],
        point[1],
        point[2],
        s=62,
        color=vertex_colors[idx],
        edgecolor="#1d2731",
        linewidth=0.7,
        depthshade=False,
        zorder=6,
    )
    shift = label_offsets[idx]
    ax.text(
        point[0] + shift[0],
        point[1] + shift[1],
        point[2] + shift[2] + (0.06 if idx == 0 else 0.0),
        label,
        fontsize=11,
        ha="center",
        va="center",
        zorder=8,
    )

face_centroid = points[1:].mean(axis=0)
altitude = np.vstack([points[0], face_centroid])
ax.plot(
    altitude[:, 0],
    altitude[:, 1],
    altitude[:, 2],
    linestyle=(0, (4, 3)),
    color="#d1495b",
    linewidth=1.4,
    zorder=7,
)
ax.scatter(
    face_centroid[0],
    face_centroid[1],
    face_centroid[2],
    s=24,
    color="#d1495b",
    edgecolor="white",
    linewidth=0.6,
    depthshade=False,
    zorder=8,
)
ax.text(
    face_centroid[0] - 0.10,
    face_centroid[1] - 0.08,
    face_centroid[2] - 0.12,
    r"$c_{\mathrm{face}}=-r_\infty/3$",
    fontsize=9.5,
    color="#9d2235",
    ha="right",
)

# The three arrows lie strictly inside the opposite face and realize its
# cyclic vertex action without changing the tetrahedral edge data.
cycle = [1, 2, 3, 1]
for source, target_index in zip(cycle[:-1], cycle[1:]):
    start = 0.68 * points[source] + 0.32 * face_centroid
    finish = 0.68 * points[target_index] + 0.32 * face_centroid
    vector = finish - start
    ax.quiver(
        start[0],
        start[1],
        start[2],
        vector[0],
        vector[1],
        vector[2],
        color="#1d4ed8",
        linewidth=1.25,
        arrow_length_ratio=0.14,
        pivot="tail",
        zorder=9,
    )

# The reflection fixes r_0 and the midpoint of the r_+,r_- edge.
reflection_midpoint = 0.5 * (points[2] + points[3])
reflection_axis = np.vstack([points[1], reflection_midpoint])
ax.plot(
    reflection_axis[:, 0],
    reflection_axis[:, 1],
    reflection_axis[:, 2],
    linestyle=(0, (2, 2)),
    color="#6b7280",
    linewidth=1.15,
    zorder=8,
)

ax.text2D(
    0.035,
    0.88,
    r"opposite face: $r_0\mapsto r_+\mapsto r_-\mapsto r_0$",
    transform=ax.transAxes,
    fontsize=9.3,
    color="#1d4ed8",
)
ax.text2D(
    0.035,
    0.825,
    r"face reflection: $r_0$ fixed, $r_+\leftrightarrow r_-$",
    transform=ax.transAxes,
    fontsize=9.3,
    color="#4b5563",
)
ax.text2D(
    0.035,
    0.77,
    r"forced ray: $r_\infty=-(r_0+r_++r_-)$",
    transform=ax.transAxes,
    fontsize=9.3,
    color="#a04d00",
)

ax.set_title(
    r"Regular tetrahedral realization of the four Fable rays",
    fontsize=13,
    pad=14,
)
ax.view_init(elev=30.0, azim=-45.0)
ax.set_xlim(-1.12, 1.12)
ax.set_ylim(-1.12, 1.12)
ax.set_zlim(-1.12, 1.12)
ax.set_box_aspect((1, 1, 1))
ax.set_axis_off()

fig.subplots_adjust(left=0.01, right=0.99, bottom=0.01, top=0.93)
fig.savefig(
    OUTPUT,
    format="pdf",
    bbox_inches="tight",
    metadata={
        "Title": "Regular tetrahedral realization of the four Fable rays",
        "Author": "The Clankers",
        "Subject": "Exact vector rendering from the regular tetrahedral Gram form",
    },
)
print(OUTPUT)

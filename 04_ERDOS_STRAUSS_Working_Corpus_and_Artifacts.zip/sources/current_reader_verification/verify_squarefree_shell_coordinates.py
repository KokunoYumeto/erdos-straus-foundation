from fractions import Fraction
from functools import lru_cache
from math import isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


def squarefree_kernel(value):
    remaining = value
    kernel = 1
    prime = 2
    while prime * prime <= remaining:
        exponent = 0
        while remaining % prime == 0:
            exponent += 1
            remaining //= prime
        if exponent % 2:
            kernel *= prime
        prime += 1
    if remaining > 1:
        kernel *= remaining
    return kernel


def is_squarefree(value):
    for prime in range(2, isqrt(value) + 1):
        if value % (prime * prime) == 0:
            return False
    return True


@lru_cache(maxsize=None)
def oriented_factor_coordinates(a):
    coordinates = []
    for s in divisors(a):
        if not is_squarefree(s):
            continue
        for t in divisors(a // s):
            m = a // (s * t)
            coordinates.append((s, t, m))
    return tuple(coordinates)


shell_count = 0
aggregate_rank = 0
aggregate_direction_count = 0
exterior_coordinate_count = 0
middle_coordinate_count = 0
primewise_direction_checks = 0
primewise_direction_equalities = 0
zero_direction_primes = []
zero_direction_resistant_primes = []
validated_a = set()

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue

    prime_rank = 0
    prime_direction_count = 0
    prime_direction_equality = True
    for a in range(p // 4 + 1, (3 * p) // 4 + 1):
        R = 4 * a - p
        if R <= 0 or R % 4 != 3:
            continue
        shell_count += 1

        coordinates = oriented_factor_coordinates(a)
        direct_divisors = set(divisors(a * a))
        if a not in validated_a:
            coordinate_divisors = {s * t * t for s, t, _ in coordinates}
            if coordinate_divisors != direct_divisors:
                raise AssertionError(
                    f"squarefree coordinates miss a divisor at a={a}"
                )
            if len(coordinates) != len(coordinate_divisors):
                raise AssertionError(
                    f"squarefree coordinates are not unique at a={a}"
                )
            for s, t, m in coordinates:
                u = s * t * t
                v = s * m * m
                if not (
                    is_squarefree(s)
                    and a == s * t * m
                    and u * v == a * a
                    and squarefree_kernel(u) == s
                ):
                    raise AssertionError(
                        f"coordinate equations fail at a={a}, u={u}"
                    )
                if (s, m, t) not in coordinates:
                    raise AssertionError(
                        f"complement swap fails at a={a}, u={u}"
                    )
            validated_a.add(a)

        exterior_direct = {
            u for u in direct_divisors if (4 * u + 1) % R == 0
        }
        exterior_coordinates = {
            (s, t, m)
            for s, t, m in coordinates
            if (4 * s * t * t + 1) % R == 0
        }
        if {s * t * t for s, t, m in exterior_coordinates} != exterior_direct:
            raise AssertionError(
                f"exterior coordinate channel fails at p={p}, a={a}, R={R}"
            )
        for s, t, m in exterior_coordinates:
            b_numerator = p * s * t * (m + p * t)
            c_numerator = s * m * (p * t + m)
            if b_numerator % R or c_numerator % R:
                raise AssertionError(
                    f"exterior reconstruction is not integral at p={p}, a={a}, R={R}"
                )
            b = b_numerator // R
            c = c_numerator // R
            if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                raise AssertionError(
                    f"exterior coordinate identity fails at p={p}, a={a}, R={R}"
                )

        middle_direct = {
            tuple(sorted((u, a * a // u)))
            for u in direct_divisors
            if (u + a) % R == 0
        }
        middle_coordinates = {
            (s, min(t, m), max(t, m))
            for s, t, m in coordinates
            if (t + m) % R == 0
        }
        reconstructed_middle = {
            tuple(sorted((s * t * t, s * m * m)))
            for s, t, m in middle_coordinates
        }
        if reconstructed_middle != middle_direct:
            raise AssertionError(
                f"middle coordinate channel fails at p={p}, a={a}, R={R}"
            )
        if any(t == m for _, t, m in middle_coordinates):
            raise AssertionError(
                f"middle coordinate fixed point occurs at p={p}, a={a}, R={R}"
            )
        for s, t, m in middle_coordinates:
            b_numerator = p * s * t * (t + m)
            c_numerator = p * s * m * (t + m)
            if b_numerator % R or c_numerator % R:
                raise AssertionError(
                    f"middle reconstruction is not integral at p={p}, a={a}, R={R}"
                )
            b = b_numerator // R
            c = c_numerator // R
            if Fraction(4, p) != Fraction(1, a) + Fraction(1, b) + Fraction(1, c):
                raise AssertionError(
                    f"middle coordinate identity fails at p={p}, a={a}, R={R}"
                )

        q_direct = len(exterior_direct) + len(middle_direct)
        q_coordinates = len(exterior_coordinates) + len(middle_coordinates)
        if q_direct != q_coordinates:
            raise AssertionError(
                f"two-channel shell count fails at p={p}, a={a}, R={R}"
            )

        one_sided = bool(exterior_coordinates) != bool(middle_coordinates)
        direction_contribution = int(one_sided)
        if direction_contribution > q_coordinates:
            raise AssertionError(
                f"direction count exceeds orbit count at p={p}, a={a}, R={R}"
            )
        shell_is_equality = direction_contribution == q_coordinates
        expected_shell_equality = (
            q_coordinates == 0
            or (
                one_sided
                and q_coordinates == 1
            )
        )
        if shell_is_equality != expected_shell_equality:
            raise AssertionError(
                f"direction equality criterion fails at p={p}, a={a}, R={R}"
            )

        prime_rank += q_coordinates
        prime_direction_count += direction_contribution
        prime_direction_equality &= shell_is_equality
        exterior_coordinate_count += len(exterior_coordinates)
        middle_coordinate_count += len(middle_coordinates)

    if prime_direction_count > prime_rank:
        raise AssertionError(
            f"primewise direction count exceeds rank at p={p}"
        )
    if (prime_direction_count == prime_rank) != prime_direction_equality:
        raise AssertionError(
            f"primewise direction equality criterion fails at p={p}"
        )
    primewise_direction_checks += 1
    primewise_direction_equalities += int(prime_direction_equality)
    if prime_direction_count == 0:
        zero_direction_primes.append(p)
        if p % 12 == 1:
            zero_direction_resistant_primes.append(p)
    aggregate_rank += prime_rank
    aggregate_direction_count += prime_direction_count


if not shell_count or not aggregate_rank:
    raise AssertionError("the tested squarefree-coordinate family was empty")
if not exterior_coordinate_count or not middle_coordinate_count:
    raise AssertionError("one squarefree-coordinate channel was empty")

print("PASS: squarefree two-channel shell coordinates")
print("every divisor u of a^2 is uniquely u=s t^2 with a=s t m and s squarefree")
print("complementation exchanges t and m")
print("the exterior channel is exactly R dividing 4 s t^2+1")
print("the middle channel is exactly R dividing t+m")
print("both coordinate channels reconstruct exact unit-fraction identities")
print("the shell rank is the sum of the two coordinate-channel counts")
print(
    "the directional coordinate is the number of shells with exactly one "
    "nonempty channel"
)
print(
    f"directional coordinate total: {aggregate_direction_count}, "
    f"aggregate rank: {aggregate_rank}"
)
print(
    f"primewise direction inequalities: {primewise_direction_checks}, "
    f"equality cases: {primewise_direction_equalities}"
)
print(
    f"zero-direction primes: {len(zero_direction_primes)}"
    + (
        f", values={zero_direction_primes}"
        if zero_direction_primes
        else ""
    )
)
print(
    "zero-direction primes congruent to 1 modulo 12: "
    f"{len(zero_direction_resistant_primes)}"
    + (
        f", values={zero_direction_resistant_primes}"
        if zero_direction_resistant_primes
        else ""
    )
)
print("all shell and aggregate tests through p=5000 passed")

from collections import Counter
from itertools import product
from pathlib import Path

import sympy as sp


CARRIER = tuple(product(range(3), range(3), range(2)))
IDENTITY = (0, 0, 0)


def multiply(left, right):
    a, b, epsilon = left
    c, d, delta = right
    if epsilon:
        c, d = d, c
    return ((a + c) % 3, (b + d) % 3, (epsilon + delta) % 2)


def element_order(element):
    power = IDENTITY
    for order in range(1, 19):
        power = multiply(power, element)
        if power == IDENTITY:
            return order
    raise AssertionError("element order exceeds the group cardinality")


def assert_subgroup(subset):
    subset = set(subset)
    if IDENTITY not in subset:
        raise AssertionError("subgroup candidate lacks the identity")
    for left in subset:
        for right in subset:
            if multiply(left, right) not in subset:
                raise AssertionError("subgroup candidate is not closed")


if len(set(CARRIER)) != 18:
    raise AssertionError("two-sheet phase carrier must have eighteen elements")

for left in CARRIER:
    for right in CARRIER:
        if multiply(left, right) not in CARRIER:
            raise AssertionError("two-sheet phase product is not closed")

diagonal = tuple((a, a, epsilon) for a in range(3) for epsilon in range(2))
antidiagonal = tuple(
    (a, (-a) % 3, epsilon) for a in range(3) for epsilon in range(2)
)
assert_subgroup(diagonal)
assert_subgroup(antidiagonal)

diagonal_orders = Counter(element_order(element) for element in diagonal)
antidiagonal_orders = Counter(element_order(element) for element in antidiagonal)
if diagonal_orders != Counter({6: 2, 3: 2, 2: 1, 1: 1}):
    raise AssertionError(f"diagonal element orders: {diagonal_orders}")
if antidiagonal_orders != Counter({2: 3, 3: 2, 1: 1}):
    raise AssertionError(f"antidiagonal element orders: {antidiagonal_orders}")
if element_order((1, 1, 1)) != 6:
    raise AssertionError("diagonal coupling lacks its order-six element")

# Exact symbolic verification of the block-square identity.
a11, a12, a21, a22, a31, a32 = sp.symbols(
    "a11 a12 a21 a22 a31 a32", real=True
)
A = sp.Matrix(((a11, a12), (a21, a22), (a31, a32)))
zero_2 = sp.zeros(2, 2)
zero_3 = sp.zeros(3, 3)
D = zero_2.row_join(A.T).col_join(A.row_join(zero_3))
expected_square = (
    (A.T * A).row_join(sp.zeros(2, 3))
    .col_join(sp.zeros(3, 2).row_join(A * A.T))
)
if D.T != D:
    raise AssertionError("coupling operator is not self-adjoint")
if sp.simplify(D * D - expected_square) != sp.zeros(5, 5):
    raise AssertionError("coupling square differs from the two Gram blocks")

x1, x2, y1, y2, y3 = sp.symbols("x1 x2 y1 y2 y3", real=True)
x = sp.Matrix((x1, x2))
y = sp.Matrix((y1, y2, y3))
vector = x.col_join(y)
quadratic = sp.expand((vector.T * expected_square * vector)[0])
gram_sum = sp.expand((A * x).dot(A * x) + (A.T * y).dot(A.T * y))
if sp.simplify(quadratic - gram_sum) != 0:
    raise AssertionError("positive quadratic identity failed")

# Exact order-three intertwining example in the Euclidean colour plane.
alpha, beta = sp.symbols("alpha beta", real=True)
sqrt3 = sp.sqrt(3)
rotation = sp.Matrix(
    ((-sp.Rational(1, 2), -sqrt3 / 2), (sqrt3 / 2, -sp.Rational(1, 2)))
)
intertwiner = alpha * sp.eye(2) + beta * rotation
if sp.simplify(rotation**3 - sp.eye(2)) != sp.zeros(2, 2):
    raise AssertionError("colour-plane rotation is not order three")
if sp.simplify(rotation * intertwiner - intertwiner * rotation) != sp.zeros(2, 2):
    raise AssertionError("order-three intertwining relation failed")
coupling = sp.zeros(4, 4)
coupling[:2, 2:] = intertwiner.T
coupling[2:, :2] = intertwiner
phase = sp.diag(rotation, rotation)
if sp.simplify(coupling * phase - phase * coupling) != sp.zeros(4, 4):
    raise AssertionError("coupling operator does not commute with phase rotation")

preprint = (
    Path(__file__).resolve().parents[1] / "es_fable_c123_preprint.tex"
).read_text(encoding="utf-8")
required_fragments = (
    r"\label{cor:two-sheet-C3-phase-group}",
    r"\label{eq:two-sheet-C3-product}",
    r"\label{eq:two-sheet-diagonal-C6}",
    r"\label{eq:two-sheet-antidiagonal-D3}",
    r"\label{lem:two-sheet-coupling-positivity}",
    r"\label{eq:two-sheet-C3-intertwiner}",
    r"\label{eq:two-sheet-coupling-square}",
    r"\label{rem:Narain-two-sheet-C3-test}",
)
for fragment in required_fragments:
    if fragment not in preprint:
        raise AssertionError(f"missing manuscript fragment: {fragment}")

print(
    "\n".join(
        (
            "PASS: exact two-sheet C3 coupling calculation",
            "full exchanged-sheet group has 18 elements",
            "diagonal six-state subgroup = C6 with two order-six elements",
            "antidiagonal six-state subgroup = D3 with element orders 1^1, 2^3, 3^2",
            "symbolic coupling square = diag(A^*A, AA^*) and its quadratic form is nonnegative",
            "exact order-three Euclidean phase intertwiner commutes with the coupling operator",
        )
    )
)

#!/usr/bin/env python3
"""Exact certificate for the equalizer-to-directed-split-pair morphism."""

from fractions import Fraction as Q
import sympy as sp


def require(label, assertion):
    if not assertion:
        raise AssertionError(label)
    print(f"{label}: PASS")


ZERO2 = ((Q(0), Q(0)), (Q(0), Q(0)))
E11 = ((Q(1), Q(0)), (Q(0), Q(0)))
E21 = ((Q(0), Q(0)), (Q(1), Q(0)))
E22 = ((Q(0), Q(0)), (Q(0), Q(1)))


def scalar_matrix(a, matrix):
    return tuple(tuple(a * entry for entry in row) for row in matrix)


def transpose(matrix):
    return tuple(zip(*matrix))


def multiply(left, right):
    return tuple(
        tuple(
            sum(left[i][k] * right[k][j] for k in range(2))
            for j in range(2)
        )
        for i in range(2)
    )


def split_pair_21(a):
    return scalar_matrix(a, E21), E21


def zeta_sheet(u):
    q = Q(-1, 2)
    return (1 + u) * q - u


def stone_defect(u):
    return -u * (1 + u)


def equalizer_split_pair(u):
    w = stone_defect(u)
    return split_pair_21(-w)


def fable(point):
    x, y, z = point
    unit = 1 + x * y
    return (
        unit**3 * z + y**2 * unit * (4 + 3 * x * y),
        y + 3 * x * unit**2 * z + 3 * x * y**2 * (4 + 3 * x * y),
        2 * x - 3 * x**2 * y - x**3 * z,
    )


q = Q(-1, 2)


def endpoint_cycle(a):
    return -Q(1) / (a + 1)


require("endpoint cycle 1 to q", endpoint_cycle(Q(1)) == q)
require("endpoint cycle q to reciprocal", endpoint_cycle(q) == q ** -1)
require("endpoint cycle reciprocal to 1", endpoint_cycle(q ** -1) == Q(1))
require(
    "directed endpoint cycle retains E21",
    tuple(split_pair_21(a) for a in (Q(1), q, q ** -1))
    == (
        (E21, E21),
        split_pair_21(q),
        split_pair_21(q ** -1),
    ),
)
require("twisted spectral endpoint value", q ** -1 * q == Q(1))

branches = (
    (Q(-1, 2), Q(1, 4), Q(-1, 4)),
    (Q(1), Q(-2), Q(2)),
)

for u, w, amplitude in branches:
    require(f"equalizer at u={u}", zeta_sheet(u) == stone_defect(u) == w)
    require(
        f"full split pair at u={u}",
        equalizer_split_pair(u) == split_pair_21(amplitude),
    )

require(
    "zero-amplitude E21 fibre point retains E21",
    split_pair_21(Q(0)) == (ZERO2, E21)
    and split_pair_21(Q(0)) != (ZERO2, ZERO2),
)
require("Boolean source support", multiply(transpose(E21), E21) == E11)
require("Boolean range support", multiply(E21, transpose(E21)) == E22)

p0 = (Q(0), Q(0), Q(-1, 4))
p_plus = (Q(1), Q(-3, 2), Q(13, 2))
p_minus = (Q(-1), Q(3, 2), Q(13, 2))
common_target = (Q(-1, 4), Q(0), Q(0))
for point in (p0, p_plus, p_minus):
    require(f"Fable collision at {point}", fable(point) == common_target)

x, y, z = sp.symbols("x y z")
unit = 1 + x * y
F = sp.Matrix(
    [
        unit**3 * z + y**2 * unit * (4 + 3 * x * y),
        y + 3 * x * unit**2 * z + 3 * x * y**2 * (4 + 3 * x * y),
        2 * x - 3 * x**2 * y - x**3 * z,
    ]
)
det_jf = sp.expand(F.jacobian((x, y, z)).det())
require("Fable Jacobian", det_jf == -2)

for n in range(1, 13):
    trivial_zero_coordinate = -2 * n
    collision_coordinate = Q(-n, 4)
    pair = split_pair_21(Q(-trivial_zero_coordinate))
    zeta_prime = (
        (-1) ** n
        * sp.factorial(2 * n)
        * sp.zeta(2 * n + 1)
        / (2 * (2 * sp.pi) ** (2 * n))
    )
    require(
        f"trivial zero -2*{n} reaches directed amplitude 2*{n}",
        pair == split_pair_21(Q(2 * n)),
    )
    require(
        f"Jacobian and collision coordinates at dilation {n}",
        -Q(-2 * n) == Q(2 * n)
        and -8 * collision_coordinate == Q(2 * n),
    )
    require(
        f"joint zeta-blade value at -2*{n}",
        (split_pair_21(sp.zeta(-2 * n)), pair)
        == (split_pair_21(Q(0)), split_pair_21(Q(2 * n))),
    )
    epsilon = sp.Symbol(f"epsilon_{n}")
    joint_jet = (
        split_pair_21(zeta_prime * epsilon),
        split_pair_21(Q(2 * n) - epsilon),
    )
    require(
        f"joint zeta-blade tangent at -2*{n}",
        joint_jet[0][0] == scalar_matrix(zeta_prime * epsilon, E21)
        and joint_jet[0][1] == E21
        and joint_jet[1][0]
        == scalar_matrix(Q(2 * n) - epsilon, E21)
        and joint_jet[1][1] == E21
        and sp.diff(joint_jet[0][0][1][0], epsilon) == zeta_prime
        and sp.diff(joint_jet[1][0][1][0], epsilon) == -1
        and zeta_prime.is_zero is False,
    )

s = sp.symbols("s")
zeta_functional_equation = (
    2**s
    * sp.pi ** (s - 1)
    * sp.sin(sp.pi * s / 2)
    * sp.gamma(1 - s)
    * sp.zeta(1 - s)
)
for n in range(1, 7):
    functional_equation_jet = sp.simplify(
        sp.limit(zeta_functional_equation / (s + 2 * n), s, -2 * n)
    )
    expected_jet = (
        (-1) ** n
        * sp.factorial(2 * n)
        * sp.zeta(2 * n + 1)
        / (2 * (2 * sp.pi) ** (2 * n))
    )
    require(
        f"functional-equation jet at -2*{n}",
        sp.simplify(functional_equation_jet - expected_jet) == 0,
    )

require("zeta endpoint reciprocal", q ** -1 == -2)
require("zeta at -2", sp.zeta(-2) == 0)
require(
    "zeta endpoint is zero-amplitude E21 fibre point",
    split_pair_21(Q(sp.zeta(-2))) == (ZERO2, E21),
)
zeta_prime_minus_two = -sp.zeta(3) / (4 * sp.pi**2)
require("zeta first jet at -2 is nonzero", zeta_prime_minus_two.is_zero is False)
print("equalizer-to-directed-full-split-pair morphism: PASS")

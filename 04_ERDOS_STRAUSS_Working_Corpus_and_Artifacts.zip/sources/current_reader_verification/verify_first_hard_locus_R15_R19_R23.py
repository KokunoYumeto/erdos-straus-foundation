#!/usr/bin/env python3
"""Exact continuation of the R=7/R=11 hard locus through R=15,19,23."""

from __future__ import annotations

from collections import Counter
from fractions import Fraction
from math import gcd, isqrt


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n) + 1, 2))


def factorization(n: int) -> dict[int, int]:
    factors: dict[int, int] = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d += 1
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def divisors(n: int) -> list[int]:
    values = [1]
    for prime, exponent in factorization(n).items():
        powers = [prime**e for e in range(exponent + 1)]
        values = [value * power for value in values for power in powers]
    return sorted(values)


def shell_count(residual: int, a: int) -> int:
    exterior = sum(
        1 for u in divisors(a * a) if (4 * u + 1) % residual == 0
    )
    middle = sum(
        1
        for x in divisors(a)
        for y in divisors(a)
        if gcd(x, y) == 1
        and a % (x * y) == 0
        and (x + y) % residual == 0
    )
    assert middle % 2 == 0
    return exterior + middle // 2


def discrete_log(value: int, modulus: int, generator: int) -> int:
    current = 1
    for exponent in range(modulus - 1):
        if current == value % modulus:
            return exponent
        current = current * generator % modulus
    raise AssertionError((value, modulus, generator))


def log_multiset(n: int, modulus: int, generator: int) -> tuple[int, ...]:
    logs: list[int] = []
    for prime, exponent in factorization(n).items():
        logs.extend([discrete_log(prime, modulus, generator)] * exponent)
    return tuple(sorted(logs))


def reachability(
    logs: tuple[int, ...], coefficients: tuple[int, ...], modulus: int
) -> set[int]:
    reached = {0}
    for value in logs:
        reached = {
            (old + coefficient * value) % modulus
            for old in reached
            for coefficient in coefficients
        }
    return reached


def r15_occupied(a: int) -> bool:
    valuations = Counter(
        prime % 15
        for prime, exponent in factorization(a).items()
        for _ in range(exponent)
    )
    return (
        valuations[11] + valuations[14] > 0
        or (valuations[2] + valuations[8])
        * (valuations[7] + valuations[13])
        > 0
    )


def r19_occupied(a: int) -> bool:
    logs = log_multiset(a, 19, 2)
    exterior = reachability(logs, (0, 1, 2), 18)
    middle = reachability(logs, (-1, 0, 1), 18)
    return 7 in exterior or 9 in middle


def r23_occupied(b: int) -> bool:
    logs = log_multiset(b, 23, 5)
    exterior = reachability(logs, (0, 1, 2), 22)
    middle = reachability(logs, (-1, 0, 1), 22)
    return bool(exterior & {7, 13, 19} or middle & {5, 11, 17})


def main() -> None:
    p = 1201
    k = 50
    c7 = 151
    d11 = 101
    assert p == 24 * k + 1
    assert c7 == 3 * k + 1
    assert d11 == 2 * k + 1

    a15 = (p + 15) // 4
    a19 = (p + 19) // 4
    b23 = (p + 23) // 12
    a23 = 3 * b23
    assert (a15, a19, b23, a23) == (304, 305, 102, 306)
    assert a15 == 2 * (c7 + 1)
    assert a19 == 2 * c7 + 3 == 3 * d11 + 2
    assert b23 == d11 + 1
    assert a23 == 3 * (d11 + 1)
    assert factorization(a15) == {2: 4, 19: 1}
    assert factorization(a19) == {5: 1, 61: 1}
    assert factorization(b23) == {2: 1, 3: 1, 17: 1}

    assert log_multiset(a19, 19, 2) == (2, 16)
    assert log_multiset(b23, 23, 5) == (2, 7, 16)
    assert not r15_occupied(a15)
    assert not r19_occupied(a19)
    assert r23_occupied(b23)
    assert (
        shell_count(15, a15),
        shell_count(19, a19),
        shell_count(23, a23),
    ) == (0, 0, 3)

    exterior_23 = [
        u for u in divisors(a23 * a23) if (4 * u + 1) % 23 == 0
    ]
    middle_23 = [
        (x, y)
        for x in divisors(a23)
        for y in divisors(a23)
        if gcd(x, y) == 1
        and a23 % (x * y) == 0
        and (x + y) % 23 == 0
    ]
    assert exterior_23 == [17, 2754]
    assert middle_23 == [(6, 17), (17, 6)]

    witness = 17
    common = (a23 + p * witness) // 23
    y = p * common
    z = a23 * common // witness
    assert (common, y, z) == (901, 1082101, 16218)
    assert Fraction(4, p) == Fraction(1, a23) + Fraction(1, y) + Fraction(1, z)

    hard_rows: list[tuple[int, int, int, int]] = []
    for prime in range(2, 20001):
        if prime % 24 != 1 or not is_prime(prime):
            continue
        c = (prime + 7) // 8
        d = (prime + 11) // 12
        if shell_count(7, 2 * c) or shell_count(11, 3 * d):
            continue

        aa15 = (prime + 15) // 4
        aa19 = (prime + 19) // 4
        bb23 = (prime + 23) // 12
        aa23 = 3 * bb23
        q15 = shell_count(15, aa15)
        q19 = shell_count(19, aa19)
        q23 = shell_count(23, aa23)
        assert (q15 > 0) == r15_occupied(aa15)
        assert (q19 > 0) == r19_occupied(aa19)
        assert (q23 > 0) == r23_occupied(bb23)
        hard_rows.append((prime, q15, q19, q23))

    assert len(hard_rows) == 28
    patterns = Counter(
        "".join("1" if q > 0 else "0" for q in row[1:])
        for row in hard_rows
    )
    assert patterns == {
        "101": 15,
        "001": 3,
        "010": 3,
        "000": 2,
        "111": 2,
        "011": 2,
        "110": 1,
    }
    unresolved = [prime for prime, q15, q19, q23 in hard_rows if not (q15 or q19 or q23)]
    assert unresolved == [3361, 8089]

    tail_expectations = {
        3361: {
            "empty": [(27, 847), (31, 848), (35, 849)],
            "occupied": (39, 850, 3),
            "exterior": [68, 42500],
            "middle": [(5, 34), (34, 5)],
            "witness": (68, 5882, 19769402, 73525),
        },
        8089: {
            "empty": [(27, 2029)],
            "occupied": (31, 2030, 4),
            "exterior": [116, 1015],
            "middle": [(2, 29), (29, 2), (35, 58), (58, 35)],
            "witness": (116, 30334, 245371726, 530845),
        },
    }
    for prime, expected in tail_expectations.items():
        for residual, denominator in expected["empty"]:
            assert denominator == (prime + residual) // 4
            assert shell_count(residual, denominator) == 0

        residual, denominator, count = expected["occupied"]
        assert denominator == (prime + residual) // 4
        exterior = [
            u
            for u in divisors(denominator * denominator)
            if (4 * u + 1) % residual == 0
        ]
        middle = [
            (x, y)
            for x in divisors(denominator)
            for y in divisors(denominator)
            if gcd(x, y) == 1
            and denominator % (x * y) == 0
            and (x + y) % residual == 0
        ]
        assert exterior == expected["exterior"]
        assert middle == expected["middle"]
        assert shell_count(residual, denominator) == count

        witness, common, y, z = expected["witness"]
        assert denominator + prime * witness == residual * common
        assert y == prime * common
        assert z == denominator * common // witness
        assert Fraction(4, prime) == (
            Fraction(1, denominator) + Fraction(1, y) + Fraction(1, z)
        )

    print("PASS: first R=7/R=11 hard point through R=15,19,23")
    print("p=1201 shell counts (R15,R19,R23): (0, 0, 3)")
    print("p=1201 R23 exterior divisors:", exterior_23)
    print("p=1201 R23 middle pairs:", middle_23)
    print("p=1201 decomposition: 4/1201 = 1/306 + 1/1082101 + 1/16218")
    print("R7/R11 double survivors below 20000:", len(hard_rows))
    print("R15/R19/R23 occupancy patterns:", dict(sorted(patterns.items())))
    print("empty through R23:", unresolved)
    print(
        "p=3361 tail: R27=R31=R35=0, R39=3; "
        "4/3361 = 1/850 + 1/19769402 + 1/73525"
    )
    print(
        "p=8089 tail: R27=0, R31=4; "
        "4/8089 = 1/2030 + 1/245371726 + 1/530845"
    )
    print("all 28 finite hard-locus points occupied by a shell R <= 39")


if __name__ == "__main__":
    main()

from sympy import Matrix, Rational, diag, simplify, sqrt


def compose(left, right):
    return tuple(left[right[index]] for index in range(4))


identity = (0, 1, 2, 3)
rho = (0, 2, 3, 1)
sigma = (0, 1, 3, 2)
rho_inverse = compose(rho, rho)

assert compose(rho, compose(rho, rho)) == identity
assert compose(sigma, sigma) == identity
assert compose(sigma, compose(rho, sigma)) == rho_inverse

root_three = sqrt(3)
v_star = Matrix([0, 0, 1, 0])
v_zero = Matrix([2, 2, 0, 2])
v_plus = Matrix([2 + root_three, -1, 0, 2 - root_three])
v_minus = Matrix([2 - root_three, -1, 0, 2 + root_three])
vertices = (v_star, v_zero, v_plus, v_minus)

rotation = Matrix(
    [
        [Rational(1, 4), root_three / 2, 0, Rational(3, 4)],
        [-root_three / 4, Rational(-1, 2), 0, root_three / 4],
        [0, 0, 1, 0],
        [Rational(3, 4), -root_three / 2, 0, Rational(1, 4)],
    ]
)
reflection = Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
quarter_reflection = diag(1, 1, -1, 1)

for index in range(4):
    assert (rotation * vertices[index] - vertices[rho[index]]).applyfunc(
        simplify
    ) == Matrix.zeros(4, 1)
    assert (reflection * vertices[index] - vertices[sigma[index]]).applyfunc(
        simplify
    ) == Matrix.zeros(4, 1)

for index in range(4):
    sign = -1 if index == 0 else 1
    assert (
        quarter_reflection * vertices[index] - sign * vertices[index]
    ).applyfunc(simplify) == Matrix.zeros(4, 1)

weights = (0, 1, 1, 1)
assert weights[rho[0]] == 0
assert tuple(weights[index] for index in range(4)) == (0, 1, 1, 1)

phi = Matrix(
    [
        [Rational(5, 8), 0, Rational(3, 4), Rational(5, 8)],
        [0, 1, 0, 0],
        [Rational(3, 8), 0, Rational(5, 4), Rational(3, 8)],
        [Rational(1, 2), 0, 0, Rational(-1, 2)],
    ]
)

face_barycentre = (v_zero + v_plus + v_minus) / 3
z_face = phi * face_barycentre
z_apex = phi * v_star
spatial_difference = Matrix(
    [
        z_face[1] - z_apex[1],
        z_face[2] - z_apex[2],
        z_face[3] - z_apex[3],
    ]
).applyfunc(simplify)
assert spatial_difference == Matrix([0, Rational(1, 4), 0])

print("PASS: exceptional C4 to Fable tetrahedron intertwiner")
print("the pointed C4 permutations satisfy the D3 relations")
print("all four arithmetic labels intertwine with the Fable vertex action")
print("the missing antipode maps to the unique negative-quarter apex")
print("the three supported classes map with equal mass to the opposite face")
print("the supported barycentre minus the apex is exactly (0,1/4,0)")

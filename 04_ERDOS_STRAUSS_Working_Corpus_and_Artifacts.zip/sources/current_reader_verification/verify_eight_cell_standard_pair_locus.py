from sympy import I, Matrix, Rational, eye, kronecker_product, sqrt


def require_matrix_equal(left, right, message):
    difference = left - right
    if any(entry.expand() != 0 for entry in difference):
        raise AssertionError(f"{message}\n{difference}")


# The four-cell orbit and crossed mirror used by the maintained manuscript.
C_3 = Matrix([[0, 1, 0], [0, 0, 1], [1, 0, 0]])
S_3 = Matrix([[0, 1, 0], [1, 0, 0], [0, 0, 1]])
P_R = Matrix.diag(Matrix([[1]]), S_3)
X_2 = Matrix([[0, 1], [1, 0]])
Z_2 = Matrix([[1, 0], [0, -1]])
J_8 = kronecker_product(X_2, P_R)

A_3 = (C_3 - C_3**-1) / (I * sqrt(3))
A_4 = Matrix.diag(Matrix([[0]]), A_3)
K_phase = kronecker_product(Z_2, A_4)

# A finite-dimensional cyclic-and-separating representation of
# direct-sum matrix blocks has dimension sum(n_j^2).  In dimension eight,
# the only square partitions are recorded below.  Each M_n block supplies
# at least n unit eigenvalues to its modular operator.
square_partitions = []
for number_of_twos in range(3):
    for number_of_ones in range(9):
        if 4 * number_of_twos + number_of_ones == 8:
            forced_unit_multiplicity = 2 * number_of_twos + number_of_ones
            square_partitions.append(
                (number_of_twos, number_of_ones, forced_unit_multiplicity)
            )

expected_partitions = [(0, 8, 8), (1, 4, 6), (2, 0, 4)]
if square_partitions != expected_partitions:
    raise AssertionError(f"unexpected square partitions: {square_partitions}")

# The logarithmic eigenvalues of K_8(s,t).
# For s != 0, at most one of t=s and t=-s can hold, so zero has
# multiplicity at most two.  On s=0 the multiplicity is four for t != 0
# and eight at the origin.
def zero_multiplicity(s_value, t_value):
    exponents = [
        s_value,
        s_value,
        -s_value,
        -s_value,
        s_value + t_value,
        s_value - t_value,
        -s_value - t_value,
        -s_value + t_value,
    ]
    return sum(value == 0 for value in exponents)


if zero_multiplicity(0, 7) != 4:
    raise AssertionError("the nonzero s=0 locus does not have four unit modes")
if zero_multiplicity(0, 0) != 8:
    raise AssertionError("the origin does not have eight unit modes")
if zero_multiplicity(7, 7) != 2 or zero_multiplicity(7, -7) != 2:
    raise AssertionError("the two exceptional s != 0 lines are miscounted")
if zero_multiplicity(7, 3) != 0:
    raise AssertionError("a generic s != 0 point unexpectedly has a unit mode")

# Construct an explicit unitary from the eight-cell carrier to
# HS(M_2) direct-sum HS(M_2) on the surviving line s=0.
omega = (-1 + I * sqrt(3)) / 2
omega_squared = (-1 - I * sqrt(3)) / 2
e_plus = Matrix([1, 0])
e_minus = Matrix([0, 1])
f = Matrix([1, 0, 0, 0])
v_zero = Matrix([0, 1, 1, 1]) / sqrt(3)
v_plus = Matrix([0, 1, omega, omega_squared]) / sqrt(3)
v_minus = Matrix([0, 1, omega_squared, omega]) / sqrt(3)


def tensor(left, right):
    return kronecker_product(left, right)


z_f_plus = (tensor(e_plus, f) + tensor(e_minus, f)) / sqrt(2)
z_f_minus = I * (tensor(e_plus, f) - tensor(e_minus, f)) / sqrt(2)
z_v_plus = (tensor(e_plus, v_zero) + tensor(e_minus, v_zero)) / sqrt(2)
z_v_minus = I * (tensor(e_plus, v_zero) - tensor(e_minus, v_zero)) / sqrt(2)

p_1 = tensor(e_plus, v_plus)
m_1 = omega_squared * tensor(e_minus, v_plus)
p_2 = tensor(e_minus, v_minus)
m_2 = omega * tensor(e_plus, v_minus)

# Columns are the source vectors corresponding, in each M_2 block, to
# E_11, E_12, E_21, E_22.
Q = Matrix.hstack(
    z_f_plus,
    p_1,
    m_1,
    z_f_minus,
    z_v_plus,
    p_2,
    m_2,
    z_v_minus,
)
require_matrix_equal(Q.H * Q, eye(8), "the displayed intertwiner is not unitary")

K_HS = Matrix.diag(0, 1, -1, 0, 0, 1, -1, 0)
require_matrix_equal(
    Q.H * K_phase * Q,
    K_HS,
    "the eight-cell phase generator does not become two HS(M_2) blocks",
)

J_4 = Matrix([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
J_HS = Matrix.diag(J_4, J_4)
require_matrix_equal(
    Q.H * J_8 * Q.conjugate(),
    J_HS,
    "the crossed antiunitary does not become adjunction on both HS blocks",
)

# The two identical density matrices have logarithms
# diag(t/2,-t/2); left-minus-right multiplication gives K_HS.
H_2 = Matrix.diag(Rational(1, 2), Rational(-1, 2))
K_one_block = Matrix.diag(
    H_2[0, 0] - H_2[0, 0],
    H_2[0, 0] - H_2[1, 1],
    H_2[1, 1] - H_2[0, 0],
    H_2[1, 1] - H_2[1, 1],
)
require_matrix_equal(
    Matrix.diag(K_one_block, K_one_block),
    K_HS,
    "the Hilbert--Schmidt modular generator is incorrect",
)

print("PASS: exact standard-pair locus of the eight-cell spectral family")
print("every eight-dimensional finite standard pair has at least four unit modes")
print("Delta_8(s,t) has at most two unit modes when s is nonzero")
print("therefore the full finite standard-pair locus is contained in s=0")
print("on s=0 an explicit unitary gives HS(M2) direct-sum HS(M2)")
print("the crossed antiunitary becomes matrix adjunction in both blocks")
print("the phase generator becomes two identical modular commutator generators")

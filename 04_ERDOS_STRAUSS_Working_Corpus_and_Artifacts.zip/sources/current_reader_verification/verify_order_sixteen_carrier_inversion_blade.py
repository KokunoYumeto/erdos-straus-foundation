#!/usr/bin/env python3
"""Exact inversion, mixer blocks, and deficit conservation on the order-16 carriers."""

from __future__ import annotations

from fractions import Fraction

from verify_order_sixteen_four_sheet_carrier import CARRIERS


Matrix2 = tuple[tuple[Fraction, Fraction], tuple[Fraction, Fraction]]


def matrix_add(left: Matrix2, right: Matrix2) -> Matrix2:
    return tuple(
        tuple(left[row][column] + right[row][column] for column in range(2))
        for row in range(2)
    )  # type: ignore[return-value]


def matrix_scale(scalar: Fraction, matrix: Matrix2) -> Matrix2:
    return tuple(
        tuple(scalar * matrix[row][column] for column in range(2))
        for row in range(2)
    )  # type: ignore[return-value]


def matrix_multiply(left: Matrix2, right: Matrix2) -> Matrix2:
    return tuple(
        tuple(
            sum(
                (left[row][index] * right[index][column] for index in range(2)),
                Fraction(0),
            )
            for column in range(2)
        )
        for row in range(2)
    )  # type: ignore[return-value]


def matrix_transpose(matrix: Matrix2) -> Matrix2:
    return tuple(
        tuple(matrix[column][row] for column in range(2))
        for row in range(2)
    )  # type: ignore[return-value]


I2: Matrix2 = (
    (Fraction(1), Fraction(0)),
    (Fraction(0), Fraction(1)),
)
S2: Matrix2 = (
    (Fraction(0), Fraction(1)),
    (Fraction(1), Fraction(0)),
)
P_PLUS = matrix_scale(Fraction(1, 2), matrix_add(I2, S2))
P_MINUS = matrix_scale(Fraction(1, 2), matrix_add(I2, matrix_scale(-1, S2)))
B_MINUS_PLUS: Matrix2 = (
    (Fraction(1, 2), Fraction(1, 2)),
    (Fraction(-1, 2), Fraction(-1, 2)),
)
B_PLUS_MINUS: Matrix2 = matrix_transpose(B_MINUS_PLUS)


def verify_mixer_block() -> None:
    assert matrix_multiply(S2, S2) == I2
    assert matrix_multiply(P_PLUS, P_PLUS) == P_PLUS
    assert matrix_multiply(P_MINUS, P_MINUS) == P_MINUS
    assert matrix_multiply(P_PLUS, P_MINUS) == matrix_scale(0, I2)
    assert matrix_multiply(matrix_transpose(B_MINUS_PLUS), B_MINUS_PLUS) == P_PLUS
    assert matrix_multiply(B_MINUS_PLUS, matrix_transpose(B_MINUS_PLUS)) == P_MINUS
    assert matrix_multiply(matrix_transpose(B_PLUS_MINUS), B_PLUS_MINUS) == P_MINUS
    assert matrix_multiply(B_PLUS_MINUS, matrix_transpose(B_PLUS_MINUS)) == P_PLUS
    assert (
        matrix_multiply(P_MINUS, matrix_multiply(B_MINUS_PLUS, P_PLUS))
        == B_MINUS_PLUS
    )
    assert (
        matrix_multiply(P_PLUS, matrix_multiply(B_PLUS_MINUS, P_MINUS))
        == B_PLUS_MINUS
    )


def flatten(sheet: tuple[int, ...], cell: int) -> tuple[int, ...]:
    return (*sheet, cell)


def negate_group_element(
    moduli: tuple[int, ...],
    element: tuple[int, ...],
) -> tuple[int, ...]:
    return tuple((-coordinate) % modulus for coordinate, modulus in zip(element, moduli))


def sheet_inverse(carrier, sheet: tuple[int, ...]) -> tuple[int, ...]:
    zero = carrier.sheets[0]
    answers = [
        candidate
        for candidate in carrier.sheets
        if carrier.sheet_add(sheet, candidate) == zero
        and carrier.sheet_add(candidate, sheet) == zero
    ]
    assert len(answers) == 1
    return answers[0]


def carrier_inverse(
    carrier,
    coordinate: tuple[tuple[int, ...], int],
) -> tuple[tuple[int, ...], int]:
    sheet, cell = coordinate
    opposite_sheet = sheet_inverse(carrier, sheet)
    carry = carrier.cocycle(sheet, opposite_sheet)
    return opposite_sheet, (-cell - carry) % 4


EXPECTED_FULL_FIXED = {
    "C16": frozenset({(0, 0), (0, 2)}),
    "C8xC2": frozenset(
        {
            (0, 0, 0),
            (0, 0, 2),
            (0, 1, 0),
            (0, 1, 2),
        }
    ),
    "C4xC4": frozenset({(0, 0), (0, 2), (2, 0), (2, 2)}),
    "C4xC2xC2": frozenset(
        (first, second, cell)
        for first in range(2)
        for second in range(2)
        for cell in (0, 2)
    ),
}

EXPECTED_MINIMUM_FIXED = {
    "C16": frozenset({(0, 0)}),
    "C8xC2": frozenset({(0, 0, 0), (0, 1, 0)}),
    "C4xC4": frozenset({(0, 0)}),
    "C4xC2xC2": frozenset(
        (first, second, 0)
        for first in range(2)
        for second in range(2)
    ),
}

EXPECTED_FULL_SPECTRUM = {
    "C16": (9, 7),
    "C8xC2": (10, 6),
    "C4xC4": (10, 6),
    "C4xC2xC2": (12, 4),
}

EXPECTED_MINIMUM_SPECTRUM = {
    "C16": (2, 1),
    "C8xC2": (4, 2),
    "C4xC4": (5, 4),
    "C4xC2xC2": (8, 4),
}


def inversion_orbits(carrier, coordinates):
    remaining = set(coordinates)
    fixed = set()
    pairs = set()
    while remaining:
        point = min(remaining, key=lambda item: flatten(*item))
        opposite = carrier_inverse(carrier, point)
        assert opposite in coordinates
        if opposite == point:
            fixed.add(point)
            remaining.remove(point)
        else:
            ordered_pair = tuple(
                sorted((point, opposite), key=lambda item: flatten(*item))
            )
            pairs.add(ordered_pair)
            remaining.remove(point)
            remaining.remove(opposite)
    return frozenset(fixed), frozenset(pairs)


def verify_carrier_inversion(carrier) -> dict[str, object]:
    inverse_coordinates = carrier.coordinates()
    all_coordinates = frozenset(inverse_coordinates.values())

    for coordinate in all_coordinates:
        opposite = carrier_inverse(carrier, coordinate)
        assert carrier_inverse(carrier, opposite) == coordinate
        assert carrier.phi(*opposite) == negate_group_element(
            carrier.moduli,
            carrier.phi(*coordinate),
        )

    full_fixed, full_pairs = inversion_orbits(carrier, all_coordinates)
    flat_full_fixed = frozenset(flatten(*coordinate) for coordinate in full_fixed)
    assert flat_full_fixed == EXPECTED_FULL_FIXED[carrier.name]
    full_spectrum = (len(full_fixed) + len(full_pairs), len(full_pairs))
    assert full_spectrum == EXPECTED_FULL_SPECTRUM[carrier.name]

    minimum_coordinates = frozenset(
        inverse_coordinates[element] for element in carrier.minimum_support
    )
    assert frozenset(
        carrier_inverse(carrier, coordinate) for coordinate in minimum_coordinates
    ) == minimum_coordinates
    minimum_fixed, minimum_pairs = inversion_orbits(carrier, minimum_coordinates)
    flat_minimum_fixed = frozenset(
        flatten(*coordinate) for coordinate in minimum_fixed
    )
    assert flat_minimum_fixed == EXPECTED_MINIMUM_FIXED[carrier.name]
    minimum_spectrum = (
        len(minimum_fixed) + len(minimum_pairs),
        len(minimum_pairs),
    )
    assert minimum_spectrum == EXPECTED_MINIMUM_SPECTRUM[carrier.name]
    assert carrier.expected_correlation_defect + len(minimum_pairs) == 4

    for pair in minimum_pairs:
        first, second = pair
        assert carrier_inverse(carrier, first) == second
        assert carrier_inverse(carrier, second) == first

    return {
        "full_fixed": tuple(sorted(flat_full_fixed)),
        "full_spectrum": full_spectrum,
        "minimum_fixed": tuple(sorted(flat_minimum_fixed)),
        "minimum_spectrum": minimum_spectrum,
        "blade_blocks": len(minimum_pairs),
        "defect": carrier.expected_correlation_defect,
    }


def main() -> None:
    verify_mixer_block()
    for carrier in CARRIERS:
        result = verify_carrier_inversion(carrier)
        print(
            f"{carrier.name}: inversion_fixed={result['full_fixed']}, "
            f"full_spectrum={result['full_spectrum']}, "
            f"minimum_fixed={result['minimum_fixed']}, "
            f"minimum_spectrum={result['minimum_spectrum']}"
        )
        print(
            f"{carrier.name}: blade_blocks={result['blade_blocks']}, "
            f"correlation_defect={result['defect']}, "
            f"conserved_cell_count={result['blade_blocks'] + result['defect']}"
        )
    print("PASS: carrier inversion, mixer blocks, and deficit conservation")


if __name__ == "__main__":
    main()

from itertools import chain, combinations, product


def subsets(items):
    items = tuple(items)
    return tuple(
        frozenset(s)
        for size in range(len(items) + 1)
        for s in combinations(items, size)
    )


def add(x, y):
    return (x[0] + y[0], x[1] | y[1])


def mul(x, y):
    return (x[0] * y[0], x[1] & y[1])


def branch(i, x):
    return int(i in x[1])


def delta(items, x):
    return tuple((x[0], 1) if i in x[1] else (0, 0) for i in items)


def pair_add(x, y):
    return (x[0] + y[0], x[1] | y[1])


def pair_mul(x, y):
    return (x[0] * y[0], x[1] & y[1])


def matrix_zero(tau):
    return [[tau, tau], [tau, tau]]


def matrix_mul(a, b, tau):
    out = matrix_zero(tau)
    for i, j in product(range(2), repeat=2):
        value = tau
        for k in range(2):
            value = add(value, mul(a[i][k], b[k][j]))
        out[i][j] = value
    return out


def branch_matrix(i, a):
    return [[branch(i, a[row][col]) for col in range(2)] for row in range(2)]


def require(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


colors = ("r", "g", "b")
full = frozenset(colors)
empty = frozenset()
zero_fibre = tuple((0, a) for a in subsets(colors))
supported = tuple((r, full) for r in (-2, -1, 1, 2))
carrier = zero_fibre + supported

require(
    "power-set branches recover every support subset",
    all(frozenset(i for i in colors if branch(i, x)) == x[1] for x in carrier),
)

require(
    "diagonal-amplitude map preserves addition",
    all(
        delta(colors, add(x, y))
        == tuple(pair_add(a, b) for a, b in zip(delta(colors, x), delta(colors, y)))
        for x, y in product(carrier, repeat=2)
    ),
)

require(
    "diagonal-amplitude map preserves multiplication",
    all(
        delta(colors, mul(x, y))
        == tuple(pair_mul(a, b) for a, b in zip(delta(colors, x), delta(colors, y)))
        for x, y in product(carrier, repeat=2)
    ),
)

atoms = {c: (0, frozenset((c,))) for c in colors}
tau = (0, empty)
e = (0, full)
require("color null atoms are scalar idempotents", all(mul(x, x) == x for x in atoms.values()))
require(
    "distinct color null atoms meet at unsupportedness",
    all(mul(atoms[c], atoms[d]) == tau for c, d in combinations(colors, 2)),
)
require("three color null atoms join to the supported zero", add(add(atoms["r"], atoms["g"]), atoms["b"]) == e)

two_full = (2, full)
directed = matrix_zero(tau)
directed[1][0] = two_full
e21 = [[0, 0], [1, 0]]
require("every color branch of the directed full-support lift is E21", all(branch_matrix(c, directed) == e21 for c in colors))

for a in subsets(colors):
    z_a = matrix_zero(tau)
    z_a[1][0] = (0, a)
    expected = {c: (e21 if c in a else [[0, 0], [0, 0]]) for c in colors}
    require(
        "directed branch tuple for support " + ("empty" if not a else "".join(sorted(a))),
        all(branch_matrix(c, z_a) == expected[c] for c in colors),
    )
    require(
        "directed carrier is square-zero for support " + ("empty" if not a else "".join(sorted(a))),
        matrix_mul(z_a, z_a, tau) == matrix_zero(tau),
    )

times = ("M", "N", "T", "E")
time_full = frozenset(times)
time_atoms = {t: (0, frozenset((t,))) for t in times}
time_tau = (0, frozenset())
time_e = (0, time_full)
time_sum = time_tau
for t in times:
    time_sum = add(time_sum, time_atoms[t])
require("four Time null atoms join to the supported zero", time_sum == time_e)
require(
    "distinct Time null atoms meet at unsupportedness",
    all(mul(time_atoms[a], time_atoms[b]) == time_tau for a, b in combinations(times, 2)),
)

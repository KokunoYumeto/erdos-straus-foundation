#!/usr/bin/env python3
"""Exact two-shell checks on the prime locus p = 1 mod 24."""

from __future__ import annotations

from math import gcd, isqrt


R11_COLON_GENERATORS = [
    {7: 1},
    {8: 1},
    {10: 1},
    {6: 1, 9: 1},
    {6: 2},
    {5: 1, 6: 1},
    {4: 1, 6: 1},
    {3: 1, 6: 1},
    {2: 1, 9: 1},
    {2: 1, 5: 1},
    {2: 1, 4: 1},
    {2: 1, 3: 1},
    {2: 2},
]


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n) + 1, 2))


def factorization(n: int) -> dict[int, int]:
    factors: dict[int, int] = {}
    prime = 2
    while prime * prime <= n:
        while n % prime == 0:
            factors[prime] = factors.get(prime, 0) + 1
            n //= prime
        prime += 1
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def divisors(n: int) -> list[int]:
    values = [1]
    for prime, exponent in factorization(n).items():
        powers = [prime**e for e in range(exponent + 1)]
        values = [value * power for value in values for power in powers]
    return sorted(values)


def shell_count(residual: int, a: int) -> int:
    divisors_a = divisors(a)
    exterior = sum(
        1
        for u in divisors(a * a)
        if (4 * u + 1) % residual == 0
    )
    middle = sum(
        1
        for x in divisors_a
        for y in divisors_a
        if gcd(x, y) == 1
        and a % (x * y) == 0
        and (x + y) % residual == 0
    )
    assert middle % 2 == 0
    return exterior + middle // 2


def residue_valuations(n: int, modulus: int) -> dict[int, int]:
    values = {r: 0 for r in range(1, modulus)}
    for prime, exponent in factorization(n).items():
        values[prime % modulus] += exponent
    return values


def r7_nonresidue_factor(c7: int) -> bool:
    return any(
        prime % 7 in {3, 5, 6}
        for prime in factorization(c7)
    )


def r11_colon_contains(d11: int) -> bool:
    valuations = residue_valuations(d11, 11)
    return any(
        all(valuations[residue] >= exponent for residue, exponent in generator.items())
        for generator in R11_COLON_GENERATORS
    )


def r11_complement_branches(d11: int) -> tuple[bool, bool]:
    valuations = residue_valuations(d11, 11)
    branch_a = all(
        prime % 11 in {1, 3, 4, 5, 9}
        for prime in factorization(d11)
    )
    branch_b = (
        valuations[2] <= 1
        and valuations[6] <= 1
        and valuations[2] + valuations[6] >= 1
        and all(
            valuations[residue] == 0
            for residue in {3, 4, 5, 7, 8, 9, 10}
        )
    )
    return branch_a, branch_b


def main() -> None:
    primes = [
        p
        for p in range(2, 20001)
        if p % 24 == 1 and is_prime(p)
    ]
    double_survivors: list[tuple[int, int, int]] = []

    for p in primes:
        c7 = (p + 7) // 8
        d11 = (p + 11) // 12
        assert p == 8 * c7 - 7
        assert p == 12 * d11 - 11
        assert 3 * d11 - 2 * c7 == 1
        assert gcd(c7, d11) == 1

        q7 = shell_count(7, 2 * c7)
        q11 = shell_count(11, 3 * d11)
        assert (q7 > 0) == r7_nonresidue_factor(c7)
        assert (q11 > 0) == r11_colon_contains(d11)

        branch_a, branch_b = r11_complement_branches(d11)
        assert not (branch_a and branch_b)
        assert (q11 == 0) == (branch_a or branch_b)

        predicted_double_empty = (
            not r7_nonresidue_factor(c7)
            and (branch_a or branch_b)
        )
        assert (q7 == 0 and q11 == 0) == predicted_double_empty
        if predicted_double_empty:
            double_survivors.append((p, c7, d11))

    print("PASS: hard-locus R=7/R=11 coprime coordinate pair")
    print(f"p=1 mod 24 primes checked: {len(primes)}")
    print(f"double-empty shells: {len(double_survivors)}")
    print(
        "first double-empty triples (p,c7,d11): "
        f"{double_survivors[:12]}"
    )


if __name__ == "__main__":
    main()

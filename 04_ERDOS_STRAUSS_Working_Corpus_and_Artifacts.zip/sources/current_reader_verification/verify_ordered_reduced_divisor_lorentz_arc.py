from pathlib import Path

import sympy as sp


def zero(expr):
    return sp.cancel(sp.expand(expr)) == 0


def assert_zero(expr, label):
    if not zero(expr):
        raise AssertionError(f"{label}: {sp.factor(expr)}")


def congruence(value, modulus):
    return int(value) % int(modulus)


N, d = sp.symbols("N d", positive=True, nonzero=True)
e = N**2 / d

x = d / (N + d)
y = N / (N + d)
delta = (d - N) / (d + N)
alpha = 4 * N * d / (N + d) ** 2

assert_zero(x + y - 1, "barycentric sum")
assert_zero(x - y - delta, "ordered coordinate")
assert_zero(4 * x * y - alpha, "quotient amplitude")
assert_zero(delta**2 + alpha - 1, "delta-alpha identity")

cell = sp.Matrix([x**2, x * y, y**2])
cell_e = sp.Matrix(
    [
        (e / (N + e)) ** 2,
        e * N / (N + e) ** 2,
        (N / (N + e)) ** 2,
    ]
)
J_raw = sp.Matrix([[0, 0, 1], [0, 1, 0], [1, 0, 0]])
for i, entry in enumerate(cell_e - J_raw * cell):
    assert_zero(entry, f"raw reflection entry {i}")

fixed = sp.Matrix(
    [(2 - alpha) / 4, alpha / 4, (2 - alpha) / 4]
)
antifixed = sp.Matrix([delta / 2, 0, -delta / 2])
for i, entry in enumerate((cell + cell_e) / 2 - fixed):
    assert_zero(entry, f"fixed cell entry {i}")
for i, entry in enumerate((cell - cell_e) / 2 - antifixed):
    assert_zero(entry, f"anti-fixed cell entry {i}")
for i, entry in enumerate(J_raw * fixed - fixed):
    assert_zero(entry, f"fixed eigenspace entry {i}")
for i, entry in enumerate(J_raw * antifixed + antifixed):
    assert_zero(entry, f"anti-fixed eigenspace entry {i}")

A = (2 - alpha) / 2
B0 = delta / 2
B1 = alpha / 4
C = (2 - alpha) / 8
circle = sp.Matrix([A, B0, B1, C])
assert_zero(B0**2 + B1**2 - A * C, "circle nullity")

u = sp.Matrix([5 * (2 - alpha) / 16, delta / 2, alpha / 4, 3 * (2 - alpha) / 16])
eta = sp.diag(-1, 1, 1, 1)
assert_zero((u.T * eta * u)[0], "Lorentz nullity")
assert_zero(u[1] ** 2 + u[2] - sp.Rational(1, 4), "parabolic arc")

J_L = sp.diag(1, -1, 1, 1)
u_e = u.subs(d, e, simultaneous=True)
for i, entry in enumerate(u_e - J_L * u):
    assert_zero(entry, f"Lorentz reflection entry {i}")

kappa_cell = sp.Matrix([4, 0, 0, -4 * cell[1]])
arithmetic_circle = sp.Matrix([4, 0, 0, -alpha])
for i, entry in enumerate(kappa_cell - arithmetic_circle):
    assert_zero(entry, f"affine descent entry {i}")

branch_lorentz = sp.Matrix([2 - alpha / 2, 0, 0, 2 + alpha / 2])
B_u = sp.Matrix([2 - 2 * u[2], 0, 0, 2 + 2 * u[2]])
for i, entry in enumerate(B_u - branch_lorentz):
    assert_zero(entry, f"Lorentz descent entry {i}")

u_scale = sp.symbols("u", positive=True, nonzero=True)
alpha_u = u_scale**4
iota = sp.I
q = (1 + iota) / sp.sqrt(2)
qbar = (1 - iota) / sp.sqrt(2)
P_square = sp.Matrix([[q / 2, -qbar / 2], [q, qbar]])
D_alpha = sp.diag(u_scale, 1 / u_scale)
P_alpha = D_alpha * P_square


def action(P, H):
    Pinv = P.inv()
    return sp.simplify(Pinv.conjugate().T * H * Pinv)


H_minus_plus = sp.Matrix(
    [[0, 2 * iota * u_scale**2], [-2 * iota * u_scale**2, 0]]
)
H_plus_minus = sp.Matrix(
    [[0, 2 * u_scale**2], [2 * u_scale**2, 0]]
)
target = sp.diag(4, -alpha_u)

for i, entry in enumerate(action(P_alpha, H_minus_plus) - target):
    assert_zero(entry, f"minus-plus transport entry {i}")
for i, entry in enumerate(action(P_alpha * P_square, H_plus_minus) - target):
    assert_zero(entry, f"plus-minus transport entry {i}")
for i, entry in enumerate(action(P_square, H_plus_minus) - H_minus_plus):
    assert_zero(entry, f"ordered intermediate entry {i}")

# Exact arithmetic receipt for the displayed p=12289 certificate.
p0 = 12289
a0 = 3075
R0 = 11
N0 = p0 * a0
d0 = 61445
e0 = N0 * N0 // d0
b0 = (N0 + d0) // R0
c0 = (N0 + e0) // R0

if d0 * e0 != N0 * N0:
    raise AssertionError("12289 complement product")
if congruence(d0 + N0, R0) != 0:
    raise AssertionError("12289 first reduced congruence")
if congruence(e0 + N0, R0) != 0:
    raise AssertionError("12289 complementary reduced congruence")
if (b0, c0) != (3440920, 2116165800):
    raise AssertionError("12289 reconstructed denominators")

delta0 = sp.Rational(d0 - N0, d0 + N0)
alpha0 = sp.Rational(4 * N0 * d0, (N0 + d0) ** 2)
assert_zero(delta0**2 + alpha0 - 1, "12289 delta-alpha identity")

lines = [
    "PASS: ordered reduced-divisor Lorentz arc",
    f"symbolic raw cell = {tuple(sp.factor(v) for v in cell)}",
    f"symbolic circle coordinates = {tuple(sp.factor(v) for v in circle)}",
    f"symbolic Lorentz coordinates = {tuple(sp.factor(v) for v in u)}",
    "identity: delta^2 + alpha = 1",
    "identity: X^2 + Y = 1/4",
    "raw reflection: d <-> N^2/d exchanges E11 and E22",
    "Lorentz reflection: d <-> N^2/d reverses X only",
    "affine descent: certificate cell -> 4 E11 - alpha E22",
    "ordered transports: (-,+) and (+,-) both verified with distinct words",
    f"12289: N0={N0}, d={d0}, e={e0}",
    f"12289: b={b0}, c={c0}",
    f"12289: delta={delta0}",
    f"12289: alpha={alpha0}",
]

out = Path(__file__).with_name("verify_ordered_reduced_divisor_lorentz_arc_output.txt")
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

from sympy import Matrix, eye, sqrt


def require(label, condition):
    if condition is not True:
        raise AssertionError(label)
    print(f"{label}: PASS")


S = Matrix([[0, 1], [1, 0]])
J = Matrix([[1, 0], [0, -1]])
H = Matrix([[1, 1], [1, -1]]) / sqrt(2)
I2 = eye(2)
E12 = Matrix([[0, 1], [0, 0]])
E21 = Matrix([[0, 0], [1, 0]])

u_plus = Matrix([1, 1]) / sqrt(2)
u_minus = Matrix([1, -1]) / sqrt(2)
P_plus = (I2 + S) / 2
P_minus = (I2 - S) / 2
B_minus_plus = Matrix([[1, 1], [-1, -1]]) / 2
B_plus_minus = Matrix([[1, -1], [1, -1]]) / 2

require("Hadamard isometry", H.T * H == I2)
require("Hadamard sends J to sheet exchange", H * J * H.T == S)
require("Hadamard sends sheet exchange to J", H * S * H.T == J)
require("positive mixer projector", u_plus * u_plus.T == P_plus)
require("negative mixer projector", u_minus * u_minus.T == P_minus)
require("E21 becomes minus-plus channel", H * E21 * H.T == B_minus_plus)
require("E12 becomes plus-minus channel", H * E12 * H.T == B_plus_minus)
require("minus-plus source is P_plus", B_minus_plus.T * B_minus_plus == P_plus)
require("minus-plus range is P_minus", B_minus_plus * B_minus_plus.T == P_minus)
require("plus-minus source is P_minus", B_plus_minus.T * B_plus_minus == P_minus)
require("plus-minus range is P_plus", B_plus_minus * B_plus_minus.T == P_plus)
require("minus-plus corner", P_minus * B_minus_plus * P_plus == B_minus_plus)
require("plus-minus corner", P_plus * B_plus_minus * P_minus == B_plus_minus)
require("minus-plus output sign", S * B_minus_plus == -B_minus_plus)
require("minus-plus input sign", B_minus_plus * S == B_minus_plus)
require("plus-minus output sign", S * B_plus_minus == B_plus_minus)
require("plus-minus input sign", B_plus_minus * S == -B_plus_minus)

from collections import Counter
from fractions import Fraction
from math import gcd
import os
import sys

from mpmath import mp

from scan_coupled_shell_coverage import (
    divisors_from_factorization,
    factor_integer,
    prime_sieve,
)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


PRIME_LIMIT = int(os.environ.get("ES_FILTER_PRIME_LIMIT", "150"))
DECIMAL_PRECISION = int(os.environ.get("ES_FILTER_DPS", "100"))
COMPARISON_TOLERANCE = mp.mpf("1e-70")
EXAMPLE_LIMIT = 6


def multiplicative_subgroup(generators, modulus):
    subgroup = {1}
    for generator in generators:
        old = tuple(subgroup)
        power = 1
        new_subgroup = set()
        while power not in new_subgroup:
            for value in old:
                new_subgroup.add(power * value % modulus)
            power = power * generator % modulus
        subgroup = new_subgroup
    return subgroup


def rotational_stabilizer(support, modulus):
    anchor = next(iter(support))
    inverse_anchor = pow(anchor, -1, modulus)
    candidates = {value * inverse_anchor % modulus for value in support}
    return {
        value
        for value in candidates
        if gcd(value, modulus) == 1
        and {value * residue % modulus for residue in support} == support
    }


def quotient_group(group, subgroup, modulus):
    element_to_coset = {}
    cosets = {}
    for value in sorted(group):
        if value in element_to_coset:
            continue
        members = frozenset(value * k % modulus for k in subgroup)
        representative = min(members)
        cosets[representative] = members
        for member in members:
            element_to_coset[member] = representative
    representatives = tuple(sorted(cosets))

    def operation(left, right):
        return element_to_coset[left * right % modulus]

    identity = element_to_coset[1]
    return representatives, element_to_coset, operation, identity


def element_order(element, operation, identity, group_order):
    power = identity
    for exponent in range(1, group_order + 1):
        power = operation(power, element)
        if power == identity:
            return exponent
    raise AssertionError("quotient element order was not found")


def cyclic_orbits(elements, generator, operation, order):
    unseen = set(elements)
    orbits = []
    while unseen:
        start = min(unseen)
        orbit = []
        current = start
        for _ in range(order):
            if current in orbit:
                raise AssertionError("cyclic orbit closed too early")
            orbit.append(current)
            current = operation(current, generator)
        if current != start or len(orbit) != order:
            raise AssertionError("cyclic orbit has the wrong order")
        unseen.difference_update(orbit)
        orbits.append(tuple(orbit))
    return tuple(orbits)


def cardinality_boundary_floor(support_size, orbit_order):
    remainder = support_size % orbit_order
    if remainder:
        return Fraction(
            remainder * (orbit_order - remainder),
            orbit_order,
        )
    return Fraction(2 * (orbit_order - 1), orbit_order)


def phase_mod_one(value):
    return Fraction(value.numerator % value.denominator, value.denominator)


def quotient_characters(elements, operation, identity):
    current_subgroup = {identity}
    characters = [{identity: Fraction(0)}]

    while len(current_subgroup) < len(elements):
        generator = next(
            value for value in elements if value not in current_subgroup
        )
        power = identity
        relative_order = None
        terminal_power = None
        powers = [identity]
        for exponent in range(1, len(elements) + 1):
            power = operation(power, generator)
            if power in current_subgroup:
                relative_order = exponent
                terminal_power = power
                break
            powers.append(power)
        if relative_order is None:
            raise AssertionError("relative order was not found")

        expanded_subgroup = {
            operation(power_value, old_value)
            for power_value in powers
            for old_value in current_subgroup
        }
        if len(expanded_subgroup) != relative_order * len(current_subgroup):
            raise AssertionError("quotient character extension has wrong index")

        extended_characters = []
        for character in characters:
            terminal_phase = character[terminal_power]
            for branch in range(relative_order):
                generator_phase = (terminal_phase + branch) / relative_order
                extension = {}
                for exponent, power_value in enumerate(powers):
                    for old_value in current_subgroup:
                        element = operation(power_value, old_value)
                        value = phase_mod_one(
                            exponent * generator_phase + character[old_value]
                        )
                        if element in extension and extension[element] != value:
                            raise AssertionError(
                                "inconsistent quotient character extension"
                            )
                        extension[element] = value
                extended_characters.append(extension)

        current_subgroup = expanded_subgroup
        characters = extended_characters

    if len(characters) != len(elements):
        raise AssertionError("dual group cardinality mismatch")
    if not any(all(value == 0 for value in chi.values()) for chi in characters):
        raise AssertionError("principal character is absent")
    return characters


def complex_phase(angle, sign=1):
    ratio = mp.mpf(angle.numerator) / angle.denominator
    return mp.exp(sign * 2 * mp.pi * mp.j * ratio)


def fourier_data(elements, measure, characters, targets):
    principal_mass = sum(measure.values())
    unweighted = mp.mpf(0)
    filtered = mp.mpf(0)
    rows = []
    parseval_left = mp.mpf(0)

    for character in characters:
        coefficient = mp.fsum(
            measure[element] * complex_phase(character[element], sign=-1)
            for element in elements
        )
        coefficient_abs = abs(coefficient)
        parseval_left += coefficient_abs**2
        is_principal = all(value == 0 for value in character.values())
        if is_principal:
            if abs(coefficient - principal_mass) > COMPARISON_TOLERANCE:
                raise AssertionError("principal Fourier mass mismatch")
            continue
        average = mp.fsum(
            complex_phase(character[target], sign=1) for target in targets
        ) / len(targets)
        average_abs = abs(average)
        unweighted += coefficient_abs
        filtered += coefficient_abs * average_abs
        rows.append((character, coefficient_abs, average_abs))

    parseval_right = len(elements) * sum(value * value for value in measure.values())
    if abs(parseval_left - parseval_right) > COMPARISON_TOLERANCE:
        raise AssertionError("Parseval check failed")
    return principal_mass, unweighted, filtered, rows


def relation(value, threshold):
    difference = value - threshold
    if abs(difference) <= COMPARISON_TOLERANCE:
        return 0
    return -1 if difference < 0 else 1


def format_real(value, digits=35):
    return mp.nstr(value, digits)


mp.dps = DECIMAL_PRECISION
sieve = prime_sieve(PRIME_LIMIT)
trial_primes = [value for value in range(2, PRIME_LIMIT + 1) if sieve[value]]

counts = Counter()
examples = []
empty_min_margin = None
classification_gap = None
shell_count = 0

for p in range(13, PRIME_LIMIT + 1, 12):
    if not sieve[p]:
        continue
    for residual in range(3, 2 * p, 4):
        a = (p + residual) // 4
        factors = factor_integer(a, trial_primes)
        generators = tuple(prime % residual for prime, _ in factors)
        group = multiplicative_subgroup(generators, residual)

        square_factors = tuple(
            (prime, 2 * exponent) for prime, exponent in factors
        )
        divisors = divisors_from_factorization(square_factors)
        inverse_a = pow(a, -1, residual)
        centered_measure = Counter(
            divisor * inverse_a % residual for divisor in divisors
        )
        support = set(centered_measure)
        if not support <= group:
            raise AssertionError("centered support left the generated subgroup")

        stabilizer = rotational_stabilizer(support, residual)
        if not stabilizer <= group:
            raise AssertionError("support stabilizer left the generated subgroup")

        (
            quotient_elements,
            quotient_map,
            quotient_operation,
            quotient_identity,
        ) = quotient_group(group, stabilizer, residual)
        quotient_measure = Counter()
        for value, multiplicity in centered_measure.items():
            quotient_measure[quotient_map[value]] += multiplicity
        for value in quotient_elements:
            quotient_measure[value] += 0
        quotient_support = {
            value for value in quotient_elements if quotient_measure[value] > 0
        }
        quotient_support_stabilizer = {
            displacement
            for displacement in quotient_elements
            if {
                quotient_operation(displacement, value)
                for value in quotient_support
            }
            == quotient_support
        }
        if quotient_support_stabilizer != {quotient_identity}:
            raise AssertionError(
                "full support-stabilizer quotient retained a support period"
            )

        target_residues = []
        for target in ((-1) % residual, (-pow(p, -1, residual)) % residual):
            if target in group:
                target_residues.append(target)
        target_cosets = tuple(
            sorted({quotient_map[target] for target in target_residues})
        )
        if not target_cosets:
            counts["no-target"] += 1
            continue

        quotient_char_list = quotient_characters(
            quotient_elements,
            quotient_operation,
            quotient_identity,
        )
        mass, unweighted, filtered, rows = fourier_data(
            quotient_elements,
            quotient_measure,
            quotient_char_list,
            target_cosets,
        )

        local_supports = []
        local_support_sizes = []
        for prime, exponent in factors:
            local = {
                quotient_map[pow(prime, beta, residual)]
                for beta in range(-exponent, exponent + 1)
            }
            local_supports.append(local)
            local_support_sizes.append(len(local))
        kappa = 1 + sum(size - 1 for size in local_support_sizes)
        surplus = kappa + len(target_cosets) - len(quotient_elements)

        occupied = any(target in support for target in target_residues)
        if not occupied and surplus > 0:
            raise AssertionError("empty shell has positive full-stabilizer surplus")

        uniform_gap_certificate = False
        cardinality_gap_certificate = False
        kneser_interval_gap_certificate = False
        boundary_gap_certificate = False
        one_factor_boundary_formula = False
        target_order = None
        cardinality_boundary_lower = None
        kneser_interval_boundary_lower = None
        boundary_energy = None
        projected_target_certificate = False
        projected_target_surplus = None
        projected_target_order = None
        projected_support_size = None
        if len(target_cosets) == 2:
            p_coset = quotient_map[p % residual]
            for character, _, average_abs in rows:
                expected = abs(
                    1 + complex_phase(character[p_coset], sign=1)
                ) / 2
                if abs(average_abs - expected) > COMPARISON_TOLERANCE:
                    raise AssertionError("two-target rotation filter failed")
            if relation(filtered, unweighted) >= 0:
                raise AssertionError(
                    "two-target average did not strictly contract Fourier mass"
                )
            counts["strict-two-target-contraction"] += 1

            target_order = element_order(
                p_coset,
                quotient_operation,
                quotient_identity,
                len(quotient_elements),
            )
            if target_order < 2:
                raise AssertionError("distinct targets have trivial displacement")
            rotated_mass = sum(
                coefficient_abs
                for character, coefficient_abs, _ in rows
                if character[p_coset] != 0
            )
            rotated_square_mass = sum(
                coefficient_abs * coefficient_abs
                for character, coefficient_abs, _ in rows
                if character[p_coset] != 0
            )
            displacement_orbits = cyclic_orbits(
                quotient_elements,
                p_coset,
                quotient_operation,
                target_order,
            )
            orbit_index = {}
            for index, orbit in enumerate(displacement_orbits):
                for value in orbit:
                    orbit_index[value] = index
            projected_elements = tuple(range(len(displacement_orbits)))

            def projected_operation(left, right):
                return orbit_index[
                    quotient_operation(
                        displacement_orbits[left][0],
                        displacement_orbits[right][0],
                    )
                ]

            projected_identity = orbit_index[quotient_identity]
            projected_support = {
                orbit_index[value] for value in quotient_support
            }
            projected_support_size = len(projected_support)
            projected_support_stabilizer = {
                displacement
                for displacement in projected_elements
                if {
                    projected_operation(displacement, value)
                    for value in projected_support
                }
                == projected_support
            }
            projected_local_supports = [
                {orbit_index[value] for value in local}
                for local in local_supports
            ]
            projected_local_saturations = [
                {
                    projected_operation(value, period)
                    for value in local
                    for period in projected_support_stabilizer
                }
                for local in projected_local_supports
            ]
            projected_kneser_lower = sum(
                len(local) for local in projected_local_saturations
            ) - (len(projected_local_saturations) - 1) * len(
                projected_support_stabilizer
            )
            if projected_support_size < projected_kneser_lower:
                raise AssertionError(
                    "projected local sumset violates Kneser's theorem"
                )
            projected_targets = {
                orbit_index[value] for value in target_cosets
            }
            projected_target_saturation = {
                projected_operation(value, period)
                for value in projected_targets
                for period in projected_support_stabilizer
            }
            projected_target_surplus_numerator = (
                projected_kneser_lower
                + len(projected_target_saturation)
                - len(projected_elements)
            )
            if (
                projected_target_surplus_numerator
                % len(projected_support_stabilizer)
            ):
                raise AssertionError(
                    "projected target surplus is not integral on the stabilizer quotient"
                )
            projected_target_surplus = (
                projected_target_surplus_numerator
                // len(projected_support_stabilizer)
            )
            projected_target_order = len(projected_elements)
            target_orbit = set(
                displacement_orbits[orbit_index[target_cosets[0]]]
            )
            full_target_orbit = target_orbit == set(target_cosets)
            if full_target_orbit:
                projected_intersection = bool(
                    projected_support & projected_targets
                )
                if projected_intersection != occupied:
                    raise AssertionError(
                        "complete target-fiber projection disagrees with occupancy"
                    )
                projected_target_certificate = projected_target_surplus > 0
                if projected_target_certificate and not occupied:
                    raise AssertionError(
                        "projected Kneser target certificate missed occupancy"
                    )
            orbit_variance = Fraction(0)
            boundary_energy = Fraction(0)
            for orbit in displacement_orbits:
                orbit_total = sum(quotient_measure[value] for value in orbit)
                orbit_mean = Fraction(orbit_total, target_order)
                orbit_variance += sum(
                    (Fraction(quotient_measure[value]) - orbit_mean) ** 2
                    for value in orbit
                )
                support_count = sum(
                    value in quotient_support for value in orbit
                )
                boundary_energy += Fraction(
                    support_count * (target_order - support_count),
                    target_order,
                )
            if orbit_variance < boundary_energy:
                raise AssertionError(
                    "integer orbit variance fell below support boundary"
                )
            if boundary_energy < Fraction(target_order - 1, target_order):
                raise AssertionError(
                    "full quotient support boundary missed universal bound"
                )
            cardinality_boundary_lower = cardinality_boundary_floor(
                len(quotient_support),
                target_order,
            )
            if boundary_energy < cardinality_boundary_lower:
                raise AssertionError(
                    "support boundary fell below cardinality residue bound"
                )
            if len(factors) == 1:
                local_length = 2 * factors[0][1] + 1
                if not local_length < len(group):
                    raise AssertionError(
                        "two-target one-factor support is not a proper interval"
                    )
                if len(stabilizer) != 1:
                    raise AssertionError(
                        "proper one-factor interval has nontrivial stabilizer"
                    )
                orbit_count = len(displacement_orbits)
                quotient_length, exceptional_orbits = divmod(
                    local_length,
                    orbit_count,
                )
                one_factor_expected_boundary = Fraction(
                    exceptional_orbits
                    * (quotient_length + 1)
                    * (target_order - quotient_length - 1)
                    + (orbit_count - exceptional_orbits)
                    * quotient_length
                    * (target_order - quotient_length),
                    target_order,
                )
                if boundary_energy != one_factor_expected_boundary:
                    raise AssertionError(
                        "one-factor interval boundary formula failed"
                    )
                one_factor_boundary_formula = True
            if surplus <= 0:
                empty_support_upper = (
                    len(quotient_elements) - len(target_cosets)
                )
                if kappa > empty_support_upper:
                    raise AssertionError(
                        "nonpositive surplus has an empty Kneser interval"
                    )
                kneser_interval_boundary_lower = min(
                    cardinality_boundary_floor(size, target_order)
                    for size in range(kappa, empty_support_upper + 1)
                )
            orbit_variance_real = (
                mp.mpf(orbit_variance.numerator) / orbit_variance.denominator
            )
            cardinality_boundary_lower_real = (
                mp.mpf(cardinality_boundary_lower.numerator)
                / cardinality_boundary_lower.denominator
            )
            if kneser_interval_boundary_lower is not None:
                kneser_interval_boundary_lower_real = (
                    mp.mpf(kneser_interval_boundary_lower.numerator)
                    / kneser_interval_boundary_lower.denominator
                )
            boundary_energy_real = (
                mp.mpf(boundary_energy.numerator) / boundary_energy.denominator
            )
            if abs(
                rotated_square_mass
                - len(quotient_elements) * orbit_variance_real
            ) > COMPARISON_TOLERANCE:
                raise AssertionError(
                    "rotated Parseval orbit-variance identity failed"
                )
            uniform_rotated_lower = mp.sqrt(
                mp.mpf(len(quotient_elements))
                * (target_order - 1)
                / target_order
            )
            cardinality_rotated_lower = mp.sqrt(
                mp.mpf(len(quotient_elements))
                * cardinality_boundary_lower_real
            )
            if kneser_interval_boundary_lower is not None:
                kneser_interval_rotated_lower = mp.sqrt(
                    mp.mpf(len(quotient_elements))
                    * kneser_interval_boundary_lower_real
                )
            boundary_rotated_lower = mp.sqrt(
                mp.mpf(len(quotient_elements)) * boundary_energy_real
            )
            if relation(rotated_mass, uniform_rotated_lower) < 0:
                raise AssertionError(
                    "rotated Fourier mass violates integral orbit bound"
                )
            if relation(rotated_mass, cardinality_rotated_lower) < 0:
                raise AssertionError(
                    "rotated Fourier mass violates cardinality boundary bound"
                )
            if (
                kneser_interval_boundary_lower is not None
                and relation(
                    rotated_mass,
                    kneser_interval_rotated_lower,
                )
                < 0
            ):
                raise AssertionError(
                    "rotated Fourier mass violates Kneser interval bound"
                )
            if relation(rotated_mass, boundary_rotated_lower) < 0:
                raise AssertionError(
                    "rotated Fourier mass violates support-boundary bound"
                )
            contraction_coefficient = 1 - mp.cos(mp.pi / target_order)
            exact_rotation_upper = (
                unweighted - contraction_coefficient * rotated_mass
            )
            uniform_rotation_upper = (
                unweighted
                - contraction_coefficient * uniform_rotated_lower
            )
            if relation(filtered, exact_rotation_upper) > 0:
                raise AssertionError(
                    "target average violates exact rotation-gap bound"
                )
            if relation(filtered, uniform_rotation_upper) > 0:
                raise AssertionError(
                    "target average violates integral orbit-gap bound"
                )
            uniform_gap_certificate = (
                relation(
                    unweighted,
                    mass
                    + contraction_coefficient * uniform_rotated_lower,
                )
                < 0
            )
            cardinality_gap_certificate = (
                relation(
                    unweighted,
                    mass
                    + contraction_coefficient * cardinality_rotated_lower,
                )
                < 0
            )
            if kneser_interval_boundary_lower is not None:
                kneser_interval_gap_certificate = (
                    relation(
                        unweighted,
                        mass
                        + contraction_coefficient
                        * kneser_interval_rotated_lower,
                    )
                    < 0
                )
            boundary_gap_certificate = (
                relation(
                    unweighted,
                    mass
                    + contraction_coefficient * boundary_rotated_lower,
                )
                < 0
            )

        old_relation = relation(unweighted, mass)
        filtered_relation = relation(filtered, mass)
        old_strict = old_relation < 0
        filtered_strict = filtered_relation < 0
        two_target_nonstrict = (
            len(target_cosets) == 2 and old_relation <= 0
        )

        shell_count += 1
        counts["occupied" if occupied else "empty"] += 1
        counts[f"target-cosets-{len(target_cosets)}"] += 1
        counts["old-strict" if old_strict else "old-inconclusive"] += 1
        counts[
            "filtered-strict" if filtered_strict else "filtered-inconclusive"
        ] += 1
        if two_target_nonstrict:
            counts["two-target-nonstrict"] += 1
        if uniform_gap_certificate:
            counts["uniform-gap-strict"] += 1
            if old_relation > 0:
                counts["uniform-gap-beyond-nonstrict"] += 1
            if not filtered_strict:
                raise AssertionError(
                    "uniform orbit-gap certificate escaped filtered test"
                )
        if cardinality_gap_certificate:
            counts["cardinality-gap-strict"] += 1
            if not uniform_gap_certificate:
                counts["cardinality-gap-beyond-uniform"] += 1
            if old_relation > 0:
                counts["cardinality-gap-beyond-nonstrict"] += 1
            if not filtered_strict:
                raise AssertionError(
                    "cardinality boundary certificate escaped filtered test"
                )
        if kneser_interval_gap_certificate:
            counts["kneser-interval-gap-strict"] += 1
            if not uniform_gap_certificate:
                counts["kneser-interval-gap-beyond-uniform"] += 1
            if old_relation > 0:
                counts["kneser-interval-gap-beyond-nonstrict"] += 1
            if not filtered_strict:
                raise AssertionError(
                    "Kneser interval certificate escaped filtered test"
                )
        if boundary_gap_certificate:
            counts["boundary-gap-strict"] += 1
            if not uniform_gap_certificate:
                counts["boundary-gap-beyond-uniform"] += 1
            if old_relation > 0:
                counts["boundary-gap-beyond-nonstrict"] += 1
            if not filtered_strict:
                raise AssertionError(
                    "support-boundary certificate escaped filtered test"
                )
        if projected_target_certificate:
            counts["projected-target-strict"] += 1
            if not uniform_gap_certificate:
                counts["projected-target-beyond-uniform"] += 1
            if not boundary_gap_certificate:
                counts["projected-target-beyond-boundary"] += 1
            if old_relation > 0:
                counts["projected-target-beyond-nonstrict"] += 1
        if one_factor_boundary_formula:
            counts["one-factor-proper-two-target"] += 1
            if boundary_gap_certificate:
                counts["one-factor-boundary-gap-strict"] += 1
            if filtered_strict:
                counts["one-factor-filtered-strict"] += 1
        if filtered_strict and not old_strict:
            counts["coupling-only"] += 1
            if len(examples) < EXAMPLE_LIMIT:
                examples.append(
                    {
                        "p": p,
                        "R": residual,
                        "a": a,
                        "factors": factors,
                        "H_order": len(group),
                        "K": tuple(sorted(stabilizer)),
                        "Q": quotient_elements,
                        "target_cosets": target_cosets,
                        "support": tuple(sorted(support)),
                        "mass": mass,
                        "unweighted": unweighted,
                        "filtered": filtered,
                        "target_order": target_order,
                        "cardinality_boundary_lower": (
                            cardinality_boundary_lower
                        ),
                        "kneser_interval_boundary_lower": (
                            kneser_interval_boundary_lower
                        ),
                        "boundary_energy": boundary_energy,
                        "uniform_gap_certificate": uniform_gap_certificate,
                        "cardinality_gap_certificate": (
                            cardinality_gap_certificate
                        ),
                        "kneser_interval_gap_certificate": (
                            kneser_interval_gap_certificate
                        ),
                        "boundary_gap_certificate": boundary_gap_certificate,
                        "projected_target_certificate": (
                            projected_target_certificate
                        ),
                        "projected_target_surplus": projected_target_surplus,
                        "projected_target_order": projected_target_order,
                        "projected_support_size": projected_support_size,
                        "surplus": surplus,
                        "occupied": occupied,
                        "rows": rows,
                    }
                )

        gap = min(
            abs(unweighted - mass),
            abs(filtered - mass),
        )
        if gap > COMPARISON_TOLERANCE:
            classification_gap = (
                gap
                if classification_gap is None
                else min(classification_gap, gap)
            )
        if not occupied:
            if filtered_relation < 0:
                raise AssertionError(
                    "empty shell violated the averaged necessary inequality"
                )
            empty_margin = filtered - mass
            empty_min_margin = (
                empty_margin
                if empty_min_margin is None
                else min(empty_min_margin, empty_margin)
            )


print("PASS: target-averaged full-stabilizer Fourier diagnostic")
print(f"prime bound: {PRIME_LIMIT}")
print(f"decimal precision: {DECIMAL_PRECISION}")
print(f"shells with at least one target coset: {shell_count}")
for key in (
    "no-target",
    "empty",
    "occupied",
    "target-cosets-1",
    "target-cosets-2",
    "strict-two-target-contraction",
    "old-strict",
    "old-inconclusive",
    "filtered-strict",
    "filtered-inconclusive",
    "two-target-nonstrict",
    "uniform-gap-strict",
    "uniform-gap-beyond-nonstrict",
    "cardinality-gap-strict",
    "cardinality-gap-beyond-uniform",
    "cardinality-gap-beyond-nonstrict",
    "kneser-interval-gap-strict",
    "kneser-interval-gap-beyond-uniform",
    "kneser-interval-gap-beyond-nonstrict",
    "boundary-gap-strict",
    "boundary-gap-beyond-uniform",
    "boundary-gap-beyond-nonstrict",
    "projected-target-strict",
    "projected-target-beyond-uniform",
    "projected-target-beyond-boundary",
    "projected-target-beyond-nonstrict",
    "one-factor-proper-two-target",
    "one-factor-boundary-gap-strict",
    "one-factor-filtered-strict",
    "coupling-only",
):
    print(f"{key}: {counts[key]}")
print(
    "smallest nonzero threshold distance: "
    f"{format_real(classification_gap)}"
)
print(
    "smallest empty-shell filtered margin: "
    f"{format_real(empty_min_margin)}"
)
print("first coupling-only examples:")
for example in examples:
    print(
        "  "
        f"p={example['p']}, R={example['R']}, a={example['a']}, "
        f"factorization={example['factors']}, "
        f"|H|={example['H_order']}, |K|={len(example['K'])}, "
        f"|Q|={len(example['Q'])}, t={len(example['target_cosets'])}, "
        f"surplus={example['surplus']}, occupied={example['occupied']}"
    )
    print(f"    K={example['K']}")
    print(f"    Q={example['Q']}")
    print(f"    target cosets={example['target_cosets']}")
    print(f"    centered support={example['support']}")
    print(
        "    "
        f"M={example['mass']}, "
        f"S={format_real(example['unweighted'])}, "
        f"S_A={format_real(example['filtered'])}"
    )
    if example["target_order"] is not None:
        print(
            "    "
            f"ord(d)={example['target_order']}, "
            "cardinality boundary lower="
            f"{example['cardinality_boundary_lower']}, "
            "Kneser interval lower="
            f"{example['kneser_interval_boundary_lower']}, "
            f"boundary energy={example['boundary_energy']}, "
            f"uniform certificate={example['uniform_gap_certificate']}, "
            "cardinality certificate="
            f"{example['cardinality_gap_certificate']}, "
            "Kneser interval certificate="
            f"{example['kneser_interval_gap_certificate']}, "
            f"boundary certificate={example['boundary_gap_certificate']}, "
            "projected target certificate="
            f"{example['projected_target_certificate']}, "
            "projected target surplus="
            f"{example['projected_target_surplus']}, "
            "projected support="
            f"{example['projected_support_size']}/"
            f"{example['projected_target_order']}"
        )
    for index, (character, coefficient_abs, average_abs) in enumerate(
        example["rows"], start=1
    ):
        phase_signature = tuple(
            str(character[value]) for value in example["Q"]
        )
        print(
            "      "
            f"chi{index}: phases={phase_signature}, "
            f"|hat|={format_real(coefficient_abs)}, "
            f"|A_U|={format_real(average_abs)}"
        )

#!/usr/bin/env python3
"""Exact Fable-ray completion to a regular tetrahedron and 4-simplex."""

from sympy import Matrix, Rational, eye, simplify, sqrt, symbols


def zero_matrix(matrix):
    return all(simplify(entry) == 0 for entry in matrix)


root3 = sqrt(3)
e21 = Matrix([0, 0, 1, 0])
r0 = Matrix([2, 2, 0, 2])
r_plus = Matrix([2 + root3, -1, 0, 2 - root3])
r_minus = Matrix([2 - root3, -1, 0, 2 + root3])
r_infinity = -(r0 + r_plus + r_minus)

g_hat = Matrix([
    [Rational(1, 16), 0, 0, Rational(-7, 144)],
    [0, Rational(2, 9), 0, 0],
    [0, 0, 1, 0],
    [Rational(-7, 144), 0, 0, Rational(1, 16)],
])

rotation = Matrix([
    [Rational(1, 4), root3 / 2, 0, Rational(3, 4)],
    [-root3 / 4, Rational(-1, 2), 0, root3 / 4],
    [0, 0, 1, 0],
    [Rational(3, 4), -root3 / 2, 0, Rational(1, 4)],
])
reflection = Matrix([
    [0, 0, 0, 1],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [1, 0, 0, 0],
])

face = [r_infinity, r0, r_plus, r_minus]
face_gram = Matrix(
    4,
    4,
    lambda i, j: simplify((face[i].T * g_hat * face[j])[0]),
)
regular_tetrahedron_gram = Matrix(
    4,
    4,
    lambda i, j: Rational(1) if i == j else Rational(-1, 3),
)
assert face_gram == regular_tetrahedron_gram

positive_coordinate_matrix = Matrix.hstack(
    Matrix([2, 2, 2]),
    Matrix([2 + root3, -1, 2 - root3]),
    Matrix([2 - root3, -1, 2 + root3]),
)
assert simplify(positive_coordinate_matrix.det() + 24 * root3) == 0

g_plus = g_hat.extract([0, 1, 3], [0, 1, 3])
assert g_plus == Matrix([
    [Rational(1, 16), 0, Rational(-7, 144)],
    [0, Rational(2, 9), 0],
    [Rational(-7, 144), 0, Rational(1, 16)],
])
assert simplify(g_plus.det() - Rational(1, 2916)) == 0
assert g_plus.eigenvals() == {
    Rational(1, 72): 1,
    Rational(1, 9): 1,
    Rational(2, 9): 1,
}

assert zero_matrix(rotation.T * g_hat * rotation - g_hat)
assert zero_matrix(reflection.T * g_hat * reflection - g_hat)
assert zero_matrix(rotation**3 - eye(4))
assert zero_matrix(reflection**2 - eye(4))
assert zero_matrix(reflection * rotation * reflection - rotation.inv())

assert zero_matrix(rotation * r_infinity - r_infinity)
assert zero_matrix(rotation * r0 - r_plus)
assert zero_matrix(rotation * r_plus - r_minus)
assert zero_matrix(rotation * r_minus - r0)
assert zero_matrix(reflection * r_infinity - r_infinity)
assert zero_matrix(reflection * r0 - r0)
assert zero_matrix(reflection * r_plus - r_minus)
assert zero_matrix(reflection * r_minus - r_plus)

scale = sqrt(15) / 4
simplex = [e21] + [scale * ray - Rational(1, 4) * e21 for ray in face]
simplex_gram = Matrix(
    5,
    5,
    lambda i, j: simplify((simplex[i].T * g_hat * simplex[j])[0]),
)
regular_four_simplex_gram = Matrix(
    5,
    5,
    lambda i, j: Rational(1) if i == j else Rational(-1, 4),
)
assert simplex_gram == regular_four_simplex_gram
centroid = simplify(sum(simplex[1:], Matrix.zeros(4, 1)) / 4)
assert centroid == -Rational(1, 4) * e21

transport = Matrix.hstack(
    Matrix([1, Rational(1, 2), 0, Rational(1, 4)]),
    Matrix([0, 0, 1, 0]),
    Matrix([2, 0, 0, Rational(-1, 2)]),
    Matrix([1, Rational(-1, 2), 0, Rational(1, 4)]),
)
quarter_inversion = Matrix([
    [0, 0, 0, 1],
    [0, Rational(1, 4), 0, 0],
    [0, 0, Rational(1, 4), 0],
    [Rational(1, 16), 0, 0, 0],
])
normal = Matrix([4, 0, 0, -1])
assert transport * e21 == Rational(1, 2) * normal
assert zero_matrix(
    transport * (-Rational(1, 4) * e21)
    - quarter_inversion * transport * e21
)

x, y, z = symbols("x y z")
fable = Matrix([
    (1 + x * y) ** 3 * z + y**2 * (1 + x * y) * (4 + 3 * x * y),
    y + 3 * x * (1 + x * y) ** 2 * z + 3 * x * y**2 * (4 + 3 * x * y),
    2 * x - 3 * x**2 * y - x**3 * z,
])
target = Matrix([Rational(-1, 4), 0, 0])
for point in (
    (0, 0, Rational(-1, 4)),
    (1, Rational(-3, 2), Rational(13, 2)),
    (-1, Rational(3, 2), Rational(13, 2)),
):
    assert fable.subs(dict(zip((x, y, z), point))) == target

print("PASS forced fourth face vertex = -6(E11+E22)")
print("PASS unique positive face form has eigenvalues 1/72, 1/9, 2/9")
print("PASS four Fable face rays have regular-tetrahedron Gram")
print("PASS Fable D3 generators preserve the face form and exact vertex action")
print("PASS five completed vertices have regular-4-simplex Gram")
print("PASS opposite-face centroid = -E21/4")
print("PASS axis transport sends the centroid to the negative quarter eigenline")
print("PASS all three Fable points map to (-1/4,0,0)")

from math import gcd, isqrt


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    for d in range(3, isqrt(n) + 1, 2):
        if n % d == 0:
            return False
    return True


def divisors(n):
    values = []
    for d in range(1, isqrt(n) + 1):
        if n % d == 0:
            values.append(d)
            if d * d != n:
                values.append(n // d)
    return sorted(values)


def prime_divisors(n):
    values = []
    d = 2
    while d * d <= n:
        if n % d == 0:
            values.append(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        values.append(n)
    return values


def exterior_count(R, a):
    return sum(1 for u in divisors(a * a) if (4 * u + 1) % R == 0)


def middle_coefficient(R, a):
    ds = divisors(a)
    return sum(
        1
        for x in ds
        for y in ds
        if gcd(x, y) == 1 and a % (x * y) == 0 and (x + y) % R == 0
    )


primes = [p for p in range(13, 5001) if p % 12 == 1 and is_prime(p)]
classification_rows = []
for p in primes:
    a = (p + 3) // 4
    e = exterior_count(3, a)
    c = middle_coefficient(3, a)
    has_two_mod_three_factor = any(
        ell % 3 == 2 for ell in prime_divisors(a)
    )
    classification_rows.append(
        (
            (e + c // 2 > 0) == has_two_mod_three_factor,
            (e > 0) == has_two_mod_three_factor,
            (c > 0) == has_two_mod_three_factor,
            not has_two_mod_three_factor or (e >= 1 and c >= 2),
        )
    )

report(
    "R=3 exact prime-factor classification",
    all(all(row) for row in classification_rows),
)

general_rows = []
for p in [q for q in range(5, 1000) if q % 4 == 1 and is_prime(q)]:
    lower = p // 4 + 1
    upper = 3 * p // 4
    for a in range(lower, upper + 1):
        R = 4 * a - p
        c = middle_coefficient(R, a)
        for d in divisors(a):
            if d % R == R - 1:
                general_rows.append(c >= 2)

report(
    "minus-one divisor forces two ordered middle witnesses",
    bool(general_rows) and all(general_rows),
)

print(f"R=3 primes checked: {len(primes)}")
print(f"general forcing instances checked: {len(general_rows)}")

from math import isqrt


def primes_up_to(limit):
    yield 2
    for candidate in range(3, limit + 1, 2):
        if all(candidate % divisor for divisor in range(3, isqrt(candidate) + 1, 2)):
            yield candidate


def divisors_of_square(value):
    remaining = value
    factorization = []
    divisor = 2
    while divisor * divisor <= remaining:
        exponent = 0
        while remaining % divisor == 0:
            exponent += 1
            remaining //= divisor
        if exponent:
            factorization.append((divisor, 2 * exponent))
        divisor += 1
    if remaining > 1:
        factorization.append((remaining, 2))

    divisors = [1]
    for prime, exponent in factorization:
        powers = [prime**power for power in range(exponent + 1)]
        divisors = [old * power for old in divisors for power in powers]
    return sorted(divisors)


for p in primes_up_to(5000):
    if p % 4 != 1:
        continue

    for R in range(3, 2 * p - 2, 4):
        a = (p + R) // 4
        N = p * a
        a_squared = a * a
        divisors = divisors_of_square(a)

        origin_zero = []
        origin_one = []
        origin_two = []
        for u in divisors:
            if (u + 4 * a_squared) % R == 0:
                origin_zero.append(u)
            if (u + a) % R == 0:
                origin_one.append(u)
            if (4 * u + 1) % R == 0:
                origin_two.append(u)

            for j, target_list in (
                (0, origin_zero),
                (1, origin_one),
                (2, origin_two),
            ):
                original = (pow(p, j, R) * (u % R) + N) % R == 0
                rewritten = u in target_list
                if original != rewritten:
                    raise AssertionError(
                        f"origin formula fails for p={p}, R={R}, j={j}, u={u}"
                    )

        complement_of_two = sorted(a_squared // u for u in origin_two)
        if sorted(origin_zero) != complement_of_two:
            raise AssertionError(f"exterior complement pairing fails for p={p}, R={R}")

        complement_of_one = sorted(a_squared // u for u in origin_one)
        if sorted(origin_one) != complement_of_one:
            raise AssertionError(f"middle complement pairing fails for p={p}, R={R}")
        if a in origin_one or len(origin_one) % 2:
            raise AssertionError(f"middle fixed-point exclusion fails for p={p}, R={R}")

        omega = len(origin_zero) + len(origin_one) + len(origin_two)
        q_formula = len(origin_two) + len(origin_one) // 2
        if omega != 2 * q_formula:
            raise AssertionError(f"orbit-count formula fails for p={p}, R={R}")

        for u in origin_two:
            k = (4 * u + 1) // R
            if k <= 0 or k % 4 != 3 or (k * R - 1) // 4 != u:
                raise AssertionError(f"exterior k-parameter fails for p={p}, R={R}, u={u}")

        for u in origin_one:
            k = (u + a) // R
            if k <= 0 or k * R - a != u:
                raise AssertionError(f"middle k-parameter fails for p={p}, R={R}, u={u}")


print("PASS: complete endpoint divisor formula")
print("the middle origin is exactly R dividing u+a")
print("the terminal exterior origin is exactly R dividing 4u+1")
print("the initial exterior origin is the complementary-divisor image")
print("q equals the external divisor count plus half the middle divisor count")
print("the integer parameters are u=(kR-1)/4 with k=3 mod 4 and u=kR-a")

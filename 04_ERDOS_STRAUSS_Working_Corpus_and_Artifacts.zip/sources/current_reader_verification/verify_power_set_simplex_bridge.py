from fractions import Fraction
from itertools import combinations

from sympy import Matrix


def subsets(n):
    for mask in range(1 << n):
        yield frozenset(i for i in range(n) if mask & (1 << i))


def q_vector(n, subset):
    weight = Fraction(len(subset), n)
    return tuple(Fraction(int(i in subset), 1) - weight for i in range(n))


def dot(x, y):
    return sum(a * b for a, b in zip(x, y))


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


for n, label in ((3, "Colour"), (4, "Time")):
    universe = frozenset(range(n))
    all_subsets = tuple(subsets(n))

    report(
        f"{label} centred vectors have coordinate sum zero",
        all(sum(q_vector(n, a), Fraction(0, 1)) == 0 for a in all_subsets),
    )
    report(
        f"{label} complements map to opposite vectors",
        all(
            q_vector(n, universe - a)
            == tuple(-x for x in q_vector(n, a))
            for a in all_subsets
        ),
    )
    report(
        f"{label} subset inner-product formula",
        all(
            dot(q_vector(n, a), q_vector(n, b))
            == Fraction(len(a & b), 1)
            - Fraction(len(a) * len(b), n)
            for a in all_subsets
            for b in all_subsets
        ),
    )

    atom_vectors = [q_vector(n, frozenset((i,))) for i in range(n)]
    gram = Matrix([[dot(x, y) for y in atom_vectors] for x in atom_vectors])
    report(f"{label} atom Gram rank is {n - 1}", gram.rank() == n - 1)
    report(
        f"{label} atom squared length",
        all(dot(x, x) == Fraction(n - 1, n) for x in atom_vectors),
    )
    report(
        f"{label} distinct atom inner product",
        all(
            dot(atom_vectors[i], atom_vectors[j]) == Fraction(-1, n)
            for i, j in combinations(range(n), 2)
        ),
    )
    report(
        f"{label} unit-direction off-diagonal Gram value",
        all(
            dot(atom_vectors[i], atom_vectors[j])
            / dot(atom_vectors[i], atom_vectors[i])
            == Fraction(-1, n - 1)
            for i, j in combinations(range(n), 2)
        ),
    )


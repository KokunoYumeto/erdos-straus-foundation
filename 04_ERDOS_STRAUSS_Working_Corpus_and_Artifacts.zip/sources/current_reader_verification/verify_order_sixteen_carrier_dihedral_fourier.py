#!/usr/bin/env python3
"""Exact dihedral action and carry phases on the order-16 four-cell carriers."""

from __future__ import annotations

from fractions import Fraction

from verify_order_sixteen_four_sheet_carrier import CARRIERS
from verify_order_sixteen_carrier_inversion_blade import (
    carrier_inverse,
    flatten,
    sheet_inverse,
)


Gaussian = tuple[Fraction, Fraction]
Coordinate = tuple[tuple[int, ...], int]
Vector = dict[Coordinate, Gaussian]


ZERO: Gaussian = (Fraction(0), Fraction(0))
ONE: Gaussian = (Fraction(1), Fraction(0))
I: Gaussian = (Fraction(0), Fraction(1))


def gaussian_add(left: Gaussian, right: Gaussian) -> Gaussian:
    return (left[0] + right[0], left[1] + right[1])


def gaussian_multiply(left: Gaussian, right: Gaussian) -> Gaussian:
    return (
        left[0] * right[0] - left[1] * right[1],
        left[0] * right[1] + left[1] * right[0],
    )


def gaussian_power_i(exponent: int) -> Gaussian:
    answer = ONE
    for _ in range(exponent % 4):
        answer = gaussian_multiply(answer, I)
    return answer


def scale_vector(scalar: Gaussian, vector: Vector) -> Vector:
    return {
        coordinate: gaussian_multiply(scalar, coefficient)
        for coordinate, coefficient in vector.items()
        if gaussian_multiply(scalar, coefficient) != ZERO
    }


def apply_permutation(permutation, vector: Vector) -> Vector:
    answer: Vector = {}
    for coordinate, coefficient in vector.items():
        image = permutation(coordinate)
        answer[image] = gaussian_add(answer.get(image, ZERO), coefficient)
    return {coordinate: value for coordinate, value in answer.items() if value != ZERO}


def cell_rotation(coordinate: Coordinate) -> Coordinate:
    sheet, cell = coordinate
    return sheet, (cell + 1) % 4


def cell_rotation_power(coordinate: Coordinate, exponent: int) -> Coordinate:
    sheet, cell = coordinate
    return sheet, (cell + exponent) % 4


def cell_fourier_vector(sheet: tuple[int, ...], frequency: int) -> Vector:
    return {
        (sheet, cell): gaussian_power_i(-frequency * cell)
        for cell in range(4)
    }


def action_orbits(carrier) -> tuple[tuple[tuple[int, ...], ...], ...]:
    coordinates = set(carrier.coordinates().values())
    remaining = set(coordinates)
    orbits = []
    while remaining:
        start = min(remaining, key=lambda item: flatten(*item))
        orbit = {
            cell_rotation_power(start, exponent)
            for exponent in range(4)
        }
        opposite = carrier_inverse(carrier, start)
        orbit.update(
            cell_rotation_power(opposite, exponent)
            for exponent in range(4)
        )
        assert all(
            cell_rotation(point) in orbit
            and carrier_inverse(carrier, point) in orbit
            for point in orbit
        )
        orbits.append(tuple(sorted((flatten(*point) for point in orbit))))
        remaining.difference_update(orbit)
    return tuple(sorted(orbits, key=lambda orbit: (len(orbit), orbit)))


EXPECTED_ORBIT_SIZES = {
    "C16": (4, 4, 8),
    "C8xC2": (4, 4, 4, 4),
    "C4xC4": (4, 4, 8),
    "C4xC2xC2": (4, 4, 4, 4),
}

EXPECTED_K2_SIGNS = {
    "C16": (1, -1, -1, -1),
    "C8xC2": (1, 1, -1, -1),
    "C4xC4": (1, 1, 1, 1),
    "C4xC2xC2": (1, 1, 1, 1),
}


def verify_carrier_dihedral_fourier(carrier) -> dict[str, object]:
    all_coordinates = tuple(carrier.coordinates().values())
    for coordinate in all_coordinates:
        rotated = coordinate
        for _ in range(4):
            rotated = cell_rotation(rotated)
        assert rotated == coordinate
        assert carrier_inverse(carrier, carrier_inverse(carrier, coordinate)) == coordinate
        assert carrier_inverse(
            carrier,
            cell_rotation(carrier_inverse(carrier, coordinate)),
        ) == cell_rotation_power(coordinate, -1)

    for sheet in carrier.sheets:
        opposite_sheet = sheet_inverse(carrier, sheet)
        carry = carrier.cocycle(sheet, opposite_sheet)
        for frequency in range(4):
            vector = cell_fourier_vector(sheet, frequency)
            rotated = apply_permutation(cell_rotation, vector)
            assert rotated == scale_vector(gaussian_power_i(frequency), vector)

            inverted = apply_permutation(
                lambda coordinate: carrier_inverse(carrier, coordinate),
                vector,
            )
            expected = scale_vector(
                gaussian_power_i(frequency * carry),
                cell_fourier_vector(opposite_sheet, -frequency),
            )
            assert inverted == expected

    orbit_sizes = tuple(sorted(len(orbit) for orbit in action_orbits(carrier)))
    assert orbit_sizes == EXPECTED_ORBIT_SIZES[carrier.name]
    k2_signs = tuple(
        1
        if carrier.cocycle(sheet, sheet_inverse(carrier, sheet)) % 2 == 0
        else -1
        for sheet in carrier.sheets
    )
    assert k2_signs == EXPECTED_K2_SIGNS[carrier.name]
    return {
        "orbit_sizes": orbit_sizes,
        "k2_signs": k2_signs,
        "fourier_ranks": (4, 4, 4, 4),
    }


def main() -> None:
    for carrier in CARRIERS:
        result = verify_carrier_dihedral_fourier(carrier)
        print(
            f"{carrier.name}: dihedral_orbit_sizes={result['orbit_sizes']}, "
            f"cell_Fourier_ranks={result['fourier_ranks']}, "
            f"k2_inversion_signs={result['k2_signs']}"
        )
    print("PASS: exact dihedral carrier action and carry-phased C4 Fourier sectors")


if __name__ == "__main__":
    main()

"""Exact checks for the consecutive-prime Hilbert--Schmidt modular ladder."""

from fractions import Fraction
from math import prod


PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23)


def prime_block(n: int) -> tuple[int, ...]:
    if n == 1:
        return (1,)
    start = n * (n - 1) // 2 - 1
    stop = n * (n + 1) // 2 - 1
    return PRIMES[start:stop]


def ratio_spectrum(block: tuple[int, ...]) -> tuple[Fraction, ...]:
    return tuple(Fraction(a, b) for a in block for b in block)


def verify_block(n: int, expected: tuple[int, ...]) -> None:
    block = prime_block(n)
    assert block == expected
    spectrum = ratio_spectrum(block)
    assert len(spectrum) == n * n
    assert spectrum.count(Fraction(1)) == n
    assert prod(spectrum, start=Fraction(1)) == 1
    off_diagonal = [
        Fraction(block[a], block[b])
        for a in range(n)
        for b in range(n)
        if a != b
    ]
    assert len(set(off_diagonal)) == n * (n - 1)
    assert {x for x in off_diagonal} == {1 / x for x in off_diagonal}


def main() -> None:
    verify_block(1, (1,))
    verify_block(2, (2, 3))
    verify_block(3, (5, 7, 11))
    verify_block(4, (13, 17, 19, 23))

    block4 = prime_block(4)
    spectrum4 = ratio_spectrum(block4)
    trace4 = sum(spectrum4, start=Fraction(0))
    assert trace4 == Fraction(1612224, 96577)

    ratio_array = tuple(
        tuple(Fraction(a, b) for b in block4) for a in block4
    )
    for a in range(4):
        assert ratio_array[a][a] == 1
        for b in range(4):
            assert ratio_array[a][b] * ratio_array[b][a] == 1

    print("All exact consecutive-prime modular-spectrum checks passed.")
    print("Prime blocks:")
    for n in range(1, 5):
        print(f"  rho_{n}: {prime_block(n)}")
    print("Delta_4:")
    print("  dimension: 16")
    print("  fixed eigenvalue 1 multiplicity: 4")
    print("  directed off-diagonal channels: 12")
    print("  reciprocal channel pairs: 6")
    print(f"  determinant: {prod(spectrum4, start=Fraction(1))}")
    print(f"  trace: {trace4}")


if __name__ == "__main__":
    main()

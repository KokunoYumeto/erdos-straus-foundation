import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def matrix_equal(left, right, label):
    require(left.shape == right.shape, f"{label}: shape")
    difference = left - right
    for entry in difference:
        if sp.simplify(entry) != 0:
            raise AssertionError(f"{label}: {sp.factor(entry)}")


p = 12289
a = 3075
R = 4 * a - p
N = p * a
g = sp.gcd(R, N)
R0 = R // g
N0 = N // g

require((R0, N0) == (11, 37788675), "reduced shell parameters")

divisors = []
for d in sp.divisors(N0 * N0):
    if (d + N0) % R0 == 0:
        divisors.append(int(d))
divisors.sort()
require(len(divisors) == 12, "12289 reduced shell cardinality")

index_d = {d: i for i, d in enumerate(divisors)}
complement = {d: N0 * N0 // d for d in divisors}
require(all(complement[d] in index_d for d in divisors), "complement closure")
require(all(complement[complement[d]] == d for d in divisors), "complement involution")

n = len(divisors)
P = sp.zeros(n)
for d in divisors:
    P[index_d[complement[d]], index_d[d]] = 1

alphas = [sp.Rational(4 * N0 * d, (N0 + d) ** 2) for d in divisors]
H = sp.diag(*[sp.sqrt(alpha) for alpha in alphas])
D = sp.diag(*alphas)

matrix_equal(P.T, P, "complement symmetry")
matrix_equal(P * P, sp.eye(n), "complement square")
matrix_equal(P * H, H * P, "amplitude commutation")

F22 = sp.zeros(3)
F22[1, 1] = 1
F23 = sp.zeros(3)
F23[1, 2] = 1
F32 = sp.zeros(3)
F32[2, 1] = 1
F33 = sp.zeros(3)
F33[2, 2] = 1

N21 = 2 * sp.kronecker_product(H * P, F32)
N12 = 2 * sp.kronecker_product(H * P, F23)
matrix_equal(N21.T, N12, "transpose channel")
matrix_equal(N21.T * N21, 4 * sp.kronecker_product(D, F22), "weighted source")
matrix_equal(N21 * N21.T, 4 * sp.kronecker_product(D, F33), "weighted range")

Hinv = sp.diag(*[1 / sp.sqrt(alpha) for alpha in alphas])
Ndag = sp.Rational(1, 2) * sp.kronecker_product(Hinv * P, F23)
source = sp.kronecker_product(sp.eye(n), F22)
target = sp.kronecker_product(sp.eye(n), F33)
matrix_equal(Ndag * N21, source, "Moore-Penrose source")
matrix_equal(N21 * Ndag, target, "Moore-Penrose range")
matrix_equal(N21 * Ndag * N21, N21, "first Penrose identity")
matrix_equal(Ndag * N21 * Ndag, Ndag, "second Penrose identity")

U21 = sp.kronecker_product(P, F32)
polar_weight = 2 * sp.kronecker_product(H, F22)
matrix_equal(U21 * polar_weight, N21, "polar carrier factorization")
matrix_equal(U21.T * U21, source, "polar source")
matrix_equal(U21 * U21.T, target, "polar range")

incidence = N21.applyfunc(lambda entry: 0 if entry == 0 else 1)
matrix_equal(incidence, U21, "Boolean incidence")

alpha_sum = sum(alphas, sp.Rational(0))
require(sp.simplify(sp.trace(D) - alpha_sum) == 0, "trace amplitude")
require(sp.simplify(sp.trace(N21.T * N21) - 4 * alpha_sum) == 0, "Hilbert-Schmidt amplitude")

# The actual endpoint edge C_{0+}=e_{b_1}e_{b_0}^T selects the
# amplitude carrier.  Bit 1 is the first two-state basis vector and
# bit 0 is the second, as in the endpoint table in the manuscript.
bit_index = {1: 0, 0: 1}
status_bits = {
    "empty": (0, 0),
    "exterior only": (0, 1),
    "middle only": (1, 0),
    "both": (1, 1),
}
status_expected = {
    "exterior only": N12,
    "middle only": N21,
    "both": 2 * sp.kronecker_product(H * P, F22),
}
Jpartial = sp.kronecker_product(sp.eye(n), F22 - F33)

for status, (b0, b1) in status_bits.items():
    C = sp.zeros(2)
    C[bit_index[b1], bit_index[b0]] = 1
    embedded = sp.zeros(3)
    for row in range(2):
        for col in range(2):
            embedded[row + 1, col + 1] = C[row, col]

    occupied = int(status != "empty")
    Nstatus = occupied * 2 * sp.kronecker_product(H * P, embedded)
    Ustatus = occupied * sp.kronecker_product(P, embedded)

    if status == "empty":
        matrix_equal(Nstatus, sp.zeros(3 * n), "empty selected carrier")
    else:
        matrix_equal(Nstatus, status_expected[status], f"{status} selected carrier")

        Nstatus_dag = (
            sp.Rational(1, 2)
            * sp.kronecker_product(Hinv * P, embedded.T)
        )
        selected_source = sp.kronecker_product(
            sp.eye(n), embedded.T * embedded
        )
        selected_range = sp.kronecker_product(
            sp.eye(n), embedded * embedded.T
        )
        matrix_equal(
            Nstatus_dag * Nstatus,
            selected_source,
            f"{status} selected source",
        )
        matrix_equal(
            Nstatus * Nstatus_dag,
            selected_range,
            f"{status} selected range",
        )
        matrix_equal(
            Ustatus.T * Ustatus,
            selected_source,
            f"{status} polar source",
        )
        matrix_equal(
            Ustatus * Ustatus.T,
            selected_range,
            f"{status} polar range",
        )

    direction = b1 - b0
    commutator = Jpartial * Nstatus - Nstatus * Jpartial
    matrix_equal(
        commutator,
        2 * direction * Nstatus,
        f"{status} endpoint commutator",
    )
    selected_energy = sp.Rational(1, 4) * sp.trace(
        commutator.T * commutator
    )
    labelled_energy = 2 * direction**2
    require(
        sp.simplify(
            selected_energy - 2 * alpha_sum * labelled_energy
        )
        == 0,
        f"{status} amplitude-weighted directional energy",
    )

# Origin-resolved certificate coordinates and their exact divisor map.
ainv = pow(a, -1, int(R0))
pinv = pow(p, -1, int(R0))
targets = {0: (-p) % R0, 1: (-1) % R0, 2: (-pinv) % R0}
X = []
for j in range(3):
    for u in sp.divisors(a * a):
        if (int(u) * ainv) % R0 == targets[j]:
            X.append((j, int(u)))
X.sort()
require(len(X) == 12, "origin-resolved cardinality")

theta = {(j, u): (p**j) * u for j, u in X}
require(sorted(theta.values()) == divisors, "certificate-divisor bijection")
for j, u in X:
    reflected = (2 - j, a * a // u)
    require(reflected in theta, "origin complement closure")
    require(theta[reflected] == complement[theta[(j, u)]], "involution intertwiner")

index_x = {x: i for i, x in enumerate(X)}
PX = sp.zeros(n)
Theta = sp.zeros(n)
for x in X:
    reflected = (2 - x[0], a * a // x[1])
    PX[index_x[reflected], index_x[x]] = 1
    Theta[index_d[theta[x]], index_x[x]] = 1

matrix_equal(Theta.T * Theta, sp.eye(n), "certificate linearization")
matrix_equal(Theta.T * P * Theta, PX, "certificate involution conjugacy")
Theta3 = sp.kronecker_product(Theta, sp.eye(3))
matrix_equal(
    Theta3.T * U21 * Theta3,
    sp.kronecker_product(PX, F32),
    "12289 four-channel carrier intertwiner",
)

pair_count = sum(1 for d in divisors if d < N0)
require(pair_count == 6, "ordered complement-pair count")

lines = [
    "PASS: amplitude-retaining polar carrier of the 12289 reduced shell",
    f"reduced data: R0={R0}, N0={N0}",
    f"certificate count={n}, complement-pair count={pair_count}",
    "the complement permutation commutes with the full diagonal Lorentz-amplitude operator",
    "the directed and transposed channels retain every exact alpha_d amplitude",
    "the Moore-Penrose products recover the complete E22 source and E33 range carriers",
    "the polar partial-isometry factor is the complement permutation tensor E32",
    "the split-zero Boolean incidence is exactly that polar carrier",
    "the squared Hilbert-Schmidt norm is four times the all-shell amplitude",
    "the endpoint-selected carrier is E23, E32, or E22 for exterior-only, middle-only, or both-channel support",
    "the endpoint commutator retains the exact amplitude and equals twice the signed endpoint difference",
    "the amplitude-weighted directional energy is twice the all-shell amplitude times the labelled energy",
    "the map (j,u) -> 12289^j u is a bijection and intertwines both complement involutions",
    "the resulting 12289 polar carrier is exactly the complete four-channel carrier",
]

print("\n".join(lines))

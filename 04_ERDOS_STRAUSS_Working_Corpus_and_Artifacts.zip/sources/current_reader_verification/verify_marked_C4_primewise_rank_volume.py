"""Exact certificate for the primewise marked C4 rank-volume identities."""

from fractions import Fraction
from itertools import product


LOCAL_ROWS = (
    (0, 0, 0),
    (1, 0, 1),
    (0, 1, 1),
    (1, 1, 2),
)


def shell_options(max_weight: int):
    yield (0, 0, 0, 0)
    for beta_1, beta_2, rank in LOCAL_ROWS[1:]:
        for weight in range(1, max_weight + 1):
            yield (beta_1, beta_2, rank, weight)


checked_packets = 0
for packet in product(tuple(shell_options(4)), repeat=3):
    q_total = 0
    null_total = 0
    timelike_total = 0
    marked_total = 0

    for beta_1, beta_2, rank, weight in packet:
        visible = (beta_1 + beta_2) % 2
        hidden = beta_1 * beta_2
        class_lift = visible + 2 * hidden

        assert class_lift == rank
        q_total += weight
        null_total += weight * visible
        timelike_total += weight * hidden
        marked_total += 3 * weight * class_lift

    log_volume = 6 * q_total

    assert q_total == null_total + timelike_total
    assert marked_total == 3 * (null_total + 2 * timelike_total)
    assert null_total == 2 * q_total - marked_total // 3
    assert timelike_total == marked_total // 3 - q_total
    assert 3 * q_total <= marked_total <= 6 * q_total
    assert marked_total <= log_volume <= 2 * marked_total
    assert (marked_total == 3 * q_total) == (timelike_total == 0)
    assert (marked_total == 6 * q_total) == (null_total == 0)
    assert (marked_total > 0) == (q_total > 0)
    if q_total > 0:
        mean_rank = Fraction(marked_total, 3 * q_total)
        assert mean_rank == 1 + Fraction(timelike_total, q_total)
        assert Fraction(1) <= mean_rank <= Fraction(2)

    checked_packets += 1


print("PASS: primewise marked C4 rank-volume reconstruction")
print(f"{checked_packets} exact three-shell packets were checked")
print("Q=N+T and C/3=N+2T recover both support multiplicities")
print("3Q <= C <= 6Q with exact null and timelike equality cases")
print("C <= log2(Vol) <= 2C and C>0 iff Q>0")

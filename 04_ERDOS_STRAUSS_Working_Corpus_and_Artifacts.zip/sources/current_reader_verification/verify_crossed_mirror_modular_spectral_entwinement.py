from sympy import I, Matrix, eye, factor, kronecker_product, sqrt, symbols


def require_matrix_equal(left, right, message):
    difference = left - right
    if any(entry != 0 for entry in difference):
        raise AssertionError(message)


P_L = Matrix(
    [
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, 0, 0, 1],
        [0, 1, 0, 0],
    ]
)
P_R = Matrix(
    [
        [1, 0, 0, 0],
        [0, 0, 1, 0],
        [0, 1, 0, 0],
        [0, 0, 0, 1],
    ]
)

C_3 = P_L[1:4, 1:4]
S_3 = P_R[1:4, 1:4]
one_plus_C3 = Matrix.diag(Matrix([[1]]), C_3)
one_plus_S3 = Matrix.diag(Matrix([[1]]), S_3)

require_matrix_equal(P_L, one_plus_C3, "P_L is not 1 plus the three-cycle")
require_matrix_equal(P_R, one_plus_S3, "P_R is not 1 plus the reflection")
require_matrix_equal(C_3**3, eye(3), "the three-cycle does not have order three")
require_matrix_equal(S_3**2, eye(3), "the reflection does not have order two")
require_matrix_equal(S_3 * C_3 * S_3, C_3**-1, "the D3 relation fails")

X_2 = Matrix([[0, 1], [1, 0]])
Z_2 = Matrix([[1, 0], [0, -1]])
I_4 = eye(4)

Theta_8 = kronecker_product(X_2, I_4)
J_8 = kronecker_product(X_2, P_R)
U_delta = kronecker_product(eye(2), P_L)
U_nabla = Matrix.diag(P_L, P_L**-1)

require_matrix_equal(Theta_8**2, eye(8), "pure exchange is not involutive")
require_matrix_equal(J_8**2, eye(8), "crossed mirror is not involutive")
require_matrix_equal(J_8.T, J_8, "crossed mirror is not symmetric")
require_matrix_equal(J_8 * U_nabla, U_nabla * J_8, "crossed mirror does not commute with U_nabla")

A_3 = (C_3 - C_3**-1) / (I * sqrt(3))
A_4 = Matrix.diag(Matrix([[0]]), A_3)
K_2 = kronecker_product(Z_2, I_4)
K_3 = kronecker_product(Z_2, A_4)

require_matrix_equal(A_3.H, A_3, "the three-state generator is not self-adjoint")
require_matrix_equal(K_2.H, K_2, "the sheet generator is not self-adjoint")
require_matrix_equal(K_3.H, K_3, "the crossed phase generator is not self-adjoint")
require_matrix_equal(K_2 * K_3, K_3 * K_2, "the two generators do not commute")
require_matrix_equal(
    (U_nabla - U_nabla**-1) / (I * sqrt(3)),
    K_3,
    "the crossed phase generator does not come from U_nabla",
)

# For an antiunitary C_8 = J_8 K_0, conjugation of a matrix A is
# A -> J_8 * conjugate(A) * J_8.
require_matrix_equal(
    J_8 * K_2.conjugate() * J_8,
    -K_2,
    "the antiunitary does not reverse the sheet generator",
)
require_matrix_equal(
    J_8 * K_3.conjugate() * J_8,
    -K_3,
    "the antiunitary does not reverse the crossed phase generator",
)

expected_A3_spectrum = {-1: 1, 0: 1, 1: 1}
if A_3.eigenvals() != expected_A3_spectrum:
    raise AssertionError(f"unexpected A_3 spectrum: {A_3.eigenvals()}")

expected_A4_spectrum = {-1: 1, 0: 2, 1: 1}
if A_4.eigenvals() != expected_A4_spectrum:
    raise AssertionError(f"unexpected A_4 spectrum: {A_4.eigenvals()}")

s, t, lam = symbols("s t lam", real=True)
K_st = s * K_2 + t * K_3
actual_characteristic = factor((lam * eye(8) - K_st).det(method="berkowitz"))
expected_characteristic = factor(
    (lam - s) ** 2
    * (lam + s) ** 2
    * (lam - s - t)
    * (lam - s + t)
    * (lam + s + t)
    * (lam + s - t)
)
if factor(actual_characteristic - expected_characteristic) != 0:
    raise AssertionError(
        "unexpected joint characteristic polynomial:\n"
        f"actual={actual_characteristic}\nexpected={expected_characteristic}"
    )

require_matrix_equal(
    J_8 * K_st.conjugate() * J_8,
    -K_st,
    "the antiunitary does not reverse the joint generator",
)

print("PASS: crossed-mirror modular spectral entwinement")
print("P_L and P_R split exactly as 1 plus a three-state orbit")
print("the eight-cell carrier is C2 tensor (C1 direct-sum C3)")
print("K2 and K3 are commuting self-adjoint generators")
print("K3 is the Hermitian generator of the antidiagonal phase U_nabla")
print("the crossed antiunitary reverses K2, K3, and every real linear combination")
print("the joint generator has four reciprocal spectral pairs after exponentiation")

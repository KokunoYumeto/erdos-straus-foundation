from itertools import product


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def prime_divisors(n):
    result = set()
    d = 2
    while d * d <= n:
        while n % d == 0:
            result.add(d)
            n //= d
        d += 1
    if n > 1:
        result.add(n)
    return result


def primitive_root(prime):
    order = prime - 1
    divisors = prime_divisors(order)
    for candidate in range(2, prime):
        if all(pow(candidate, order // d, prime) != 1 for d in divisors):
            return candidate
    raise AssertionError(f"no primitive root modulo {prime}")


def logarithm_table(prime, generator):
    table = {}
    value = 1
    for exponent in range(prime - 1):
        table[value] = exponent
        value = value * generator % prime
    if len(table) != prime - 1:
        raise AssertionError("generator does not produce the full unit group")
    return table


def reduced_middle_box(half_logs, modulus):
    return {
        sum(coefficient * logarithm for coefficient, logarithm
            in zip(coefficients, half_logs)) % modulus
        for coefficients in product((-1, 0, 1), repeat=len(half_logs))
    }


def reduced_exterior_box(half_logs, modulus):
    return {
        sum(coefficient * logarithm for coefficient, logarithm
            in zip(coefficients, half_logs)) % modulus
        for coefficients in product((0, 1, 2), repeat=len(half_logs))
    }


safe_primes = []
for residual in range(7, 1001):
    if not is_prime(residual):
        continue
    half_order = (residual - 1) // 2
    if half_order % 2 == 1 and is_prime(half_order):
        safe_primes.append(residual)

for residual in safe_primes:
    quadratic_residues = {
        value * value % residual
        for value in range(1, residual)
    }

    def character(value):
        return 1 if value % residual in quadratic_residues else -1

    def sheet_map(value):
        sign = character(value)
        return sign, sign * value % residual

    images = {
        sheet_map(value)
        for value in range(1, residual)
    }
    expected_images = {
        (sign, residue)
        for sign in (-1, 1)
        for residue in quadratic_residues
    }
    assert images == expected_images
    for left in range(1, residual):
        for right in range(1, residual):
            sign_left, residue_left = sheet_map(left)
            sign_right, residue_right = sheet_map(right)
            assert sheet_map(left * right % residual) == (
                sign_left * sign_right,
                residue_left * residue_right % residual,
            )

    inverse_four = pow(4, -1, residual)
    assert sheet_map(residual - 1) == (-1, 1)
    assert sheet_map((-inverse_four) % residual) == (
        -1,
        inverse_four,
    )

report("canonical Legendre-sheet isomorphism and target images", True)

for residual in safe_primes:
    half_order = (residual - 1) // 2
    generator = primitive_root(residual)
    logarithms = logarithm_table(residual, generator)
    log_two = logarithms[2]
    middle_target = logarithms[residual - 1]
    exterior_target = logarithms[
        (-pow(4, -1, residual)) % residual
    ]
    assert middle_target == half_order
    assert exterior_target == (half_order - 2 * log_two) % (2 * half_order)
    assert middle_target % 2 == 1
    assert exterior_target % 2 == 1

report("safe-residual target logarithms and parity", True)

quadratic_residues_7 = {
    value * value % 7
    for value in range(1, 7)
}
assert quadratic_residues_7 == {1, 2, 4}
assert (-pow(4, -1, 7)) % 7 == 5
assert (
    (-1, 1),
    (-1, 2),
) == (
    (-1, 1),
    (-1, (-5) % 7),
)
report("R=7 exact C2-sheet and C3-phase targets", True)


profiles_checked = 0
for residual in [r for r in safe_primes if r <= 107]:
    half_order = (residual - 1) // 2
    generator = primitive_root(residual)
    logarithms = logarithm_table(residual, generator)
    log_two = logarithms[2]
    middle_target = half_order
    exterior_target = (half_order - 2 * log_two) % (2 * half_order)

    for odd_log in range(1, 2 * half_order, 2):
        for h1 in range(half_order):
            for h2 in range(half_order):
                half_logs = (h1, h2)
                middle_box = reduced_middle_box(half_logs, half_order)
                exterior_box = reduced_exterior_box(half_logs, half_order)

                direct_middle = any(
                    (
                        odd_coefficient * odd_log
                        + 2 * d1 * h1
                        + 2 * d2 * h2
                    ) % (2 * half_order) == middle_target
                    for odd_coefficient in (-1, 0, 1)
                    for d1 in (-1, 0, 1)
                    for d2 in (-1, 0, 1)
                )
                reduced_middle = (
                    ((half_order - odd_log) // 2) % half_order in middle_box
                    or ((half_order + odd_log) // 2) % half_order in middle_box
                )

                direct_exterior = any(
                    (
                        odd_coefficient * odd_log
                        + 2 * e1 * h1
                        + 2 * e2 * h2
                    ) % (2 * half_order) == exterior_target
                    for odd_coefficient in (0, 1, 2)
                    for e1 in (0, 1, 2)
                    for e2 in (0, 1, 2)
                )
                reduced_exterior = (
                    (
                        half_order
                        - 2 * log_two
                        - odd_log
                    ) // 2
                ) % half_order in exterior_box

                assert direct_middle == reduced_middle
                assert direct_exterior == reduced_exterior
                profiles_checked += 1

report("one-odd-occurrence quotient reduction", True)


residual = 107
half_order = 53
generator = 2
logarithms = logarithm_table(residual, generator)
factor_logs = {
    3: logarithms[3],
    11: logarithms[11],
    43: logarithms[43],
    47: logarithms[47],
}
expected_logs = {3: 70, 11: 22, 43: 59, 47: 66}
assert factor_logs == expected_logs

log_two = logarithms[2]
odd_log = factor_logs[43]
half_logs = (
    factor_logs[3] // 2,
    factor_logs[3] // 2,
    factor_logs[11] // 2,
    factor_logs[11] // 2,
    factor_logs[47] // 2,
)
assert log_two == 1
assert odd_log == 59
assert half_logs == (35, 35, 11, 11, 33)

middle_positive_target = ((half_order - odd_log) // 2) % half_order
middle_negative_target = ((half_order + odd_log) // 2) % half_order
exterior_reduced_target = (
    (half_order - 2 * log_two - odd_log) // 2
) % half_order
assert (
    middle_positive_target,
    middle_negative_target,
    exterior_reduced_target,
) == (50, 3, 49)

middle_positive_solutions = [
    (beta_3, beta_11, beta_47)
    for beta_3 in range(-2, 3)
    for beta_11 in range(-2, 3)
    for beta_47 in range(-1, 2)
    if (
        35 * beta_3 + 11 * beta_11 + 33 * beta_47
    ) % 53 == middle_positive_target
]
middle_negative_solutions = [
    (beta_3, beta_11, beta_47)
    for beta_3 in range(-2, 3)
    for beta_11 in range(-2, 3)
    for beta_47 in range(-1, 2)
    if (
        35 * beta_3 + 11 * beta_11 + 33 * beta_47
    ) % 53 == middle_negative_target
]
exterior_solutions = [
    (epsilon_3, epsilon_11, epsilon_47)
    for epsilon_3 in range(5)
    for epsilon_11 in range(5)
    for epsilon_47 in range(3)
    if (
        35 * epsilon_3 + 11 * epsilon_11 + 33 * epsilon_47
    ) % 53 == exterior_reduced_target
]

assert middle_positive_solutions == [(2, 0, 1)]
assert middle_negative_solutions == [(-2, 0, -1)]
assert exterior_solutions == []

centered_middle = sorted(
    (beta_3, beta_11, beta_43, beta_47)
    for beta_3 in range(-2, 3)
    for beta_11 in range(-2, 3)
    for beta_43 in range(-1, 2)
    for beta_47 in range(-1, 2)
    if (
        70 * beta_3
        + 22 * beta_11
        + 59 * beta_43
        + 66 * beta_47
    ) % 106 == 53
)
centered_exterior = [
    (beta_3, beta_11, beta_43, beta_47)
    for beta_3 in range(-2, 3)
    for beta_11 in range(-2, 3)
    for beta_43 in range(-1, 2)
    for beta_47 in range(-1, 2)
    if (
        70 * beta_3
        + 22 * beta_11
        + 59 * beta_43
        + 66 * beta_47
    ) % 106 == 60
]
assert centered_middle == [(-2, 0, -1, -1), (2, 0, 1, 1)]
assert centered_exterior == []

log_a = (
    2 * factor_logs[3]
    + 2 * factor_logs[11]
    + factor_logs[43]
    + factor_logs[47]
) % 106
unshifted_exterior_target = (half_order - 2 * log_two) % 106
centered_exterior_target = (unshifted_exterior_target - log_a) % 106
assert (log_a, unshifted_exterior_target, centered_exterior_target) == (
    97,
    51,
    60,
)

report("R=107 unique odd factor-log occurrence", True)
report("R=107 reduced middle targets and unique solutions", True)
report("R=107 reduced exterior obstruction", True)
report("R=107 centered target transport", True)

print(f"safe residual primes checked through 1000: {len(safe_primes)}")
print(f"one-odd profiles checked through R=107: {profiles_checked}")
print(f"safe residual primes: {tuple(safe_primes)}")
print(f"R=107 reduced targets: {(50, 3, 49)}")
print(
    "R=107 centered middle vectors: "
    f"{tuple(centered_middle)}"
)
print(
    "R=107 exterior targets: "
    f"unshifted={unshifted_exterior_target}, "
    f"centered={centered_exterior_target}"
)

import itertools

import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def matrix_equal(left, right, label):
    require(left.shape == right.shape, f"{label}: shape")
    for entry in left - right:
        if sp.simplify(entry) != 0:
            raise AssertionError(f"{label}: {sp.factor(entry)}")


p = 12289
a = 3075
R = 4 * a - p
N = p * a
g = sp.gcd(R, N)
R0 = R // g
N0 = N // g
require((R0, N0) == (11, 37788675), "reduced shell")

divisors = sorted(
    int(d)
    for d in sp.divisors(N0 * N0)
    if (d + N0) % R0 == 0
)
require(len(divisors) == 12, "reduced divisor count")
index_d = {d: i for i, d in enumerate(divisors)}
complement = {d: N0 * N0 // d for d in divisors}

P = sp.zeros(len(divisors))
for d in divisors:
    P[index_d[complement[d]], index_d[d]] = 1

alpha_d = [
    sp.Rational(4 * N0 * d, (N0 + d) ** 2)
    for d in divisors
]
Hdiv = sp.diag(*[sp.sqrt(value) for value in alpha_d])
Hdiv_inv = sp.diag(*[1 / sp.sqrt(value) for value in alpha_d])

low_representatives = [d for d in divisors if d < N0]
require(len(low_representatives) == 6, "complement orbit count")
alpha_orbit = [
    sp.Rational(4 * N0 * d, (N0 + d) ** 2)
    for d in low_representatives
]
q = len(alpha_orbit)
Horb = sp.diag(*[sp.sqrt(value) for value in alpha_orbit])
Horb_inv = sp.diag(*[1 / sp.sqrt(value) for value in alpha_orbit])
Dorb = sp.diag(*alpha_orbit)
alpha_sum = 2 * sum(alpha_orbit, sp.Rational(0))
require(
    sp.simplify(alpha_sum - sum(alpha_d, sp.Rational(0))) == 0,
    "orbit-to-divisor amplitude sum",
)

I3 = sp.eye(3)
Jpath = sp.kronecker_product(
    sp.eye(q),
    sp.diag(-1, 1),
    I3,
)

F22 = sp.zeros(3)
F22[1, 1] = 1
F23 = sp.zeros(3)
F23[1, 2] = 1
F32 = sp.zeros(3)
F32[2, 1] = 1
F33 = sp.zeros(3)
F33[2, 2] = 1
Jdiv = sp.kronecker_product(sp.eye(2 * q), F22 - F33)

status_bits = {
    "empty": (0, 0),
    "exterior only": (0, 1),
    "middle only": (1, 0),
    "both": (1, 1),
}

E21 = sp.zeros(2)
E21[1, 0] = 1
E12 = sp.zeros(2)
E12[0, 1] = 1
E22 = sp.zeros(2)
E22[1, 1] = 1
expected_path_cells = {
    "exterior only": E21,
    "middle only": E12,
    "both": E22,
}

bit_index_div = {1: 0, 0: 1}
polar_rank_energy_by_status = {}
timelike_operator_energy_by_status = {}

for status, (b0, b1) in status_bits.items():
    occupied = int(status != "empty")
    direction = b1 - b0

    Cpath = sp.zeros(2)
    Cpath[b1, b0] = 1
    W = occupied * 2 * sp.kronecker_product(Horb, Cpath, I3)

    if status == "empty":
        matrix_equal(W, sp.zeros(6 * q), "empty path carrier")
        polar_rank_energy_by_status[status] = (0, sp.Rational(0))
        timelike_operator_energy_by_status[status] = sp.Rational(0)
    else:
        matrix_equal(
            Cpath,
            expected_path_cells[status],
            f"{status} order-forced path cell",
        )
        Wdag = (
            sp.Rational(1, 2)
            * sp.kronecker_product(Horb_inv, Cpath.T, I3)
        )
        path_source = sp.kronecker_product(
            sp.eye(q), Cpath.T * Cpath, I3
        )
        path_range = sp.kronecker_product(
            sp.eye(q), Cpath * Cpath.T, I3
        )
        matrix_equal(Wdag * W, path_source, f"{status} path source")
        matrix_equal(W * Wdag, path_range, f"{status} path range")
        require(W.rank() == 3 * q, f"{status} path rank")
        require(
            sp.simplify(sp.trace(W.T * W) - 6 * alpha_sum) == 0,
            f"{status} path norm",
        )

        source_modulus = sp.Rational(1, 4) * W.T * W
        range_modulus = sp.Rational(1, 4) * W * W.T
        selected_source = sp.zeros(6 * q, 3 * q)
        selected_range = sp.zeros(6 * q, 3 * q)
        for orbit in range(q):
            for rotation in range(3):
                restricted_index = 3 * orbit + rotation
                selected_source[6 * orbit + 3 * b0 + rotation, restricted_index] = 1
                selected_range[6 * orbit + 3 * b1 + rotation, restricted_index] = 1

        selected_path_modulus = sp.kronecker_product(Dorb, I3)
        matrix_equal(
            selected_source.T * source_modulus * selected_source,
            selected_path_modulus,
            f"{status} selected source modulus",
        )
        matrix_equal(
            selected_range.T * range_modulus * selected_range,
            selected_path_modulus,
            f"{status} selected range modulus",
        )

        polar = sp.kronecker_product(sp.eye(q), Cpath, I3)
        matrix_equal(polar.T * polar, path_source, f"{status} polar source")
        matrix_equal(polar * polar.T, path_range, f"{status} polar range")
        matrix_equal(
            polar * source_modulus * polar.T,
            range_modulus,
            f"{status} polar modulus transport",
        )
        matrix_equal(
            Jpath * polar - polar * Jpath,
            2 * (b1 - b0) * polar,
            f"{status} polar signed grading",
        )
        polar_commutator = Jpath * polar - polar * Jpath
        polar_anticommutator = Jpath * polar + polar * Jpath
        matrix_equal(
            polar_anticommutator,
            2 * (b0 + b1 - 1) * polar,
            f"{status} polar grading anticommutator",
        )
        polar_energy = sp.Rational(1, 4) * sp.trace(
            polar_commutator.T * polar_commutator
        )
        timelike_energy = sp.Rational(1, 4) * sp.trace(
            polar_anticommutator.T * polar_anticommutator
        )
        selected_rank = selected_path_modulus.rank()
        require(selected_rank == 3 * q, f"{status} selected modulus rank")
        require(
            polar_energy == 3 * q * direction**2,
            f"{status} polar rank energy",
        )
        require(
            2 * polar_energy == 3 * q * (2 * direction**2),
            f"{status} polar-labelled energy relation",
        )
        require(
            0 <= polar_energy <= selected_rank,
            f"{status} polar rank bound",
        )
        require(
            timelike_energy == 3 * q * (b0 + b1 - 1) ** 2,
            f"{status} timelike anticommutator energy",
        )
        require(
            polar_energy + timelike_energy == selected_rank,
            f"{status} commutator-anticommutator rank exhaustion",
        )
        polar_rank_energy_by_status[status] = (selected_rank, polar_energy)
        timelike_operator_energy_by_status[status] = timelike_energy

        stable_flip = sp.zeros(6 * q)
        for orbit in range(q):
            for rotation in range(3):
                for sheet in range(2):
                    source_index = 6 * orbit + 2 * rotation + sheet
                    target_index = 6 * orbit + 3 * sheet + rotation
                    stable_flip[target_index, source_index] = 1
        divisor_modulus = sp.kronecker_product(Dorb, sp.eye(2))
        matrix_equal(
            stable_flip
            * sp.kronecker_product(selected_path_modulus, sp.eye(2))
            * stable_flip.T,
            sp.kronecker_product(divisor_modulus, I3),
            f"{status} selected stable C3-C2 transfer",
        )
        require(
            sp.simplify(
                2 * sp.trace(selected_path_modulus)
                - 3 * sp.trace(divisor_modulus)
            )
            == 0,
            f"{status} selected target coefficient and null mass transfer",
        )

    path_commutator = Jpath * W - W * Jpath
    matrix_equal(
        path_commutator,
        2 * direction * W,
        f"{status} path commutator",
    )
    path_energy = sp.Rational(1, 4) * sp.trace(
        path_commutator.T * path_commutator
    )
    labelled_energy = 2 * direction**2
    require(
        sp.simplify(path_energy - 3 * alpha_sum * labelled_energy) == 0,
        f"{status} path energy",
    )

    Cdiv = sp.zeros(2)
    Cdiv[bit_index_div[b1], bit_index_div[b0]] = 1
    embedded = sp.zeros(3)
    for row in range(2):
        for col in range(2):
            embedded[row + 1, col + 1] = Cdiv[row, col]
    Nstatus = occupied * 2 * sp.kronecker_product(Hdiv * P, embedded)

    divisor_commutator = Jdiv * Nstatus - Nstatus * Jdiv
    divisor_energy = sp.Rational(1, 4) * sp.trace(
        divisor_commutator.T * divisor_commutator
    )

    require(
        2 * W.rank() == 3 * Nstatus.rank(),
        f"{status} rank multiplicity",
    )
    require(
        sp.simplify(
            2 * sp.trace(W.T * W)
            - 3 * sp.trace(Nstatus.T * Nstatus)
        )
        == 0,
        f"{status} norm multiplicity",
    )
    require(
        sp.simplify(2 * path_energy - 3 * divisor_energy) == 0,
        f"{status} energy multiplicity",
    )

require(
    polar_rank_energy_by_status["empty"] == (0, 0),
    "empty polar rank-energy pair",
)
for status in ("exterior only", "middle only"):
    require(
        polar_rank_energy_by_status[status] == (3 * q, 3 * q),
        f"{status} polar rank-energy pair",
    )
require(
    polar_rank_energy_by_status["both"] == (3 * q, 0),
    "both-channel polar rank-energy pair",
)

target_masses_by_status = {
    "empty": (sp.Rational(0), sp.Rational(0)),
    "exterior only": (sp.Rational(0), sp.Rational(5, 3)),
    "middle only": (sp.Rational(7, 4), sp.Rational(0)),
    "both": (sp.Rational(7, 4), sp.Rational(5, 3)),
}
for status, (alpha1, alpha2) in target_masses_by_status.items():
    lambda_plus = alpha2 + alpha1 / 2
    lambda_minus = alpha2 - alpha1 / 2
    target_lorentz_matrix = sp.Matrix(
        [[lambda_plus, lambda_minus], [lambda_minus, lambda_plus]]
    )
    target_rank = target_lorentz_matrix.rank()
    target_determinant = sp.factor(target_lorentz_matrix.det())
    polar_rank_energy = polar_rank_energy_by_status[status][1]
    occupied_orbit_count = 0 if status == "empty" else q
    require(
        polar_rank_energy
        == 3 * occupied_orbit_count * target_rank * (2 - target_rank),
        f"{status} polar-Lorentz rank formula",
    )
    require(
        (polar_rank_energy > 0)
        == (target_lorentz_matrix != sp.zeros(2) and target_determinant == 0),
        f"{status} polar nonzero null-boundary criterion",
    )
    if target_rank == 1:
        b0, b1 = status_bits[status]
        require(
            sp.factor(lambda_minus / lambda_plus - (b1 - b0)) == 0,
            f"{status} polar direction equals Lorentz null-ray sign",
        )

typewise_amplitudes_by_status = {
    "empty": ([], []),
    "exterior only": ([sp.Rational(5, 3)], []),
    "middle only": ([], [sp.Rational(7, 4)]),
    "both": ([sp.Rational(5, 3)], [sp.Rational(7, 4)]),
}
positive_spectral_functions = {
    "zeroth moment": lambda value: sp.Rational(1),
    "second moment": lambda value: value**2,
    "heat": lambda value: sp.exp(-value),
    "resolvent": lambda value: 1 / (sp.Rational(11) - value),
}
for status, (amplitudes_02, amplitudes_11) in typewise_amplitudes_by_status.items():
    alpha1, alpha2 = target_masses_by_status[status]
    base_lambda_plus = alpha2 + alpha1 / 2
    base_lambda_minus = alpha2 - alpha1 / 2
    base_matrix = sp.Matrix(
        [
            [base_lambda_plus, base_lambda_minus],
            [base_lambda_minus, base_lambda_plus],
        ]
    )
    base_rank = base_matrix.rank()
    for function_name, spectral_function in positive_spectral_functions.items():
        eta_02 = sum(
            (spectral_function(value) for value in amplitudes_02),
            sp.Rational(0),
        )
        eta_11 = sum(
            (spectral_function(value) for value in amplitudes_11),
            sp.Rational(0),
        )
        spectral_plus = eta_02 + eta_11
        spectral_minus = eta_02 - eta_11
        spectral_matrix = sp.Matrix(
            [
                [spectral_plus, spectral_minus],
                [spectral_minus, spectral_plus],
            ]
        )
        require(
            spectral_matrix.rank() == base_rank,
            f"{status} {function_name} Lorentz-rank preservation",
        )
        if base_rank == 1:
            b0, b1 = status_bits[status]
            require(
                sp.factor(
                    spectral_minus / spectral_plus - (b1 - b0)
                )
                == 0,
                f"{status} {function_name} directed null-ray ratio",
            )

target_bits_by_status = {
    "empty": (0, 0),
    "exterior only": (0, 1),
    "middle only": (1, 0),
    "both": (1, 1),
}
for status, (beta1, beta2) in target_bits_by_status.items():
    b0, b1 = status_bits[status]
    endpoint_direction = b1 - b0
    occupied_orbit_count = 0 if status == "empty" else q
    polar_rank = 3 * occupied_orbit_count * (beta1 - beta2) ** 2
    timelike_rank = 3 * occupied_orbit_count * beta1 * beta2
    total_path_rank = 3 * occupied_orbit_count
    require(
        (b0, b1) == (beta1, beta2),
        f"{status} split-zero endpoint-pair identification",
    )
    require(
        endpoint_direction == beta2 - beta1,
        f"{status} split-zero endpoint-direction identification",
    )
    require(
        polar_rank == polar_rank_energy_by_status[status][1],
        f"{status} split-zero polar rank",
    )
    require(
        polar_rank + timelike_rank == total_path_rank,
        f"{status} polar-timelike path-rank decomposition",
    )
    require(
        timelike_rank == timelike_operator_energy_by_status[status],
        f"{status} split-zero timelike anticommutator rank",
    )

mu = [0] * 10
for beta_3, beta_5, beta_41 in itertools.product(
    range(-1, 2),
    range(-2, 3),
    range(-1, 2),
):
    residue = (8 * beta_3 + 4 * beta_5 + 3 * beta_41) % 10
    mu[residue] += 1
require(
    mu == [3, 6, 3, 6, 3, 6, 3, 6, 3, 6],
    "12289 full divisor convolution",
)
q02 = mu[4]
q11 = mu[5] // 2
require(mu[5] % 2 == 0, "middle target coefficient parity")
require((q02, q11) == (3, 3), "12289 two-target extraction")
require(q02 + q11 == q, "target extraction equals complement-orbit rank")
require(sum(mu) == 3 * 5 * 3, "full convolution positive mass")

target_orbit_counts_by_status = {
    "empty": (0, 0),
    "exterior only": (q, 0),
    "middle only": (0, q),
    "both": (q02, q11),
}
modular_path_dimension = 6
for status, (status_q02, status_q11) in target_orbit_counts_by_status.items():
    shell_q = status_q02 + status_q11
    b0, b1 = status_bits[status]
    require(
        b0 == int(status_q11 > 0) and b1 == int(status_q02 > 0),
        f"{status} convolution target support bits",
    )
    if shell_q == 0:
        require(status == "empty", "zero extracted target is empty")
        continue

    modular_projection = sp.kronecker_product(
        sp.eye(shell_q),
        sp.diag(1, *([0] * (modular_path_dimension - 1))),
    )
    modular_projection_amplified = sp.kronecker_product(
        modular_projection,
        sp.eye(3),
    )
    path_dimension = shell_q * 2 * 3
    modular_dimension = shell_q * modular_path_dimension * 3
    sheet_maps = {}
    for endpoint, bit in ((0, b0), (1, b1)):
        sheet_map = sp.zeros(path_dimension, modular_dimension)
        for orbit in range(shell_q):
            for rotation in range(3):
                path_index = 6 * orbit + 3 * bit + rotation
                modular_index = (
                    18 * orbit
                    + 3 * 0
                    + rotation
                )
                sheet_map[path_index, modular_index] = 1
        sheet_maps[endpoint] = sheet_map
        final_projection = sp.kronecker_product(
            sp.eye(shell_q),
            sp.diag(*(
                [1 if index == bit else 0 for index in range(2)]
            )),
            sp.eye(3),
        )
        matrix_equal(
            sheet_map.T * sheet_map,
            modular_projection_amplified,
            f"{status} modular amplified initial projection",
        )
        matrix_equal(
            sheet_map * sheet_map.T,
            final_projection,
            f"{status} selected-sheet final projection",
        )

    modular_transition = sheet_maps[1] * sheet_maps[0].T
    expected_transition = sp.zeros(path_dimension)
    for orbit in range(shell_q):
        for rotation in range(3):
            source_index = 6 * orbit + 3 * b0 + rotation
            target_index = 6 * orbit + 3 * b1 + rotation
            expected_transition[target_index, source_index] = 1
    matrix_equal(
        modular_transition,
        expected_transition,
        f"{status} modular amplification equals polar transport",
    )
    require(
        expected_transition.rank()
        == 3 * modular_projection.rank()
        == 3 * shell_q,
        f"{status} convolution-modular-polar rank chain",
    )

sample_one_sided_orbit_counts = [1, 2, 4]
sample_both_channel_orbit_counts = [3, 5]
sample_Xi = len(sample_one_sided_orbit_counts)
sample_Q = sum(sample_one_sided_orbit_counts + sample_both_channel_orbit_counts)
sample_labelled_energy = 2 * sample_Xi
sample_polar_energy = 3 * sum(sample_one_sided_orbit_counts)
sample_timelike_energy = 3 * sum(sample_both_channel_orbit_counts)
require(
    sp.Rational(3, 2) * sample_labelled_energy
    <= sample_polar_energy
    <= 3 * sample_Q,
    "primewise polar rank-direction bounds",
)
require(
    (sample_polar_energy > 0) == (sample_Xi > 0),
    "primewise polar positivity equivalence",
)
require(
    sample_polar_energy + sample_timelike_energy == 3 * sample_Q,
    "primewise polar-timelike complexity-volume decomposition",
)

sum_alpha = sum(alpha_orbit, sp.Rational(0))
product_alpha = sp.prod(alpha_orbit)
M2 = sum((value**2 for value in alpha_orbit), sp.Rational(0))
require(
    sp.factor((sum_alpha / q) ** q - product_alpha) >= 0,
    "determinant-volume lower mean bound",
)
require(
    sp.factor(q * M2 - sum_alpha**2) >= 0,
    "control-length upper mean bound",
)

equal_alpha = [sp.Rational(7, 5)] * 4
equal_sum = sum(equal_alpha, sp.Rational(0))
equal_product = sp.prod(equal_alpha)
equal_M2 = sum((value**2 for value in equal_alpha), sp.Rational(0))
require(
    (equal_sum / len(equal_alpha)) ** len(equal_alpha)
    == equal_product,
    "equal-amplitude lower equality",
)
require(
    len(equal_alpha) * equal_M2 == equal_sum**2,
    "equal-amplitude upper equality",
)

t = sp.symbols("t")
selected_path_characteristic = sp.prod(
    (t - value) ** 3 for value in alpha_orbit
)
divisor_characteristic = sp.prod(
    (t - value) ** 2 for value in alpha_orbit
)
common_stable_characteristic = sp.prod(
    (t - value) ** 6 for value in alpha_orbit
)
require(
    sp.expand(selected_path_characteristic**2 - common_stable_characteristic)
    == 0,
    "selected path squared characteristic product",
)
require(
    sp.expand(divisor_characteristic**3 - common_stable_characteristic) == 0,
    "divisor cubed characteristic product",
)

print("PASS: endpoint-selected weighted C1-C2-C3 path carrier")
print(f"reduced data: R0={R0}, N0={N0}")
print(f"complement-orbit count={q}, divisor count={2*q}")
print("the unique order map sends endpoint 0 to the low sheet and endpoint 1 to the high sheet")
print("exterior-only selects low-to-high, middle-only selects high-to-low, and both selects the high diagonal")
print("the Moore-Penrose products recover the selected path source and range")
print("the path commutator retains the signed endpoint difference and every orbit amplitude")
print("twice each path rank, squared norm, and directional energy equals three times its divisor counterpart")
print("the one-sided path energy obeys the exact determinant-volume and control-length mean bounds")
print("the selected source and range moduli recover the same orbit amplitudes on their ordered sheets")
print("the polar partial isometry transports source modulus to range modulus and retains the signed grading")
print("the polar rank-energy pair classifies empty, one-sided, and both-channel support")
print("the primewise polar energy lies between three times the one-sided-shell count and three times total orbit rank")
print("the polar energy detects the nonzero target-Lorentz null boundary and its commutator sign selects the null ray")
print("strictly positive moments, heat kernels, and resolvents preserve the Lorentz rank and directed null ray")
print("the split-zero support pair equals the ordered endpoint pair")
print("the grading commutator and anticommutator realize the XOR and AND ranks and exhaust total path rank")
print("the full divisor convolution maps through its two target coefficients to the orbit rank")
print("the C3-amplified modular unit line maps exactly to both selected sheets and their polar transition")
print("both selected sheets satisfy the exact C3-C2 stable spectral transfer")
print("the squared selected-path and cubed divisor characteristic products coincide")
print("both selected sheets transfer the aggregate target coefficient and target-null mass exactly")

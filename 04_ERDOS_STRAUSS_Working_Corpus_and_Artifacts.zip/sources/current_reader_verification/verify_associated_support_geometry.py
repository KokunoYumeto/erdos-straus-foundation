"""Exact checks for the associated finite-universe support--geometry carrier.

The script uses rational centered-simplex coordinates and finite support sets.
It does not approximate any angle or scalar.
"""

from fractions import Fraction
from itertools import permutations, product


def inverse_permutation(p):
    q = [0] * len(p)
    for i, pi in enumerate(p):
        q[pi] = i
    return tuple(q)


def act_tuple(p, x):
    """(p.x)_i = x_{p^{-1}(i)}."""
    q = inverse_permutation(p)
    return tuple(x[q[i]] for i in range(len(p)))


def act_subset(p, subset):
    return frozenset(p[i] for i in subset)


def support(x):
    return frozenset(i for i, xi in enumerate(x) if xi is not None)


def add_support_values(x, y):
    # Only support is needed: tau is additive zero, so support is union.
    return tuple(
        None if xi is None and yi is None else 0 for xi, yi in zip(x, y)
    )


def multiply_support_values(x, y):
    # tau is absorbing, so support is intersection.
    return tuple(
        0 if xi is not None and yi is not None else None
        for xi, yi in zip(x, y)
    )


def dot(x, y):
    return sum((a * b for a, b in zip(x, y)), Fraction(0))


for n in range(2, 7):
    # Unscaled centered vertices w_i=e_i-(1/n)j.  Their norm ratio gives the
    # unit-simplex Gram matrix without adjoining square roots.
    vertices = []
    for i in range(n):
        vertices.append(
            tuple(Fraction(int(i == j), 1) - Fraction(1, n) for j in range(n))
        )

    assert all(sum(v, Fraction(0)) == 0 for v in vertices)
    assert all(
        sum((vertices[i][j] for i in range(n)), Fraction(0)) == 0
        for j in range(n)
    )
    norm = Fraction(n - 1, n)
    for i in range(n):
        for j in range(n):
            expected = norm if i == j else Fraction(-1, n)
            assert dot(vertices[i], vertices[j]) == expected
            if i != j:
                assert dot(vertices[i], vertices[j]) / norm == Fraction(-1, n - 1)

    # Exhaust all frames through n=5; for n=6 use the cyclic generator and
    # reflection to keep the check deliberately small.
    if n <= 5:
        frames = permutations(range(n))
    else:
        frames = [tuple((i + 1) % n for i in range(n)), tuple(reversed(range(n)))]

    support_vectors = list(product((None, 0), repeat=n))
    for a in range(n):
        target_support = frozenset({a})
        for summands in product(support_vectors, repeat=3):
            total = summands[0]
            for term in summands[1:]:
                total = add_support_values(total, term)
            if support(total) == target_support:
                assert all(support(term) <= target_support for term in summands)

    for p in frames:
        for x in support_vectors:
            px = act_tuple(p, x)
            assert support(px) == act_subset(p, support(x))

        for x in support_vectors:
            for y in support_vectors:
                lhs_add = act_tuple(p, add_support_values(x, y))
                rhs_add = add_support_values(act_tuple(p, x), act_tuple(p, y))
                lhs_mul = act_tuple(p, multiply_support_values(x, y))
                rhs_mul = multiply_support_values(act_tuple(p, x), act_tuple(p, y))
                assert lhs_add == rhs_add
                assert lhs_mul == rhs_mul

        local_zeros = []
        for i in range(n):
            z = tuple(0 if j == i else None for j in range(n))
            local_zeros.append(z)
            assert act_tuple(p, z) == tuple(0 if j == p[i] else None for j in range(n))
        assert {act_tuple(p, z) for z in local_zeros} == set(local_zeros)

    print(
        f"n={n}: support equivariance, union/intersection, local-zero orbit, "
        f"pure-target sums, and simplex Gram checks passed"
    )

print("All associated support--geometry carrier checks passed.")

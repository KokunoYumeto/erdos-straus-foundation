#!/usr/bin/env python3
"""Exact circle and Lorentz data of the two ordered pulled blade cells."""

import sympy as sp


u2 = sp.Matrix(
    [
        [1 / sp.sqrt(2), -1 / sp.sqrt(2), 0],
        [1 / sp.sqrt(6), 1 / sp.sqrt(6), -2 / sp.sqrt(6)],
    ]
)
p2 = sp.eye(3) - sp.ones(3, 3) / 3
assert sp.simplify(u2.T * u2 - p2) == sp.zeros(3)

e21 = sp.Matrix([[0, 0], [1, 0]])
e12 = sp.Matrix([[0, 1], [0, 0]])
n_minus_plus = 2 * e21
n_plus_minus = e12

q_range_minus_plus = e21 * e21.T
q_range_plus_minus = e12 * e12.T
carrier_minus_plus = n_minus_plus.T * n_minus_plus - q_range_minus_plus
carrier_plus_minus = n_plus_minus.T * n_plus_minus - q_range_plus_minus

assert carrier_minus_plus == sp.diag(4, -1)
assert carrier_plus_minus == sp.diag(-1, 1)

pulled_carrier_minus_plus = sp.simplify(u2.T * carrier_minus_plus * u2)
pulled_carrier_plus_minus = sp.simplify(u2.T * carrier_plus_minus * u2)

expected_pulled_minus_plus = sp.Matrix(
    [[11, -13, 2], [-13, 11, 2], [2, 2, -4]]
) / 6
expected_pulled_plus_minus = sp.Matrix(
    [[-1, 2, -1], [2, -1, -1], [-1, -1, 2]]
) / 3

assert sp.simplify(
    pulled_carrier_minus_plus - expected_pulled_minus_plus
) == sp.zeros(3)
assert sp.simplify(
    pulled_carrier_plus_minus - expected_pulled_plus_minus
) == sp.zeros(3)


def sarnak_data(carrier):
    a = carrier[0, 0]
    c = carrier[1, 1]
    t = (a + c) / 2
    w = (a - c) / 2
    norm = -a * c
    ratio = c / a
    return (a, sp.Integer(0), sp.Integer(0), c), (t, 0, 0, w), norm, ratio


circle_mp, lorentz_mp, norm_mp, ratio_mp = sarnak_data(carrier_minus_plus)
circle_pm, lorentz_pm, norm_pm, ratio_pm = sarnak_data(carrier_plus_minus)

assert circle_mp == (4, 0, 0, -1)
assert lorentz_mp == (sp.Rational(3, 2), 0, 0, sp.Rational(5, 2))
assert norm_mp == 4
assert ratio_mp == -sp.Rational(1, 4)

assert circle_pm == (-1, 0, 0, 1)
assert lorentz_pm == (0, 0, 0, -1)
assert norm_pm == 1
assert ratio_pm == -1

assert sp.simplify(pulled_carrier_minus_plus * sp.ones(3, 1)) == sp.zeros(3, 1)
assert sp.simplify(pulled_carrier_plus_minus * sp.ones(3, 1)) == sp.zeros(3, 1)

print("PASS pulled directed blade carrier is the stated 3-by-3 support matrix")
print("PASS pulled transposed raw-cell carrier is the stated distinct 3-by-3 support matrix")
print("PASS directed circle and Sarnak data are (4,0,0,-1) and (3/2,0,0,5/2)")
print("PASS transposed raw-cell data are (-1,0,0,1) and (0,0,0,-1)")
print("PASS exact simple ratios are -1/4 and -1 without conflating E12 with 2E12")
print("PASS both pulled carriers kill the all-one label line")

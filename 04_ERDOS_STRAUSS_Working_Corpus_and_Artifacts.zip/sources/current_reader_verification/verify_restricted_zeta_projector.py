#!/usr/bin/env python3
"""Exact certificate for the zeta projector on the common-value scheme."""

from fractions import Fraction as Q


def require(label, assertion):
    if not assertion:
        raise AssertionError(label)
    print(f"{label}: PASS")


def evaluate_linear(coefficients, point):
    constant, linear = coefficients
    return constant + linear * point


w_points = (Q(1, 4), Q(-2))
u_points = (Q(-1, 2), Q(1))
s_points = (Q(0), Q(1))

e_quarter = (Q(8, 9), Q(4, 9))
e_minus_two = (Q(1, 9), Q(-4, 9))

e_quarter_values = tuple(evaluate_linear(e_quarter, p) for p in w_points)
e_minus_two_values = tuple(evaluate_linear(e_minus_two, p) for p in w_points)

require("quarter component idempotent has values (1,0)", e_quarter_values == (1, 0))
require("minus-two component idempotent has values (0,1)", e_minus_two_values == (0, 1))
require(
    "component idempotents are orthogonal and sum to one",
    tuple(a * b for a, b in zip(e_quarter_values, e_minus_two_values)) == (0, 0)
    and tuple(a + b for a, b in zip(e_quarter_values, e_minus_two_values))
    == (1, 1),
)

w_from_u = tuple(-u * (1 + u) for u in u_points)
require("common-value points are (1/4,-2)", w_from_u == w_points)

pulled_e_quarter_on_u = tuple(Q(4, 9) * (w + 2) for w in w_from_u)
target_on_u = tuple(Q(2, 3) * (1 - u) for u in u_points)
require(
    "quarter projector pulls back to 2(1-u)/3",
    pulled_e_quarter_on_u == target_on_u == (1, 0),
)

u_from_s = tuple(Q(3 * s - 1, 2) for s in s_points)
pulled_e_quarter_on_s = tuple(Q(2, 3) * (1 - u) for u in u_from_s)
target_on_s = tuple(1 - s for s in s_points)
require(
    "quarter projector pulls back to 1-s",
    pulled_e_quarter_on_s == target_on_s == (1, 0),
)

require(
    "restricted zeta vanishes exactly on the minus-two component",
    e_quarter_values[0] != 0 and e_quarter_values[1] == 0,
)
require(
    "the zero component transports to u=1 and s=1",
    u_points[1] == 1 and s_points[1] == 1 and w_points[1] == -2,
)

functional_equation_rational_factor = Q(1, 4) * Q(-1, 2) * Q(2)
require(
    "functional equation gives the factor -1/4 in zeta'(-2)",
    functional_equation_rational_factor == Q(-1, 4),
)
require(
    "the first-jet scalar is invertible once zeta(3) and pi are nonzero",
    functional_equation_rational_factor != 0,
)

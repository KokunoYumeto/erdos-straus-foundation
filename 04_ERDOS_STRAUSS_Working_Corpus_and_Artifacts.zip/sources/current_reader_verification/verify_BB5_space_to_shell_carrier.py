from itertools import product

import sympy as sp


S4 = 107
SPACE4 = 16
S5 = 47_176_870
SIGMA5 = 4098
SPACE5 = 12_289
R = 11


if SPACE5 != S4**2 + 840:
    raise AssertionError("adjacent Busy-Beaver identity")
if SPACE5 % S4 != (-SPACE4) % S4:
    raise AssertionError("adjacent Busy-Beaver congruence")
if not sp.isprime(SPACE5):
    raise AssertionError("12289 primality")

a = (SPACE5 + R) // 4
if 4 * a != SPACE5 + R or a != 3 * 5**2 * 41:
    raise AssertionError("shell factorization")

mu = [0] * 10
for beta_3, beta_5, beta_41 in product(
    range(-1, 2), range(-2, 3), range(-1, 2)
):
    residue = (8 * beta_3 + 4 * beta_5 + 3 * beta_41) % 10
    mu[residue] += 1

expected_mu = [3, 6, 3, 6, 3, 6, 3, 6, 3, 6]
if mu != expected_mu:
    raise AssertionError(f"C10 shell vector: {mu}")
if sum(mu) != 45:
    raise AssertionError("exponent-box count")

nu = sp.Matrix([mu[0], mu[1]])
if nu != sp.Matrix([3, 6]):
    raise AssertionError(f"C2 descent: {nu}")
for h, coefficient in enumerate(mu):
    if coefficient != nu[h % 2]:
        raise AssertionError(f"descent fibre at {h}")

left_convolution = sp.Matrix([[nu[0], nu[1]], [nu[1], nu[0]]])
if left_convolution.eigenvals() != {sp.Integer(9): 1, sp.Integer(-3): 1}:
    raise AssertionError("C2 convolution spectrum")
convolution_gap = 12

e12 = sp.Matrix([[0, 1], [0, 0]])
e21 = sp.Matrix([[0, 0], [1, 0]])
ad_e12 = left_convolution * e12 - e12 * left_convolution
ad_e21 = left_convolution * e21 - e21 * left_convolution
if ad_e12 != sp.Matrix([[-6, 0], [0, 6]]):
    raise AssertionError(f"standard-coordinate commutator on E12: {ad_e12}")
if ad_e21 != sp.Matrix([[6, 0], [0, -6]]):
    raise AssertionError(f"standard-coordinate commutator on E21: {ad_e21}")

fourier = sp.Matrix([[1, 1], [1, -1]]) / sp.sqrt(2)
carried = sp.simplify(fourier.T * left_convolution * fourier)
if carried != sp.diag(9, -3):
    raise AssertionError(f"Fourier-carried convolution: {carried}")
blade_positive = e12
blade_negative = e21
point_blade_positive = sp.simplify(fourier * e12 * fourier.T)
point_blade_negative = sp.simplify(fourier * e21 * fourier.T)
if (
    left_convolution * point_blade_positive
    - point_blade_positive * left_convolution
    != 12 * point_blade_positive
):
    raise AssertionError("positive point-basis blade")
if (
    left_convolution * point_blade_negative
    - point_blade_negative * left_convolution
    != -12 * point_blade_negative
):
    raise AssertionError("negative point-basis blade")
if carried * blade_positive - blade_positive * carried != 12 * blade_positive:
    raise AssertionError("positive ordered blade")
if carried * blade_negative - blade_negative * carried != -12 * blade_negative:
    raise AssertionError("negative ordered blade")

origin_counts = (3, 6, 3)
omega_11 = sum(origin_counts)
cover_count = 3 * omega_11
quotient_count = omega_11 // 2
if (omega_11, cover_count, quotient_count) != (12, 36, 6):
    raise AssertionError("shell and D3 cover counts")
if convolution_gap != omega_11:
    raise AssertionError("space-to-shell spectral identity")

print("PASS: exact five-state Busy-Beaver space-to-shell carrier")
print(f"Busy-Beaver extrema = ({S5},{SIGMA5},{SPACE5})")
print("12289 = 107^2 + 840 and 12289 = -16 (mod 107)")
print("shell vector on C10 = (3,6,3,6,3,6,3,6,3,6)")
print("C2 descent = (3,6); convolution spectrum = (9,-3)")
print("ordered Fourier-blade eigenvalues = (+12,-12)")
print("finite counts = exponent box 45, shell 12, cover 36, quotient 6")
print("convolution spectral gap = Omega_11(space(M5*)) = 12")

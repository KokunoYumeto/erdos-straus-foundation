from itertools import product
from pathlib import Path

import sympy as sp


def zero(expr):
    return sp.cancel(sp.expand(expr)) == 0


def assert_zero(expr, label):
    if not zero(expr):
        raise AssertionError(f"{label}: {sp.factor(expr)}")


def assert_matrix_zero(matrix, label):
    for index, entry in enumerate(matrix):
        assert_zero(entry, f"{label} entry {index}")


sqrt3 = sp.sqrt(3)
delta = sp.symbols("delta", real=True)

R_raw = sp.Matrix(
    [
        [sp.Rational(1, 4), sqrt3 / 2, 0, sp.Rational(3, 4)],
        [-sqrt3 / 4, -sp.Rational(1, 2), 0, sqrt3 / 4],
        [0, 0, 1, 0],
        [sp.Rational(3, 4), -sqrt3 / 2, 0, sp.Rational(1, 4)],
    ]
)
J_raw = sp.Matrix(
    [
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ]
)
R_perp = sp.Matrix(
    [
        [-sp.Rational(1, 2), sqrt3 / 2],
        [-sqrt3 / 2, -sp.Rational(1, 2)],
    ]
)
R_L = sp.diag(1, 1, 1, 1)
R_L[1:3, 1:3] = R_perp
J_L = sp.diag(1, -1, 1, 1)
eta = sp.diag(-1, 1, 1, 1)
Lambda = sp.Matrix(
    [
        [sp.Rational(5, 8), 0, 0, sp.Rational(5, 8)],
        [sp.Rational(1, 2), 0, 0, -sp.Rational(1, 2)],
        [0, 1, 0, 0],
        [sp.Rational(3, 8), 0, 0, sp.Rational(3, 8)],
    ]
)

assert_matrix_zero(R_raw**3 - sp.eye(4), "raw rotation order")
assert_matrix_zero(J_raw**2 - sp.eye(4), "raw reflection order")
assert_matrix_zero(J_raw * R_raw * J_raw - R_raw**2, "raw D3 relation")
assert_matrix_zero(R_L**3 - sp.eye(4), "Lorentz rotation order")
assert_matrix_zero(J_L**2 - sp.eye(4), "Lorentz reflection order")
assert_matrix_zero(J_L * R_L * J_L - R_L**2, "Lorentz D3 relation")
assert_matrix_zero(Lambda * R_raw - R_L * Lambda, "rotation intertwining")
assert_matrix_zero(Lambda * J_raw - J_L * Lambda, "reflection intertwining")


def raw_cell(parameter):
    x = (1 + parameter) / 2
    y = (1 - parameter) / 2
    return sp.Matrix([x**2, x * y, 0, y**2])


def lorentz_arc(parameter, m):
    return R_L**m * Lambda * raw_cell(parameter)


assert_matrix_zero(J_raw * raw_cell(delta) - raw_cell(-delta),
                   "raw complement")
for m in range(3):
    raw_point = R_raw**m * raw_cell(delta)
    lorentz_point = lorentz_arc(delta, m)
    assert_matrix_zero(Lambda * raw_point - lorentz_point,
                       f"raw-to-Lorentz sheet {m}")
    assert_matrix_zero(R_raw * raw_point - R_raw ** ((m + 1) % 3)
                       * raw_cell(delta), f"raw rotation sheet {m}")
    assert_matrix_zero(J_raw * raw_point - R_raw ** ((-m) % 3)
                       * raw_cell(-delta), f"raw reflection sheet {m}")
    assert_matrix_zero(R_L * lorentz_point
                       - lorentz_arc(delta, (m + 1) % 3),
                       f"Lorentz rotation sheet {m}")
    assert_matrix_zero(J_L * lorentz_point
                       - lorentz_arc(-delta, (-m) % 3),
                       f"Lorentz reflection sheet {m}")
    assert_zero((lorentz_point.T * eta * lorentz_point)[0],
                f"Lorentz nullity sheet {m}")


def kappa_base(vector):
    return sp.Matrix([4, 0, 0, -4 * vector[1]])


def kappa_sheet(vector, m):
    return kappa_base(R_raw ** ((-m) % 3) * vector)


def branch_base(vector):
    return sp.Matrix([2 - 2 * vector[2], 0, 0, 2 + 2 * vector[2]])


def branch_sheet(vector, m):
    return branch_base(R_L ** ((-m) % 3) * vector)


raw_symbols = sp.Matrix(sp.symbols("a b c d", real=True))
lorentz_symbols = sp.Matrix(sp.symbols("T X Y W", real=True))
for m in range(3):
    assert_matrix_zero(
        kappa_sheet(R_raw * raw_symbols, (m + 1) % 3)
        - kappa_sheet(raw_symbols, m),
        f"indexed raw rotation descent {m}",
    )
    assert_matrix_zero(
        kappa_sheet(J_raw * raw_symbols, (-m) % 3)
        - kappa_sheet(raw_symbols, m),
        f"indexed raw reflection descent {m}",
    )
    assert_matrix_zero(
        branch_sheet(R_L * lorentz_symbols, (m + 1) % 3)
        - branch_sheet(lorentz_symbols, m),
        f"indexed Lorentz rotation descent {m}",
    )
    assert_matrix_zero(
        branch_sheet(J_L * lorentz_symbols, (-m) % 3)
        - branch_sheet(lorentz_symbols, m),
        f"indexed Lorentz reflection descent {m}",
    )

alpha = 1 - delta**2
carrier_raw = sp.Matrix([4, 0, 0, -alpha])
carrier_lorentz = sp.Matrix(
    [2 - alpha / 2, 0, 0, 2 + alpha / 2]
)
for m in range(3):
    assert_matrix_zero(
        kappa_sheet(R_raw**m * raw_cell(delta), m) - carrier_raw,
        f"raw cover descent {m}",
    )
    assert_matrix_zero(
        branch_sheet(lorentz_arc(delta, m), m) - carrier_lorentz,
        f"Lorentz cover descent {m}",
    )


def divisors_from_factorization(factors):
    values = [1]
    for prime, exponent in factors.items():
        values = [value * prime**power for value in values
                  for power in range(exponent + 1)]
    return sorted(values)


p = 12289
a_value = 3075
R_value = 11
N_value = p * a_value
a_inverse = pow(a_value, -1, R_value)
p_inverse = pow(p, -1, R_value)
targets = {
    0: (-p) % R_value,
    1: (-1) % R_value,
    2: (-p_inverse) % R_value,
}
u_divisors = divisors_from_factorization({3: 2, 5: 4, 41: 2})
certificate_set = {
    (j, u)
    for j, u in product(range(3), u_divisors)
    if (u * a_inverse) % R_value == targets[j]
}

origin_counts = tuple(
    sum(1 for j0, _ in certificate_set if j0 == j) for j in range(3)
)
if origin_counts != (3, 6, 3):
    raise AssertionError(f"origin counts: {origin_counts}")
if len(certificate_set) != 12:
    raise AssertionError(f"certificate count: {len(certificate_set)}")


def rotate(point):
    m, j, u = point
    return ((m + 1) % 3, j, u)


def reflect(point):
    m, j, u = point
    return ((-m) % 3, 2 - j, a_value**2 // u)


cover = {(m, j, u) for m in range(3) for j, u in certificate_set}
for point in cover:
    if rotate(rotate(rotate(point))) != point:
        raise AssertionError("finite rotation order")
    if reflect(reflect(point)) != point:
        raise AssertionError("finite reflection order")
    if reflect(rotate(reflect(point))) != rotate(rotate(point)):
        raise AssertionError("finite D3 relation")


def orbit(point):
    pending = [point]
    result = set()
    while pending:
        current = pending.pop()
        if current in result:
            continue
        result.add(current)
        pending.extend([rotate(current), reflect(current)])
    return result


orbits = []
unseen = set(cover)
while unseen:
    current_orbit = orbit(next(iter(unseen)))
    orbits.append(current_orbit)
    unseen -= current_orbit
if len(orbits) != 6 or any(len(item) != 6 for item in orbits):
    raise AssertionError(
        f"free cover orbit sizes: {[len(item) for item in orbits]}"
    )


def divisor_of(point):
    _, j, u = point
    return p**j * u


def delta_of_divisor(divisor):
    return sp.Rational(divisor - N_value, divisor + N_value)


def alpha_of_divisor(divisor):
    return sp.Rational(4 * N_value * divisor, (N_value + divisor) ** 2)


def lorentz_key(point):
    m, _, _ = point
    vector = lorentz_arc(delta_of_divisor(divisor_of(point)), m)
    return tuple(sp.simplify(entry) for entry in vector)


lorentz_keys = {lorentz_key(point) for point in cover}
if len(lorentz_keys) != 36:
    raise AssertionError(f"distinct Lorentz point count: {len(lorentz_keys)}")
for point in cover:
    vector = sp.Matrix(lorentz_key(point))
    assert_zero((vector.T * eta * vector)[0], "finite cover nullity")


def carrier_key(point):
    amplitude = alpha_of_divisor(divisor_of(point))
    return (sp.Integer(4), sp.Integer(0), sp.Integer(0), -amplitude)


carrier_keys = {carrier_key(point) for point in cover}
if len(carrier_keys) != 6:
    raise AssertionError(f"carrier image count: {len(carrier_keys)}")
for current_orbit in orbits:
    if len({carrier_key(point) for point in current_orbit}) != 1:
        raise AssertionError("carrier value varies within a D3 orbit")
if len({next(iter({carrier_key(point) for point in current_orbit}))
        for current_orbit in orbits}) != 6:
    raise AssertionError("different D3 orbits share a carrier value")

representatives = sorted(
    min(divisor_of((0, j, u)), N_value**2 // divisor_of((0, j, u)))
    for j, u in certificate_set
)
representatives = sorted(set(representatives))
expected_rows = [
    (615, -sp.Rational(30722, 30723), sp.Rational(61445, 943902729)),
    (5125, -sp.Rational(18431, 18436), sp.Rational(184335, 339886096)),
    (230625, -sp.Rational(6107, 6182), sp.Rational(921675, 38217124)),
    (61445, -sp.Rational(307, 308), sp.Rational(615, 94864)),
    (2765025, -sp.Rational(19, 22), sp.Rational(123, 484)),
    (23041875, -sp.Rational(8, 33), sp.Rational(1025, 1089)),
]
if representatives != sorted(row[0] for row in expected_rows):
    raise AssertionError(f"complement representatives: {representatives}")
for divisor, expected_delta, expected_alpha in expected_rows:
    if delta_of_divisor(divisor) != expected_delta:
        raise AssertionError(f"delta for divisor {divisor}")
    if alpha_of_divisor(divisor) != expected_alpha:
        raise AssertionError(f"alpha for divisor {divisor}")

lifted_origin_counts = tuple(3 * count for count in origin_counts)
if lifted_origin_counts != (9, 18, 9):
    raise AssertionError(f"lifted origin counts: {lifted_origin_counts}")

lines = [
    "PASS: Star-Kneser free D3 Lorentz cover",
    "raw and Lorentz D3 equivariance verified symbolically",
    "three indexed raw and Lorentz descents verified symbolically",
    "12289 origin counts = (3, 6, 3)",
    "12289 cover = 36 distinct Lorentz-null points",
    "12289 cover = six free D3 orbits",
    "D3 quotient = six distinct arithmetic carrier values",
    "12289 lifted origin counts = (9, 18, 9)",
    "six exact divisor parameters agree with the manuscript table",
]

output = Path(__file__).with_name(
    "verify_star_kneser_D3_lorentz_cover_output.txt"
)
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

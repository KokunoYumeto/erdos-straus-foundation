#!/usr/bin/env python3
"""Draw the exact marked D3 map from the Fable face to the 12289 count orbit."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUT_PDF = ROOT / "figures" / "fable_12289_count_orbit.pdf"
OUT_PNG = ROOT / "figures" / "fable_12289_count_orbit_qa.png"

SQRT3 = np.sqrt(3.0)
SQRT6 = np.sqrt(6.0)

face = np.array(
    [
        [1.0, 0.0],
        [-0.5, SQRT3 / 2.0],
        [-0.5, -SQRT3 / 2.0],
    ]
)
count_chart = SQRT6 * face
count_labels = (r"$(3,6,3)$", r"$(3,3,6)$", r"$(6,3,3)$")
face_labels = (r"$e_0$", r"$e_+$", r"$e_-$")
colors = ("#d73027", "#1a9850", "#4575b4")


def add_rotation(ax, radius: float) -> None:
    theta = np.linspace(np.deg2rad(18), np.deg2rad(92), 80)
    ax.plot(radius * np.cos(theta), radius * np.sin(theta), color="0.2", lw=1.0)
    ax.annotate(
        "",
        xy=(radius * np.cos(theta[-1]), radius * np.sin(theta[-1])),
        xytext=(radius * np.cos(theta[-3]), radius * np.sin(theta[-3])),
        arrowprops={"arrowstyle": "-|>", "color": "0.2", "lw": 1.0},
    )
    ax.text(
        radius * 0.72,
        radius * 0.72,
        r"$120^\circ$",
        ha="center",
        va="center",
        fontsize=9,
    )


fig, axes = plt.subplots(1, 2, figsize=(11.8, 6.4))
fig.subplots_adjust(left=0.055, right=0.975, bottom=0.25, top=0.80, wspace=0.34)

theta = np.linspace(0.0, 2.0 * np.pi, 500)

ax = axes[0]
ax.plot(np.cos(theta), np.sin(theta), color="0.35", lw=1.2)
closed = np.vstack([face, face[0]])
ax.plot(closed[:, 0], closed[:, 1], color="0.15", lw=1.5)
for point, label, color in zip(face, face_labels, colors):
    ax.scatter(*point, s=58, color=color, edgecolor="white", linewidth=0.7, zorder=3)
    offset = {
        r"$e_0$": (0.09, 0.04),
        r"$e_+$": (-0.18, 0.10),
        r"$e_-$": (-0.18, -0.15),
    }[label]
    ax.text(point[0] + offset[0], point[1] + offset[1], label, fontsize=11)
ax.scatter(0, 0, s=26, color="black", zorder=3)
ax.text(0.04, 0.05, r"$(0,0)$", fontsize=9)
add_rotation(ax, 0.62)
ax.set_title(r"A. Transported Fable face $\mathcal{F}_3$")
ax.set_xlabel(r"$X$")
ax.set_ylabel(r"$W$")
ax.set_aspect("equal")
ax.set_xlim(-1.25, 1.25)
ax.set_ylim(-1.18, 1.18)
ax.grid(alpha=0.18)

ax = axes[1]
ax.plot(SQRT6 * np.cos(theta), SQRT6 * np.sin(theta), color="0.35", lw=1.2)
closed = np.vstack([count_chart, count_chart[0]])
ax.plot(closed[:, 0], closed[:, 1], color="0.15", lw=1.5)
for point, label, color in zip(count_chart, count_labels, colors):
    ax.scatter(*point, s=58, color=color, edgecolor="white", linewidth=0.7, zorder=3)
    offset = {
        r"$(3,6,3)$": (0.16, 0.08),
        r"$(3,3,6)$": (-0.62, 0.21),
        r"$(6,3,3)$": (-0.62, -0.30),
    }[label]
    ax.text(point[0] + offset[0], point[1] + offset[1], label, fontsize=10)
ax.scatter(0, 0, s=26, color="black", zorder=3)
ax.text(0.08, 0.10, r"centroid $(4,4,4)$", fontsize=9)
add_rotation(ax, 0.62 * SQRT6)
ax.set_title(r"B. $12289$ count plane $m_0+m_1+m_2=12$")
ax.set_xlabel(r"orthonormal count coordinate $\xi$")
ax.set_ylabel(r"orthonormal count coordinate $\eta$")
ax.set_aspect("equal")
ax.set_xlim(-3.10, 3.10)
ax.set_ylim(-2.90, 2.90)
ax.grid(alpha=0.18)

fig.text(
    0.5,
    0.93,
    r"Exact marked $D_3$ identification: "
    r"$\Psi(X,W)=(4-X-\sqrt{3}W,\,4+2X,\,4-X+\sqrt{3}W)$",
    ha="center",
    fontsize=12,
    fontweight="bold",
)
fig.text(
    0.5,
    0.155,
    r"$D^{\top}D=6I_2,\qquad "
    r"Z\!\circ\!\Psi=3\omega(X+iW),\qquad "
    r"\Sigma=12,\ |Z|^2=9,\ \Sigma^2-|Z|^2=135$",
    ha="center",
    fontsize=10.5,
)
fig.text(
    0.5,
    0.065,
    r"Count-orbit $D_3$ is exact; a cyclic action on the certificate fibres "
    r"would require $3=6=3$ and therefore has no lift.",
    ha="center",
    fontsize=9.5,
)

OUT_PDF.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT_PDF, bbox_inches="tight")
fig.savefig(OUT_PNG, dpi=130, bbox_inches="tight")
plt.close(fig)

print(f"wrote {OUT_PDF}")
print(f"wrote {OUT_PNG}")

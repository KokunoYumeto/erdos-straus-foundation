from fractions import Fraction
from itertools import product


def report(name, condition):
    if not condition:
        raise AssertionError(name)
    print(f"{name}: PASS")


tested_multiplicities = tuple(range(0, 9))

report(
    "common orbit factor dimensions",
    all(
        len(tuple(product(range(q), range(2), range(3)))) == 6 * q
        and len(tuple(product(range(q), range(4)))) == 4 * q
        for q in tested_multiplicities
    ),
)
report("four-Time block-order independence", (-1) ** (4 * 4) == 1)
report(
    "SU4 determinant action",
    all(Fraction(2 * 3 * 5, 30) ** q == 1 for q in tested_multiplicities),
)
report(
    "determinant volume",
    all(4 ** (3 * q) == 2 ** (6 * q) for q in tested_multiplicities),
)
report(
    "Time dimension to log-volume",
    all(Fraction(3, 2) * (4 * q) == 6 * q for q in tested_multiplicities),
)
report(
    "Time dimension to H length",
    all(Fraction(51, 4) * (4 * q) == 51 * q for q in tested_multiplicities),
)
report(
    "Time dimension to K length",
    all(
        Fraction(75, 8) * (4 * q) == Fraction(75, 2) * q
        for q in tested_multiplicities
    ),
)
report(
    "nonvanishing equivalence",
    all(
        (q > 0) == (4 * q >= 4) == (4 ** (3 * q) > 1)
        for q in tested_multiplicities
    ),
)
report(
    "directional energy bound",
    all(
        2 * xi <= Fraction(1, 2) * (4 * q)
        == Fraction(1, 3) * (6 * q)
        and ((2 * xi == 2 * q) == (xi == q))
        for q in tested_multiplicities
        for xi in range(q + 1)
    ),
)

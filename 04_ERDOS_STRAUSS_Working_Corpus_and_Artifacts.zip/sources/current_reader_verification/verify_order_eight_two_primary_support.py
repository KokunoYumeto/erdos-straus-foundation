from collections import deque
from itertools import product


def subgroup_generated(elements, zero, add):
    subgroup = {zero}
    changed = True
    while changed:
        changed = False
        for left in tuple(subgroup):
            for right in elements:
                value = add(left, right)
                if value not in subgroup:
                    subgroup.add(value)
                    changed = True
    return frozenset(subgroup)


def support_closure(elements, zero, add, scalar_mul, order):
    local_supports = set()
    for direction in elements:
        direction_order = order(direction)
        for exponent in range(1, direction_order // 2 + 1):
            local_supports.add(
                frozenset(
                    scalar_mul(beta, direction)
                    for beta in range(-exponent, exponent + 1)
                )
            )

    start = frozenset({zero})
    reachable = {start}
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for local in local_supports:
            successor = frozenset(
                add(left, right)
                for left in current
                for right in local
            )
            if successor not in reachable:
                reachable.add(successor)
                queue.append(successor)

    nonfull_generating = {
        support
        for support in reachable
        if len(support) < len(elements)
        and len(subgroup_generated(support, zero, add)) == len(elements)
    }
    return local_supports, reachable, nonfull_generating


def cyclic_data(modulus):
    elements = tuple(range(modulus))

    def add(left, right):
        return (left + right) % modulus

    def scalar_mul(integer, value):
        return integer * value % modulus

    def order(value):
        for candidate in range(1, modulus + 1):
            if candidate * value % modulus == 0:
                return candidate
        raise AssertionError

    return elements, 0, add, scalar_mul, order


def product_data(moduli):
    elements = tuple(product(*(range(modulus) for modulus in moduli)))
    zero = tuple(0 for _ in moduli)

    def add(left, right):
        return tuple(
            (left[index] + right[index]) % moduli[index]
            for index in range(len(moduli))
        )

    def scalar_mul(integer, value):
        return tuple(
            integer * value[index] % moduli[index]
            for index in range(len(moduli))
        )

    def order(value):
        for candidate in range(1, 17):
            if scalar_mul(candidate, value) == zero:
                return candidate
        raise AssertionError

    return elements, zero, add, scalar_mul, order


c8 = cyclic_data(8)
c8_local, c8_reachable, c8_bad = support_closure(*c8)
c8_three = {
    frozenset({0, 1, 7}),
    frozenset({0, 3, 5}),
}
c8_five = {
    frozenset({0, 1, 2, 6, 7}),
    frozenset({0, 2, 3, 5, 6}),
}
c8_six = {frozenset({0, 1, 3, 4, 5, 7})}
c8_seven = {frozenset({0, 1, 2, 3, 5, 6, 7})}
assert c8_bad == c8_three | c8_five | c8_six | c8_seven

c4c2 = product_data((4, 2))
c4c2_local, c4c2_reachable, c4c2_bad = support_closure(*c4c2)
c4c2_six = {
    frozenset({(0, 0), (0, 1), (1, 0), (1, 1), (3, 0), (3, 1)}),
    frozenset({(0, 0), (1, 0), (1, 1), (2, 1), (3, 0), (3, 1)}),
}
c4c2_seven = {
    frozenset(
        {(0, 0), (0, 1), (1, 0), (1, 1), (2, 1), (3, 0), (3, 1)}
    )
}
assert c4c2_bad == c4c2_six | c4c2_seven

c2cubed = product_data((2, 2, 2))
c2cubed_local, c2cubed_reachable, c2cubed_bad = support_closure(*c2cubed)
assert not c2cubed_bad

print("PASS: exact order-eight 2-primary support classification")
print(f"C8_distinct_local_supports={len(c8_local)}")
print(f"C8_reachable_supports={len(c8_reachable)}")
print(f"C8_generating_nonfull_supports={len(c8_bad)}")
print("C8_types=two three-point, two five-point, one six-point, one seven-point")
print(f"C4xC2_distinct_local_supports={len(c4c2_local)}")
print(f"C4xC2_reachable_supports={len(c4c2_reachable)}")
print(f"C4xC2_generating_nonfull_supports={len(c4c2_bad)}")
print("C4xC2_types=two six-point, one seven-point")
print(f"C2cubed_distinct_local_supports={len(c2cubed_local)}")
print(f"C2cubed_reachable_supports={len(c2cubed_reachable)}")
print("C2cubed_generating_nonfull_supports=0")

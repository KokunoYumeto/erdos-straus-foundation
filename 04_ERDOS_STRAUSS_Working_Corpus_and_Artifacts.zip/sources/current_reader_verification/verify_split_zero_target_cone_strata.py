from fractions import Fraction
from math import gcd

import sympy as sp


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def reduced_divisor_set(p, a):
    R = 4 * a - p
    N = p * a
    require(gcd(R, N) == 1, "coprime shell")
    return R, N, [
        d for d in sp.divisors(N * N) if (d + N) % R == 0
    ]


def p_origin(d, p):
    j = 0
    while d % p == 0:
        d //= p
        j += 1
    return j


# Symbolic four-stratum cone.
x, y = sp.symbols("x y", nonnegative=True)
lambda_plus = y + x / 2
lambda_minus = y - x / 2
G = sp.Matrix(
    [
        [lambda_plus, lambda_minus],
        [lambda_minus, lambda_plus],
    ]
)
require(
    set(G.eigenvals()) == {x, 2 * y},
    "target cone eigenvalues",
)
require(sp.factor(G.det() - 2 * x * y) == 0, "target cone determinant")

# Positive null shell: p=3, a=2.
R3, N3, divisors3 = reduced_divisor_set(3, 2)
require((R3, N3, divisors3) == (5, 6, [4, 9]), "p=3 divisor set")
origins3 = [p_origin(d, 3) for d in divisors3]
require(origins3 == [0, 2], "p=3 exterior origins")
alpha2_3 = Fraction(4 * N3 * 4, (N3 + 4) ** 2)
require(alpha2_3 == Fraction(24, 25), "p=3 exterior amplitude")
G3 = sp.Matrix(
    [
        [sp.Rational(24, 25), sp.Rational(24, 25)],
        [sp.Rational(24, 25), sp.Rational(24, 25)],
    ]
)
require(G3.rank() == 1 and G3.det() == 0, "p=3 positive null matrix")
require(
    Fraction(4, 3)
    == Fraction(1, 2) + Fraction(1, 2) + Fraction(1, 3),
    "p=3 certificate",
)

# Negative null shell: p=29, a=10.
R29, N29, divisors29 = reduced_divisor_set(29, 10)
require(
    (R29, N29, divisors29) == (11, 290, [29, 2900]),
    "p=29 divisor set",
)
origins29 = [p_origin(d, 29) for d in divisors29]
require(origins29 == [1, 1], "p=29 middle origins")
orbit_weight29 = Fraction(4 * N29 * 29, (N29 + 29) ** 2)
require(orbit_weight29 == Fraction(40, 121), "p=29 middle orbit amplitude")
G29 = sp.Matrix(
    [
        [sp.Rational(40, 121), -sp.Rational(40, 121)],
        [-sp.Rational(40, 121), sp.Rational(40, 121)],
    ]
)
require(G29.rank() == 1 and G29.det() == 0, "p=29 negative null matrix")
require(
    Fraction(4, 29)
    == Fraction(1, 10) + Fraction(1, 29) + Fraction(1, 290),
    "p=29 certificate",
)

lines = [
    "PASS: split-zero target Lorentz strata",
    "the cone matrix has eigenvalues alpha_1 and 2 alpha_2",
    "its rank is the integer sum of the two Boolean target supports",
    "local ES positivity is the Boolean disjunction of target supports",
    "timelikeness is the Boolean conjunction of target supports",
    "the p=3 shell has the exact reduced divisor set {4,9}",
    "the p=3 shell occupies only the exterior target",
    "the p=3 target vector lies on the positive future-null ray",
    "the p=29 shell has the exact reduced divisor set {29,2900}",
    "the p=29 shell occupies only the middle target",
    "the p=29 target vector lies on the negative future-null ray",
    "both displayed unit-fraction certificates hold exactly",
]

print("\n".join(lines))

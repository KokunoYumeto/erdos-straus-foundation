"""Exact low-cost checks for the BCM character-sector D3 carrier."""


def mm(a, b):
    return tuple(
        tuple(sum(a[i][k] * b[k][j] for k in range(len(b)))
              for j in range(len(b[0])))
        for i in range(len(a))
    )


I3 = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
R = ((0, 0, 1), (1, 0, 0), (0, 1, 0))
J = ((1, 0, 0), (0, 0, 1), (0, 1, 0))
P0 = ((1, 0, 0), (0, 0, 0), (0, 0, 0))
Pp = ((0, 0, 0), (0, 1, 0), (0, 0, 0))
Pm = ((0, 0, 0), (0, 0, 0), (0, 0, 1))

assert mm(mm(R, R), R) == I3
assert mm(J, J) == I3
assert mm(mm(J, R), J) == mm(R, R)
assert mm(mm(J, P0), J) == P0
assert mm(mm(J, Pp), J) == Pm
assert mm(mm(J, Pm), J) == Pp

# The label intertwiner T is the identity matrix in the ordered bases
# (e0,e1,e2) and (d0,d+,d-).
T = I3
assert mm(T, R) == mm(R, T)
assert mm(T, J) == mm(J, T)

# Coefficient conjugation changes chi to bar-chi; J then exchanges the
# corresponding sector positions.
sector_twist = ("I", "chi", "bar-chi")
after_coefficient_conjugation = ("I", "bar-chi", "chi")
after_J = (
    after_coefficient_conjugation[0],
    after_coefficient_conjugation[2],
    after_coefficient_conjugation[1],
)
assert after_J == sector_twist

# On the Artin tensor carrier, coefficient conjugation exchanges the two
# character insertions and Sigma_23 exchanges their tensor positions.
artin_twist = ("I", "chi", "bar-chi")
conjugated_artin_twist = ("I", "bar-chi", "chi")
sigma23_result = (
    conjugated_artin_twist[0],
    conjugated_artin_twist[2],
    conjugated_artin_twist[1],
)
assert sigma23_result == artin_twist

hamiltonian_summands = {
    ("H", "I", "I"),
    ("I", "H", "I"),
    ("I", "I", "H"),
}
sigma23_hamiltonian_summands = {
    (a, c, b) for (a, b, c) in hamiltonian_summands
}
assert sigma23_hamiltonian_summands == hamiltonian_summands

print("R^3 = I: PASS")
print("J^2 = I: PASS")
print("J R J = R^{-1}: PASS")
print("J exchanges P_+ and P_- and fixes P_0: PASS")
print("T intertwines the two ordered D3 label representations: PASS")
print("sector character operator is charge-conjugation invariant: PASS")
print("Artin tensor twist is charge-conjugation invariant: PASS")
print("Artin tensor Hamiltonian sum is charge-conjugation invariant: PASS")

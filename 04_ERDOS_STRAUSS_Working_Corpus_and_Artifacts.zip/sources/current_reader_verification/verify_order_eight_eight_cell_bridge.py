from itertools import product


FACE = ("g0", "g1", "g2")
CELLS = ("f",) + FACE
EIGHT_CELLS = tuple(product((0, 1), CELLS))


def phase(cell):
    return {
        "f": "f",
        "g0": "g2",
        "g1": "g0",
        "g2": "g1",
    }[cell]


def reflect(cell):
    return {
        "f": "f",
        "g0": "g1",
        "g1": "g0",
        "g2": "g2",
    }[cell]


def u_delta(cell):
    sheet, sign = cell
    return sheet, phase(sign)


def r_hat(cell):
    sheet, sign = cell
    return sheet, reflect(sign)


def j_eight(cell):
    sheet, sign = cell
    return 1 - sheet, reflect(sign)


CELL_OF = {
    "apex": "f",
    "minus": "g0",
    "plus": "g1",
    "zero": "g2",
}
FACE_LABELS = ("zero", "plus", "minus")


def add_c8(left, right):
    return (left + right) % 8


def add_c4c2(left, right):
    return (left[0] + right[0]) % 4, (left[1] + right[1]) % 2


def model(name, elements, zero, q, r, add, neg):
    x_value = {
        "zero": zero,
        "plus": q,
        "apex": add(q, q),
        "minus": neg(q),
    }

    def encode(sheet, label):
        return add(r if sheet else zero, x_value[label])

    coordinates = {
        encode(sheet, label): (sheet, label)
        for sheet in (0, 1)
        for label in ("zero", "plus", "apex", "minus")
    }
    assert len(coordinates) == 8
    assert set(coordinates) == set(elements)

    def theta(value):
        sheet, label = coordinates[value]
        return sheet, CELL_OF[label]

    rho_label = {
        "zero": "plus",
        "plus": "minus",
        "minus": "zero",
        "apex": "apex",
    }
    sigma_label = {
        "zero": "zero",
        "plus": "minus",
        "minus": "plus",
        "apex": "apex",
    }

    def rho(value):
        sheet, label = coordinates[value]
        return encode(sheet, rho_label[label])

    def diagonal_reflection(value):
        sheet, label = coordinates[value]
        return encode(sheet, sigma_label[label])

    def crossed_reflection(value):
        sheet, label = coordinates[value]
        return encode(1 - sheet, sigma_label[label])

    for value in elements:
        assert theta(rho(value)) == u_delta(theta(value))
        assert theta(diagonal_reflection(value)) == r_hat(theta(value))
        assert theta(crossed_reflection(value)) == j_eight(theta(value))
        assert rho(rho(rho(value))) == value
        assert diagonal_reflection(diagonal_reflection(value)) == value
        assert crossed_reflection(crossed_reflection(value)) == value
        assert (
            diagonal_reflection(rho(diagonal_reflection(value)))
            == rho(rho(value))
        )
        assert crossed_reflection(rho(crossed_reflection(value))) == rho(
            rho(value)
        )

    both_faces = {
        encode(sheet, label)
        for sheet in (0, 1)
        for label in FACE_LABELS
    }
    both_apices = {encode(0, "apex"), encode(1, "apex")}
    sheet_zero_face = {encode(0, label) for label in FACE_LABELS}
    sheet_zero_all = sheet_zero_face | {encode(0, "apex")}

    assert {theta(value) for value in both_faces} == {
        (sheet, cell) for sheet in (0, 1) for cell in FACE
    }
    assert {theta(value) for value in both_apices} == {
        (0, "f"),
        (1, "f"),
    }

    return {
        "name": name,
        "encode": encode,
        "theta": theta,
        "rho": rho,
        "diagonal_reflection": diagonal_reflection,
        "crossed_reflection": crossed_reflection,
        "both_faces": both_faces,
        "both_apices": both_apices,
        "sheet_zero_face": sheet_zero_face,
        "sheet_zero_all": sheet_zero_all,
    }


def invariant(support, action):
    return {action(value) for value in support} == support


c8_elements = tuple(range(8))
c8 = model(
    "C8",
    c8_elements,
    0,
    1,
    4,
    add_c8,
    lambda value: (-value) % 8,
)
c8_a3 = frozenset({0, 1, 7})
c8_a5 = frozenset({0, 1, 2, 6, 7})
c8_a6 = frozenset({0, 1, 3, 4, 5, 7})
c8_a7 = frozenset({0, 1, 2, 3, 5, 6, 7})

assert c8_a3 == c8["sheet_zero_face"]
assert c8_a5 == c8["sheet_zero_all"] | {c8["encode"](1, "apex")}
assert c8_a6 == c8["both_faces"]
assert c8_a7 == set(c8_elements) - {c8["encode"](1, "zero")}
assert invariant(c8_a3, c8["rho"])
assert invariant(c8_a3, c8["diagonal_reflection"])
assert invariant(c8_a5, c8["rho"])
assert invariant(c8_a5, c8["diagonal_reflection"])
assert invariant(c8_a6, c8["rho"])
assert invariant(c8_a6, c8["crossed_reflection"])
assert not invariant(c8_a7, c8["rho"])

c4c2_elements = tuple(product(range(4), range(2)))
c4c2_models = [
    model(
        f"C4xC2_r={r}",
        c4c2_elements,
        (0, 0),
        (1, 0),
        r,
        add_c4c2,
        lambda value: ((-value[0]) % 4, (-value[1]) % 2),
    )
    for r in ((0, 1), (2, 1))
]
c4c2_b6 = [
    frozenset(
        {
            (0, 0),
            (0, 1),
            (1, 0),
            (1, 1),
            (3, 0),
            (3, 1),
        }
    ),
    frozenset(
        {
            (0, 0),
            (1, 0),
            (1, 1),
            (2, 1),
            (3, 0),
            (3, 1),
        }
    ),
]
for current, expected in zip(c4c2_models, c4c2_b6):
    assert current["both_faces"] == expected
    assert invariant(expected, current["rho"])
    assert invariant(expected, current["crossed_reflection"])

c4c2 = c4c2_models[0]
c4c2_b7 = frozenset(set(c4c2_elements) - {(2, 0)})
assert c4c2_b7 == set(c4c2_elements) - {c4c2["encode"](0, "apex")}
assert invariant(c4c2_b7, c4c2["rho"])
assert invariant(c4c2_b7, c4c2["diagonal_reflection"])
assert not invariant(c4c2_b7, c4c2["crossed_reflection"])

assert {phase(cell) for cell in FACE} == set(FACE)
assert {reflect(cell) for cell in FACE} == set(FACE)

print("PASS: order-eight support to eight-cell carrier")
print("all three inherited eight-cell intertwinings hold on C8 and C4xC2")
print("C8_A3=one diagonal face orbit")
print("C8_A5=one diagonal face orbit plus both fixed apices")
print("C8_A6=the crossed six-path orbit; its complement is the fixed pair")
print("C8_A7=is not invariant under the inherited phase rotation")
print("C4xC2_B6=the crossed six-path orbit for both external sheet choices")
print("C4xC2_B7=seven cells with one diagonal fixed apex missing")

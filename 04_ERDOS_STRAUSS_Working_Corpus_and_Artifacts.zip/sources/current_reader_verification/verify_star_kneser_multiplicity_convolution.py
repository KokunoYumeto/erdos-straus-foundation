from collections import Counter
from itertools import product
from pathlib import Path


def convolve(group_order, left, right):
    result = Counter()
    for x, left_value in left.items():
        for y, right_value in right.items():
            result[(x + y) % group_order] += left_value * right_value
    return result


def support(counter):
    return {key for key, value in counter.items() if value > 0}


def cosets(group_order, subgroup):
    unseen = set(range(group_order))
    result = []
    while unseen:
        representative = min(unseen)
        current = frozenset(
            (representative + element) % group_order for element in subgroup
        )
        result.append(current)
        unseen -= current
    return result


def push(counter, quotient_cosets):
    return tuple(sum(counter[element] for element in current)
                 for current in quotient_cosets)


group_order = 10
local_data = [
    (range(-1, 2), 8),
    (range(-2, 3), 4),
    (range(-1, 2), 3),
]

local_functions = []
local_supports = []
for interval, step in local_data:
    function = Counter((beta * step) % group_order for beta in interval)
    local_functions.append(function)
    local_supports.append(support(function))

expected_local_supports = [
    {0, 2, 8},
    {0, 2, 4, 6, 8},
    {0, 3, 7},
]
if local_supports != expected_local_supports:
    raise AssertionError(f"local supports: {local_supports}")

mu = Counter({0: 1})
for function in local_functions:
    mu = convolve(group_order, mu, function)

direct = Counter()
divisors = set()
for beta_3, beta_5, beta_41 in product(
    range(-1, 2), range(-2, 3), range(-1, 2)
):
    residue = (8 * beta_3 + 4 * beta_5 + 3 * beta_41) % group_order
    direct[residue] += 1
    divisors.add(3 ** (1 + beta_3) * 5 ** (2 + beta_5)
                 * 41 ** (1 + beta_41))

if mu != direct:
    raise AssertionError("convolution differs from the exponent-box count")
if len(divisors) != 45:
    raise AssertionError(f"distinct divisor count: {len(divisors)}")

expected_mu = (3, 6, 3, 6, 3, 6, 3, 6, 3, 6)
actual_mu = tuple(mu[index] for index in range(group_order))
if actual_mu != expected_mu:
    raise AssertionError(f"full coefficient vector: {actual_mu}")
for index in range(group_order):
    if mu[index] != mu[(-index) % group_order]:
        raise AssertionError(f"inversion symmetry at {index}")

sumset = {0}
for local_support in local_supports:
    sumset = {
        (left + right) % group_order
        for left in sumset
        for right in local_support
    }
if support(mu) != sumset or sumset != set(range(group_order)):
    raise AssertionError("support of convolution differs from the sumset")

subgroups = {
    1: {0},
    2: {0, 5},
    5: {0, 2, 4, 6, 8},
    10: set(range(10)),
}
expected_pushes = {
    1: (3, 6, 3, 6, 3, 6, 3, 6, 3, 6),
    2: (9, 9, 9, 9, 9),
    5: (15, 30),
    10: (45,),
}
expected_star_rows = {
    1: ((3, 5, 3), 9, 2, 1),
    2: ((3, 5, 3), 9, 2, 6),
    5: ((1, 1, 2), 2, 2, 2),
    10: ((1, 1, 1), 1, 1, 1),
}
targets = {4, 5}

for subgroup_order, subgroup in subgroups.items():
    quotient_cosets = cosets(group_order, subgroup)
    full_push = push(mu, quotient_cosets)
    if full_push != expected_pushes[subgroup_order]:
        raise AssertionError(
            f"pushforward for subgroup order {subgroup_order}: {full_push}"
        )

    local_pushes = [push(function, quotient_cosets)
                    for function in local_functions]
    quotient_convolution = Counter({0: 1})
    quotient_order = len(quotient_cosets)
    for local_push in local_pushes:
        local_counter = Counter(
            {index: value for index, value in enumerate(local_push)}
        )
        quotient_convolution = convolve(
            quotient_order, quotient_convolution, local_counter
        )
    if tuple(quotient_convolution[index] for index in range(quotient_order)) \
            != full_push:
        raise AssertionError(
            f"pushforward-convolution identity for subgroup order {subgroup_order}"
        )

    local_sizes = tuple(sum(value > 0 for value in local_push)
                        for local_push in local_pushes)
    target_cosets = {
        index
        for index, current in enumerate(quotient_cosets)
        if current & targets
    }
    kappa = 1 + sum(size - 1 for size in local_sizes)
    surplus = kappa + len(target_cosets) - quotient_order
    actual_row = (local_sizes, kappa, len(target_cosets), surplus)
    if actual_row != expected_star_rows[subgroup_order]:
        raise AssertionError(
            f"Star row for subgroup order {subgroup_order}: {actual_row}"
        )

middle_target = 5
exterior_target = 4
opposite_exterior_target = 6
m1 = mu[middle_target]
m2 = mu[exterior_target]
m0 = mu[opposite_exterior_target]
if (m0, m1, m2) != (3, 6, 3):
    raise AssertionError(f"origin coefficient vector: {(m0, m1, m2)}")
if m1 % 2 != 0:
    raise AssertionError("middle target coefficient must be even")

omega = m1 + 2 * m2
cover_count = 3 * omega
orbit_count = m2 + m1 // 2
if (omega, cover_count, orbit_count) != (12, 36, 6):
    raise AssertionError(
        f"count bridge: {(omega, cover_count, orbit_count)}"
    )

lines = [
    "PASS: Star-Kneser multiplicity convolution",
    "local supports reproduce A3, A5, and A41",
    "convolution equals the 45-point exponent-box fibre count",
    "full C10 coefficient vector = (3,6,3,6,3,6,3,6,3,6)",
    "all four subgroup pushforward-convolution identities verified",
    "Star surplus rows = (1,6,2,1)",
    "target coefficients = (m0,m1,m2) = (3,6,3)",
    "Omega = 12, Lorentz cover size = 36, D3 quotient size = 6",
]

output = Path(__file__).with_name(
    "verify_star_kneser_multiplicity_convolution_output.txt"
)
output.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("\n".join(lines))

#!/usr/bin/env python3
"""Exact algebra behind the two vector figures added on 2026-08-05."""

from sympy import Matrix, Rational, eye, simplify, sqrt


def assert_zero_matrix(matrix):
    assert all(simplify(entry) == 0 for entry in matrix)


def verify_tetrahedral_carrier():
    root3 = sqrt(3)

    v_star = Matrix([0, 0, 1, 0])
    v_zero = Matrix([2, 2, 0, 2])
    v_plus = Matrix([2 + root3, -1, 0, 2 - root3])
    v_minus = Matrix([2 - root3, -1, 0, 2 + root3])

    coordinate_matrix = Matrix.hstack(v_star, v_zero, v_plus, v_minus)
    assert simplify(coordinate_matrix.det() + 24 * root3) == 0

    rotation = Matrix([
        [Rational(1, 4), root3 / 2, 0, Rational(3, 4)],
        [-root3 / 4, Rational(-1, 2), 0, root3 / 4],
        [0, 0, 1, 0],
        [Rational(3, 4), -root3 / 2, 0, Rational(1, 4)],
    ])
    reflection = Matrix([
        [0, 0, 0, 1],
        [0, 1, 0, 0],
        [0, 0, 1, 0],
        [1, 0, 0, 0],
    ])
    quarter = Matrix.diag(1, 1, -1, 1)

    assert_zero_matrix(rotation**3 - eye(4))
    assert_zero_matrix(reflection**2 - eye(4))
    assert_zero_matrix(reflection * rotation * reflection - rotation.inv())

    assert_zero_matrix(rotation * v_star - v_star)
    assert_zero_matrix(rotation * v_zero - v_plus)
    assert_zero_matrix(rotation * v_plus - v_minus)
    assert_zero_matrix(rotation * v_minus - v_zero)

    assert_zero_matrix(reflection * v_star - v_star)
    assert_zero_matrix(reflection * v_zero - v_zero)
    assert_zero_matrix(reflection * v_plus - v_minus)
    assert_zero_matrix(reflection * v_minus - v_plus)

    assert_zero_matrix(quarter * v_star + v_star)
    for vector in (v_zero, v_plus, v_minus):
        assert_zero_matrix(quarter * vector - vector)

    return coordinate_matrix.det()


def verify_c6_figure():
    carrier = {0, 1, 5}
    target = {2, 3, 4}
    left_ordered = (4, 3, 2)
    right_ordered = (2, 3, 4)

    inversion = {exponent: (-exponent) % 6 for exponent in range(6)}
    assert set(inversion) == set(range(6))
    assert set(inversion.values()) == set(range(6))
    assert carrier.isdisjoint(target)
    assert carrier | target == set(range(6))
    assert tuple(inversion[x] for x in left_ordered) == right_ordered
    assert inversion[0] == 0 and inversion[3] == 3
    assert inversion[1] == 5 and inversion[5] == 1
    assert inversion[2] == 4 and inversion[4] == 2

    exchange = Matrix([[0, 1], [1, 0]])
    assert exchange**2 == eye(2)
    return left_ordered, right_ordered


if __name__ == "__main__":
    determinant = verify_tetrahedral_carrier()
    left, right = verify_c6_figure()
    print(f"PASS tetrahedral coordinate determinant = {determinant}")
    print("PASS Fable D3 action = fixed apex plus cyclic/reflected opposite face")
    print("PASS quarter signs = (-1,+1,+1,+1)")
    print(f"PASS ordered C6 targets = {left} -> {right}")
    print("PASS C6 inversion = 0,3 fixed; 1<->5; 2<->4")
    print("PASS endpoint exchange matrix squares to identity")

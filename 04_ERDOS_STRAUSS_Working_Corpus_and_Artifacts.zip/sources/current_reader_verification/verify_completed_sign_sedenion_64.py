"""Exact checks for the completed two-sign sedenion carrier.

The central sign factor is R[C2 x C2].  The blade factor is the
fourfold Cayley--Dickson algebra in binary-subset order.  Coefficients
are integers throughout.
"""

from __future__ import annotations

from collections import defaultdict
from itertools import product


Vector = dict[int, int]
Completed = dict[tuple[int, int], int]


def clean(vector: Vector) -> Vector:
    return {index: coefficient for index, coefficient in vector.items() if coefficient}


def add(left: Vector, right: Vector, scale: int = 1) -> Vector:
    result = dict(left)
    for index, coefficient in right.items():
        result[index] = result.get(index, 0) + scale * coefficient
    return clean(result)


def conjugate(vector: Vector) -> Vector:
    return {
        index: coefficient if index == 0 else -coefficient
        for index, coefficient in vector.items()
    }


def cayley_dickson(left: Vector, right: Vector, level: int = 4) -> Vector:
    """Multiply using (a,b)(c,d)=(ac-d* b, da+b c*)."""
    if level == 0:
        coefficient = left.get(0, 0) * right.get(0, 0)
        return {0: coefficient} if coefficient else {}

    half = 1 << (level - 1)
    a = {index: coefficient for index, coefficient in left.items() if index < half}
    b = {index - half: coefficient for index, coefficient in left.items() if index >= half}
    c = {index: coefficient for index, coefficient in right.items() if index < half}
    d = {index - half: coefficient for index, coefficient in right.items() if index >= half}

    first = add(
        cayley_dickson(a, c, level - 1),
        cayley_dickson(conjugate(d), b, level - 1),
        -1,
    )
    second = add(
        cayley_dickson(d, a, level - 1),
        cayley_dickson(b, conjugate(c), level - 1),
    )
    return add(first, {index + half: coefficient for index, coefficient in second.items()})


def blade_product(left: int, right: int) -> tuple[int, int]:
    value = cayley_dickson({left: 1}, {right: 1})
    assert len(value) == 1
    blade, coefficient = next(iter(value.items()))
    assert coefficient in (-1, 1)
    assert blade == (left ^ right)
    return coefficient, blade


def completed_add(left: Completed, right: Completed, scale: int = 1) -> Completed:
    result: defaultdict[tuple[int, int], int] = defaultdict(int)
    for key, coefficient in left.items():
        result[key] += coefficient
    for key, coefficient in right.items():
        result[key] += scale * coefficient
    return {key: coefficient for key, coefficient in result.items() if coefficient}


def completed_product(left: Completed, right: Completed) -> Completed:
    result: defaultdict[tuple[int, int], int] = defaultdict(int)
    for (left_sign, left_blade), left_coefficient in left.items():
        for (right_sign, right_blade), right_coefficient in right.items():
            blade_sign, blade = blade_product(left_blade, right_blade)
            result[(left_sign ^ right_sign, blade)] += (
                left_coefficient * right_coefficient * blade_sign
            )
    return {key: coefficient for key, coefficient in result.items() if coefficient}


def basis(sign: int, blade: int, coefficient: int = 1) -> Completed:
    return {(sign, blade): coefficient} if coefficient else {}


def associator(left: Completed, middle: Completed, right: Completed) -> Completed:
    return completed_add(
        completed_product(completed_product(left, middle), right),
        completed_product(left, completed_product(middle, right)),
        -1,
    )


def gamma(left: Completed, right: Completed, value: Completed) -> Completed:
    commutator_action = completed_add(
        completed_product(left, completed_product(right, value)),
        completed_product(right, completed_product(left, value)),
        -1,
    )
    commutator = completed_add(
        completed_product(left, right),
        completed_product(right, left),
        -1,
    )
    return completed_add(
        commutator_action,
        completed_product(commutator, value),
        -1,
    )


def main() -> None:
    # Four central sign labels and sixteen blade labels give 64 cells.
    labels = {(sign, blade) for sign in range(4) for blade in range(16)}
    assert len(labels) == 64
    assert [16 * (2**extra_bits) for extra_bits in range(3)] == [16, 32, 64]

    # Ordered two-factor histories and their product projection.
    histories = {
        (left_sign, right_sign, blade)
        for left_sign in range(4)
        for right_sign in range(4)
        for blade in range(16)
    }
    assert len(histories) == 256
    history_fibres: defaultdict[tuple[int, int], set[tuple[int, int, int]]] = defaultdict(set)
    for left_sign, right_sign, blade in histories:
        history_fibres[(left_sign ^ right_sign, blade)].add(
            (left_sign, right_sign, blade)
        )
    assert len(history_fibres) == 64
    assert {len(fibre) for fibre in history_fibres.values()} == {4}

    # The champion order has lower signs (+,-); the reversed order has (-,+).
    # In bit order (hat,check), check=0 means lower plus and check=1 lower minus.
    champion_histories = {
        (upper_scalar, upper_leg | 2, blade)
        for upper_scalar in (0, 1)
        for upper_leg in (0, 1)
        for blade in range(16)
    }
    reversed_histories = {
        (right_sign, left_sign, blade)
        for left_sign, right_sign, blade in champion_histories
    }
    assert len(champion_histories) == 64
    assert len(reversed_histories) == 64
    assert champion_histories.isdisjoint(reversed_histories)
    assert len(champion_histories | reversed_histories) == 128
    assert {
        (left_sign ^ right_sign, blade)
        for left_sign, right_sign, blade in champion_histories
    } == {
        (left_sign ^ right_sign, blade)
        for left_sign, right_sign, blade in reversed_histories
    }
    champion_image = {
        (left_sign ^ right_sign, blade)
        for left_sign, right_sign, blade in champion_histories
    }
    assert len(champion_image) == 32

    # The observed and reversed sign words remain distinct before multiplication.
    observed_history = (1, 2, 12)  # ((-,+),(+,-),o_34)
    reversed_history = (2, 1, 12)  # ((+,-),(-,+),o_34)
    transposed_history = (0, 3, 12)  # ((+,+),(-,-),o_34)
    reversed_transposed_history = (3, 0, 12)  # ((-,-),(+,+),o_34)
    assert observed_history in champion_histories
    assert reversed_history in reversed_histories
    assert transposed_history in champion_histories
    assert reversed_transposed_history in reversed_histories
    assert observed_history != reversed_history
    target_history_fibre = {
        history
        for history in histories
        if (history[0] ^ history[1], history[2]) == (3, 12)
    }
    assert target_history_fibre == {
        observed_history,
        reversed_history,
        transposed_history,
        reversed_transposed_history,
    }

    def factor_order(history: tuple[int, int, int]) -> tuple[int, int, int]:
        left_sign, right_sign, blade = history
        return right_sign, left_sign, blade

    def upper_sign_transpose(history: tuple[int, int, int]) -> tuple[int, int, int]:
        left_sign, right_sign, blade = history
        new_left = (right_sign & 1) | (left_sign & 2)
        new_right = (left_sign & 1) | (right_sign & 2)
        return new_left, new_right, blade

    # The two involutions commute and preserve every completed product cell.
    for history in histories:
        assert factor_order(factor_order(history)) == history
        assert upper_sign_transpose(upper_sign_transpose(history)) == history
        assert factor_order(upper_sign_transpose(history)) == upper_sign_transpose(
            factor_order(history)
        )
        target = (history[0] ^ history[1], history[2])
        assert (
            factor_order(history)[0] ^ factor_order(history)[1],
            factor_order(history)[2],
        ) == target
        assert (
            upper_sign_transpose(history)[0] ^ upper_sign_transpose(history)[1],
            upper_sign_transpose(history)[2],
        ) == target

    expected_orbit_sizes = {0: 1, 1: 2, 2: 2, 3: 4}
    for target_sign, expected_size in expected_orbit_sizes.items():
        for blade in range(16):
            fibre = history_fibres[(target_sign, blade)]
            for history in fibre:
                orbit = {
                    history,
                    factor_order(history),
                    upper_sign_transpose(history),
                    factor_order(upper_sign_transpose(history)),
                }
                assert len(orbit) == expected_size
                assert orbit <= fibre

    assert upper_sign_transpose(observed_history) == transposed_history
    assert factor_order(observed_history) == reversed_history
    assert factor_order(upper_sign_transpose(observed_history)) == (
        reversed_transposed_history
    )

    # Closure and the six-bit carrier law.
    for left_sign, left_blade in labels:
        for right_sign, right_blade in labels:
            coefficient, blade = blade_product(left_blade, right_blade)
            assert coefficient in (-1, 1)
            assert (left_sign ^ right_sign, blade) in labels

    # Products printed in the completed-tesserine source.
    source_products = {
        (1, 2): (1, 3),
        (15, 12): (1, 3),
        (1, 12): (-1, 13),
        (15, 2): (-1, 13),
        (2, 1): (-1, 3),
        (12, 15): (-1, 3),
        (2, 15): (1, 13),
        (12, 1): (1, 13),
        (3, 12): (-1, 15),
        (13, 12): (1, 1),
    }
    for pair, expected in source_products.items():
        assert blade_product(*pair) == expected

    # Primary two-sided zero-divisor pair.
    x = completed_add(basis(0, 1), basis(0, 15), -1)
    y = completed_add(basis(0, 2), basis(0, 12))
    assert completed_product(x, y) == {}
    assert completed_product(y, x) == {}

    # Completed compressed pair.  Bits 01 and 10 denote hat and check.
    hat = 1
    check = 2
    hat_check = 3
    x_bar = completed_add(basis(0, 1), basis(hat_check, 15))
    y_bar = completed_add(basis(0, 2), basis(check, 12))
    rhs = completed_add(
        completed_add(basis(0, 3), basis(hat, 3)),
        completed_add(basis(check, 13), basis(hat_check, 13)),
        -1,
    )
    assert completed_product(x_bar, y_bar) == rhs
    assert completed_product(y_bar, x_bar) == {
        key: -coefficient for key, coefficient in rhs.items()
    }

    # The source's completed associator residue.
    unit = basis(0, 0)
    target = basis(check, 12)
    assert gamma(x_bar, y_bar, unit) == {}
    assert gamma(x_bar, y_bar, target) == basis(hat, 1, 2)

    # Central sign bits do not change whether a blade triple associates.
    nonzero_blade_associators = 0
    for left_blade, middle_blade, right_blade in product(range(16), repeat=3):
        base = associator(
            basis(0, left_blade),
            basis(0, middle_blade),
            basis(0, right_blade),
        )
        if base:
            nonzero_blade_associators += 1
        for sign_triple in ((0, 0, 0), (1, 2, 3), (3, 1, 2)):
            lifted = associator(
                basis(sign_triple[0], left_blade),
                basis(sign_triple[1], middle_blade),
                basis(sign_triple[2], right_blade),
            )
            expected = {
                (sign_triple[0] ^ sign_triple[1] ^ sign_triple[2], blade): coefficient
                for (_, blade), coefficient in base.items()
            }
            assert lifted == expected

    print("PASS: exact completed two-sign sedenion carrier")
    print("homogeneous carrier = C2^2 x C2^4 with 4 x 16 = 64 cells")
    print("binary grading tower dimensions = 16, 32, 64")
    print("unrestricted ordered two-factor history carrier = 256 cells with four histories per product cell")
    print("champion factor order plus its reversed order = 64 + 64 = 128 disjoint histories")
    print("both champion orders project onto the same 32 lower-minus product cells")
    print("observed ((-,+),(+,-),o_34) and reversed ((+,-),(-,+),o_34) histories remain distinct")
    print("the (-,-,o_34) product fibre contains exactly four ordered histories, including E21 and E12")
    print("upper-sign transpose and factor-order reversal commute and preserve product cells")
    print("history-orbit sizes over (++),(-,+),(+,-),(-,-) sectors are 1,2,2,4")
    print("the (-,-) sector is the unique four-point C2 x C2 history torsor")
    print("all 4096 basis products close by XOR with Cayley--Dickson sign")
    print("all displayed source products and the two-sided zero-divisor pair agree")
    print("compressed products and completed associator residue agree")
    print(
        "central sign bits preserve the associator support; "
        f"{nonzero_blade_associators} of 4096 ordered blade triples have nonzero associator"
    )


if __name__ == "__main__":
    main()

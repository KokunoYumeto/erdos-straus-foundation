from fractions import Fraction


def mat_zero(rows, cols):
    return [[Fraction(0) for _ in range(cols)] for _ in range(rows)]


def mat_identity(n):
    out = mat_zero(n, n)
    for i in range(n):
        out[i][i] = Fraction(1)
    return out


def mat_transpose(a):
    return [list(row) for row in zip(*a)]


def mat_mul(a, b):
    rows = len(a)
    inner = len(b)
    cols = len(b[0])
    return [
        [sum(a[i][k] * b[k][j] for k in range(inner)) for j in range(cols)]
        for i in range(rows)
    ]


def mat_rank(a):
    m = [row[:] for row in a]
    rows = len(m)
    cols = len(m[0]) if rows else 0
    pivot_row = 0
    for col in range(cols):
        pivot = next((i for i in range(pivot_row, rows) if m[i][col]), None)
        if pivot is None:
            continue
        m[pivot_row], m[pivot] = m[pivot], m[pivot_row]
        scale = m[pivot_row][col]
        m[pivot_row] = [x / scale for x in m[pivot_row]]
        for i in range(rows):
            if i != pivot_row and m[i][col]:
                factor = m[i][col]
                m[i] = [x - factor * y for x, y in zip(m[i], m[pivot_row])]
        pivot_row += 1
        if pivot_row == rows:
            break
    return pivot_row


def permutation_matrix(size, image):
    out = mat_zero(size, size)
    for old, new in enumerate(image):
        out[new][old] = Fraction(1)
    return out


def source_index(q, orbit, m, epsilon):
    return ((orbit * 3 + m) * 2) + epsilon


def target_index(q, orbit, epsilon, m):
    return ((orbit * 2 + epsilon) * 3) + m


for q in (1, 2, 6):
    size = 6 * q

    theta_image = [None] * size
    source_r_image = [None] * size
    source_s_image = [None] * size
    target_r_image = [None] * size
    target_s_image = [None] * size

    for orbit in range(q):
        for m in range(3):
            for epsilon in range(2):
                src = source_index(q, orbit, m, epsilon)
                tgt = target_index(q, orbit, epsilon, m)
                theta_image[src] = tgt
                source_r_image[src] = source_index(q, orbit, (m + 1) % 3, epsilon)
                source_s_image[src] = source_index(q, orbit, (-m) % 3, 1 - epsilon)
                target_r_image[tgt] = target_index(q, orbit, epsilon, (m + 1) % 3)
                target_s_image[tgt] = target_index(q, orbit, 1 - epsilon, (-m) % 3)

    theta = permutation_matrix(size, theta_image)
    r_source = permutation_matrix(size, source_r_image)
    s_source = permutation_matrix(size, source_s_image)
    r_target = permutation_matrix(size, target_r_image)
    s_target = permutation_matrix(size, target_s_image)

    assert mat_mul(theta, r_source) == mat_mul(r_target, theta)
    assert mat_mul(theta, s_source) == mat_mul(s_target, theta)
    assert mat_mul(mat_mul(r_source, r_source), r_source) == mat_identity(size)
    assert mat_mul(s_source, s_source) == mat_identity(size)
    assert mat_mul(mat_mul(s_source, r_source), s_source) == mat_mul(r_source, r_source)

    collapse = mat_zero(q, size)
    for orbit in range(q):
        for epsilon in range(2):
            for m in range(3):
                collapse[orbit][target_index(q, orbit, epsilon, m)] = Fraction(1)
    collapse_source = mat_mul(collapse, theta)
    assert mat_rank(collapse_source) == q
    assert size - mat_rank(collapse_source) == 5 * q
    assert mat_mul(collapse_source, r_source) == collapse_source
    assert mat_mul(collapse_source, s_source) == collapse_source

    blade_21_source = mat_zero(size, size)
    blade_21_target = mat_zero(size, size)
    low_source = mat_zero(size, size)
    high_source = mat_zero(size, size)
    low_target = mat_zero(size, size)
    high_target = mat_zero(size, size)

    for orbit in range(q):
        for m in range(3):
            src_low = source_index(q, orbit, m, 0)
            src_high = source_index(q, orbit, m, 1)
            tgt_low = target_index(q, orbit, 0, m)
            tgt_high = target_index(q, orbit, 1, m)
            blade_21_source[src_high][src_low] = Fraction(2)
            blade_21_target[tgt_high][tgt_low] = Fraction(2)
            low_source[src_low][src_low] = Fraction(1)
            high_source[src_high][src_high] = Fraction(1)
            low_target[tgt_low][tgt_low] = Fraction(1)
            high_target[tgt_high][tgt_high] = Fraction(1)

    blade_12_source = mat_transpose(blade_21_source)
    blade_12_target = mat_transpose(blade_21_target)

    assert mat_mul(mat_mul(theta, blade_21_source), mat_transpose(theta)) == blade_21_target
    assert mat_mul(mat_mul(theta, blade_12_source), mat_transpose(theta)) == blade_12_target
    assert mat_mul(blade_12_source, blade_21_source) == [[4 * x for x in row] for row in low_source]
    assert mat_mul(blade_21_source, blade_12_source) == [[4 * x for x in row] for row in high_source]
    assert mat_mul(blade_12_target, blade_21_target) == [[4 * x for x in row] for row in low_target]
    assert mat_mul(blade_21_target, blade_12_target) == [[4 * x for x in row] for row in high_target]
    assert mat_mul(mat_mul(s_source, blade_21_source), s_source) == blade_12_source
    assert mat_mul(mat_mul(r_source, blade_21_source), mat_transpose(r_source)) == blade_21_source

    # Every orbit contributes three independent low-to-high blade channels.
    assert mat_rank(blade_21_source) == 3 * q
    assert mat_rank(blade_12_source) == 3 * q

print("PASS order-determined map is a bijection for one, two, and six complement orbits")
print("PASS source and path actions satisfy the D3 relations")
print("PASS orbitwise map intertwines both D3 generators")
print("PASS C1 support collapse has rank q and nullity 5q")
print("PASS support collapse is invariant under rotation and reflection")
print("PASS directed low-to-high and high-to-low blade channels retain their order")
print("PASS quarter products recover the low and high sheet projectors")
print("PASS reflection exchanges the two blades and rotation preserves each blade")
print("PASS each complement orbit contributes three directed blade channels")

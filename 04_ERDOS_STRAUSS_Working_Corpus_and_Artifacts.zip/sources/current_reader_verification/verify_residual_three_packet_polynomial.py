#!/usr/bin/env python3
"""Verify the exact residual-three packet polynomial and divisor moments."""

from collections import Counter
from math import isqrt


PRIME_BOUND = 5000


def is_prime(n: int) -> bool:
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def factorization(n: int) -> dict[int, int]:
    factors: dict[int, int] = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d = 3 if d == 2 else d + 2
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors


def divisors(n: int) -> list[int]:
    result = [1]
    for prime, exponent in factorization(n).items():
        powers = [prime**j for j in range(exponent + 1)]
        result = [d * power for d in result for power in powers]
    return sorted(result)


def is_squarefree(n: int) -> bool:
    return all(exponent == 1 for exponent in factorization(n).values())


def divisor_count(n: int) -> int:
    value = 1
    for exponent in factorization(n).values():
        value *= exponent + 1
    return value


def divisor_power_sum(n: int, power: int) -> int:
    return sum(d**power for d in divisors(n))


def chi3(n: int) -> int:
    residue = n % 3
    if residue == 1:
        return 1
    if residue == 2:
        return -1
    return 0


def direct_packets(a: int) -> set[tuple[int, int, int]]:
    packets: set[tuple[int, int, int]] = set()
    for s in divisors(a):
        if not is_squarefree(s):
            continue
        n = a // s
        for t in divisors(n):
            m = n // t
            if t >= m:
                continue
            if (4 * s * t * t + 1) % 3 == 0:
                packets.add((s, t, m))
    return packets


def predicted_packets(a: int) -> set[tuple[int, int, int]]:
    packets: set[tuple[int, int, int]] = set()
    for s in divisors(a):
        if not is_squarefree(s) or s % 3 != 2:
            continue
        n = a // s
        assert n % 3 == 2
        assert isqrt(n) ** 2 != n
        for t in divisors(n):
            m = n // t
            if t < m:
                packets.add((s, t, m))
    return packets


def polynomial(packets: set[tuple[int, int, int]]) -> Counter[tuple[int, int]]:
    return Counter((t + m, m - t) for _, t, m in packets)


def local_products(a: int) -> tuple[int, int, int, int, int, int]:
    a0 = b0 = a1 = b1 = a2 = b2 = h = k = 1
    for prime, exponent in factorization(a).items():
        assert prime != 3
        sigma0_e = exponent + 1
        sigma0_previous = exponent
        sigma1_e = divisor_power_sum(prime**exponent, 1)
        sigma1_previous = divisor_power_sum(prime ** (exponent - 1), 1)
        sigma2_e = divisor_power_sum(prime**exponent, 2)
        sigma2_previous = divisor_power_sum(prime ** (exponent - 1), 2)
        character = chi3(prime)
        a0 *= sigma0_e + sigma0_previous
        b0 *= sigma0_e + character * sigma0_previous
        a1 *= sigma1_e + sigma1_previous
        b1 *= sigma1_e + character * sigma1_previous
        a2 *= sigma2_e + sigma2_previous
        b2 *= sigma2_e + character * sigma2_previous
        h *= (exponent + 1) * prime**exponent + exponent * prime ** (exponent - 1)
        k *= (exponent + 1) * prime**exponent + character * exponent * prime ** (exponent - 1)
    return a0, b0, a1, b1, a2, b2, h, k


def main() -> None:
    primes = [
        p
        for p in range(2, PRIME_BOUND)
        if p % 12 == 1 and is_prime(p)
    ]
    occupied = 0
    total_packets = 0
    first_data: list[tuple[object, ...]] = []

    for p in primes:
        a = (p + 3) // 4
        assert a % 3 == 1
        direct = direct_packets(a)
        predicted = predicted_packets(a)
        assert direct == predicted

        poly = polynomial(direct)
        assert all(coefficient == 1 for coefficient in poly.values())
        assert len(poly) == len(direct)

        factors = factorization(a)
        a_plus = 1
        for prime, exponent in factors.items():
            if prime % 3 == 1:
                a_plus *= prime**exponent
        delta = divisor_count(a * a) - divisor_count(a_plus * a_plus)
        assert delta % 4 == 0
        assert len(direct) == delta // 4

        a0, b0, a1, b1, a2, b2, h, k = local_products(a)
        assert a0 == divisor_count(a * a)
        assert b0 == divisor_count(a_plus * a_plus)
        assert len(direct) == (a0 - b0) // 4

        dx = sum(t + m for _, t, m in direct)
        dx2 = sum((t + m) ** 2 for _, t, m in direct)
        dz2 = sum((m - t) ** 2 for _, t, m in direct)
        assert dx == (a1 - b1) // 2
        assert dx2 == (a2 - b2 + h - k) // 2
        assert dz2 == (a2 - b2 - h + k) // 2

        direct_dx = 0
        direct_dx2 = 0
        direct_dz2 = 0
        for s in divisors(a):
            if not is_squarefree(s) or s % 3 != 2:
                continue
            n = a // s
            direct_dx += divisor_power_sum(n, 1)
            direct_dx2 += divisor_power_sum(n, 2) + n * divisor_count(n)
            direct_dz2 += divisor_power_sum(n, 2) - n * divisor_count(n)
        assert (dx, dx2, dz2) == (direct_dx, direct_dx2, direct_dz2)

        rank = 3 * len(direct)
        coefficient_count = 2 * len(direct)
        assert rank * 2 == coefficient_count * 3

        if direct:
            occupied += 1
            total_packets += len(direct)
            if len(first_data) < 8:
                first_data.append(
                    (p, a, tuple(sorted(poly)), len(direct), rank, dx, dx2, dz2)
                )

    print("residual-three packet parametrization below 5000: PASS")
    print("residual-three polynomial coefficient uniqueness below 5000: PASS")
    print("residual-three multiplicative rank formula below 5000: PASS")
    print("residual-three first sum moment below 5000: PASS")
    print("residual-three quadratic sum and gap moments below 5000: PASS")
    print("primes checked=", len(primes))
    print("occupied residual-three shells=", occupied)
    print("total residual-three packets=", total_packets)
    print("first residual-three polynomial data=", tuple(first_data))


if __name__ == "__main__":
    main()

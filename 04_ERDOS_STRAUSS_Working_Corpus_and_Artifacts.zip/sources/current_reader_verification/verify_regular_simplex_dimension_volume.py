#!/usr/bin/env python3
"""Exact checks for the centered regular-simplex dimension--volume identities."""

from fractions import Fraction
from math import factorial

import sympy as sp


def product_nonzero_eigenvalues(matrix: sp.Matrix) -> sp.Expr:
    product = sp.Integer(1)
    for eigenvalue, multiplicity in matrix.eigenvals().items():
        if eigenvalue != 0:
            product *= eigenvalue ** multiplicity
    return sp.factor(product)


for n in range(2, 13):
    one_vertices = sp.ones(n + 1, 1)
    centered_gram = (
        sp.Rational(n + 1, n) * sp.eye(n + 1)
        - sp.Rational(1, n) * (one_vertices * one_vertices.T)
    )
    assert centered_gram.rank() == n
    assert centered_gram.eigenvals() == {
        sp.Integer(0): 1,
        sp.Rational(n + 1, n): n,
    }
    centered_pdet = product_nonzero_eigenvalues(centered_gram)
    assert centered_pdet == sp.Rational(n + 1, n) ** n

    one_face = sp.ones(n, 1)
    projected_gram = sp.Rational(n + 1, n) * (
        sp.eye(n) - sp.Rational(1, n) * (one_face * one_face.T)
    )
    assert projected_gram.rank() == n - 1
    assert projected_gram.eigenvals() == {
        sp.Integer(0): 1,
        sp.Rational(n + 1, n): n - 1,
    }
    projected_pdet = product_nonzero_eigenvalues(projected_gram)
    assert projected_pdet == sp.Rational(n + 1, n) ** (n - 1)
    assert centered_pdet == sp.Rational(n + 1, n) * projected_pdet

    edge_gram = sp.Rational(n + 1, n) * (sp.eye(n) + sp.ones(n))
    expected_edge_det = sp.Rational((n + 1) ** (n + 1), n**n)
    assert sp.factor(edge_gram.det()) == expected_edge_det
    volume_squared = sp.factor(edge_gram.det() / factorial(n) ** 2)
    expected_volume_squared = sp.Rational(
        (n + 1) ** (n + 1), factorial(n) ** 2 * n**n
    )
    assert volume_squared == expected_volume_squared
    assert factorial(n) ** 2 * volume_squared == (n + 1) * centered_pdet

    face_edge_gram = sp.Rational(n + 1, n) * (
        sp.eye(n - 1) + sp.ones(n - 1)
    )
    expected_face_edge_det = n * sp.Rational(n + 1, n) ** (n - 1)
    assert sp.factor(face_edge_gram.det()) == expected_face_edge_det
    face_volume_squared = sp.factor(
        face_edge_gram.det() / factorial(n - 1) ** 2
    )
    expected_face_volume_squared = sp.Rational(
        (n + 1) ** (n - 1), n ** (n - 2) * factorial(n - 1) ** 2
    )
    assert face_volume_squared == expected_face_volume_squared
    assert (
        factorial(n - 1) ** 2 * face_volume_squared
        == n * projected_pdet
    )

    height = sp.Rational(n + 1, n)
    assert volume_squared == sp.factor(
        (height / n) ** 2 * face_volume_squared
    )

    vertex_state = centered_gram / (n + 1)
    assert sp.trace(vertex_state) == 1
    assert vertex_state.eigenvals() == {
        sp.Integer(0): 1,
        sp.Rational(1, n): n,
    }
    assert sp.trace(vertex_state**2) == sp.Rational(1, n)
    assert product_nonzero_eigenvalues(vertex_state) == sp.Rational(1, n**n)
    assert volume_squared == sp.factor(
        sp.Rational((n + 1) ** (n + 1), factorial(n) ** 2)
        * product_nonzero_eigenvalues(vertex_state)
    )

    face_state = sp.Rational(n, n**2 - 1) * projected_gram
    assert sp.trace(face_state) == 1
    assert face_state.eigenvals() == {
        sp.Integer(0): 1,
        sp.Rational(1, n - 1): n - 1,
    }
    assert sp.trace(face_state**2) == sp.Rational(1, n - 1)
    assert product_nonzero_eigenvalues(face_state) == sp.Rational(
        1, (n - 1) ** (n - 1)
    )
    assert face_volume_squared == sp.factor(
        sp.Rational(
            (n**2 - 1) ** (n - 1),
            n ** (n - 2) * factorial(n - 1) ** 2,
        )
        * product_nonzero_eigenvalues(face_state)
    )

    projection = sp.eye(n + 1) - sp.Rational(1, n + 1) * (
        one_vertices * one_vertices.T
    )
    traceless_generator = projection - sp.Rational(n, n + 1) * sp.eye(n + 1)
    state_path_length_squared = sp.trace(vertex_state**2)
    special_path_length_squared = sp.trace(traceless_generator**2)
    assert state_path_length_squared == sp.Rational(1, n)
    assert special_path_length_squared == sp.Rational(n, n + 1)
    assert sp.Rational(1, n) == state_path_length_squared
    assert volume_squared == sp.factor(
        sp.Rational((n + 1) ** (n + 1), factorial(n) ** 2)
        * state_path_length_squared**n
    )
    assert volume_squared == sp.factor(
        sp.Rational(n + 1, factorial(n) ** 2)
        * special_path_length_squared ** (-n)
    )

print("PASS centered vertex Gram has rank n and nonzero spectrum ((n+1)/n)^n")
print("PASS projected face Gram has rank n-1 and nonzero spectrum ((n+1)/n)^(n-1)")
print("PASS centered and projected pseudodeterminants differ by (n+1)/n")
print("PASS n-simplex squared volume = (n+1)^(n+1)/((n!)^2 n^n)")
print("PASS opposite-face squared volume = (n+1)^(n-1)/(n^(n-2)((n-1)!)^2)")
print("PASS altitude and face volume recover the full simplex volume")
print("PASS trace-one vertex state has spectrum 0,(1/n)^n and entropy log(n)")
print("PASS trace-one face state has spectrum 0,(1/(n-1))^(n-1) and entropy log(n-1)")
print("PASS vertex-state and face-state pseudodeterminants recover both Euclidean volumes")
print("PASS hidden displacement magnitude = state purity = squared Hilbert-Schmidt path length")
print("PASS U(n+1) and SU(n+1) control lengths recover the full simplex volume")

n = 4
assert Fraction((n + 1) ** (n + 1), factorial(n) ** 2 * n**n) == Fraction(
    3125, 147456
)
assert Fraction(
    (n + 1) ** (n - 1), n ** (n - 2) * factorial(n - 1) ** 2
) == Fraction(125, 576)
assert Fraction(1, n) == Fraction(1, 4)
print("PASS n=4 centroid displacement = -v0/4, V4^2 = 3125/147456, face V3^2 = 125/576")
print("PASS n=4 trace-one vertex state has four nonzero eigenvalues equal to 1/4")
print("PASS n=4 state-path length = 1/2 and traceless-path length = 2/sqrt(5)")

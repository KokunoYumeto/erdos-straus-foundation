"""First occupied residual after R=23 in the prime-cofactor E21 family."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import argparse
import hashlib
from math import gcd

from sympy import factorint

from scan_prime_cofactor_r23_pullback import (
    DEFAULT_BOUND,
    Survivor,
    census,
    survivor_kind,
)


EXPECTED_DEFAULT_RESIDUAL_COUNTS = {
    27: 556,
    31: 574,
    35: 234,
    39: 144,
    43: 10,
    47: 10,
    51: 1,
    55: 2,
    59: 3,
}
EXPECTED_DEFAULT_HASH = (
    "40ff82510a860198c07b31c5aaa898b87b679128de483d57851de543514afc70"
)


def multiplicative_reach(
    modulus: int,
    factors: dict[int, int],
    channel: str,
) -> set[int]:
    reached = {1}
    for prime, exponent in sorted(factors.items()):
        residue = prime % modulus
        assert gcd(residue, modulus) == 1
        if channel == "exterior":
            powers = {pow(residue, power, modulus) for power in range(2 * exponent + 1)}
        elif channel == "middle":
            powers = {
                pow(residue, power, modulus)
                for power in range(-exponent, exponent + 1)
            }
        else:
            raise ValueError(channel)
        reached = {left * right % modulus for left in reached for right in powers}
    return reached


def incidence(prime: int, residual: int):
    denominator = (prime + residual) // 4
    assert 4 * denominator == prime + residual
    factors = factorint(denominator)
    assert gcd(denominator, residual) == 1
    exterior = multiplicative_reach(residual, factors, "exterior")
    middle = multiplicative_reach(residual, factors, "middle")
    quarter = -pow(4, -1, residual) % residual
    minus = residual - 1
    matrix = (
        (int(quarter in exterior), int(minus in exterior)),
        (int(quarter in middle), int(minus in middle)),
    )
    occupied = bool(matrix[0][0] or matrix[1][1])
    return denominator, tuple(sorted(factors.items())), matrix, occupied


def matrix_name(matrix) -> str:
    names = {
        ((0, 0), (0, 0)): "0",
        ((0, 1), (0, 0)): "E12",
        ((0, 0), (1, 0)): "E21",
        ((0, 1), (1, 0)): "S",
        ((1, 1), (1, 1)): "I+S",
    }
    return names.get(matrix, repr(matrix))


def divisors(factors: tuple[tuple[int, int], ...], doubled: bool = False):
    values = [1]
    for prime, exponent in factors:
        if doubled:
            exponent *= 2
        values = [
            value * prime**power
            for value in values
            for power in range(exponent + 1)
        ]
    return tuple(sorted(values))


def exterior_certificate(row):
    witnesses = tuple(
        value
        for value in divisors(row.factors, doubled=True)
        if (4 * value + 1) % row.residual == 0
    )
    assert witnesses
    witness = witnesses[0]
    lift_numerator = row.denominator + row.source.p * witness
    assert lift_numerator % row.residual == 0
    lift = lift_numerator // row.residual
    denominator_two = row.source.p * lift
    assert row.denominator * lift % witness == 0
    denominator_three = row.denominator * lift // witness
    assert (
        4 * row.denominator * denominator_two * denominator_three
        == row.source.p
        * (
            denominator_two * denominator_three
            + row.denominator * denominator_three
            + row.denominator * denominator_two
        )
    )
    return witness, denominator_two, denominator_three


@dataclass(frozen=True)
class Escape:
    source: Survivor
    residual: int
    denominator: int
    factors: tuple[tuple[int, int], ...]
    matrix: tuple[tuple[int, int], tuple[int, int]]

    @property
    def kind(self):
        return survivor_kind(self.source.logs)


def scan(bound: int, residual_limit: int):
    _, survivors = census(bound)
    escapes = []
    unresolved = []
    for source in survivors:
        found = None
        for residual in range(27, residual_limit + 1, 4):
            denominator, factors, matrix, occupied = incidence(source.p, residual)
            if occupied:
                found = Escape(source, residual, denominator, factors, matrix)
                break
        if found is None:
            unresolved.append(source)
        else:
            escapes.append(found)
    return survivors, tuple(escapes), tuple(unresolved)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ell-bound", type=int, default=DEFAULT_BOUND)
    parser.add_argument("--residual-limit", type=int, default=203)
    parser.add_argument("--show-rows", action="store_true")
    args = parser.parse_args()

    survivors, escapes, unresolved = scan(args.ell_bound, args.residual_limit)
    residual_counts = Counter(row.residual for row in escapes)
    state_counts = Counter((row.residual, matrix_name(row.matrix)) for row in escapes)
    kind_counts = Counter((row.kind, row.residual) for row in escapes)
    max_residual = max((row.residual for row in escapes), default=None)
    max_rows = tuple(row for row in escapes if row.residual == max_residual)

    serialization = "\n".join(
        f"{row.source.ell}|{row.source.p}|{row.kind}|{row.residual}|"
        f"{row.denominator}|{row.factors}|{row.matrix}"
        for row in escapes
    )
    digest = hashlib.sha256(serialization.encode("ascii")).hexdigest()

    assert len(escapes) + len(unresolved) == len(survivors)
    if args.ell_bound == DEFAULT_BOUND and args.residual_limit == 203:
        assert not unresolved
        assert dict(residual_counts) == EXPECTED_DEFAULT_RESIDUAL_COUNTS
        assert max_residual == 59
        assert digest == EXPECTED_DEFAULT_HASH
    print("PASS: first post-R23 escape census in the prime-cofactor E21 family")
    print(f"ell bound: {args.ell_bound}")
    print(f"residual limit: {args.residual_limit}")
    print(f"R23 survivors: {len(survivors)}")
    print(f"escaped by limit: {len(escapes)}")
    print(f"unresolved by limit: {len(unresolved)}")
    print("first occupied residual counts: " + repr(dict(sorted(residual_counts.items()))))
    print("factor-type / first residual counts: " + repr(dict(sorted(kind_counts.items()))))
    print(f"maximal first occupied residual: {max_residual}")
    for row in max_rows:
        print(
            f"  maximal row: ell={row.source.ell}; p={row.source.p}; "
            f"type={row.kind}; R={row.residual}; a={row.denominator}; "
            f"factors={row.factors}; Xi={matrix_name(row.matrix)}"
        )
        witness, denominator_two, denominator_three = exterior_certificate(row)
        print(
            f"    exterior witness={witness}; decomposition: 4/{row.source.p}="
            f"1/{row.denominator}+1/{denominator_two}+1/{denominator_three}"
        )
    if unresolved:
        print("unresolved rows:")
        for row in unresolved:
            print(
                f"  ell={row.ell}; p={row.p}; type={survivor_kind(row.logs)}; "
                f"b={row.b}; factors={row.factors}; logs={row.logs}"
            )
    if args.show_rows:
        print("escape rows:")
        for row in escapes:
            print(
                f"  ell={row.source.ell}; p={row.source.p}; type={row.kind}; "
                f"R={row.residual}; a={row.denominator}; factors={row.factors}; "
                f"Xi={matrix_name(row.matrix)}"
            )
    print("escape-row SHA-256: " + digest)


if __name__ == "__main__":
    main()

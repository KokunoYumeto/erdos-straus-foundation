from collections import defaultdict
from functools import lru_cache
from math import gcd, isqrt
import sys


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(newline="\n")


def primes_up_to(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[:2] = b"\x00\x00"
    for prime in range(2, isqrt(limit) + 1):
        if sieve[prime]:
            sieve[prime * prime : limit + 1 : prime] = (
                b"\x00" * (((limit - prime * prime) // prime) + 1)
            )
    return [value for value in range(2, limit + 1) if sieve[value]]


@lru_cache(maxsize=None)
def divisors(value):
    result = []
    for divisor in range(1, isqrt(value) + 1):
        if value % divisor == 0:
            result.append(divisor)
            if divisor * divisor != value:
                result.append(value // divisor)
    return tuple(sorted(result))


@lru_cache(maxsize=None)
def factorization(value):
    factors = []
    candidate = 2
    while candidate * candidate <= value:
        exponent = 0
        while value % candidate == 0:
            value //= candidate
            exponent += 1
        if exponent:
            factors.append((candidate, exponent))
        candidate += 1 if candidate == 2 else 2
    if value > 1:
        factors.append((value, 1))
    return tuple(factors)


def divisor_count_square(value):
    result = 1
    for _, exponent in factorization(value):
        result *= 2 * exponent + 1
    return result


def unit_group_coefficients(a, modulus):
    coefficients = {1: 1}
    for prime, exponent in factorization(a):
        local = defaultdict(int)
        local[1] += 1
        for power in range(1, exponent + 1):
            residue = pow(prime, power, modulus)
            local[residue] += 1
            local[pow(residue, -1, modulus)] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left * right) % modulus] += left_count * right_count
        coefficients = dict(product)
    return coefficients


def c6_coefficients(a):
    residue_to_exponent = {pow(3, exponent, 7): exponent for exponent in range(6)}
    coefficients = {0: 1}
    for prime, exponent in factorization(a):
        generator_exponent = residue_to_exponent[prime % 7]
        local = defaultdict(int)
        local[0] += 1
        for power in range(1, exponent + 1):
            local[(power * generator_exponent) % 6] += 1
            local[(-power * generator_exponent) % 6] += 1
        product = defaultdict(int)
        for left, left_count in coefficients.items():
            for right, right_count in local.items():
                product[(left + right) % 6] += left_count * right_count
        coefficients = dict(product)
    return coefficients


shell_count = 0
r3_count = 0
r7_count = 0
r7_occupied_count = 0

for p in primes_up_to(5000):
    if p % 4 != 1:
        continue
    for R in divisors(p - 1):
        if R % 4 != 3:
            continue
        a = (p + R) // 4
        if 4 * a != p + R:
            raise AssertionError(f"nonintegral coupled shell at p={p}, R={R}")
        shell_count += 1

        ordered_pairs = [
            (x, y)
            for x in divisors(a)
            for y in divisors(a)
            if gcd(x, y) == 1
            and a % (x * y) == 0
            and (x + y) % R == 0
        ]
        group_coefficients = unit_group_coefficients(a, R)
        minus_one_coefficient = group_coefficients.get(R - 1, 0)
        if minus_one_coefficient != len(ordered_pairs):
            raise AssertionError(
                f"group coefficient fails at p={p}, R={R}, a={a}"
            )
        if minus_one_coefficient % 2:
            raise AssertionError(
                f"odd minus-one coefficient at p={p}, R={R}, a={a}"
            )

        packets = {
            (min(x, y), max(x, y))
            for x, y in ordered_pairs
        }
        if len(ordered_pairs) != 2 * len(packets):
            raise AssertionError(
                f"factor exchange fails at p={p}, R={R}, a={a}"
            )
        q = 3 * len(packets)
        if 2 * q != 3 * minus_one_coefficient:
            raise AssertionError(
                f"three-halves formula fails at p={p}, R={R}, a={a}"
            )

        if R == 3:
            r3_count += 1
            a_plus = 1
            for prime, exponent in factorization(a):
                if prime % 3 == 1:
                    a_plus *= prime**exponent
            expected_q = 3 * (
                divisor_count_square(a) - divisor_count_square(a_plus)
            ) // 4
            if q != expected_q:
                raise AssertionError(
                    f"R=3 divisor formula fails at p={p}, a={a}"
                )

        if R == 7:
            r7_count += 1
            c6_minus_one = c6_coefficients(a).get(3, 0)
            if c6_minus_one != minus_one_coefficient:
                raise AssertionError(
                    f"R=7 C6 coefficient fails at p={p}, a={a}"
                )
            if c6_minus_one:
                r7_occupied_count += 1


if not shell_count or not r3_count or not r7_count or not r7_occupied_count:
    raise AssertionError("the required coupled-shell test families were not all present")

print("PASS: coupled-shell unit-group coefficient formula")
print("the coefficient at minus one equals the ordered coprime-factor count")
print("the coefficient is even and half of it equals the packet count")
print("q_R,p equals three halves of the minus-one coefficient")
print("the R=3 specialization matches the divisor-rank formula")
print("the R=7 specialization is the C6 coefficient at z^3")
print("all coupled shells through p=5000 passed")

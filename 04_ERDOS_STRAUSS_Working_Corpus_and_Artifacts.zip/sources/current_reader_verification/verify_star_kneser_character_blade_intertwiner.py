from itertools import product

import sympy as sp


def exact(value):
    return sp.simplify(sp.expand_complex(value))


def require_zero(value, label):
    if exact(value) != 0:
        raise AssertionError(f"{label}: {exact(value)}")


def require_zero_matrix(matrix, label):
    for row in range(matrix.rows):
        for column in range(matrix.cols):
            require_zero(matrix[row, column], f"{label}[{row},{column}]")


order = 10
local_data = [
    (range(-1, 2), 8),
    (range(-2, 3), 4),
    (range(-1, 2), 3),
]

mu = [0] * order
for beta_3, beta_5, beta_41 in product(
    range(-1, 2), range(-2, 3), range(-1, 2)
):
    residue = (8 * beta_3 + 4 * beta_5 + 3 * beta_41) % order
    mu[residue] += 1

expected_mu = [3, 6, 3, 6, 3, 6, 3, 6, 3, 6]
if mu != expected_mu:
    raise AssertionError(f"coefficient vector: {mu}")

zeta = sp.exp(2 * sp.pi * sp.I / order)
fourier = [
    exact(sum(mu[h] * zeta ** (-k * h) for h in range(order)))
    for k in range(order)
]
expected_fourier = [45, 0, 0, 0, 0, -15, 0, 0, 0, 0]
if fourier != expected_fourier:
    raise AssertionError(f"C10 Fourier coefficients: {fourier}")

for k in range(order):
    local_factors = [
        sum(zeta ** (-k * step * beta) for beta in interval)
        for interval, step in local_data
    ]
    require_zero(
        sp.prod(local_factors) - fourier[k],
        f"local Fourier factorization at character {k}",
    )

nu = sp.Matrix([3, 6])
parity_pullback = sp.Matrix(
    order,
    2,
    lambda h, residue: 1 if h % 2 == residue else 0,
)
if parity_pullback * nu != sp.Matrix(mu):
    raise AssertionError("C10 coefficient vector is not the parity pullback")

sqrt2 = sp.sqrt(2)
u0 = sp.Matrix([[1, 1], [1, -1]]) / sqrt2
f0 = u0[:, 0]
f1 = u0[:, 1]
pi0 = f0 * f0.T
q0 = f1 * f1.T

left_convolution = sp.Matrix([[3, 6], [6, 3]])
require_zero_matrix(
    u0.T * left_convolution * u0 - sp.diag(9, -3),
    "C2 Fourier diagonalization",
)
require_zero_matrix(
    left_convolution - (9 * pi0 - 3 * q0),
    "projector decomposition",
)

x_positive = f0 * f1.T
x_negative = f1 * f0.T
require_zero_matrix(
    left_convolution * x_positive - x_positive * left_convolution
    - 12 * x_positive,
    "positive ordered channel",
)
require_zero_matrix(
    left_convolution * x_negative - x_negative * left_convolution
    + 12 * x_negative,
    "negative ordered channel",
)

e12 = sp.Matrix([[0, 1], [0, 0]])
e21 = sp.Matrix([[0, 0], [1, 0]])
require_zero_matrix(u0.T * x_positive * u0 - e12, "E12 carriage")
require_zero_matrix(u0.T * x_negative * u0 - e21, "E21 carriage")

w10 = sp.Matrix(
    order,
    order,
    lambda h, k: zeta ** (h * k) / sp.sqrt(order),
)
iota = sp.zeros(order, 2)
iota[0, 0] = 1
iota[5, 1] = 1
require_zero_matrix(
    w10.H * parity_pullback * u0 - sp.sqrt(5) * iota,
    "normalized Fourier parity intertwiner",
)

carried_generator = sp.diag(9, -3)
arithmetic_blade = 2 * e21
require_zero_matrix(
    carried_generator * arithmetic_blade
    - arithmetic_blade * carried_generator
    + 12 * arithmetic_blade,
    "arithmetic blade eigenvalue",
)

omega = 12
if carried_generator[0, 0] - carried_generator[1, 1] != omega:
    raise AssertionError("Fourier eigenvalue gap differs from Omega")

a, b = sp.symbols("a b", real=True)
symbolic_convolution = sp.Matrix([[a, b], [b, a]])
require_zero_matrix(
    u0.T * symbolic_convolution * u0 - sp.diag(a + b, a - b),
    "symbolic C2 convolution spectrum",
)
require_zero_matrix(
    symbolic_convolution - ((a - b) * sp.eye(2) + 2 * b * pi0),
    "symbolic C2 projector decomposition",
)
require_zero_matrix(
    symbolic_convolution * x_positive - x_positive * symbolic_convolution
    - 2 * b * x_positive,
    "symbolic positive ordered channel",
)
require_zero_matrix(
    symbolic_convolution * x_negative - x_negative * symbolic_convolution
    + 2 * b * x_negative,
    "symbolic negative ordered channel",
)
require_zero((2 * b) - (b + 2 * a) - (b - 2 * a), "gap criterion")

lines = [
    "PASS: Star-Kneser character-to-blade intertwiner",
    "C10 divisor transform = (45,0,0,0,0,-15,0,0,0,0)",
    "the transform factors exactly through the three local Dirichlet kernels",
    "the coefficient vector is the parity pullback of nu = (3,6) on C2",
    "the normalized Fourier pullback lands at characters 0 and 5 with scale sqrt(5)",
    "C2 convolution matrix [[3,6],[6,3]] has Fourier spectrum (9,-3)",
    "its commutator has ordered blade eigenvalues (+12,-12)",
    "the arithmetic blade 2E21 occupies the -12 channel",
    "the Fourier eigenvalue gap equals Omega_11(12289) = 12",
    "general C2 gap = 2b and shell count = b+2a; equality holds exactly at b=2a",
]

print("\n".join(lines))

#!/usr/bin/env python3
"""Vector explanation of the free-shell spectrum and length--volume laws."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "figures" / "general_shell_control_volume.pdf"

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.5))

# Panel A: exact one-orbit spectrum, including the ambient kernel directions.
ax = axes[0]
ax.axhline(0, color="0.72", linewidth=1.1)
for x, color in [(-1, "#2f6fbb"), (0, "#999999"), (4, "#c43c35")]:
    ax.scatter([x], [0], s=150, color=color, zorder=3)
ax.text(-1, 0.16, r"$-1$  (three support directions)", ha="center", fontsize=10)
ax.text(0, -0.20, r"$0$  (three ambient kernel directions)", ha="center", fontsize=10)
ax.text(4, 0.16, r"$4$  (three support directions)", ha="center", fontsize=10)
ax.annotate("", xy=(4, -0.43), xytext=(-1, -0.43),
            arrowprops=dict(arrowstyle="<->", color="#4d4d4d", lw=1.3))
ax.text(1.5, -0.58, r"support dimension per orbit $=6$", ha="center", fontsize=10)
ax.set_xlim(-2.1, 5.1)
ax.set_ylim(-0.72, 0.55)
ax.set_yticks([])
ax.set_xticks([-1, 0, 4])
ax.set_title("A. Exact carrier spectrum", loc="left", fontweight="bold")
for side in ("left", "right", "top"):
    ax.spines[side].set_visible(False)

# Panel B: all quantities grow along exact rays indexed by Omega.
ax = axes[1]
omega = np.arange(2, 13, 2, dtype=float)
log2_volume = 3 * omega
length_h_sq = 51 * omega / 2
length_k_sq = 75 * omega / 4
ax.plot(omega, length_h_sq, "o-", color="#c43c35", label=r"$L_H^2=51\Omega/2$")
ax.plot(omega, length_k_sq, "s-", color="#2f6fbb", label=r"$L_K^2=75\Omega/4$")
ax.plot(omega, log2_volume, "^-", color="#2d8a4b", label=r"$\log_2\operatorname{Vol}=3\Omega$")
ax.set_xlabel(r"shell support count $\Omega=2q$")
ax.set_ylabel("exact value")
ax.set_xticks(omega.astype(int))
ax.grid(alpha=0.22)
ax.legend(frameon=False, fontsize=9, loc="upper left")
ax.set_title("B. Control lengths and determinant volume", loc="left", fontweight="bold")
ax.text(
    0.5,
    -0.28,
    r"$\log\mathrm{Vol}=\frac{2\log 2}{17}L_H^2$"
    "\n"
    r"$=\frac{4\log 2}{25}L_K^2$",
    transform=ax.transAxes,
    ha="center",
    va="top",
    fontsize=11,
)

fig.suptitle("Free-shell support: one spectrum, two exact length--volume coordinates",
             fontsize=13, fontweight="bold")
fig.tight_layout(rect=(0, 0.04, 1, 0.93))
OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, bbox_inches="tight")
plt.close(fig)
print(OUT)

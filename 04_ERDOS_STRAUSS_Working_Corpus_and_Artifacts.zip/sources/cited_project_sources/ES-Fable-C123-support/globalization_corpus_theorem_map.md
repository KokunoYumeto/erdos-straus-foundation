# Globalization corpus theorem and source map

This map records bounded, line-by-line source reads. It distinguishes proved
identities, source-level defects, and proposed bridges that still require an
explicit map.

## Read protocol

- Root: 'sources/cited_project_sources/globalization'
- Inventory: 22 TeX files, 1,157,668 bytes.
- Duplicate files are identified byte-for-byte and read through their unique
  representative.
- The next required root is
  'sources/cited_project_sources/split_zero_projective_monads_surcomplex'.

## Completed sources

### '2\split_zero_secondary_note.tex'

- Defines \(G(R)=R\sqcup\{\tau\}\), with supported zero \(e=0_R\), and its
  unique Boolean character.
- Establishes the all-orders flow \(L_t=e^{-tD}L\), \(D=sT\).
- For
  \[
  \mathcal Z_{1,u}(s)=(1+u)\zeta(s)-u,\qquad \lambda=1+u,
  \]
  proves the endpoint defect
  \[
  \delta(\lambda)=\lambda-\lambda^2=-u(1+u).
  \]
  At \(u=1\), \(\lambda=2\), this is \(\delta(2)=-2\).
- At the origin,
  \[
  \zeta(0)=-\frac12,\qquad
  \mathcal Z_{1,1}(0)=2\zeta(0)-1=-2.
  \]

### '3\primitive_defect_preprint.tex'

The file '4\primitive_defect_preprint.tex' is byte-identical.

- Defines the primitive defect \(\delta=-d\) on \(D_r=\mathbb Z^r\), with
  kernel \(A_{r-1}\).
- Gives two archimedean endpoint contributions \(p_\pm\mapsto-1\), hence total
  \(-2\).
- With
  \[
  u=s(s-1),\qquad v=2s-1,\qquad v^2=1+4u,
  \]
  proves
  \[
  d\log u=\frac vu\,ds,\qquad
  \operatorname{Res}_0(d\log u)=1,\quad
  \operatorname{Res}_1(d\log u)=1,\quad
  \operatorname{Res}_\infty(d\log u)=-2.
  \]

### '4\primitive_support_defects_preprint.tex'

- Reconstructs the split-zero and augmentation layers and the same exact
  residue triple \(1,1,-2\).
- Interprets the total projective residue as the doubled primitive
  anti-invariant \(-1\) carried by the two finite endpoints.
- Develops the \(C_3/A_2\), Weyl, CUE, F-theory, VOA, Nielsen, and Epstein
  carriers around that primitive-defect structure.

### '4\split_zero_defect_preprint.tex'

The file '4\split_zero_defect_preprint (1).tex' is byte-identical.

- Establishes the scalar/root ladder
  \[
  -1/A_0,\quad -2/A_1,\quad -3/A_2,\quad -4/A_3\cong D_3.
  \]
- For the completed shifted endpoint,
  \[
  \operatorname{PP}_{\{0,1\}}(\Lambda_t)
  =\frac{1+t}{u}-t\frac vu.
  \]
  At \(t=1\), the anti-invariant term has residues \(-1,-1\), total \(-2\).
- Repeats the exact projective residue triple \(1,1,-2\).
- Gives the Stone endpoint algebra
  \[
  \delta(\lambda)=\lambda-\lambda^2,\qquad \delta(2)=-2.
  \]
- Gives
  \[
  C(s,t)=\frac{\zeta(s)\zeta(t)}{\zeta(s+t)}-\zeta(s)-\zeta(t)+1,
  \quad C(0,0)=\frac32,
  \]
  hence the doubled defect \(D_2(0,0)=-3\).

### '5\some considerrations.tex'

- Gives the semiring, ideal, congruence, localization, semimodule, and
  projective forms of the split-zero repair.
- Establishes
  \[
  A=\{0,\tau\}\cong\mathbb B,\qquad G(R)_R\cong\mathbb B.
  \]
- Separates the ordinary ideal zeta from the quotient-size sheet
  \(\zeta(s)-1\).
- Proves that the supported-zero boundary matrix \(C_q^0\) is nontrivially
  unimodular precisely at \(q=3\), including its explicit \(4\times4\)
  inverse.
- Contains the residual Erdős--Strauss divisor criterion and split-zero
  coefficient support.

### '5\split_zero_moonshine_repair.tex'

- Gives coefficient-level split-zero lifts for Monster and umbral moonshine.
- Distinguishes a supported zero coefficient, an absent coordinate, and a
  virtual polar term.
- Establishes the support-complete character inversion with
  \(\chi(g^{-1})\).
- Treats the Monster \(q^0\) coefficient as supported zero and the umbral
  polar coefficient \(-2[\mathbf1]\) as a virtual boundary term.

### '6\zeta_split_zero_sheaf.tex'

- For every zeta zero \(\rho\),
  \[
  F_1(\rho)=\zeta(\rho)-1=-1,\qquad
  \operatorname{Fix}_{G(\mathbb Z)}(-1)=\{0,\tau\}\cong\mathbb B.
  \]
- Constructs the reduced divisor sheaf \(\mathcal A_\zeta\) and the
  multiplicity sheaf \(\mathcal V_\zeta\) with stalk
  \(\mathbb B^{m_\rho}\).
- Proves the retract
  \[
  \mathcal V_\zeta\xrightarrow{\Sigma}\mathcal A_\zeta
  \xrightarrow{\Delta}\mathcal V_\zeta,\qquad
  \Sigma\Delta=\operatorname{id}.
  \]
- Proves the trivial zeros are simple and
  \[
  \zeta'(-2n)=(-1)^n
  \frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1).
  \]

### 'shefy\integrated_split_zero_zeta_consolidated.tex'

Fully read: 3,004 lines.

#### Boolean, Artin, jet, and infinity layers

- Proves
  \[
  \operatorname{Fix}_{G(R)}(u)=\{\tau\}\cup\operatorname{Ann}_R(u-1),
  \]
  hence \(\operatorname{Fix}_{G(R)}(u)=\{0,\tau\}\) for a nonidentity unit in
  a domain.
- Proves the finite-support presheaf sheafifies to the full-product Boolean
  multiplicity sheaf.
- Identifies the Artin ideal chain \(C_m\) inside the Boolean cube
  \(B_m=\mathcal P([m])\) through
  \[
  L_m\dashv i_m\dashv R_m.
  \]
- The derivative jet maps to coefficient support and the Boolean cube is a
  pointed-set retract.
- At projective infinity, the full-product extension differs from the
  finite-support extension by the tail object
  \[
  \prod_xV_x\big/\bigoplus_xV_x.
  \]

#### Exact zeta endpoint data

- Proves
  \[
  \zeta(s)=-\frac12-\frac12\log(2\pi)s+O(s^2),
  \]
  \[
  \Lambda(s)=-\frac1s+\frac{\gamma-\log(4\pi)}2+O(s),
  \]
  \[
  \xi(s)=\frac12+\frac{\log(4\pi)-2-\gamma}{4}s+O(s^2).
  \]
  Thus
  \[
  \zeta(0)=-\frac12,\qquad \xi(0)=\xi(1)=\frac12.
  \]
- Proves the trivial-zero derivative and completed-value relation
  \[
  |\zeta'(-2n)|=\frac{n!}{2\pi^n}\Lambda(-2n).
  \]

#### Packet, spectral, and phase layers

- Groups the completed-zeta divisor into Klein-four packets. Critical-line
  packets give quadratic factors; off-line packets give quartic factors.
- Establishes the centered Hadamard product, packet product, exact Taylor
  symmetric sums, pole/trivial/packet factorization, and grouped logarithmic
  derivative.
- Uses
  \[
  \Phi(s)=i\left(s-\frac12\right)
  \]
  to transport packets to the Connes--Consani spectral coordinate and proves
  \[
  -\rho(1-\rho)=-\Phi(\rho)^2-\frac14.
  \]
- Critical packets determine the primitive cycle length \(2\pi/|\gamma|\).
- Constructs local logarithmic phase series and exact affine phase atoms.

#### Exact \(-\tfrac12\) and \(-2\) spectral evaluation

For the circle Laplacian with the kernel fixed and every nonzero Fourier mode
acted on by \(-1\), the source proves
\[
\mathcal L_U(s)=-2(4\pi^2)^{-s}\zeta(2s),
\]
and therefore
\[
\mathcal L_U(0)=-2\zeta(0)=1.
\]
This is an exact bridge between the multiplicity-two nonzero Fourier spectrum
and \(\zeta(0)=-\tfrac12\). The same source separately treats the trivial
zero at \(-2\), the projective residue \(-2\) in earlier sources, and the
Stone defect \(\delta(2)=-2\). Equality among those roles requires the
explicit maps supplied by the remaining corpus; it is not inferred from the
shared scalar.

#### Source-level notation defects

1. The affine phase factor is defined as \(u(a)\), then repeatedly written as
   \(\nu(a)\). The latter symbol is not defined as that function.
2. The heat-evolved spline is defined as \(u_0(x,t)\), then its derivative is
   repeatedly written as \(\partial_x\nu_0(0,t)\).
3. The packet sheaf notation later uses \(\mathcal P_\xi\) after the explicit
   definition introduced \(\mathcal P_\xi^{\mathcal V}\).

These are transcription defects in the source. The surrounding formulas
determine the intended objects, and any later citation must use the corrected
symbols explicitly.

### 'shefy\New folder\corrected_wick_rotated_spline_wavelet_note.tex'

Fully read: 864 lines.

- Identifies the Perelman energy operator
  \[
  H_\tau=\tau(-4\Delta_g+R).
  \]
- Proves the ground-state-normalized Wick character and separates its vacuum
  coefficient from the reduced twisted spectral-zeta value by the explicit
  circle calculation
  \[
  \mathcal L_U(s)=-2(4\pi^2)^{-s}\zeta(2s),
  \qquad \mathcal L_U(0)=1.
  \]
- Proves that the wave lift
  \[
  \partial_t^2-4\Delta_g+R
  \]
  has principal symbol
  \[
  -\sigma^2+4g^{ij}\xi_i\xi_j,
  \]
  hence signature \((3,1)\) in spatial dimension three.
- Defines the half-period translation and its odd projector
  \[
  (Tf)(x)=f(x+\tfrac12),
  \qquad P_-=\frac12(I-T),
  \]
  with
  \[
  P_-e_k=\frac{1-(-1)^k}{2}e_k.
  \]
  This is an explicit projector to test against the ordered mixer-support and
  blade channels.
- Constructs the centered periodic spline tower, its reflection parity,
  distributional equation, Bernoulli form, Sobolev threshold, Mellin
  recursion, and integrated-Haar Riesz basis.
- Derives the odd theta character and its Mellin series
  \[
  2(1-2^{-2s})\zeta(2s).
  \]

### 'shefy\New folder\modular_hamiltonian_wick_spline_paper.tex'

Fully read: 1,062 lines.

- Gives the heat coefficients for \(L=-4\Delta_g+R\), the meromorphic
  spectral-zeta continuation, the value at zero, and the high-temperature
  free-energy coefficients.
- Repeats the exact spectral evaluation
  \[
  \mathcal L_U(0)=-2\zeta(0)=1
  \]
  and the Lorentzian principal symbol of the hyperbolic lift.
- Proves half-period oddness, reflection parity
  \[
  Pg_n=(-1)^{n+1}g_n,
  \]
  and the mode formula
  \[
  \widehat g_n(2m)=0,
  \qquad
  \widehat g_n(2m+1)=\frac{4}{(2\pi i(2m+1))^{n+1}}.
  \]
- Defines the same exact odd-sector projector
  \[
  P_-=\frac12(I-T),
  \]
  and evaluates its diagonal action in the Fourier basis.  This supplies the
  operator matrix needed for the later ordered-channel comparison.
- The source's full theorem package agrees at formula level with the 864-line
  corrected note on the spectral, Lorentzian, spline, theta, and Dirichlet
  statements; its longer heat/free-energy development supplies additional
  intermediate results.

### Original QSM provenance: '43.5.7.tex'

Fully read: 1,361 lines; 65,056 bytes; SHA-256
'C6B8DF0D6E40AD257509DB3444DCAECF04AAC762DDEBD24EFB83E070A91F9E1F'.

Exact path:
'supporting_sources/qsm_entropy/43.5.7.tex'.

- Contains the original derivation of
  \[
  H=\tau(-4\Delta_g+R)
  \]
  from the energy component of Perelman's \(\mathcal W\)-functional, followed
  by the heat coefficients, spectral-zeta continuation, free-energy series,
  and geometric residue dictionary retained in the later paper.
- Introduces a geometric QSM triple and a formal BCM dictionary, then proposes
  the vacuum-character identity
  \[
  L(0,U)=-c.
  \]
  The later circle calculation gives the exact counterexample
  \[
  c=1,
  \qquad
  \mathcal L_U(0)=-2\zeta(0)=1,
  \]
  and thereby determines precisely which original assertion required repair.
- The original Green-identity display at lines 425--426 contains a nested
  integral transcription error.  The corrected source supplies the proper
  expectation-value calculation.
- The source's claim that the single integrated spline hierarchy forms an
  \(L^2(\mathbb T)\)-basis is replaced by two exact later statements: the
  single chain lies in the half-period-odd subspace, and the full family
  \(\{Q^n\psi_{j,m}\}_{j,m}\) is a Riesz basis of the mean-zero Sobolev space.
- The original source already contains the parity operator, the centered
  spline recursion, the distributional derivative, the Fourier decay, the
  Mellin recursion, and the odd-mode heat evolution.  The later sources retain
  these formulas and add the explicit projector
  \[
  P_-=\frac12(I-T),
  \]
  the odd theta trace, and the Lorentzian hyperbolic lift.
- The original source also contains a separate GMT/isoperimetric programme.
  Several global stability steps are stated through a measurable-selection
  interchange and a torus QII citation; those steps are outside the present
  Wick/spectral correction and require their own audit before reuse.

### 'shefy\split_zero_zeta_analytic_completion.tex'

Fully read: 1,102 lines; 43,082 bytes; SHA-256
'71694A745770CEC067118CD71701372EF193DEF0FF72BBE67356DBC9B5B8F849'.

- Splits the divisor data exactly as
  \[
  \operatorname{div}(\zeta)=D_{\mathrm{tr}}+D_{\mathrm{nt}}-[1],
  \quad
  \operatorname{div}(\Lambda)=D_{\mathrm{nt}}-[0]-[1],
  \quad
  \operatorname{div}(\xi)=D_{\mathrm{nt}}.
  \]
- Records the origin and completed-function expansions
  \[
  \zeta(s)=-\frac12-\frac12\log(2\pi)s+O(s^2),
  \]
  \[
  \Lambda(s)=-\frac1s+\frac{\gamma-\log(4\pi)}2+O(s),
  \quad
  \xi(s)=\frac12+\frac{\log(4\pi)-2-\gamma}{4}s+O(s^2).
  \]
  Thus this source gives separate, explicit local roles to the value
  \(-\tfrac12\) and the residue \(-1\); it contains no derivation equating
  either of them with the projective residue \(-2\).
- At each trivial zero it proves
  \[
  \zeta'(-2n)=(-1)^n\frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1),
  \]
  \[
  \Lambda(-2n)=\frac{(2n)!}{4^n n!\pi^n}\zeta(2n+1),
  \quad
  |\zeta'(-2n)|=\frac{n!}{2\pi^n}\Lambda(-2n).
  \]
- For a nontrivial zero \(\rho\), the leading jets satisfy
  \[
  \lambda_\rho^\xi
  =\frac12\rho(\rho-1)\pi^{-\rho/2}
   \Gamma(\rho/2)\lambda_\rho^\zeta.
  \]
  The reflection and conjugation identities make the absolute jet weight
  constant on each functional-equation packet.
- With \(\Xi(z)=\xi(1/2+z)\), sign pairing yields the locally uniformly
  convergent product
  \[
  \Xi(z)=\Xi(0)\prod_\alpha\left(1-\frac{z^2}{\alpha^2}\right).
  \]
  Critical packets give quadratic real factors; off-line packets give real
  quartic factors.  Hence RH is equivalent, inside this exact packet
  factorization, to the absence of quartic packet factors.
- The centered Taylor coefficients are the absolutely convergent elementary
  symmetric sums in \(\alpha^{-2}\):
  \[
  \frac{\xi^{(2n)}(1/2)}{(2n)!\xi(1/2)}=(-1)^n\sigma_n,
  \qquad
  \xi^{(2n+1)}(1/2)=0.
  \]
- Combining the reciprocal-gamma product with the packet product gives
  \[
  \zeta(s)=
  \frac{\xi(1/2)e^{(\gamma+\log\pi)s/2}}{s-1}
  \prod_{n\ge1}\left(1+\frac{s}{2n}\right)e^{-s/(2n)}
  \prod_{O\in Y_\xi}P_O(s)^{m_O}.
  \]
  Its logarithmic derivative separates the pole at \(1\), the trivial-zero
  terms, and the packet partial fractions by explicit summands.
- The packet datum \((m_O,P_O,|\lambda_\rho^\xi|)\) records respectively the
  Boolean stalk multiplicity, the global holomorphic packet factor, and the
  absolute leading local jet.  This is an exact analytic enrichment of the
  earlier packet shadow, and supplies the source-side objects needed for the
  later comparison with mixer-support projections.

### 'shefy\nontrivial_zeta_packet_geometry_preprint.tex'

Fully read: 961 lines; 32,702 bytes; SHA-256
'10752ED3D98014F4A6AF7E7DB0B9BAF242FD55C481B3D60E391AC63463B915FA'.

- Defines the split-zero semiring
  \[
  S=\mathbb Z\sqcup\{\tau\},
  \qquad A=\{0,\tau\}\cong\mathbf B,
  \]
  where \(\tau\) is the additive identity and multiplicative absorber, and
  proves
  \[
  S^\times=\{\pm1\},
  \qquad \operatorname{Fix}_S(-1)=A.
  \]
  Hence every zeta zero gives the same pointwise coefficient
  \(F_1(\rho)=\zeta(\rho)-1=-1\) and the same fixed Boolean pair.
- Builds the nontrivial-zero divisor of \(\xi\), proves equal
  multiplicities under conjugation and reflection, and groups the zeros into
  Klein-four packets
  \[
  \{\rho,\bar\rho,1-\rho,1-\bar\rho\}.
  \]
  Critical packets have two points; off-line packets have four.
- Proves the fixed-point descent of the Boolean multiplicity shadow.  Over a
  packet \(O\) of size \(r_O\), the pushforward stalk is
  \((A^{m_O})^{r_O}\), and its packet-action fixed part is the diagonal
  \(A^{m_O}\).
- Introduces the affine spectral coordinate
  \[
  \Phi(s)=i\left(s-\frac12\right),
  \quad
  \Phi(1-s)=-\Phi(s),
  \quad
  \Phi(\bar s)=-\overline{\Phi(s)}.
  \]
  Thus a zeta packet maps exactly to
  \(\{z,-z,\bar z,-\bar z\}\).
- Uses the Connes--Consani spectral realization to prove
  \[
  -\rho(1-\rho)=-\Phi(\rho)^2-\frac14.
  \]
  This is an exact, source-level origin of the quarter shift as the centered
  quadratic spectral identity.  A map identifying this quarter with the
  Fable target has not yet been extracted from this source.
- On the critical locus, \(\rho=\tfrac12+i\gamma\) maps to the real packet
  \(\{\pm\gamma\}\), and the packet determines the primitive zeta-cycle
  length \(2\pi/|\gamma|\).
- The leading jet transforms by
  \[
  \lambda_{1-\rho}=(-1)^{m_\rho}\lambda_\rho,
  \quad
  \lambda_{\bar\rho}=\overline{\lambda_\rho},
  \]
  so \(|\lambda_\rho|\) descends to a positive packet weight.
- Source audit findings: line 400 has a stray math delimiter in the proof of
  the orbit-size result; line 541 contains an extra line-break command before
  the multiplicity definition; and the real-zero proof omits the explicit
  endpoint checks \(s=0,1\), although \(\zeta(0)=-\tfrac12\) and the pole at
  \(1\) close those cases.  These are source-presentation defects and do not
  alter the displayed packet or spectral identities.

### 'shefy\split_zero_zeta_divisor_refined_preprint.tex'

Fully read: 1,324 lines; 48,683 bytes; SHA-256
'6636DC69F445D430E026CE0AAA164D0E38BC0AADAEDFCBB36AB1275D186298A2'.

This source supplies the following explicit morphism skeleton.

1. For a commutative ring \(R\),
   \[
   G(R)=R\sqcup\{\tau\},
   \qquad
   \operatorname{Fix}_{G(R)}(u)
   =\{\tau\}\cup\operatorname{Ann}_R(u-1).
   \]
   In a domain and for \(u\ne1\), the fixed object is the Boolean pair
   \(A_R=\{0,\tau\}\cong\mathbf B\).
2. For an effective discrete divisor \(D\), the inclusion
   \[
   \eta_D:\mathcal P_D\longrightarrow\mathcal V_D
   \]
   from finite-support families to arbitrary product families has
   \(\mathcal V_D\) as its sheafification.
3. The multiplicity shadow and reduced shadow are connected by
   \[
   \mathcal A_D\xrightarrow{\Delta_D}\mathcal V_D
   \xrightarrow{\Sigma_D}\mathcal A_D,
   \qquad
   \Sigma_D\Delta_D=\operatorname{id}_{\mathcal A_D}.
   \]
4. At multiplicity \(m\), the Artin ideal chain \(C_m\) and Boolean cube
   \(B_m\) are connected by the explicit biadjunction
   \[
   L_m\dashv i_m\dashv R_m.
   \]
   Here \(L_m(I)\) is the least terminal segment containing \(I\), and
   \(R_m(I)\) is the greatest terminal segment contained in \(I\).
5. In the derivative-enhanced jet stalk, coefficient support gives a pointed
   retraction
   \[
   A^m\xrightarrow{\iota_{x,m}}E_{x,m}
   \xrightarrow{\sigma_{x,m}}A^m,
   \qquad
   \sigma_{x,m}\iota_{x,m}=\operatorname{id}_{A^m}.
   \]
   A zero of multiplicity \(m\) maps to the Boolean vector supported only in
   terminal coordinate \(m\).
6. Compactification supplies the exact projective-tail morphism
   \[
   0\longrightarrow j_!\mathcal F_V
   \longrightarrow j_*\mathcal F_V
   \longrightarrow
   i_{\infty *}\left(\prod_{x\in Z}V_x\big/\bigoplus_{x\in Z}V_x\right)
   \longrightarrow0.
   \]
   The quotient records the germ at projective infinity modulo finite
   modification.
7. Reflection and conjugation act on the completed-zeta shadows.  Taking the
   packet-action fixed part sends the pushforward product stalk to its
   diagonal packet stalk, for both Boolean cubes and Artin chains.
8. The trivial-zero stalk is a single Boolean pair with exact weight
   \[
   |\zeta'(-2n)|
   =\frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1).
   \]
9. The colleague-attributed phase results prove the orthogonal-walk identity
   \[
   \prod_{k=1}^m(1+i\alpha_k)
   =\sum_{r=0}^m i^r e_r(\alpha_1,\ldots,\alpha_m)
   \]
   and the exact ray chart
   \[
   \operatorname{Arg}(1+t\zeta_5)=\theta
   \quad\Longleftrightarrow\quad
   t=\frac{\sin\theta}{\sin(2\pi/5-\theta)}.
   \]
   When these results are cited in the maintained paper, provenance must use
   the public Reddit handle u/UmbrellaCorp_HR and its supplied public post.

Source audit finding: the ray chart is valid for real \(t>0\).  The expression
\(1+t\zeta_5\) belongs to \(\mathbb Q(\zeta_5)\) only when the coefficient
\(t\) belongs to that field.  Therefore the source's statement that an
arbitrary real phase on the arc is carried by an affine factor *in* the CM
field requires this coefficient restriction; the geometric ray identity
itself remains exact.

### 'shefy\zeta_boolean_jet_packet_shadows.tex'

Fully read: 1,123 lines; 42,676 bytes; SHA-256
'67313640F556557CA5CC439CEC412416D20BE73302BDE052331190E9DA6303B9'.

This is a direct predecessor of
'split_zero_zeta_divisor_refined_preprint.tex'.  It proves the same fixed-locus,
Boolean-cube, Artin-chain, biadjunction, compactified-tail, packet-descent, and
trivial-zero-weight results.  Its additional source value is the fully
spelled-out definition of extension by zero:
\[
(j_!\mathcal F_M)(V)
=\{s\in(j_*\mathcal F_M)(V):\operatorname{supp}(s)
  \text{ is closed in }V\},
\]
and the direct proof that this assignment is a sheaf.  For a neighborhood of
infinity this is exactly the finite-support subobject, while the direct image
permits arbitrary product families.  Hence the infinity stalk is the quotient
by finite modification.

The 1,324-line refined source extends this predecessor by adding the
finite-support sheafification theorem, the explicit coefficient-support
retraction, and the colleague-attributed phase chart.  No conflicting formula
was found in their common theorem chain.

### 'shefy\zeta_split_zero_compactified_shadows.tex'

Fully read: 967 lines; 38,656 bytes; SHA-256
'305289498182C797019FEA295AF0804407FE6882ECA9ABA01EC2E23C0594FF8B'.

This source gives an explicit coefficient-to-support-to-tail chain.  At a
point \(x\) of multiplicity \(m_x\),
\[
J_x=\mathbb C[s]/(s-x)^{m_x}
\xrightarrow{\sigma_x}A^{m_x}
\xrightarrow{\Sigma_{m_x}}A,
\qquad
\Sigma_{m_x}\sigma_x(\alpha)=\tau\iff\alpha=0.
\]
The fiber of \(\sigma_x\) over a Boolean subset \(I\) consists exactly of the
jets whose nonzero coefficient positions are \(I\).

For the zeta germ the derivative-enhanced class satisfies
\[
[\zeta]_\rho
=\frac{\zeta^{(m_\rho)}(\rho)}{m_\rho!}
 (s-\rho)^{m_\rho}
\longmapsto(\tau,\ldots,\tau,0).
\]
Taking products over the zero divisor and compactifying gives
\[
j_!\mathcal K_\zeta\longrightarrow j_*\mathcal K_\zeta
\longrightarrow i_{\infty *}T_\zeta^K,
\qquad
T_\zeta^K=
\prod_\rho K_\rho\Big/\bigoplus_\rho K_\rho.
\]
Thus the local terminal-support datum has a projective-infinity class that is
unchanged by finite modification.

The trivial-zero stalk map carries the supported point to the exact derivative
weight
\[
0\longmapsto
|\zeta'(-2n)|
=\frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1),
\qquad
\tau\longmapsto0.
\]

Source audit finding: the asserted Klein-four action on the jet sheaves needs
the actual stalk maps, not only a permutation of indices.  The maps induced by
complex conjugation and reflection are respectively
\[
[f(s)]_\rho\longmapsto[\overline{f(\bar s)}]_{\bar\rho},
\qquad
[f(s)]_\rho\longmapsto[f(1-s)]_{1-\rho}.
\]
They are semilinear and linear as appropriate and preserve the powers of the
corresponding maximal ideals.  These formulas will be checked in the final
morphism synthesis.

### 'shefy\zeta_split_zero_professional_preprint.tex'

Fully read: 1,430 lines; 54,580 bytes; SHA-256
'8F621BF3EE50EFF7BA554043DB5AFCBF2B67C04FCD6041301AD3FC96BAA0F551'.

This is an earlier complete presentation of the sheafification,
chain--cube, jet-support, compactified-tail, packet, and phase results.  Its
most useful typing statement is that
\[
 \sigma_x:J_x\twoheadrightarrow A^{m_x},
 \qquad
 \kappa_x:K_x\twoheadrightarrow A^{m_x+1}
\]
are split epimorphisms in pointed sets and generally fail to preserve
addition because coefficients may cancel.  Consequently any composite from
the zeta or Fable coefficient carriers to Boolean support must either be
typed in pointed sets or retain enough coefficient data to control
cancellation.

The source repeats the exact trivial-zero weight, tail quotient, packet
descent, and finite phase-product formulas already recovered from its later
successors.  Its phase attribution uses a private personal name; public
provenance must instead use u/UmbrellaCorp_HR and the supplied public post.

### 'shefy\zeta_split_zero_professional_preprint (1).tex'

Fully read: 1,587 lines; 61,288 bytes; SHA-256
'D13832B31FD0FFCFDE6187956BC09D0245073C1F08444491852B4B8477825238'.

This version makes the Boolean affine carrier explicit:
\[
 \mathbb A^m_{\mathbf B}(\mathbf B)
 \cong\mathbf B^m\cong A^m.
\]
The diagonal and fold maps on points are induced contravariantly by
\[
 \mathbf B[t]\longrightarrow\mathbf B[t_1,\ldots,t_m],
 \quad t\longmapsto t_1+\cdots+t_m,
\]
and
\[
 \mathbf B[t_1,\ldots,t_m]\longrightarrow\mathbf B[t],
 \quad t_j\longmapsto t.
\]
Their composite fixes \(t\), so this is a scheme-level realization of the
split support retract.

It also defines the packet phase quotient
\[
 \Phi_O=S^1/\langle z\mapsto\bar z,
                       z\mapsto(-1)^{m_O}z\rangle
\]
and proves that the leading jet phase determines a section of the resulting
packet sheaf.  The Eisenstein ray
\[
 t\longmapsto1+t\omega,
 \qquad \omega=e^{2\pi i/3},
\]
has
\[
 |1+t\omega|^2=1-t+t^2,
 \qquad
 \frac{d}{dt}\operatorname{Arg}(1+t\omega)
 =\frac{\sqrt3/2}{1-t+t^2}>0,
\]
so its unit-modulus image parametrizes the open \(120^\circ\) arc.  This is
an exact local \(C_3\) phase coordinate.  The same field-membership boundary
applies here: \(1+t\omega\in\mathbb Q(\omega)\) only when
\(t\in\mathbb Q(\omega)\).

### 'shefy\zeta_split_zero_professional_preprint (2).tex'

Fully read: 1,456 lines; 51,385 bytes; SHA-256
'FF35E1757300F75B085D7A2E0AA0D4BC37B0A444D4114F727593B22D66AFF5D3'.

This version gives the complete sheafification, Boolean affine-space,
chain--cube, derivative-support, projective-tail, packet-descent, trivial-zero
weight, and phase-decorated simple-shadow chain.  Its typing statement is
especially relevant: the derivative-support retraction
\[
 \mathcal E_D\xrightarrow{\sigma_D}\mathcal V_D
 \xrightarrow{\iota_D}\mathcal E_D,
 \qquad \sigma_D\iota_D=\operatorname{id},
\]
is a retraction in pointed sets.  At a trivial zero it retains three distinct
coordinates:
\[
 -2n,\qquad
 \varphi_\zeta(-2n)=(-1)^n,\qquad
 |\zeta'(-2n)|
 =\frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1).
\]
The source's phase attribution uses a private personal name.  Public
provenance must instead use u/UmbrellaCorp_HR and the supplied public post.

### 'shefy\zeta_zero_atomic_phase_packets.tex'

Fully read: 822 lines; 30,114 bytes; SHA-256
'53A2F72B2A1BAE7DB59543259693E17322EEF2A866ED3F23D7A71F2DB5A9DDC9'.

For a zero \(\rho\) of multiplicity \(m\), division by the leading jet and
the distinguished logarithm give
\[
 \xi(\rho+z)
 \longmapsto
 \psi_\rho(z)
 :=\frac{\xi(\rho+z)}{\lambda_\rho z^m}
 \longmapsto
 h_\rho(z):=\log\psi_\rho(z),
 \qquad h_\rho(0)=0.
\]
For a unit direction \(\nu\), taking directional imaginary Taylor
coefficients and then the tangent gives
\[
 h_\rho
 \longmapsto
 \bigl(\beta_{\rho,\nu,n}\bigr)_{n\geq1},
 \qquad
 \beta_{\rho,\nu,n}=\operatorname{Im}(c_{\rho,n}\nu^n),
\]
\[
 \bigl(\beta_{\rho,\nu,n}\bigr)_{n\geq1}
 \longmapsto
 \bigl(\alpha_{\rho,\nu,n}(t)\bigr)_{n\geq1},
 \qquad
 \alpha_{\rho,\nu,n}(t)=\tan(\beta_{\rho,\nu,n}t^n).
\]
The product of the corresponding unit-phase factors recovers the local phase
of \(\xi\) exactly.  Reflection and conjugation act by
\[
 \Theta_{1-\rho,-\nu}=\Theta_{\rho,\nu},
 \qquad
 \Theta_{\bar\rho,\bar\nu}=-\Theta_{\rho,\nu},
\]
and hence preserve, respectively negate, the ordered slope sequence.  These
are explicit candidates for comparison with the ordered blade channels.

The final packet map sends a non-trivial zero to
\[
 \left(
   A^{m_\rho},
   \{z_\rho,-z_\rho,\bar z_\rho,-\bar z_\rho\},
   \left|\frac{\xi^{(m_\rho)}(\rho)}{m_\rho!}\right|,
   (\alpha_{\rho,\nu,n})_{n\geq1}
 \right),
 \qquad
 z_\rho=i\left(\rho-\frac12\right).
\]

Source audit findings: the phase atom is introduced as \(u(a)\) and later
written \(\nu(a)\), although \(\nu\) also denotes the unit direction.  The
two symbols must be disentangled before reuse.  The bibliography uses a
private personal-name attribution; any public citation in the maintained
paper must instead use u/UmbrellaCorp_HR and the supplied public post.

## Morphism synthesis in progress

### Globalization equalizer for the quarter and minus two

The direct map recovered from the globalization algorithm is the two-sheet
deformation
\[
 \mathcal Z_{1,u}(s)=(1+u)\zeta(s)-u
\]
together with the Stone idempotence defect
\[
 \delta(\lambda)=\lambda-\lambda^2,
 \qquad \lambda=1+u.
\]
Put \(q=\zeta(0)=-1/2\) and define
\[
 Z_q(u):=\mathcal Z_{1,u}(0)=(1+u)q-u,
 \qquad
 D(u):=\delta(1+u)=-u(1+u).
\]
Then
\[
 Z_q(u)-D(u)
 =(u-1)\left(u+\frac12\right).
\]
Their equalizer is therefore
\[
 \mathscr I
 =\operatorname{Spec}
  \frac{\mathbb C[u]}{((u-1)(2u+1))}.
\]
The common-value morphism is an isomorphism
\[
 \mathscr I
 \xrightarrow{\sim}
 \mathscr W
 :=\operatorname{Spec}
  \frac{\mathbb C[w]}{((4w-1)(w+2))},
 \qquad
 [w]\longmapsto[-u(1+u)],
\]
whose inverse sends
\[
 [u]\longmapsto-\frac{2[w]+1}{3}.
\]
Its two components are
\[
 u=-\frac12\longmapsto w=\frac14,
 \qquad
 u=1\longmapsto w=-2.
\]

At the first component, \(u=q\) and the common value is \(q^2=1/4\).
Centered reflection sends \(q\) to \(-q\), giving the oriented endpoint
product
\[
 q(-q)=-\frac14.
\]
At the second component,
\[
 -2=4q=q^{-1}=\det JF.
\]
This is the exact globalization morphism joining the Fable quarter and
Jacobian scalar.  It supersedes the earlier description of \(-2\) by its
position in the trivial-zero list.

### Maps leaving the minus-two component

The projective residue map gives
\[
 \operatorname{Res}_{s=\infty}d\log(s(s-1))=-2.
\]
The analytic zeta map sends the common-value point to
\[
 -2\longmapsto\zeta(-2)=0.
\]
The local jet-support-weight map at that image is
\[
 [\zeta]_{-2}=\zeta'(-2)(s+2)
 \longmapsto0\in A
 \longmapsto\frac{\zeta(3)}{4\pi^2},
\]
and its phase coordinate is \(-1\).  The twisted spectral expression
\[
 \mathcal L_U(s)=q^{-1}(4\pi^2)^{-s}\zeta(2s)
\]
uses the same common value \(q^{-1}=-2\) as its multiplicity coefficient and
satisfies \(\mathcal L_U(0)=1\).

## Integrated globalization source

The master source
'globalization nte/shefy/New folder/split_zero_zeta_packet_geometry_integrated.tex'
has 4,072 lines, 150,993 bytes, and SHA-256
'7EEC27FBA5E59018B2AB77C061B83F3579C2C2F9E88E25A2397E110F75732B8D'.
Its four mathematical parts are the four constituent sources already read in
full; its fifth part is the global synthesis.  The cross-part morphism chain
relevant to the equalizer is:
\[
 \mathscr I
 \xrightarrow[\sim]{\vartheta}
 \mathscr W
 \supset\{w=-2\}
 \xrightarrow{\zeta}
 \{-2\in D_\zeta\}
 \xrightarrow{[\zeta]_{-2}}
 E_{-2,1}
 \xrightarrow{\sigma_{-2,1}}
 A.
\]
The first arrow is induced by \(w=-u(1+u)\).  The analytic arrow evaluates
\(\zeta\) at the scalar \(w=-2\).  Since the zero is simple,
\[
 [\zeta]_{-2}=\zeta'(-2)(s+2),
 \qquad
 \sigma_{-2,1}([\zeta]_{-2})=0\in A.
\]
The support point then carries two additional maps:
\[
 0\longmapsto
 \left|\zeta'(-2)\right|
 =\frac{\zeta(3)}{4\pi^2},
 \qquad
 0\longmapsto
 \frac{\zeta'(-2)}{|\zeta'(-2)|}=-1.
\]
Compactification sends the full family of local stalks to the tail quotient
\[
 \prod_{\rho}M_\rho\longrightarrow
 \frac{\prod_\rho M_\rho}{\bigoplus_\rho M_\rho},
\]
which records families modulo finite modification.  Packet descent instead
acts on the nontrivial-zero divisor through the Klein-four quotient; it is a
separate outgoing branch from the zeta divisor.

## Foundational split-zero/projective source

The source
`split_zero_projective_monads_surcomplex/split_zero_projective_monads_surcomplex.tex`
was read in full: 2,614 lines, 86,879 bytes, SHA-256
`44DE737B1D20FDB86F44C416AF0A42FAF4B9314674398C70787A69620671FC61`.

For every nonzero commutative ring \(R\), the globalization semiring is
\[
 G(R)=R\sqcup\{\tau\},
 \qquad e:=0_R\ne\tau:=0_{G(R)}.
\]
The ring reflection and Boolean support character satisfy
\[
 p_R(e)=p_R(\tau)=0,
 \qquad
 \chi_R(e)=1,
 \qquad
 \chi_R(\tau)=0.
\]
Equivalently, under the pair model,
\[
 \tau\longmapsto(0,0),
 \qquad
 e\longmapsto(0,1),
 \qquad
 r\in R^\times\longmapsto(r,1).
\]
Thus the analytic zero obtained from \(\zeta(-2)=0\) is typed by the
composite
\[
 \{-2\}\xrightarrow{\zeta}R\xrightarrow{\iota_R}G(R),
 \qquad
 -2\longmapsto0_R=e,
\]
and has Boolean support one.  It is not sent to \(\tau\), because \(\tau\)
is outside the image of the canonical inclusion \(\iota_R:R\to G(R)\).
The common-value point \(w=-2\) is likewise a supported nonzero amplitude
before zeta evaluation.  The exact typed branch is therefore
\[
 \{w=-2\}\longrightarrow\{\iota_R(-2)\}
 \xrightarrow{\zeta}\{e\}
 \xrightarrow{\chi_R}\{1\}.
\]

On the split projective line, the two zero states and their two reciprocal
states are
\[
 0_\tau=[\tau:1],\qquad 0_e=[e:1],\qquad
 \infty_\tau=[1:\tau],\qquad \infty_e=[1:e].
\]
The projective inversion matrix
\[
 J=\begin{pmatrix}\tau&1\\1&\tau\end{pmatrix}
\]
exchanges \(0_\tau\leftrightarrow\infty_\tau\) and
\(0_e\leftrightarrow\infty_e\).  It preserves the support type of each
orbit.  This supplies the source-side rule for every later comparison with
the ordered blade channels: the support coordinate must be retained before
any amplitude or projective coordinate is compared.

## Globalization equalizer and endpoint-divisor realization

The primary scalar morphism is the affine equalizer
\[
 \mathscr I
 =\operatorname{Eq}(Z_q,D)
 =\operatorname{Spec}
   \frac{\mathbb C[u]}{((u-1)(2u+1))},
 \qquad q=\zeta(0)=-\frac12,
\]
where
\[
 Z_q(u)=(1+u)q-u,
 \qquad
 D(u)=-u(1+u).
\]
Its common-value map is the isomorphism
\[
 \vartheta:\mathscr I\xrightarrow{\sim}
 \operatorname{Spec}
 \frac{\mathbb C[w]}{((4w-1)(w+2))},
 \qquad
 w=-u(1+u),
\]
with inverse \(u=-(2w+1)/3\) and component values
\[
 u=-\frac12\longmapsto\frac14,
 \qquad
 u=1\longmapsto-2.
\]
This is the globalization source of the quarter and \(-2\) fibres.

The endpoint divisor gives a second realization.  For
\[
 D_{01}=[0]+[1],
 \qquad f(s)=s(s-1),
 \qquad \rho(s)=s-\frac12,
\]
one has
\[
 \rho(0)\rho(1)=-\frac14,
 \qquad
 \operatorname{Res}_{\infty}(d\log f)=-2.
\]
The negative-degree map
\[
 \mathfrak r_{\infty}\left(\sum_a n_a[a]\right)=-\sum_a n_a
\]
therefore satisfies
\[
 \mathfrak r_{\infty}(D_{01})
 =\vartheta(u=1)
 =\zeta(0)^{-1}
 =4\zeta(0)
 =\det JF
 =-2.
\]
The supported analytic branch is
\[
 D_{01}\xmapsto{\mathfrak r_{\infty}}-2
 \xmapsto{\zeta}0_{\mathbb C}
 \xmapsto{\iota_{\mathbb C}}e
 \xmapsto{\chi}1.
\]
The equalizer is the primary globalization morphism; the divisor residue
is an independent realization of its \(-2\) component.

The reduced functional-equation endpoint scheme is itself isomorphic to
the equalizer:
\[
 \mathscr E
 :=\operatorname{Spec}\frac{\mathbb C[s]}{(s(s-1))}
 \xrightarrow[\sim]{\alpha}
 \mathscr I,
 \qquad
 \alpha^\#([u])=\left[\frac{3s-1}{2}\right].
\]
The inverse sends \([s]\) to \([(2u+1)/3]\).  Composing with
\(\vartheta\) gives
\[
 \omega^\#([w])
 =
 \left[\frac{1-9s^2}{4}\right]
 =
 \left[\frac{1-9s}{4}\right],
\]
and therefore
\[
 0\longmapsto-\frac12\longmapsto\frac14,
 \qquad
 1\longmapsto1\longmapsto-2.
\]
The endpoint involution \(s\mapsto1-s\) transports to
\[
 u\mapsto\frac12-u,
 \qquad
 w\mapsto-w-\frac74.
\]
The three exchanges are conjugate.  The centered coordinate
\(\rho=s-\tfrac12\) is anti-invariant and obeys
\[
 \rho(0)\rho(1)=-\omega(0)=-\frac14.
\]

The common-value ring has canonical component idempotents
\[
 e_{1/4}=\frac{4(w+2)}9,
 \qquad
 e_{-2}=\frac{1-4w}{9}.
\]
Writing \(c=\zeta(1/4)\), one has \(c<0\), and the restriction of the
analytic zeta function to \(\mathscr W\) is the regular function
\[
 Z_{\mathscr W}
 =
 c\,e_{1/4}
 =
 \frac{4c}{9}(w+2).
\]
Its pullbacks are
\[
 \vartheta^\#Z_{\mathscr W}
 =
 \frac{2c}{3}(1-u),
 \qquad
 \omega^\#Z_{\mathscr W}
 =
 c(1-s).
\]
The zero component is therefore
\[
 \{s=1\}
 \xrightarrow{\sim}\{u=1\}
 \xrightarrow{\sim}\{w=-2\}
 \xrightarrow{\zeta}\{0_{\mathbb C}\}
 \xrightarrow{\iota_{\mathbb C}}\{e\}
 \xrightarrow{\chi}\{1\}.
\]

At first order, with \(w=-2+\varepsilon\) and \(\varepsilon^2=0\),
\[
 \zeta(-2+\varepsilon)
 =
 -\frac{\zeta(3)}{4\pi^2}\varepsilon.
\]
The coefficient is nonzero, so the first infinitesimal neighborhood of
the \(-2\) component maps isomorphically to the first infinitesimal
neighborhood of the supported analytic zero.

### Endpoint norm transported from the affine equalizer

The endpoint algebra is a coordinate presentation of the source-defined
equalizer, rather than the source of that equalizer.  Explicitly,
\[
 \alpha:
 \operatorname{Spec}\frac{\mathbb C[s]}{(s(s-1))}
 \xrightarrow{\sim}
 \operatorname{Eq}(Z_q,D),
 \qquad
 u=\frac{3s-1}{2}.
\]
The centered endpoint section therefore has the equalizer formula
\[
 \rho=s-\frac12=\frac{4u-1}{6}.
\]
At \(u=-1/2\) and \(u=1\), its ordered values are \(-1/2\) and \(1/2\).
The rank-two algebra trace and norm are consequently
\[
 \operatorname{Tr}(\rho)=0,
 \qquad
 N(\rho)=-\frac14.
\]
The binary cubic formed from this norm is
\[
 C_\rho(U,V)
 =U^2V+N(\rho)V^3
 =U^2V-\frac14V^3,
\]
and its discriminant is \(-4N(\rho)=1\).  This is the common Fable cubic
already derived from the marked-factor chart.  The construction order is
therefore
\[
 \operatorname{Eq}(Z_q,D)
 \longleftarrow
 \mathscr E
 \xrightarrow{\,N(\rho)\,}
 -\frac14
 \longrightarrow
 C_{\mathrm F}.
\]
The Fable target entries verify the final realization; they do not define
the equalizer.

Exact certificate:
'verification/verify_endpoint_norm_fable_discriminant.py'.  All thirteen
checks pass and its output matches the captured receipt.

### Dilation orbit from the minus-two component to every trivial zero

The second component of the affine equalizer has common value
\[
 q^{-1}=4q=-2,
 \qquad q=\zeta(0)=-\frac12.
\]
The entire function
\[
 g_{\mathrm{triv}}(z)=\frac{1}{z\Gamma(z/2)}
\]
has simple zero set \(\{-2n:n\ge1\}\).  Therefore
\[
 \underline{\mathbb N}_{>0}
 \xrightarrow{\sim}
 \mathscr T_{\mathrm{triv}},
 \qquad
 n\longmapsto nq^{-1}=-2n
\]
identifies the positive-integer dilation orbit of the globalization
minus-two component with the reduced trivial-zero divisor.  The functional
equation gives
\[
 \zeta'(-2n)
 =
 (-1)^n
 \frac{(2n)!}{2(2\pi)^{2n}}
 \zeta(2n+1)\ne0,
\]
so zeta also identifies the first infinitesimal neighborhoods at every
point of this divisor with the first infinitesimal neighborhood at the
supported complex zero.

The same parameter acts on the displayed Fable target chart through
\[
 L_\lambda(X,Y,Z)=(\lambda X,Y,Z),
 \qquad
 F^{(\lambda)}=L_\lambda\circ F.
\]
This is an algebraic \(\mathbb G_m\)-orbit and
\[
 \det JF^{(\lambda)}=-2\lambda,
 \qquad
 F^{(\lambda)}(p_\bullet)
 =
 \left(-\frac{\lambda}{4},0,0\right).
\]
Restricting to \(\lambda=n\) therefore gives
\[
 \det JF^{(n)}=-2n,
 \qquad
 F^{(n)}(p_\bullet)
 =
 \left(-\frac n4,0,0\right).
\]
The original Fable result is the \(n=1\) member.  The construction order is
the globalization equalizer, its minus-two component, the dilation orbit,
and the corresponding Fable target-line orbit.

Exact certificate:
'verification/verify_globalization_trivial_zero_fable_dilation.py'.
All sixty-three checks pass and the output matches the captured receipt.

## Primary split-zero and mixed-support coordinates

Source: `split_zero_projective_monads_surcomplex/split_support_geometry_arithmetic_curve_v11.tex`, lines 370--1207.

The globalization functor has the pair model
\[
 G(R)\cong \{(0,0)\}\cup(R\times\{1\}),
 \qquad
 \tau\longmapsto(0,0),
 \qquad
 r\longmapsto(r,1).
\]
The ring zero is therefore the supported point
\[
 e=0_R\longmapsto(0,1),
\]
whereas \(\tau\) is absence.  These are the primary zero coordinates in
the globalization theory.  The affine Stone-defect equalizer and its
quarter/minus-two common values occur downstream.

For a finite coordinate set \(I\), the universal ring reflection is
\[
 p_I:G(R)^I\longrightarrow R^I,
\]
and its zero fibre consists of the masks
\[
 \epsilon_A=(\epsilon_{A,i})_{i\in I},
 \qquad
 \epsilon_{A,i}=
 \begin{cases}
 e,&i\in A,\\
 \tau,&i\notin A.
 \end{cases}
\]
They satisfy
\[
 \epsilon_A+\epsilon_B=\epsilon_{A\cup B},
 \qquad
 \epsilon_A\epsilon_B=\epsilon_{A\cap B},
\]
so the absolute ring-null halo is the Boolean cube \(\mathbb B^I\).
In two coordinates its four points are
\[
 (\tau,\tau),\quad(e,\tau),\quad(\tau,e),\quad(e,e).
\]
The ordered points \((e,\tau)\) and \((\tau,e)\) are distinct
mixed-support channels and are the source-level objects to compare with
the ordered blade signs.

Localization detects all three coordinate types.  If
\[
 U(x)=\{i:x_i\in K^\times\},\quad
 Z(x)=\{i:x_i=e\},\quad
 N(x)=\{i:x_i=\tau\},
\]
then
\[
 G(K)^I[x^{-1}]
 \cong
 G(K)^{U(x)}\times\mathbb B^{Z(x)}.
\]
Coordinates in \(N(x)\) disappear.  In particular,
\[
 G(K)^2[(\tau,e)^{-1}]\cong\mathbb B,
 \qquad
 \frac{(a,b)}{(\tau,e)}=\chi_K(b),
\]
which erases the absent coordinate and retains only the support of the
second coordinate.  A scoped identity on \(A\subseteq I\) produces the
partial support reflection
\[
 G(K)^I/{\sim_A}\cong\mathbb B^A\times G(K)^{I\setminus A}.
\]

The supported zero is ring-null and derivationally fixed:
\[
 \mathfrak I_{\mathrm{abs}}(G(R))=\{\tau,e\},
 \qquad d(e)=0.
\]
An idempotent probe is instead a two-endpoint finite-difference object:
\[
 A[q]/(q^2-q)\cong A\times A,
 \qquad
 f(x+qh)=f(x)+q\bigl(f(x+h)-f(x)\bigr),
 \qquad
 \Omega^1_{A[q]/(q^2-q)/A}=0.
\]
This separates the primary support masks from later tangent, endpoint,
and spectral realizations without severing the morphisms among them.

## Matrix, monad, and adelic morphisms recovered from v11

For a split trace word, the ring projection is the ordinary trace and the
Boolean projection is existence of a closed supported walk with the ordered
edge colours.  Monomial conjugacy is classified by weighted cycles:
\[
 \mathcal W(M)=\{(|C|,w_C(M))\}_C,
 \qquad
 \det(I-uM)^{-1}=\prod_C(1-w_Cu^{|C|})^{-1}.
\]

For (q:A\twoheadrightarrow k), with kernel \(\mathfrak m\), the primary
monad fibres are
\[
 G(q)^{-1}(a)=\widetilde a+\mathfrak m,
 \qquad
 G(q)^{-1}(\tau)=\{\tau\},
 \qquad
 G(q)^{-1}(e_k)=\mathfrak m.
\]
Hence the exact local chain is
\[
 \tau\longrightarrow e_A\longrightarrow
 h\in\mathfrak m\setminus\{0\}.
\]
The several-coordinate monad is a Boolean cube of affine tangent fibres;
support activation and tangent displacement are independent data.

The Connes--Consani arithmetic Jacobian admits the exact Boolean-coordinate
map
\[
 \operatorname{Jac}_{\mathrm{ar}}
 \cong\operatorname{Pic}_f\times\mathbb B
 \xrightarrow{c_{\operatorname{Pic}_f}}
 \operatorname{Pic}_f^\tau,
\]
where (c(m,1)=m\) and (c(m,0)=\tau\).  This collapses the full degenerate
metric stratum to the reduced absent point.

On an adelic curve, support is measured by
\[
 \Delta_S([A])(a)=\int_A\log|a|_\omega\,d\nu(\omega).
\]
Balanced faces are exactly those on which projective heights descend.  For
the standard adelic curve of a global field, only the empty and full faces
are balanced.  Adjoining trivial places contributes an explicit
height-neutral Boolean cube.

Finally, the local metric states have the faithful two-bit form
\[
 \text{absence}\mapsto(0,0),\qquad
 \text{zero seminorm}\mapsto(1,0),\qquad
 \text{nondegenerate}\mapsto(1,1).
\]
This incidence pair retains presence and nondegeneracy separately.

## Active comparison obligations

1. Read every TeX source under 'split_zero_projective_monads_surcomplex'.
2. Recover the exact maps, if present, among:
   \[
   \zeta(0)=-\frac12,\quad
   \delta(2)=-2,\quad
   \operatorname{Res}_\infty(d\log(s(s-1)))=-2,\quad
   \zeta(-2)=0,
   \]
   and the Fable fixed-point/interpolation carrier.
3. The mixer-support versus ordered-blade comparison has been completed by
   the explicit Hadamard intertwiner recorded below.
4. Inspect the targeted localization/globalization source named by the user
   after the two required corpus roots are complete.
5. If the original QSM programme is reused beyond the repaired Wick/spectral
   chain, audit its measurable-selection and torus-stability steps separately.

## Full matrix zero fibre and internal split construction

The scalar pair model extends entrywise:
\[
 \Phi_n:M_n(G(R))\xrightarrow{\sim}
 \left\{(A,S)\in M_n(R)\times M_n(\mathbb B):
 S_{ij}=0\Longrightarrow A_{ij}=0_R\right\}.
\]
Its ring-null fibre is
\[
 \widehat p_R^{-1}(0_n)
 =
 \{(0_n,S):S\in M_n(\mathbb B)\}
 \cong M_n(\mathbb B).
\]
Thus the matrix zero amplitude does not erase the support matrix.  For the
directed blade lift,
\[
 \widetilde N\longmapsto(2E_{21},E_{21}),
\]
and \(E_{11}\), \(E_{22}\) are the derived source and range support
projectors.

The final unread portion of
split_support_geometry_arithmetic_curve_v11.tex has now been read through
line 9249.  Its sheafwise construction is
\[
 \operatorname{Spl}_{\mathscr E}(A)=1\amalg A,
\]
with universal amplitude and support maps.  For sheaves on a space,
\[
 \operatorname{Spl}(\mathcal A)(U)
 \cong
 \coprod_{V\in\operatorname{Clop}(U)}\mathcal A(V).
\]
The arithmetic and scaling-site stalks both retain three ordered levels:
absence, supported zero, and supported nonzero amplitude.

The exact product relation is
\[
 \operatorname{Spl}(A\times B)
 \cong
 \operatorname{Spl}(A)\times_{\mathbb B}\operatorname{Spl}(B).
\]
The Cartesian product on the right before fibre restriction carries
independent support bits.  The fibre product is its synchronized-support
subobject.

The final synthesis in v11 joins support lattices, split matrix invariants,
adelic defect transforms, Frobenius towers, finite quadratic gerbes,
Heisenberg/theta boundaries, UHF limits, monomial spectral descent, and the
reciprocal Beurling endpoint.  Earlier-version unique blocks remain to be
checked before the morphism construction resumes.

## Equalizer morphism into the full directed split-pair stratum

The relevant matrix coordinate is the full amplitude/support pair.  For
\(a\in\mathbb C\),
\[
 \mathbf e_{21}(a)=
 \begin{pmatrix}\tau&\tau\\ \widetilde a&\tau\end{pmatrix},
 \qquad
 \Phi_2(\mathbf e_{21}(a))=(aE_{21},E_{21}).
\]
This includes the zero-amplitude point on the fixed (E_{21})-support fibre
\[
 \Phi_2(\mathbf e_{21}(0))=(0_2,E_{21}),
\]
which is distinct from the ambient additive zero \((0_2,0_2)\).

The fixed-support locus
\[
 \mathscr L_{21}^{\mathrm{spl}}
 =\{(aE_{21},E_{21}):a\in\mathbb C\}
\]
is an affine line.  Composing the globalization common-value morphism
\[
 w=-u(1+u)
\]
with the forced affine reflection \(a=-w\) and this fixed-support embedding
gives
\[
 u\longmapsto
 \bigl(u(1+u)E_{21},E_{21}\bigr).
\]
Its two values are
\[
 u=-\frac12\longmapsto
 \left(-\frac14E_{21},E_{21}\right),
 \qquad
 u=1\longmapsto(2E_{21},E_{21}).
\]
The first is the Fable collision target in the directed channel; the second
is the complete split-pair image of the directed blade.

On the trivial-zero divisor, the same morphism gives
\[
 -2n\longmapsto(2nE_{21},E_{21})
 =
 \left(\bigl(-\det JF^{(n)}\bigr)E_{21},E_{21}\right)
 =
 \left(\bigl(-8F_1^{(n)}(p_\bullet)\bigr)E_{21},E_{21}\right).
\]
The Boolean history is \(E_{21}\) for every \(n\), while its source and
range projectors are \(E_{11}\) and \(E_{22}\).

## Matrix-valued restricted zeta morphism

The restricted zeta function on the common-value scheme has the full
split-pair lift
\[
 \mathcal Z_{21}^{\mathrm{spl}}(w)
 =
 \bigl(Z_{\mathscr W}(w)E_{21},E_{21}\bigr).
\]
Its component values are
\[
 \mathcal Z_{21}^{\mathrm{spl}}\!\left(\frac14\right)
 =
 \bigl(\zeta(1/4)E_{21},E_{21}\bigr),
 \qquad
 \mathcal Z_{21}^{\mathrm{spl}}(-2)
 =
 (0_2,E_{21}).
\]
The second value is the zero-amplitude point
\(\Phi_2(\mathbf e_{21}(0))\) on the fixed (E_{21})-support fibre,
distinct from the ambient additive zero
\((0_2,0_2)\).

Its first jet is
\[
 \mathcal Z_{21}^{\mathrm{spl}}(-2+\varepsilon)
 =
 \left(
  -\frac{\zeta(3)}{4\pi^2}\varepsilon E_{21},
  E_{21}
 \right)
 \pmod{\varepsilon^2}.
\]
For the endpoint divisor \(D=[0]+[1]\), the residue
\(\mathfrak r_\infty(D)=-2\) has two exact images:
\[
 \mathcal Z_{21}^{\mathrm{spl}}\bigl(\mathfrak r_\infty(D)\bigr)
 =(0_2,E_{21}),
 \qquad
 \mathfrak b_{21}\bigl(\mathfrak r_\infty(D)\bigr)
 =(2E_{21},E_{21}).
\]
The amplitudes differ while their Boolean history is the same directed
support matrix \(E_{21}\).

## Ambient and joint zeta--blade morphisms

The affine map used on the full trivial-zero orbit has ambient domain
\(\mathbb A^1_w\):
\[
 \mathfrak B_{21}(w)=(-wE_{21},E_{21}).
\]
Its restriction to the common-value scheme is the previously constructed
\(\mathfrak b_{21}\).

On
\[
 \Omega_\zeta=\mathbb A^{1,\mathrm{an}}_{\mathbb C}\setminus\{1\},
\]
the analytic zeta lift and the joint map are
\[
 \widehat{\mathcal Z}_{21}(z)
 =
 (\zeta(z)E_{21},E_{21}),
\]
\[
 \mathfrak J_{21}(z)
 =
 \left(
  (\zeta(z)E_{21},E_{21}),
  (-zE_{21},E_{21})
 \right).
\]
For every \(n\ge1\),
\[
 \mathfrak J_{21}(-2n)
 =
 \left(
  (0_2,E_{21}),
  (2nE_{21},E_{21})
 \right),
\]
and
\[
 \mathfrak J_{21}(-2n+\varepsilon)
 =
 \left(
  \bigl(\zeta'(-2n)\varepsilon E_{21},E_{21}\bigr),
  \bigl((2n-\varepsilon)E_{21},E_{21}\bigr)
 \right)
 \pmod{\varepsilon^2}.
\]
The exact first tangent is
\[
 \zeta'(-2n)
 =
 (-1)^n\frac{(2n)!}{2(2\pi)^{2n}}\zeta(2n+1),
\]
while the second tangent is \(-1\).  At the base point,
\[
 2n=-\det JF^{(n)}=-8F_1^{(n)}(p_\bullet),
\]
so this single morphism records the supported zeta zero, the odd-zeta first
jet, and the Fable dilation coordinate without dropping \(E_{21}\).

## Endpoint--reciprocal--spectral three-cycle

Put \(q=\zeta(0)=-1/2\).  The ordered scalar set
\[
 \mathscr C_q=\{1,q,q^{-1}\}
\]
has the unique projective automorphism
\[
 \Theta([A:B])=[-B:A+B],
 \qquad
 \Theta(a)=-\frac1{a+1},
\]
which satisfies
\[
 1\longmapsto q\longmapsto q^{-1}\longmapsto1.
\]
Its projective matrix
\[
 \begin{pmatrix}0&-1\\1&1\end{pmatrix}
\]
has cube \(-I_2\), so the action has order three.  The fixed-support lift
cycles
\[
 (E_{21},E_{21})
 \longmapsto
 \left(-\frac12E_{21},E_{21}\right)
 \longmapsto
 (-2E_{21},E_{21})
 \longmapsto
 (E_{21},E_{21}).
\]
This retains the Boolean coordinate throughout.

For
\[
 \mathcal L_U(s)=q^{-1}(4\pi^2)^{-s}\zeta(2s),
\]
one has \(\mathcal L_U(0)=q^{-1}q=1\).  Hence the cycle consists of
the twisted spectral value, zeta endpoint, and reciprocal endpoint.  The
reciprocal is also the Fable Jacobian scalar:
\[
 q^{-1}=\det JF=-2.
\]
The two ambient matrix morphisms leaving this point are
\[
 \widehat{\mathcal Z}_{21}(q^{-1})=(0_2,E_{21}),
 \qquad
 \mathfrak B_{21}(q^{-1})=(2E_{21},E_{21}).
\]
The former is the zero-amplitude point on the fixed (E_{21})-support
fibre; the latter is the directed blade pair.  Their differing amplitudes
and shared support are retained by the joint morphism.  The ambient additive
zero is \((0_2,0_2)\).

## Mixer projections and ordered blade channels

Let
\[
 S=\begin{pmatrix}0&1\\1&0\end{pmatrix},
 \qquad
 J=\begin{pmatrix}1&0\\0&-1\end{pmatrix},
 \qquad
 H=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}.
\]
Then
\[
 HJH^{\mathsf T}=S,
 \qquad
 HSH^{\mathsf T}=J.
\]
Writing
\[
 u_+=\frac1{\sqrt2}(1,1)^{\mathsf T},
 \qquad
 u_-=\frac1{\sqrt2}(1,-1)^{\mathsf T},
 \qquad
 P_\pm=u_\pm u_\pm^{\mathsf T}=\frac12(I_2\pm S),
\]
one obtains
\[
 HE_{21}H^{\mathsf T}=u_-u_+^{\mathsf T},
 \qquad
 HE_{12}H^{\mathsf T}=u_+u_-^{\mathsf T}.
\]
The first channel has source (P_+) and range (P_-); the second has
source (P_-) and range (P_+).  The ordered bimodule signs are
\[
 S(u_-u_+^{\mathsf T})=-u_-u_+^{\mathsf T},
 \qquad
 (u_-u_+^{\mathsf T})S=u_-u_+^{\mathsf T},
\]
and the reverse channel has the opposite pair.  Thus the half-period mixer
projectors are the source and range supports of the blades, while the blades
remain directed partial isometries between those support lines.

## Power-set branches and regular-simplex carriers

For a finite label set \(I\), the membership branches identify
\[
 \mathcal P(I)\cong\mathbb B^I.
\]
After the entrywise embedding \(\mathbb B^I\subset\mathbb R^I\), put
\[
 \Pi_I=I-\frac1{|I|}\mathbf j_I\mathbf j_I^{\mathsf T},
 \qquad
 q_I(A)=\Pi_I\mathbf1_A.
\]
Then
\[
 q_I(I\setminus A)=-q_I(A),
 \qquad
 \langle q_I(A),q_I(B)\rangle
 =
 |A\cap B|-\frac{|A||B|}{|I|}.
\]
The unit singleton directions have Gram rule
\[
 \langle\nu_i,\nu_j\rangle=
 \begin{cases}
 1,&i=j,\\
 -1/(|I|-1),&i\ne j.
 \end{cases}
\]
This is the explicit permutation-equivariant morphism from the support cube
to the regular-simplex metric carrier.  It gives the \(120^\circ\) Colour
triangle when \(|I|=3\) and the tetrahedral Times carrier when \(|I|=4\).

## Colour support and the baryonic Wilson contraction

For \(V=\mathbb C[\{\mathrm r,\mathrm g,\mathrm b\}]\), let
\[
 \varepsilon_{\mathcal C}
 =e_{\mathrm r}\wedge e_{\mathrm g}\wedge e_{\mathrm b}.
\]
Together with its dual covolume form, every nonzero component uses the
three Colour atoms exactly once:
\[
 0_a+0_b+0_c=e,
 \qquad
 0_a0_b=0_b0_c=0_c0_a=\tau.
\]
For three Colour holonomies,
\[
 W_{\mathcal C}(U_1,U_2,U_3)
 =
 \frac1{3!}\varepsilon_{abc}\varepsilon^{a'b'c'}
 (U_1)^a{}_{a'}(U_2)^b{}_{b'}(U_3)^c{}_{c'}
\]
is invariant under
\[
 U_j\longmapsto g_yU_jg_x^{-1},
 \qquad
 g_x,g_y\in SU(3),
\]
by
\[
 \varepsilon_{abc}g^a{}_d g^b{}_e g^c{}_f
 =(\det g)\varepsilon_{def}.
\]
The power-set coordinate records the exact colour cover.  The alternating
tensor supplies the ordered signs.

## Four-Time \(SU(4)\) continuation

For the Time labels \(\mathcal T=\{\mathrm M,\mathrm N,\mathrm T,\mathrm E\}\),
put
\[
 \varepsilon_{\mathcal T}
 =
 e_{\mathrm M}\wedge e_{\mathrm N}
 \wedge e_{\mathrm T}\wedge e_{\mathrm E}.
\]
Its twenty-four nonzero components use all four atoms exactly once.  The
four-arm contraction
\[
 W_{\mathcal T}
 =
 \frac1{4!}\varepsilon_{a_1a_2a_3a_4}
 \varepsilon^{b_1b_2b_3b_4}
 \prod_{j=1}^4(U_j)^{a_j}{}_{b_j}
\]
is invariant under independent \(SU(4)\) endpoint actions.  The metric and
support carriers meet at the exact identity
\[
 q_{\mathcal T}(\{t\})
 =
 e_t-\frac14\mathbf j_{\mathcal T}
 =
 \lambda_t.
\]
Thus a Time atom maps to the corresponding \(A_3\) weight, and the factor
\(2/\sqrt3\) gives the tetrahedral unit direction.

## Finite-universe exterior-junction law

For any ordered finite label set \(I=(i_1,\ldots,i_n)\), the tensor
\[
 \varepsilon_I=e_{i_1}\wedge\cdots\wedge e_{i_n}
\]
is supported exactly on the \(n!\) orderings whose singleton supports are
pairwise disjoint and jointly cover \(I\):
\[
 \sum_{j=1}^n0_{a_j}=e,
 \qquad
 0_{a_j}0_{a_k}=\tau\quad(j\ne k).
\]
The associated exterior contraction obeys
\[
 W_I(g_yU_1g_x^{-1},\ldots,g_yU_ng_x^{-1})
 =
 \frac{\det g_y}{\det g_x}W_I(U_1,\ldots,U_n).
\]
It is \(SU(n)\)-invariant at both endpoints.  The same singleton support
maps under the centred branch morphism to
\[
 q_I(\{i\})=e_i-\frac1n\mathbf j_I,
\]
the defining-weight orbit of \(A_{n-1}\).  The Colour Wilson junction and
the four-Time volume junction are respectively the \(n=3\) and \(n=4\)
instances.

## Exterior--Wick ladder and Fuzzionic carrier

For an ordered \(m\)-label universe, define
\[
 u_I=\frac1{\sqrt m}\mathbf j_I,
 \qquad
 H_I=u_I^\perp,
 \qquad
 \widehat\omega_I=\iota_{u_I}\Omega_I^\vee,
 \qquad
 \omega_I=\left.\widehat\omega_I\right|_{H_I}.
\]
Then
\[
 u_I^\vee\wedge\widehat\omega_I=\Omega_I^\vee,
 \qquad
 \dim H_I=m-1.
\]
The exact Lorentz form on the label carrier is
\[
 \eta_I=I_m-\frac2m\mathbf j_I\mathbf j_I^{\mathsf T};
\]
it has signature \((m-1,1)\).  The corrected wave lift on
\(\mathbb R_t\times H_I\) has principal symbol
\[
 -\sigma^2+4\lVert\xi\rVert^2.
\]
Together with the finite-universe exterior law, this gives
\[
 m=3:\ SU(3),(2,1),
 \qquad
 m=4:\ SU(4),(3,1),
 \qquad
 m=5:\ SU(5),(4,1).
\]
Thus four Times are the exact \(SU(4)\), \(3+1\)-dimensional rung.  The
five Fingers
\[
 \mathcal F=\{\mathrm t,\mathrm i,\mathrm m,\mathrm r,\mathrm p\}
\]
are the exact \(SU(5)\), \(4+1\)-dimensional rung; the labels mean thumb,
index, middle (also called long), ring, and pinky.

A Fuzzionic carrier datum adds the physical maps needed to place this
finite label carrier on a spacelike bulk slice: a rank-\(m\) Hermitian
bundle with determinant covolume, an \(SU(m)\) connection, and an oriented
isometry \(\Theta:H_I\to T\Sigma\).  The term Fuzzionic matter state is
reserved for the proposed four-Time realization in a \(3+1\)-dimensional
holographic microstate geometry.  Its induced spatial volume is
\[
 \operatorname{vol}_{\Theta,I}=(\Theta^{-1})^*\omega_I.
\]
The carrier and dimension count are theorems; its occurrence in an ERB or
fuzzball bulk is a physical conjecture.

## Arithmetic four-Time multiplicity carrier

For every resistant prime, the finite complement-orbit union
\[
 \mathscr O_p
 =
 \bigsqcup_{a\in\mathscr A_p}\mathscr O_{R_a,p}
\]
has cardinality
\[
 |\mathscr O_p|
 =
 Q_p
 =
 \sum_{a\in\mathscr A_p}
 \left(
 |\mathcal S^{\mathrm{ext}}_{R_a,a}|
 +
 |\mathcal S^{\mathrm{mid}}_{R_a,a}|
 \right).
\]
The exact arithmetic four-Time carrier is
\[
 \mathscr V^{\mathrm{Time}}_p
 =
 \mathbb C[\mathscr O_p]\otimes\mathbb C[\mathcal T],
 \qquad
 \dim\mathscr V^{\mathrm{Time}}_p=4Q_p.
\]
Its top covolume is independent of the order of the orbit blocks because
two degree-four blocks commute with exterior sign
\((-1)^{4\cdot4}=1\).  The standard \(SU(4)\) action fixes that
covolume.

The old and new carriers share exactly the arithmetic factor
\(\mathbb C[\mathscr O_p]\):
\[
 \mathscr S_p
 \cong
 \mathbb C[\mathscr O_p]\otimes\operatorname{Ran}P_2\otimes\mathbb C^3,
 \qquad
 \mathscr V^{\mathrm{Time}}_p
 =
 \mathbb C[\mathscr O_p]\otimes\mathbb C[\mathcal T].
\]
Consequently,
\[
 \mathrm{ES}(p)
 \Longleftrightarrow
 \mathscr V^{\mathrm{Time}}_p\ne0,
\]
and
\[
\log_2\operatorname{Vol}^{\det}_p
=
\frac32\dim\mathscr V^{\mathrm{Time}}_p.
\]

## Two-target divisor forcing and the exact \(R=3\) shell

For every admissible shell \(R=4a-p\), either target below forces
\(q_{R,p}>0\):
\[
 u\mid a^2,\quad 4u+1\equiv0\pmod R,
\]
or
\[
 \gcd(x,y)=1,\quad xy\mid a,\quad x+y\equiv0\pmod R.
\]
The second target contributes both ordered pairs \((x,y)\) and
\((y,x)\), so \(c_{R,a}\ge2\).  In particular,
\[
 d\mid a,\quad d\equiv-1\pmod R
 \quad\Longrightarrow\quad
 c_{R,a}\ge2.
\]
This is the exact mechanism of the \(R=107\) extremal shell, with
\[
 d=18189=3^2\cdot43\cdot47.
\]

For \(p\equiv1\pmod{12}\), let \(a_3=(p+3)/4\).  Then
\[
 q_{3,p}>0
 \quad\Longleftrightarrow\quad
 a_3\text{ has a prime divisor }\ell\equiv2\pmod3.
\]
Such an \(\ell\) occupies both channels:
\[
 \ell\in\mathcal E_{3,a_3},
 \qquad
 (\ell,1),(1,\ell)
 \text{ contribute to }c_{3,a_3}.
\]
If no such prime divisor exists, every divisor of \(a_3^2\) is
\(1\pmod3\), both target sets are empty, and \(q_{3,p}=0\).

Elsholtz and Tao (J. Aust. Math. Soc. 94 (2013), 50--105;
arXiv:1107.1010) place parametric solution families in soluble residue
classes used by sieve and computational arguments.  The theorem above
is an exact factor-residue criterion for the affine first-shell
coordinate.  It leaves the later-shell problem unchanged when the
\(R=3\) shell is empty.

## Exact \(R=7\) factor-residue sieve

For \(a_7=(p+7)/4\), let
\[
 \nu_r(a_7)
 =
 \sum_{\ell\equiv r\ (7)}v_\ell(a_7).
\]
Then
\[
 q_{7,p}>0
\]
if and only if at least one of
\[
 \nu_5+\nu_6>0,\qquad
 \nu_3\ge3,\qquad
 \nu_3\ge1\ \text{and}\ \nu_2+\nu_4\ge1
\]
holds.  With \(3\) as generator,
\[
 U_7=(1,3,2,6,4,5).
\]
The empty states are exactly:

1. all prime-factor residues lie in the order-three subgroup
   \(\{1,2,4\}\);
2. all prime-factor residues lie in \(\{1,3\}\) and the total
   \(3\)-residue valuation is one or two.

The first case cannot reach either target because both divisor and
ratio residues remain in the subgroup.  In the second case the
exterior exponent interval stops at four and the middle interval stops
at two.

On the remaining prime locus \(p\equiv1\pmod{24}\), put
\[
c=\frac{p+7}{8},
\qquad
a_7=2c.
\]
The marked factor \(2\) lies in \(Q_7=\{1,2,4\}\), so the general
classification collapses to
\[
q_{7,p}>0
\iff
\text{some prime }\ell\mid c\text{ lies in }\{3,5,6\}\pmod7
\iff
\left(\frac{\ell}{7}\right)=-1
\text{ for some prime }\ell\mid c.
\]
Equivalently,
\[
\operatorname{Supp}_{7,p}(a_7)
=
1-
\prod_{\substack{\ell\mid c\\\ell\ {\rm prime}}}
\frac{1+\left(\frac{\ell}{7}\right)}2.
\]
This is an exact support-sheet-phase decomposition:
\[
\operatorname{Supp}_{7,p}(a_7)\in\{0,1\},
\qquad
U_7/Q_7\cong C_2,
\qquad
Q_7\cong C_3.
\]
The support bit is the Boolean disjunction of the nonresidue-sheet
flags; the three structures remain individually defined.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:hard-locus-R7-Boolean-sheet-formula.

The updated residual-seven checker verifies the formula for all \(267\)
primes \(p\equiv1\pmod{24}\) below \(20000\): \(201\) shells are
occupied and \(66\) are empty.  The first empty pairs \((p,c)\) are
\[
(337,43),\quad(457,58),\quad(1009,127),\quad(1129,142).
\]

## Exact \(R=11\) factor-residue ideal

For \(a_{11}=(p+11)/4\), use \(2\) as generator of \(U_{11}\):
\[
\begin{array}{c|ccccccccc}
k&1&2&3&4&5&6&7&8&9\\ \hline
2^k\bmod11&2&4&8&5&10&9&7&3&6.
\end{array}
\]
The exterior and middle targets have exponent \(3\) and \(5\),
respectively.  For
\[
\boldsymbol\nu
=
(\nu_2,\nu_4,\nu_8,\nu_5,\nu_{10},
 \nu_9,\nu_7,\nu_3,\nu_6),
\]
the exact target conditions are
\[
3\in
\sum_{k=1}^{9}k\{0,\ldots,2\nu_{2^k}\}\pmod{10}
\]
and
\[
5\in
\sum_{k=1}^{9}k\{-\nu_{2^k},\ldots,\nu_{2^k}\}\pmod{10}.
\]

Let
\[
\mathfrak m_{11}(a_{11})
=
\prod_{r=2}^{10}X_r^{\nu_r(a_{11})}.
\]
Then \(q_{11,p}>0\) exactly when this monomial is divisible by one of
\[
\begin{gathered}
X_8,\ X_{10},\\
X_6X_7,\ X_3X_7,\ X_6X_9,\ X_7X_9,\ X_5X_6,\
X_4X_6,\ X_4X_7,\ X_2X_9,\ X_2X_5,\ X_2X_4,\ X_2^2,\\
X_3X_6^2,\ X_3^2X_6,\ X_5^2X_7,\
X_2X_3^2,\ X_2X_7^2,\\
X_6^4,\ X_5X_7^3,\ X_7^5.
\end{gathered}
\]
These are the twenty-one coordinatewise-minimal occupied states.

The exhaustion is finite.  A target representation with at least ten
terms in \(C_{10}\) contains a nonempty zero-sum subsequence by the
partial-sum argument.  Repeated removal leaves at most nine terms.
There are \(\binom{18}{9}-1=48619\) nonzero valuation states of total
degree at most nine.  The checker
\(\texttt{verification/verify\_residual\_eleven\_factor\_classification.py}\)
computes their exact antichain and compares ideal membership with the
original divisor definitions on \(2728\) coprime integers and \(555\)
affine prime shells.

## Exact \(R=15\) parity-coupling ideal

The isomorphism
\[
\phi:U_{15}\longrightarrow C_4\times C_2,
\qquad
\phi\bigl(2^i(-1)^j\bigr)=(i,j),
\]
places the exterior and middle targets at
\[
\phi(11)=(2,1),
\qquad
\phi(14)=(0,1).
\]
For \(a_{15}=(p+15)/4\), the complete criterion is
\[
q_{15,p}>0
\quad\Longleftrightarrow\quad
\nu_{11}+\nu_{14}>0
\quad\text{or}\quad
(\nu_2+\nu_8)(\nu_7+\nu_{13})>0.
\]
Equivalently,
\[
I_{15}
=
\langle X_{11},X_{14}\rangle
+(X_2,X_8)(X_7,X_{13}).
\]

## One-box reduction and prime-twisted target volume

For an extracted factor \(a=\ell b\), the exterior and middle
reachability sets are related by the exact translation
\[
\mathscr R_R^{\mathrm E}\bigl(\boldsymbol\nu_R(b)\bigr)
=
\overline b\,
\mathscr R_R^{\mathrm M}\bigl(\boldsymbol\nu_R(b)\bigr).
\]
The coordinate map is \(e_g=d_g+\nu_g\).  It sends the exterior
interval \(0\le e_g\le2\nu_g\) bijectively onto the signed interval
\(-\nu_g\le d_g\le\nu_g\).  The two divisor channels therefore reduce
to one signed reachability box tested against
\[
\mathcal T_{R,\ell}^{\mathrm M}
\cup
(4\overline\ell\,\overline b)^{-1}
\mathcal T_{R,\ell}^{\mathrm M}.
\]

For \(p=12k+1\), \(R_m=12m-1\), and \(b_m=k+m\),
\[
12b_m=p+R_m,
\qquad
(12\overline b_m)^{-1}=\overline p^{-1}.
\]
Set
\[
\mathcal T_m=\mathcal T_{R_m,3}^{\mathrm M},
\qquad
\mathcal D_{m,p}
=
\mathcal T_m\cup\overline p^{-1}\mathcal T_m.
\]
Then
\[
q_{R_m,p}>0
\quad\Longleftrightarrow\quad
\mathscr R_{R_m}^{\mathrm M}
\bigl(\boldsymbol\nu_{R_m}(b_m)\bigr)
\cap\mathcal D_{m,p}\ne\varnothing.
\]
Since
\[
-\mathcal T_m=\{3^{-1},1,3\},
\]
the exact target volume is
\[
|\mathcal D_{m,p}|
=
\begin{cases}
3,&p\equiv1,\\
4,&p\equiv3^{\pm1},\\
5,&p\equiv3^{\pm2},\\
6,&\text{otherwise}
\end{cases}
\pmod{R_m}.
\]
The checker verifies this law on all \(55214\) unit classes in the
first \(100\) universal residuals, together with the complete
\(R=11\) and \(R=23\) tables.

For a fixed prime \(p=12k+1\), define
\[
\delta_{11}(N;X)
=
\#\{d\mid N:d\le X,\ d\equiv11\pmod{12}\}.
\]
With \(X_k=24k-1\), the exact counts of submaximal target shells are
\[
\mathcal N_3(k)=\delta_{11}(k;X_k),
\]
\[
\mathcal N_4(k)
=
\delta_{11}(6k-1;X_k)+\delta_{11}(18k+1;X_k),
\]
\[
\mathcal N_5(k)
=
\delta_{11}(3k-2;X_k)+\delta_{11}(27k+2;X_k).
\]
Hence
\[
\mathcal N_6(k)
=
2k-\mathcal N_3(k)-\mathcal N_4(k)-\mathcal N_5(k),
\]
and, for every \(\varepsilon>0\),
\[
\mathcal N_3(k)+\mathcal N_4(k)+\mathcal N_5(k)
=
O_\varepsilon(k^\varepsilon),
\qquad
\frac{\mathcal N_6(k)}{2k}\longrightarrow1.
\]
The target has maximal volume six on asymptotically almost every
every-third shell.  The checker confirms the exact formulas on
\(62294\) shells attached to \(159\) primes below \(5000\).

## Forced factor and colon filtration at residual 11

For \(p=4n+1\equiv1\pmod{12}\), one has \(n\equiv0\pmod3\), hence
\[
3\mid a_{11}=n+3.
\]
The corresponding factor-residue monomial therefore contains \(X_3\).
The exact third-shell criterion may be divided by this forced factor:
\[
q_{11,p}>0
\quad\Longleftrightarrow\quad
\frac{\mathfrak m_{11}(a_{11})}{X_3}
\in(I_{11}:X_3).
\]
The irredundant first colon ideal is
\[
(I_{11}:X_3)
=
\langle
X_7,X_8,X_{10},
X_6X_9,X_6^2,X_5X_6,X_4X_6,X_3X_6,
X_2X_9,X_2X_5,X_2X_4,X_2X_3,X_2^2
\rangle.
\]
The filtration stabilizes after the second forced copy:
\[
(I_{11}:X_3^e)
=
\langle X_2,X_6,X_7,X_8,X_{10}\rangle
\qquad(e\ge2).
\]
Furthermore,
\[
v_3(a_{11})\ge2
\quad\Longleftrightarrow\quad
p\equiv25\pmod{36}.
\]
For \(b_{11}=(p+11)/36\) in this stratum,
\[
q_{11,p}=0
\quad\Longleftrightarrow\quad
\ell\bmod11\in\{1,3,4,5,9\}
\quad
\text{for every prime }\ell\mid b_{11}.
\]
The extended \(R=11\) checker derives the two colon antichains and
compares these criteria with the original divisor definitions on the
maintained prime range.

## Coprime \(R=7/R=11\) coordinates on the hard prime locus

For a prime \(p\equiv1\pmod{24}\), write \(p=24k+1\) and put
\[
c_7=\frac{p+7}{8}=3k+1,
\qquad
d_{11}=\frac{p+11}{12}=2k+1.
\]
Then
\[
p=8c_7-7=12d_{11}-11,
\qquad
3d_{11}-2c_7=1,
\qquad
\gcd(c_7,d_{11})=1,
\]
while the original shell denominators are
\[
a_7=2c_7,
\qquad
a_{11}=3d_{11}.
\]
The two shells are empty simultaneously exactly when

1. every prime divisor of \(c_7\) lies in
   \(\{1,2,4\}\pmod7\); and
2. \(\mathfrak m_{11}(d_{11})\notin J_{11}^{(1)}\).

The second condition is the disjoint union of the two exact branches
in cor:residual-eleven-first-colon-complement: either every prime
divisor of \(d_{11}\) lies in
\(\{1,3,4,5,9\}\pmod{11}\), or
\[
d_{11}=vq_2^{\epsilon_2}q_6^{\epsilon_6},
\qquad
\epsilon_2,\epsilon_6\in\{0,1\},
\qquad
1\le\epsilon_2+\epsilon_6\le2,
\]
with all prime divisors of \(v\) congruent to \(1\pmod{11}\) and each
present \(q_j\) prime in class \(j\pmod{11}\).

The exact first-principles replay checks all \(267\) primes
\(p\equiv1\pmod{24}\) below \(20000\).  Exactly \(28\) leave both
shells empty; the first triples \((p,c_7,d_{11})\) are
\[
(1201,151,101),\quad
(2137,268,179),\quad
(2377,298,199),\quad
(2521,316,211).
\]
Source theorem:
thm:hard-locus-R7-R11-coprime-coordinate-pair.
Checker:
verification/verify_hard_locus_R7_R11_pair.py.

## First continuation through \(R=15,19,23\)

On the prime locus \(p=24k+1\), the next three shell denominators are
\[
a_{15}=6k+4=2(c_7+1),
\qquad
a_{19}=6k+5=2c_7+3=3d_{11}+2,
\qquad
a_{23}=6k+6=3(d_{11}+1).
\]
Thus \(a_{15},a_{19},a_{23}\) are consecutive.

At the first residual-\(7\)/residual-\(11\) double survivor,
\[
(p,k,c_7,d_{11})=(1201,50,151,101),
\]
one has
\[
(a_{15},a_{19},b_{23},a_{23})=(304,305,102,306)
\]
and
\[
(q_{15,1201},q_{19,1201},q_{23,1201})=(0,0,3).
\]
The exact witnesses are
\[
\mathcal E_{23,306}=\{17,2754\},
\qquad
\mathcal M_{23,306}=\{(6,17),(17,6)\}.
\]
The witness \(u=17\) gives
\[
\frac4{1201}
=
\frac1{306}+\frac1{1082101}+\frac1{16218}.
\]

Among the \(28\) double survivors below \(20000\), the residual-\(15\),
residual-\(19\), and residual-\(23\) shells occupy \(26\).  Their exact
occupation-pattern counts are
\[
\begin{array}{c|rrrrrrr}
(q_{15}>0,q_{19}>0,q_{23}>0)
 &(0,0,0)&(0,0,1)&(0,1,0)&(0,1,1)&(1,0,1)&(1,1,0)&(1,1,1)\\
\text{count}&2&3&3&2&15&1&2.
\end{array}
\]
The two points empty through \(R=23\) are \(3361\) and \(8089\).
Their exact tails are
\[
\begin{array}{c|c|c}
p&\text{preceding empty shells}&\text{first occupied shell}\\ \hline
3361&R=27,31,35&R=39,\ q_{39}=3,\\
8089&R=27&R=31,\ q_{31}=4.
\end{array}
\]
The complete witness sets at those occupied shells are
\[
\mathcal E_{39,850}=\{68,42500\},
\qquad
\mathcal M_{39,850}=\{(5,34),(34,5)\},
\]
and
\[
\mathcal E_{31,2030}=\{116,1015\},
\]
\[
\mathcal M_{31,2030}
=\{(2,29),(29,2),(35,58),(58,35)\}.
\]
They reconstruct
\[
\frac4{3361}
=
\frac1{850}+\frac1{19769402}+\frac1{73525},
\]
\[
\frac4{8089}
=
\frac1{2030}+\frac1{245371726}+\frac1{530845}.
\]
Therefore every one of the \(28\) finite double survivors is occupied
by some shell \(R\le39\).  This is a finite-range theorem; the uniform
coverage statement remains the active arithmetic problem.

Source statements:
cor:hard-locus-next-three-affine-coordinates,
thm:first-hard-locus-R23-resolution, and
comp:first-hard-locus-R15-R19-R23-certificate.
Tail theorem:
thm:finite-hard-locus-tail-resolution.
Exact checker:
verification/verify_first_hard_locus_R15_R19_R23.py.
Lean source:
verification/FirstHardLocusR15R19R23Certificate.lean.

## First escape through \(R=39\) and exact \(R=59\) exit

The finite bound from the first \(28\) hard-locus points does not extend.
Among the \(1372\) primes \(p\equiv1\pmod{24}\) with \(p\le118801\), the
unique prime empty at every shell \(R=3,7,\ldots,39\) is
\[
p=118801=24\cdot4950+1.
\]
It remains empty through \(R=55\).  Its affine shell coordinates are
\[
a_{4j-1}=29700+j
\qquad
(1\le j\le15),
\]
so they form the consecutive string \(29701,\ldots,29715\).  At the
first occupied shell,
\[
R=59,
\qquad
a_{59}=29715=3\cdot5\cdot7\cdot283,
\]
the complete witness sets are
\[
\mathcal E_{59,29715}=\{21225\},
\qquad
\mathcal M_{59,29715}=\{(1,1415),(1415,1)\}.
\]
Thus \(q_{59,118801}=2\), and
\[
\frac4{118801}
=
\frac1{29715}
+\frac1{5077395546660}
+\frac1{59834124}.
\]

Source theorem:
thm:first-R39-escape-R59-resolution.
Exact checker:
verification/verify_first_escape_through_R39.py.
Lean source:
verification/FirstEscapeThroughR39Certificate.lean.

## Crossed target incidence at the first \(R=39\) escape

For each shell, the two exponent alphabets and the two arithmetic
targets define
\[
\Xi_{R,a}
=
\begin{pmatrix}
\mathbf1_{\{t_R\in\mathscr R_R^{\mathrm E}\}}&
\mathbf1_{\{s_R\in\mathscr R_R^{\mathrm E}\}}\\
\mathbf1_{\{t_R\in\mathscr R_R^{\mathrm M}\}}&
\mathbf1_{\{s_R\in\mathscr R_R^{\mathrm M}\}}
\end{pmatrix}.
\]
Its diagonal is the exterior/middle occupancy pair.

For
\[
(p,R,a)=(118801,39,29710),
\]
the factor residues are \((2,5,7)\), \(t_{39}=29\), \(s_{39}=38\), and
exact exhaustion gives
\[
\Xi_{39,29710}
=
\begin{pmatrix}0&1\\1&0\end{pmatrix}
=S.
\]
The crossed entries have exponent witnesses
\[
2\cdot5^2\cdot7\equiv38\pmod{39},
\qquad
5^{-1}7^{-1}\equiv29\pmod{39}.
\]
Thus both targets are reached in the opposite exponent alphabets while
the two occupancy entries remain zero.  Under the existing mixer
intertwiner,
\[
H\Xi_{39,29710}H^{\mathsf T}=HSH^{\mathsf T}=J.
\]
The established endpoint bridge still assigns the empty shell the pair
\((P_-,P_-)\); \(J\) is the image of the crossed pre-occupancy
incidence.

At the first occupied shell,
\[
\Xi_{59,29715}
=
\begin{pmatrix}1&1\\1&1\end{pmatrix},
\]
with correct diagonal witnesses \(21225\equiv44=t_{59}\) and
\(1415\equiv58=s_{59}\pmod{59}\).  The occupied comparison shell
\((3361,39,850)\) has the same all-incidence matrix, proving that the
pure transposition is attached to the factor-residue datum rather than
to \(R=39\) alone.

Writing \(\Xi=D+C\) for its diagonal and off-diagonal parts gives
\[
(D,C)_{R=39}=(0,S),
\qquad
(D,C)_{R=59}=(I_2,S),
\]
and therefore
\[
\Xi_{59,29715}-\Xi_{39,29710}=I_2.
\]
Hadamard transport sends these decompositions to
\[
(0,J)
\quad\hbox{and}\quad
(I_2,J),
\]
respectively.  In every shell,
\[
\operatorname{tr}\Xi_{R,a}
=
\mathbf1_{\{\mathcal E_{R,a}\ne\varnothing\}}
+
\mathbf1_{\{\mathcal M_{R,a}\ne\varnothing\}},
\]
so the trace is positive exactly when \(q_{R,p}\) is positive.  The
\(q\)-based determinant-volume carrier detects the diagonal support.
At the empty \(R=39\) shell the crossed component remains nonzero:
\[
q_{39,118801}=0,
\qquad
\lVert S\rVert_{\mathrm{HS}}^2=2.
\]
This is an exact pre-occupancy grading on the zero-support boundary.

The full fifteen-shell incidence classification is
\[
\Xi_{R,a_R}=0
\quad
\text{for }
R\in\{3,7,11,15,23,27,31,35,43,47,51,55\},
\]
\[
\Xi_{19,29705}=E_{21},
\qquad
\Xi_{39,29710}=S,
\qquad
\Xi_{59,29715}=I_2+S.
\]
Thus the first nonzero hidden incidence is the ordered raw blade
\(E_{21}\), and
\[
HE_{21}H^{\mathsf T}=B_{-+}.
\]
At this \(R=19\) shell,
\[
a_{19}=29705=5\cdot13\cdot457,
\qquad
\frac{13}{5}\equiv14\equiv-\frac14\pmod{19},
\]
with the exact one-surplus identities
\[
4\cdot13+5=3\cdot19,
\qquad
13+5+1=19.
\]

The localization morphism
\[
\rho_{19}:\mathbb Z[1/2]\longrightarrow\mathbb F_{19}
\]
base changes the integral Fable polynomial map.  It sends the three
marked inputs to
\[
(0,0,14),\qquad(1,8,16),\qquad(18,11,16),
\]
and the reduced map sends all three to \((14,0,0)\).  Hence
\[
\operatorname{pr}_1\rho_{19}^{\,3}F(p_0)
=
\rho_{19}(-1/4)
=14
=13\cdot5^{-1}
\quad\text{in }\mathbb F_{19}.
\]
This is the exact common finite-field coordinate of the Fable quarter
and the first hidden arithmetic blade.

The bounded hidden-incidence census extends this single trajectory to
every prime \(p\le10^6\), \(p\equiv1\pmod{24}\).  Among the \(9732\)
primes, all first occupied shells have \(R\le59\).  The \(6463\)
pre-occupancy shells have exact matrix distribution
\[
\begin{array}{c|rrrr}
\Xi&0&E_{12}&E_{21}&S\\ \hline
\#&6381&3&40&39.
\end{array}
\]
Exactly \(75\) primes have a nonzero hidden matrix before occupation.
Their first hidden types occur \(2,38,35\) times for
\(E_{12},E_{21},S\), respectively.  Their hidden-to-occupied gaps have
distribution
\[
\begin{array}{c|rrrrrrrr}
g&4&8&12&16&20&28&36&40\\ \hline
\#&27&23&15&5&2&1&1&1.
\end{array}
\]
The unique gap-\(40\) case is
\[
(p,R_{\rm hid},R_{\rm occ})=(118801,19,59).
\]

There are seven two-step hidden paths:
\[
\begin{array}{r|c|r}
p&\text{hidden path}&R_{\rm occ}\\ \hline
2521&E_{21}[11]\to E_{21}[19]&23\\
28921&E_{21}[11]\to S[19]&23\\
104161&E_{21}[11]\to S[19]&23\\
118801&E_{21}[19]\to S[39]&59\\
214561&S[11]\to E_{21}[19]&23\\
246241&S[11]\to S[27]&39\\
415969&S[23]\to E_{12}[27]&31.
\end{array}
\]
All seven first occupied matrices are \(I_2+S\).

Complete enumeration of every primitive coprime pair
\[
uv\mid a_{p,R},
\qquad
uv^{-1}\equiv-\frac14\pmod R
\]
in a hidden lower-left channel finds \(R-u-v>0\) exactly twice:
\[
\begin{array}{c|c|c|c|c|c|c}
p&R&u&v&(4u+v)/R&R-u-v&R_{\rm occ}\\ \hline
118801&19&13&5&3&1&59\\
359041&19&13&5&3&1&23.
\end{array}
\]
No zero-surplus primitive pair occurs.  Thus the one-surplus Fable
quarter is shared by two finite arithmetic shells, while the
\(E_{21}[19]\to S[39]\to(I_2+S)[59]\) delay is unique in the tested
range.

The two one-surplus rows admit an exact next-shell comparison.  In the
prime-cofactor family
\[
p=260\ell-19,
\qquad
a_{19}=65\ell,
\]
the complete \(R=19\) incidence matrix depends only on
\(k=\log_2(\ell)\in\mathbb Z/18\mathbb Z\).  Its seven fibres are
\[
\begin{array}{c|l}
\Xi_{19,a_{19}}&k\\ \hline
E_{21}&0,5\\
S&8,13\\
I_2+S&2,4,6,9,11,12\\
\left(\begin{smallmatrix}0&0\\1&1\end{smallmatrix}\right)&14,16\\
\left(\begin{smallmatrix}1&0\\1&0\end{smallmatrix}\right)&10,15\\
\left(\begin{smallmatrix}1&0\\1&1\end{smallmatrix}\right)&7\\
\left(\begin{smallmatrix}1&1\\1&0\end{smallmatrix}\right)&1,3,17.
\end{array}
\]
The cofactor residues for \(457\) and \(1381\) have logarithms \(0\)
and \(5\), respectively, so both \(R=19\) shells have matrix
\(E_{21}\).

At \(R=23\), however, the paths separate.  For \(p=118801\), both
reachability alphabets equal
\[
Q_{23}=\{1,2,3,4,6,8,9,12,13,16,18\},
\]
which contains neither target \(17\) nor \(22\).  For \(p=359041\),
the factor \(4987\equiv19\pmod{23}\) is a nonresidue; adjoining its
permitted powers to the quadratic-residue part fills all of \(U_{23}\)
in both alphabets.  Hence
\[
\Xi_{23,29706}=0,
\qquad
\Xi_{23,89766}=I_2+S.
\]
The latter shell has
\[
\mathcal E_{23,89766}=\{179532\},
\qquad
\mathcal M_{23,89766}=\{3,2685978252\},
\]
and reconstructs
\[
\frac4{359041}
=
\frac1{89766}
+
\frac1{1006242664629726}
+
\frac1{1401292143}.
\]
The established fixed-target colon ideal gives the internal
\(Q_{23}\)-coordinate of this split.  With
\[
b_p=\frac{p+23}{12},
\]
one has
\[
\mathfrak m_{23}^{\log}(b_{118801})
=X_2X_{18}\notin J_{23}^{(3)},
\qquad
\mathfrak m_{23}^{\log}(b_{359041})
=X_2X_{15}X_{16}\in J_{23}^{(3)}.
\]
The pair \((2,15)\) is a minimal degree-two generator, while
\((2,18)\) is absent from the complete degree-one and degree-two
carrier lists.  Thus the coset opening and the internal support-ideal
hit are two coordinate descriptions of the same \(R=23\) transition.
For every prime-cofactor row with \(p=260\ell-19\) prime and
\(p\equiv1\pmod{12}\), this yields the family criterion
\[
\Xi_{19,a_{19}}=E_{21},\quad q_{23,p}=0
\quad\Longleftrightarrow\quad
\lambda_{19}(\ell)\in\{0,5\},\quad
\mathfrak m_{23}^{\log}\!\left(\frac{65\ell+1}{3}\right)
\notin J_{23}^{(3)}.
\]
This is the exact pullback of the \(R=23\) colon ideal to the
prime-cofactor \(E_{21}\) locus.
This proves that the shared one-surplus quarter determines the same
hidden blade but does not determine the length of the subsequent empty
trajectory.

Source theorem:
thm:first-R39-escape-target-transposition.
Finite-field bridge theorem:
thm:first-escape-hidden-blade-Fable-quarter.
Bounded census theorem:
thm:bounded-hidden-incidence-census.
One-surplus branch theorem:
thm:one-surplus-quarter-branch-comparison.
One-surplus colon corollary:
cor:one-surplus-R23-colon-split.
Prime-cofactor survivor corollary:
cor:prime-cofactor-E21-survivor-through-R23.
Propagation corollary:
cor:first-escape-identity-support-increment.
Exact checker:
verification/verify_first_escape_target_transposition.py.
Bounded census checker:
verification/scan_hidden_target_incidence.py.
Lean source:
verification/FirstEscapeTargetTranspositionCertificate.lean.
Bounded structural Lean source:
verification/HiddenIncidenceMatrixStructure.lean.
One-surplus comparison checker:
verification/compare_one_surplus_quarter_branches.py.
One-surplus comparison Lean source:
verification/OneSurplusQuarterBranchCertificate.lean.

## Prime-factor colon reduction and every-third-shell lattice

For a shell \(R=4j-1\), \(a=n+j\), extraction of an actual prime factor
\(\ell^e\mid a\) gives
\[
\mathfrak m_R(a)
=
X_{\overline\ell}^{\,e}\mathfrak m_R(a/\ell^e),
\]
hence
\[
q_{R,p}>0
\quad\Longleftrightarrow\quad
\mathfrak m_R(a/\ell^e)
\in(I_R:X_{\overline\ell}^{\,e}).
\]

If \(p=12k+1\), every index \(j=3m\) satisfies
\[
R_m=12m-1,
\qquad
a_m=3(k+m).
\]
Therefore
\[
q_{R_m,p}>0
\quad\Longleftrightarrow\quad
\mathfrak m_{R_m}(k+m)
\in(I_{R_m}:X_{\overline3}).
\]
This is the universal forced-\(3\) colon lattice running through every
third affine shell.

## Three-position target packets

For \(a=\ell b\), extraction of one factor produces the two reduced
target packets
\[
\mathcal T_{R,\ell}^{\mathrm E}
=
\{t_R,t_R\overline\ell^{-1},t_R\overline\ell^{-2}\},
\]
\[
\mathcal T_{R,\ell}^{\mathrm M}
=
\{s_R\overline\ell,s_R,s_R\overline\ell^{-1}\}.
\]
The shell is occupied exactly when the reduced exterior reachability
set meets the first packet or the reduced middle reachability set meets
the second.

For the first universal forced-\(3\) shell,
\[
\mathcal T_{11,3}^{\mathrm E}
=
\mathcal T_{11,3}^{\mathrm M}
=
\{7,8,10\}.
\]
For the next,
\[
\mathcal T_{23,3}^{\mathrm E}
=
\{7,17,21\},
\qquad
\mathcal T_{23,3}^{\mathrm M}
=
\{15,20,22\}.
\]
Thus residual \(11\) gives a collision of the two three-position
packets, whereas residual \(23\) gives two disjoint triples.

The checker
\(\texttt{verification/verify\_forced\_factor\_target\_packets.py}\)
verifies the packet identities on \(715\) reduced \(R=11\) states,
\(12650\) reduced \(R=23\) states, and \(1110\) direct affine-shell
comparisons.

## Unique collision in the universal forced-\(3\) family

For \(R_m=12m-1\), the two reduced packets are
\[
\mathcal T_{R_m,3}^{\mathrm E}
=
\left\{-\frac14,-\frac1{12},-\frac1{36}\right\},
\qquad
\mathcal T_{R_m,3}^{\mathrm M}
=
\left\{-3,-1,-\frac13\right\}.
\]
Both packets have three distinct entries.  If they coincide, equality
of sums gives \(R_m\mid143\), while equality of products gives
\(R_m\mid1727\).  Since \(\gcd(143,1727)=11\) and \(R_m\ge11\),
\[
\mathcal T_{R_m,3}^{\mathrm E}
=
\mathcal T_{R_m,3}^{\mathrm M}
\quad\Longleftrightarrow\quad
R_m=11
\quad\Longleftrightarrow\quad
m=1.
\]
Thus the residual-\(11\) two-channel target collapse is unique in the
complete every-third-shell family.

## Weighted packet exchange and ordered-blade carriage

For every extracted factor \(\ell\),
\[
\mathcal T_{R,\ell}^{\mathrm E}
=
\alpha_{R,\ell}\mathcal T_{R,\ell}^{\mathrm M},
\qquad
\alpha_{R,\ell}=(4\overline\ell)^{-1}.
\]
On the ordered two-channel module, the packet exchange is
\[
\mathscr J_{R,\ell}
=
\begin{pmatrix}
0&\alpha_{R,\ell}\\
\alpha_{R,\ell}^{-1}&0
\end{pmatrix},
\qquad
\mathscr J_{R,\ell}^2=I.
\]
It exchanges the two tagged packets and anticommutes with their ordered
sign grading.

On the base-changed ordered blade module
\[
W_R=A_RE_{21}\oplus A_RE_{12},
\]
blade transpose is \(X\mapsto SXS\), where
\(S=E_{12}+E_{21}\).  Every line-preserving packet--blade
intertwiner is
\[
\Phi_u(e_{\mathrm E})=uE_{21},
\qquad
\Phi_u(e_{\mathrm M})=\alpha_{R,\ell}uE_{12}.
\]
Equal blade amplitudes occur exactly when
\(\alpha_{R,\ell}=1\).  For the universal forced factor \(3\),
\[
[\mathscr J_{11,3}]
=
\begin{pmatrix}0&1\\1&0\end{pmatrix},
\qquad
[\mathscr J_{23,3}]
=
\begin{pmatrix}0&2\\12&0\end{pmatrix}.
\]
Thus \(R=11\) is the unique universal residual admitting the
equal-amplitude ordered-blade carriage; \(R=23\) retains the exact
amplitude ratio \(2\).

## Reduced first-six affine carrier

For
\[
c=\frac{p+11}{12},
\]
the first six coordinates reduce to
\[
\left(
a_3,a_7,\frac{a_{11}}3,a_{15},a_{19},\frac{a_{23}}3
\right)
=
(3c-2,3c-1,c,3c+1,3c+2,c+1).
\]
The maintained preprint gives the exact four simultaneous survivor
conditions for the first four entries and records their coprimality
cycle.
The coupling generators follow from
\[
2\cdot13\equiv8\cdot7\equiv11\pmod{15},
\qquad
2\cdot7\equiv8\cdot13\equiv14\pmod{15}.
\]
If the direct target classes are absent and the two displayed factor
classes do not couple, every expression with second \(C_2\)-coordinate
one has odd \(C_4\)-coordinate, whereas both targets have even
\(C_4\)-coordinate.  This proves necessity.

The checker
\(\texttt{verification/verify\_residual\_fifteen\_factor\_classification.py}\)
recovers the six minimal generators from \(329\) bounded states and
compares the criterion with the original divisor definitions on
\(1600\) coprime integers and \(555\) affine prime shells.

## General residual support ideal

For an admissible odd residual \(R\), aggregate the factor valuations
of \(a\) by \(g\in U_R\setminus\{\overline1\}\).  Define
\[
\mathscr R_R^{\mathrm E}(\boldsymbol\nu)
=
\left\{\prod_g g^{e_g}:0\le e_g\le2\nu_g\right\},
\qquad
\mathscr R_R^{\mathrm M}(\boldsymbol\nu)
=
\left\{\prod_g g^{d_g}:-\nu_g\le d_g\le\nu_g\right\}.
\]
The shell is occupied exactly when
\[
\overline{-4^{-1}}\in
\mathscr R_R^{\mathrm E}(\boldsymbol\nu_R(a))
\quad\text{or}\quad
\overline{-1}\in
\mathscr R_R^{\mathrm M}(\boldsymbol\nu_R(a)).
\]
This is a coordinatewise up-set.  Its minimal valuation vectors generate
a finite monomial ideal \(I_R\), and
\[
q_{R,p}>0
\quad\Longleftrightarrow\quad
\mathfrak m_R(a)\in I_R.
\]

If \(D(U_R)\) is the Davenport constant, every minimal generator has
degree at most \(D(U_R)-1\).  The proof removes product-one
subsequences from any longer exterior or signed-middle target
representation.

For \(p=4n+1\), the exact global form is
\[
\mathrm{ES}(p)
\quad\Longleftrightarrow\quad
\exists\,1\le j\le2n:
\mathfrak m_{4j-1}(n+j)\in I_{4j-1}.
\]
Thus a counterexample is a consecutive affine sequence avoiding every
residual support ideal.

The first four coordinates are \(n+1,n+2,n+3,n+4\), with
\[
I_3=\langle X_2\rangle,
\]
\[
I_7
=
\langle X_5,X_6,X_3^3,X_2X_3,X_3X_4\rangle,
\]
the twenty-one-generator \(I_{11}\), and
\[
I_{15}
=
\langle X_{11},X_{14}\rangle
+(X_2,X_8)(X_7,X_{13}).
\]

## Universal every-second binary packet

For a resistant prime \(p=12k+1\), put
\(\eta_k\equiv k\pmod2\), \(\eta_k\in\{0,1\}\), and
\[
j_m^{(2)}=2m-\eta_k,
\qquad
R_m^{(2)}=8m-4\eta_k-1,
\qquad
b_m^{(2)}=\frac{3k-\eta_k}{2}+m.
\]
Then
\[
3k+j_m^{(2)}=2b_m^{(2)},
\qquad
8b_m^{(2)}=p+R_m^{(2)}.
\]
The two divisor channels occupy one signed reachability box against
\[
\mathcal D_{m,p}^{(2)}
=
\{-2,-1,-2^{-1}\}
\cup
\overline p^{-1}\{-2,-1,-2^{-1}\}.
\]
The only members of this residual family for which \(2\) has order at
most four are \(3,7,15\).  Away from them, the target volume is
\(3,4,5,6\) according as the prime translate differs by a power
\(2^0,2^{\pm1},2^{\pm2}\), or any remaining class.

The first shell proves the unconditional families
\[
p\equiv13\pmod{24}
\quad\text{or}\quad
p\equiv73,97,145\pmod{168}.
\]
The bounded checker compares the packet criterion with the original
divisor definitions on \(4062\) shells for the \(36\) resistant primes
below \(1000\), and all comparisons pass.

## Exact four-carrier residue sieve

The second binary shell at \(R=15\) proves
\[
p\equiv73,97\pmod{120},
\]
and the first ternary shell at \(R=11\) proves
\[
p\equiv73,85,109\pmod{132}.
\]
Together with the \(R=3\) and \(R=7\) first binary carriers, these
families define an exact sieve modulo
\[
9240=\operatorname{lcm}(24,5,7,11).
\]
Among the \(480\) reduced classes modulo \(9240\) satisfying
\(r\equiv1\pmod{12}\), the four carriers certify \(438\).  The
remaining \(42\) classes are characterized by
\[
r\equiv1\pmod{24},\qquad
r\bmod5\in\{1,4\},\qquad
r\bmod7\in\{1,2,4\},\qquad
r\bmod11\in\{1,2,3,4,5,6,9\}.
\]
Thus the exact certified fraction of eligible residue classes is
\[
\frac{438}{480}=\frac{73}{80}.
\]
The remainder count factors as \(1\cdot2\cdot3\cdot7=42\); subsequent
carriers can be studied directly on this smaller CRT box.

## \(R=23\) signed-two-power refinement

For the second every-third shell,
\[
b=k+2=\frac{p+23}{12},
\qquad
\mathcal T_{23,3}^{\mathrm M}
=\{\overline{15},\overline{20},\overline{22}\}.
\]
The signed powers \(2^{-1},1,2\) produce the nine prime classes
\[
\mathcal P_1
=
\{\overline7,\overline{10},\overline{11},
\overline{15},\overline{17},\overline{19},
\overline{20},\overline{21},\overline{22}\}.
\]
The five powers \(2^{-2},\ldots,2^2\) produce
\[
\mathcal P_2
=
U_{23}\setminus\langle\overline2\rangle,
\]
the eleven quadratic nonresidues modulo \(23\).  Consequently,
\[
p\equiv1\pmod{48},\quad p\bmod23\in\mathcal P_1
\]
or
\[
p\equiv25\pmod{48},\quad p\bmod23\in\mathcal P_2
\]
forces occupation of the \(R=23\) shell.

The prime \(2521\) has the exact witness
\[
b=212=4\cdot53,\qquad
2^{-2}\equiv6,\qquad
2521\cdot6\equiv15\pmod{23}.
\]

Refining the four-carrier sieve to modulus \(425040\) gives \(21120\)
eligible reduced classes, of which \(20112\) are certified.  Thus the
exact certified fraction is
\[
\frac{20112}{21120}=\frac{419}{440},
\]
and the explicit remainder contains \(1008\) classes.

## Fixed-factor morphism at \(R=23\)

For a prime \(\ell\ne23\), an exponent \(e\ge1\), and
\[
b=\frac{p+23}{12},
\]
the condition \(\ell^e\mid b\) inserts the signed interval
\(\ell^{-e},\ldots,\ell^e\) into the middle reachability box.  Its
corresponding prime-class packet is
\[
\mathcal P_{\ell,e}
=
\bigcup_{d=-e}^{e}
\overline\ell^{-d}\mathcal T_{23,3}^{\mathrm M}.
\]
Thus
\[
\ell^e\mid b,\qquad
\overline p\in\mathcal P_{\ell,e}
\quad\Longrightarrow\quad
q_{23,p}>0.
\]
The factor condition is equivalently
\[
p\equiv-23\pmod{12\ell^e}.
\]

At \(\ell=3\), \(e=1\),
\[
\mathcal P_{3,1}
=
\{\overline5,\overline{14},\overline{15},
\overline{20},\overline{22}\}.
\]
This supplies the new family
\[
p\equiv49\pmod{144},
\qquad
p\equiv5,14\pmod{23}.
\]
At modulus \(1275120\), the cumulative carrier set certifies
\[
\frac{60420}{63360}
=
\frac{1007}{1056}
\]
of the eligible reduced classes.

## Additive \(R=23\) reachability criterion

The class \(5\bmod23\) has order \(22\), giving the isomorphism
\[
\lambda:U_{23}\longrightarrow\mathbb Z/22\mathbb Z,
\qquad
\lambda(5)=1.
\]
The middle target packet has logarithmic coordinates
\[
\lambda(\{15,20,22\})=\{17,5,11\}.
\]
For
\[
b=\prod_{r\mid b}r^{\nu_r(b)},
\]
define
\[
\mathscr B_{23}(b)
=
\left\{
\sum_{r\mid b}d_r\lambda(r):
-\nu_r(b)\le d_r\le\nu_r(b)
\right\}.
\]
If \(\rho=\lambda(p)\) and \(\mathcal S=\{5,11,17\}\), then the exact
shell criterion is
\[
q_{23,p}>0
\quad\Longleftrightarrow\quad
\mathscr B_{23}(b)
\cap
\left(
\mathcal S\cup(\mathcal S-\rho)
\right)
\ne\varnothing.
\]
When \(p\) is a quadratic residue modulo \(23\), occupation therefore
requires \(b\) to possess at least one quadratic-nonresidue prime
factor modulo \(23\).  The checker verifies the additive criterion
against the original divisor channels for every resistant prime below
\(20001\).

The affine identity gives the sharper character relation
\[
b\equiv2p\pmod{23},
\qquad
\left(\frac b{23}\right)=\left(\frac p{23}\right),
\]
because \(2\equiv5^2\pmod{23}\).  Thus the number of nonresidue prime
factors of \(b\), counted with multiplicity, has the same parity as the
quadratic character of \(p\).  In the quadratic-residue branch,
occupation of the \(R=23\) shell consequently requires at least two
nonresidue prime-factor occurrences.

## First factor-seventeen carrier

At \(\ell=17\), the signed one-step packet is
\[
\mathcal P_{17,1}
=
\{2,4,6,9,12,15,18,20,22\}\pmod{23}.
\]
The congruence
\[
p\equiv181\pmod{204}
\]
is equivalent to \(17\mid(p+23)/12\).  It therefore certifies every
prime on that branch whose modulo-\(23\) class belongs to the displayed
packet.

The genuinely new modulo-\(23\) classes in the preceding remainder are
\[
2,4,6,9,12,18.
\]
At modulus
\[
21677040=17\cdot1275120,
\]
the exact admissible and certified counts are
\[
1013760,\qquad968232,
\]
respectively.  The certified fraction is
\[
\frac{40343}{42240},
\]
and \(45528\) classes remain.

## Complete \(R=23\) edge-log classification

For the two edge logarithms
\[
\rho=\lambda(p)\in\{1,21\},
\]
negation symmetry gives the common effective forbidden set
\[
\mathcal F
=
\{4,5,6,10,11,12,16,17,18\}
\subset\mathbb Z/22\mathbb Z.
\]
The allowed nonzero one-term logarithms are
\[
\{\pm1,\pm2,\pm3,\pm7,\pm8,\pm9\}.
\]
The safe three-term multisets consist exactly of the four sign
multisets drawn from \(\{\pm1\}\) and the four drawn from
\(\{\pm7\}\).  No four-term multiset of nonzero logarithms is safe.

Writing \(\mathfrak L_{23}^{\times}(b)\) for the prime-log multiset of
\(b=(p+23)/12\) after zero logarithms are deleted, the shell is empty
exactly for
\[
\begin{array}{c|c}
\rho&\mathfrak L_{23}^{\times}(b)\\ \hline
1&\{3\},\{1,2\},\{1,1,1\}\\
21&\{1\},\{2,21\},\{8,15\},\{1,1,21\},\{15,15,15\}.
\end{array}
\]
Equivalently, the prime-factor residue multisets are
\[
\begin{array}{c|c}
p\bmod23&\text{non-\(1\) residue multiset}\\ \hline
5&\{10\},\{5,2\},\{5,5,5\}\\
14&\{5\},\{2,14\},\{16,19\},\{5,5,14\},\{19,19,19\}.
\end{array}
\]
Thus four prime-factor occurrences outside \(1\bmod23\) force
occupation.  The finite checker verifies the complete signed-box
classification and its equivalence with the original divisor-channel
criterion for bounded resistant primes.

## Exact two-adic survivor form at \(R=23\)

On the branch
\[
p\equiv1\pmod{48},
\qquad
p\equiv5\ \text{or}\ 14\pmod{23},
\]
write \(b=(p+23)/12\).  Then \(b\equiv2\pmod4\), so the prime-log
multiset contains exactly one occurrence of
\(\lambda(2)=2\).  Inspection of the complete edge table leaves one
pattern on each branch:
\[
\rho=1:\ \{1,2\},
\qquad
\rho=21:\ \{2,21\}.
\]
Hence
\[
q_{23,p}=0
\quad\Longleftrightarrow\quad
b=2\ell u,
\]
where \(\ell\) is a prime occurring once,
\(\ell\equiv p\pmod{23}\), and every prime divisor of \(u\) is
congruent to \(1\pmod{23}\).  The bounded checker verifies this
equivalence against the original divisor-channel criterion.

## Adjacent-shell isolation of an \(R=23\) edge survivor

For an empty edge shell with \(p\equiv1\pmod{48}\), write
\[
b=2\ell u,\qquad c=b-1.
\]
The first six reduced affine coordinates become
\[
\left(
a_3,a_7,\frac{a_{11}}3,a_{15},a_{19},\frac{a_{23}}3
\right)
=
\left(
6\ell u-5,\,
2(3\ell u-2),\,
2\ell u-1,\,
2(3\ell u-1),\,
6\ell u-1,\,
2\ell u
\right).
\]
Their gcds with \(b\) are
\[
\begin{array}{c|ccccc}
x&a_3&a_7&a_{11}/3&a_{15}&a_{19}\\ \hline
\gcd(b,x)&\gcd(b,5)&2&1&2&1.
\end{array}
\]
It follows that \(u\) is coprime to all five preceding coordinates.
The distinguished prime \(\ell\) is also isolated from them, except
that \(\ell=5\) may occur in \(a_3\).  Thus the next complementarity
argument must use the affine relations among the shell coordinates;
common prime-factor inheritance supplies no general bridge.

## Exact first-six intersection on an \(R=23\) edge branch

For
\[
p\equiv1\pmod{48},
\qquad
p\equiv5\ \text{or}\ 14\pmod{23},
\]
an empty \(R=23\) shell has
\[
b=2\ell u,
\]
with the distinguished prime and the \(1\pmod{23}\) tail described in
the two-adic survivor theorem.  Substitution into the first-four
classification removes one alternative at each of \(R=7\) and
\(R=15\): the mandatory prime factor \(2\) belongs to neither
\(\{1,3\}\pmod7\) nor \(\{1,4,7,13\}\pmod{15}\).  Consequently the
first six shells are empty exactly when the two-adic factorization is
accompanied by

- prime factors of \(6\ell u-5\) lying in \(1\pmod3\);
- prime factors of \(3\ell u-2\) lying in
  \(\{1,2,4\}\pmod7\);
- \(\mathfrak m_{11}(2\ell u-1)\notin J_{11}^{(1)}\);
- prime factors of \(3\ell u-1\) lying in
  \(\{1,2,4,8\}\pmod{15}\);
- \(\mathfrak m_{19}^{\log}(6\ell u-1)\notin I_{19}^{\log}\).

The bounded checker verifies the complete equivalence on all
two-adic edge survivors below \(20001\).

## Exact residual-\(19\) factor-log ideal

The group \(U_{19}\) is cyclic of order \(18\), generated by \(2\).
In primitive-log coordinates the exterior target is \(7\) and the
middle target is \(9\):
\[
-4^{-1}\equiv14\equiv2^7\pmod{19},
\qquad
-1\equiv18\equiv2^9\pmod{19}.
\]
The minimal occupied prime-log multisets form an exact antichain of
\(174\) elements with degree profile
\[
\begin{array}{c|rrrrrrrrr}
d&1&2&3&4&5&6&7&8&9\\ \hline
\#&2&32&91&30&9&5&3&1&1.
\end{array}
\]
The complete canonical list has SHA--256
d2b4644e85c20abe36ad943b8e5b5bbd659d758f3ed1bbd9dc7307f418ae4d01.
Its degree-one members are \((7)\) and \((9)\), corresponding to
prime-factor residues \(14\) and \(18\pmod{19}\); the maintained
theorem displays all thirty-two degree-two members.

The finite certificate checks the complete antichain through the
Davenport bound \(17\), the low-degree tables, and agreement with the
original exterior and middle divisor definitions for \(2843\)
coprime integers and \(555\) affine prime shells.  It also records the
late edge survivor
\[
p=53089,\qquad
\frac{p+23}{12}=2\cdot2213,\qquad
a_{19}=11\cdot17\cdot71.
\]
Since \(71\equiv14\pmod{19}\), this shell is occupied by the
degree-one log-\(7\) carrier.

## Exact complement branches for the first residual-\(11\) colon

The thirteen irredundant generators of \(J_{11}^{(1)}\) give a
complete factor-level description of its complement.  For an integer
\(c\) coprime to \(11\), one has
\[
\mathfrak m_{11}(c)\notin J_{11}^{(1)}
\]
exactly on two disjoint branches:

1. every prime factor of \(c\) lies in
   \(\{1,3,4,5,9\}\pmod{11}\);
2. every prime factor outside class \(1\) is a single class-\(2\)
   prime and/or a single class-\(6\) prime, each occurring to the
   first power.

On a two-adic \(R=23\) survivor put \(x=\ell u\) and
\(c=2x-1\).  Since \(a_{11}=3c\), the exact edge criterion splits as
follows.  If \(x\equiv2\pmod3\), the remaining integer is \(c/3\),
and all of its prime factors must lie in
\(\{1,3,4,5,9\}\pmod{11}\).  If \(x\not\equiv2\pmod3\), the integer
\(c\) must lie in one of the two branches above.  The independent
checker verifies the complement on \(2728\) coprime integers and the
edge split on fourteen applicable prime shells.

## Pairwise-coprime five-Finger carrier on the three-adic edge

Use the ordered Finger labels
\[
(\mathrm t,\mathrm i,\mathrm m,\mathrm r,\mathrm p)
\]
for thumb, index, middle (or long), ring, and pinky.  On the
three-adic residual-\(11\) branch put
\[
d=\frac{2x-1}{3}.
\]
Then \(d\) is odd and
\[
p=36d-11,
\qquad
(a_3,a_7,a_{11},a_{15},a_{19})
=(9d-2,9d-1,9d,9d+1,9d+2).
\]
After dividing only by the factors forced by the edge equations, the
five coordinates become
\[
(F_{\mathrm t},F_{\mathrm i},F_{\mathrm m},F_{\mathrm r},F_{\mathrm p})
=
\left(
9d-2,\frac{9d-1}{2},d,\frac{9d+1}{2},9d+2
\right).
\]
They are pairwise coprime.  Four adjacent Bezout relations have
right-hand side one; the remaining six have right-hand sides
\(2,3,4,1,3,2\), and parity together with
\(F_{\mathrm t}\equiv F_{\mathrm i}\equiv1\pmod3\) removes every
remaining common divisor.

Thus each prime factor belongs to exactly one Finger.  The first-six
intersection problem on this branch is an affine coupling of five
disjoint factor supports rather than a problem of common-factor
inheritance.  The maintained checker verifies the exact identities
and all ten gcds for \(5000\) odd centers and four applicable affine
edge primes below \(20000\).

### Exact Finger factor intersection

Under the retained residual-\(23\) edge conditions, all six shells
at residuals \(3,7,11,15,19,23\) are empty exactly when

- every prime factor of \(F_{\mathrm t}\) is \(1\pmod3\);
- every prime factor of \(F_{\mathrm i}\) lies in
  \(\{1,2,4\}\pmod7\);
- every prime factor of \(F_{\mathrm m}\) lies in
  \(\{1,3,4,5,9\}\pmod{11}\);
- every prime factor of \(F_{\mathrm r}\) lies in
  \(\{1,2,4,8\}\pmod{15}\);
- the residual-\(19\) factor-log monomial of \(F_{\mathrm p}\) lies
  outside \(I_{19}^{\log}\).

This statement is the exact five-coordinate factor-monoid form of the
remaining edge obstruction.

### Fixed five-shell evaluation volume

For \(A_j=9d-2+j\), \(0\le j\le4\), the ordered Vandermonde matrix
has
\[
\det(A_j^k)_{0\le k,j\le4}=288=2^5 3^2.
\]
The polynomial with roots \(A_0,\ldots,A_4\) therefore has
discriminant
\[
82944=2^{10}3^4.
\]
Translation of the center \(9d\) leaves both invariants fixed.  This
is an exact evaluation-volume carrier behind the prime-support
separation: no prime at least \(5\) can divide two shell coordinates.

### Sixty-class character shadow

The first four Finger factor restrictions, together with the
residual-\(23\) edge congruences, imply
\[
\begin{aligned}
d&\equiv3\pmod4,&
d&\equiv3,9\pmod{23},\\
d&\equiv1,5,6\pmod7,&
d&\equiv1,3,4,5,9\pmod{11},\\
d&\equiv0,2\pmod5.
\end{aligned}
\]
These are exactly sixty classes modulo \(35420\), with density
\(3/1771\).  Their affine images \(p=36d-11\) are sixty distinct
classes modulo \(1275120\).

For each of the sixty classes \(r\), the progression
\(r+35420\mathbb Z\) maps bijectively to
\(\mathbb Z/19\mathbb Z\).  Therefore \(F_{\mathrm p}=9d+2\) also
runs through all residual-\(19\) classes on every progression.  Any
argument forcing residual-\(19\) occupancy must use the full factor
data or the residual-\(23\) distinguished-prime structure; the sixty
product classes alone carry no residual-\(19\) restriction.

### Multiquadratic split-support lift

The first four Finger conditions are the splitting kernels for
\[
\mathbb Q(\sqrt{-3}),\quad
\mathbb Q(\sqrt{-7}),\quad
\mathbb Q(\sqrt{-11}),\quad
\mathbb Q(\sqrt{-15}).
\]
For an integer \(n\) supported on split primes in one of these
fields, independently selecting one of the two conjugate prime ideals
above each \(q\mid n\) gives an ideal of norm \(n\).  The complete
fiber is a torsor under \(C_2^{\omega(n)}\).  Pairwise coprimality of
the Fingers therefore gives a four-field carrier under
\[
C_2^{\omega(F_{\mathrm t}F_{\mathrm i}F_{\mathrm m}F_{\mathrm r})}.
\]

The analogous split-support monoid for
\(\mathbb Q(\sqrt{-19})\) is an exact residual-\(19\) safe face.  Its
prime residues have even primitive logs, whereas the exterior and
middle targets are the odd logs \(7\) and \(9\).  Therefore
\[
F_{\mathrm p}\in\mathcal S_{19}
\Longrightarrow
q_{19,p}=0.
\]
The simultaneous five-field split-support system is a concrete
subsystem that a residual-\(19\) forcing argument must exclude using
the residual-\(23\) factorization or stronger affine reciprocity.
## Exact long five-Finger survivor and residual-31 closure

The targeted three-adic \(R=23\) edge scan produced the exact row
\[
p=415969,\qquad d=11555,
\]
\[
(F_{\mathrm t},F_{\mathrm i},F_{\mathrm m},
F_{\mathrm r},F_{\mathrm p})
=(103993,51997,11555,51998,103997).
\]
The seven admissible residuals through \(27\) are empty:
\[
q_{R,p}=0
\qquad
(R=3,7,11,15,19,23,27).
\]
The next shell closes the row:
\[
a_{31}=104000=2^6\cdot5^3\cdot13,
\qquad
q_{31,p}=10.
\]
Its exterior endpoint set is
\[
\{5200,166400,650000,20800000\},
\]
and its middle endpoint set has twelve elements.  The least exterior
seed \(u=5200\) maps through
\[
(j,u)\longmapsto D=p^ju
\]
at \(j=2\) to
\[
D=899757086597200,
\qquad
N=43260776000,
\qquad
N^2/D=2080000.
\]
The reconstructed identity is
\[
\frac4{415969}
=
\frac1{104000}
+
\frac1{29025817657200}
+
\frac1{1395576000}.
\]

The pinky Finger \(103997\) is an inert prime modulo \(19\), with
primitive logarithm \(17\) to base \(2\).  It therefore proves that
the residual-\(19\) split-support face is sufficient for emptiness
but does not exhaust the empty-shell locus.  The maintained checker
verification/verify_five_finger_first_six_survivor.py verifies the
complete chain and records the exact endpoint sets.  The companion
checker verification/verify_five_finger_split_face_scan.py reproduces
the bounded scan and the uniqueness statement below two million.

### Residual-31 exterior progression

The certificate extends to every prime
\[
p\equiv14209\pmod{22320}.
\]
Equivalently, its five-Finger center satisfies
\[
d=\frac{p+11}{36}\equiv395\pmod{620}.
\]
Then
\[
a_{31}=\frac{p+31}{4},
\qquad
u=\frac{a_{31}}{20}
\]
are integers and \(31\mid4u+1\).  The exact family is
\[
\frac4p
=
\frac{1}{(p+31)/4}
+
\frac{1}{p(p+31)(p+20)/2480}
+
\frac{1}{(p+31)(p+20)/124}.
\]
Thus the observed \(p=415969\) closure is a member of a complete
prime progression rather than an isolated divisor certificate.

## All-five split-support face and residual-27 closure

An exact scan of the sixty three-adic edge-candidate classes modulo
\(35420\), followed by the direct residual-\(23\) endpoint test,
finds below \(p=20000000\):
\[
147\text{ empty }R=23\text{ edge rows},\qquad
25\text{ first-four split rows},\qquad
10\text{ all-five split rows}.
\]
Class membership alone does not force the \(R=23\) shell to be empty:
\(p=3878449\), \(d=107735\) is an explicit occupied candidate.

The least all-five split-supported row is
\[
p=3368401,\qquad d=93567,
\]
\[
(F_{\mathrm t},F_{\mathrm i},F_{\mathrm m},
F_{\mathrm r},F_{\mathrm p})
=(842101,421051,93567,421052,842105).
\]
All shells \(R=3,7,11,15,19,23\) are empty.  At \(R=27\),
\[
a=842107=7\cdot59\cdot2039,
\]
\[
\mathcal E_{27,a}=\{49684313\}=\{59a\},
\qquad
\mathcal M_{27,a}=\varnothing,
\qquad
q_{27,p}=1.
\]
The unique endpoint gives
\[
\frac4{3368401}
=
\frac1{842107}
+
\frac1{20878683089630846060}
+
\frac1{105057558340}.
\]

### Residual-27 exterior progression

For every prime
\[
p\equiv3985\pmod{6372},
\]
the quantities
\[
a=\frac{p+27}{4},
\qquad
u=59a
\]
satisfy \(u\mid a^2\) and \(27\mid4u+1\).  Hence
\[
\frac4p
=
\frac1{(p+27)/4}
+
\frac1{p(p+27)(59p+1)/108}
+
\frac1{(p+27)(59p+1)/6372}.
\]
The maintained checker
verification/verify_five_finger_all_split_first_row.py and its
captured receipt reproduce the bounded classification, Pocklington
certificate, endpoint sets, denominator reconstruction, and the
full progression.

## Eight endpoint progressions covering the certified bounded all-five face

Two exact reconstruction maps organize the calculation.  For
\(a=(p+R)/4\), \(N=pa\), and \(u\mid a^2\), an exterior endpoint
\(R\mid4u+1\) gives
\[
(a,b,c)
=
\left(
a,\frac{p(a+pu)}R,\frac{pa+a^2/u}R
\right),
\]
whereas a middle endpoint \(R\mid a+u\) gives
\[
(a,b,c)
=
\left(
a,\frac{p(a+u)}R,\frac{p(a+a^2/u)}R
\right).
\]

The ten all-five split-supported rows certified below
\(p=20000000\) are covered by eight exact endpoint progressions:
\[
\begin{array}{c|c|c|c|c}
X&R&\text{endpoint}&u&p\\ \hline
A&27&\mathcal E&59a&3985+6372t\\
B&39&\mathcal M&2&889+936t\\
C&27&\mathcal E&317&2509+11412t\\
D&31&\mathcal M&16&1393+4464t\\
E&31&\mathcal E&116&1825+2088t\\
F&31&\mathcal M&1352&39697+58032t\\
G&27&\mathcal E&a^2/4913&25405+31212t\\
H&31&\mathcal M&200&4129+22320t.
\end{array}
\]
Every initial residue is \(25\pmod{36}\), and every modulus is a
multiple of \(36\).  Thus every family stays in the five-Finger prime
class.  The exact bounded memberships are
\[
\begin{gathered}
p_A(528)=3368401,\quad
p_B(5505)=5153569,\quad
p_C(501)=5719921,\\
p_D(1629)=7273249,\quad
p_D(2687)=11996161,\quad
p_D(3554)=15866449,\\
p_E(4562)=9527281,\quad
p_E(7598)=15866449,\quad
p_F(232)=13503121,\\
p_G(567)=17722609,\quad
p_H(802)=17904769.
\end{gathered}
\]
The overlap at \(p=15866449\) supplies both a middle \(R=31\)
certificate and an exterior \(R=31\) certificate.

The checker
verification/verify_five_finger_all_split_progression_cover.py and
its captured receipt verify the union, every bounded membership, and
five exact parameter values in each family.  This is a bounded cover.
The unresolved global question is whether every all-five
split-supported row must enter a finite collection of endpoint
progressions.

## Fixed endpoint seeds and the first row outside the eight-family cover

For
\[
u=\prod_\ell\ell^{e_\ell},
\qquad
\kappa(u)=\prod_\ell\ell^{\lceil e_\ell/2\rceil},
\]
the condition \(u\mid a^2\) is equivalent to
\(\kappa(u)\mid a\).  Consequently an exterior fixed seed with
\(R\mid4u+1\) is carried by the CRT system
\[
p\equiv25\pmod{36},
\qquad
p\equiv-R\pmod{4\kappa(u)}.
\]
A middle fixed seed is carried by
\[
p\equiv25\pmod{36},
\qquad
p\equiv-R\pmod{4\kappa(u)},
\qquad
p\equiv-R-4u\pmod{4R}.
\]
Every compatible system is one residue class modulo the least common
multiple of its displayed moduli.  This also shows why an arbitrary
finite list of certified rows always admits a finite fixed-seed
progression cover.  A global theorem requires a seed set or
parameterized seed laws independent of the search bound.

The exact extension to \(p<100000000\) gives
\[
519\text{ empty }R=23\text{ rows},
\qquad
29\text{ all-five rows}.
\]
Thirteen of the \(29\) lie in the eight families \(A\)--\(H\); sixteen
do not.  The least row outside those families is
\[
p=25371889,\qquad d=704775,
\]
\[
a=6342979=19\cdot47\cdot7103,
\]
with
\[
\mathcal E_{27,a}=\{47,2564183\},
\qquad
\mathcal M_{27,a}=\varnothing.
\]

The small endpoint \(u=47\) gives a ninth exact family:
\[
p\equiv349\pmod{1692},
\]
\[
\frac4p
=
\frac1{(p+27)/4}
+
\frac1{p(7p+1)/4}
+
\frac1{(p+27)(7p+1)/752}.
\]
The least row above is the member with \(t=14995\):
\[
\frac4{25371889}
=
\frac1{6342979}
+
\frac1{1126532321342534}
+
\frac1{5992199575342}.
\]

The maintained extended scanner and receipt certify all finite counts,
the least row, its Pocklington certificate and endpoint sets, and the
new progression.

## Exterior endpoint--origin transpose and fixed origin carriers

Every exterior endpoint has unique squarefree coordinates
\[
u=st^2,\qquad a=stm,
\]
and its complementary origin carrier is
\[
v=\frac{a^2}{u}=sm^2.
\]
The corresponding \(j=2\) and \(j=0\) divisor certificates are
\[
D_2=p^2u,\qquad D_0=v,\qquad D_2D_0=(pa)^2.
\]
Their ordered reconstructions are
\[
(b_2,c_2)
=
\left(
\frac{pst(m+pt)}R,
\frac{sm(pt+m)}R
\right)
\]
and
\[
(b_0,c_0)
=
\left(
\frac{sm(pt+m)}R,
\frac{pst(m+pt)}R
\right).
\]
Hence
\[
(b_0,c_0)=(c_2,b_2).
\]
This is the exact ordered arithmetic transpose to be compared with the
two maintained blade channels.

For a fixed origin carrier \(v=sm^2\), define
\[
L_R=\operatorname{lcm}(R,9),\qquad B_R=\frac{R+25}{4},
\]
\[
\mathscr T_{R;v}
=
\left\{
\overline t\in\mathbb Z/L_R\mathbb Z:
4st^2+1\equiv0\pmod R,\ 
smt\equiv B_R\pmod9
\right\}.
\]
Every class \(t=t_0+L_Rn\) gives
\[
p=4smt-R.
\]
Each prime \(p>R\) in such a class lies in the five-Finger prime
class and has endpoint--origin pair
\[
(u,v)=(st^2,sm^2).
\]
Conversely, every five-Finger exterior orbit with origin carrier \(v\)
arises this way.  The residual equation is
\[
4st^2\equiv-1\pmod R
\quad\Longleftrightarrow\quad
(2st)^2\equiv-s\pmod R.
\]
Thus residual solvability depends on the squarefree carrier \(s\);
the branch length \(m\) governs the modulo-\(9\) condition and the
resulting prime progression.

At \(R=27\), two sparse rows are:
\[
v=251,\quad (s,m)=(251,1),\quad
\mathscr T_{27;251}=\{\overline{23}\},\quad
p=23065+27108n,
\]
containing \(p=25558801\) at \(n=942\); and
\[
v=2878829=149\cdot139^2,\quad
(s,m)=(149,139),\quad
\mathscr T_{27;2878829}=\{\overline{11}\},\quad
p=911257+2236788n,
\]
containing \(p=41173441\) at \(n=18\).

The checker
verification/verify_five_finger_origin_carrier_progressions.py and its
receipt verify the complete residue sets, five parameters in both
families, both exact transposes, and both integer certificates.

## Infinite five-Finger prime families on every residual

For every positive integer \(R\equiv3\pmod4\), choose a prime
\(s\neq3\) satisfying
\[
4s+1\equiv0\pmod R
\]
and choose \(m>0\) with
\[
sm\equiv\frac{R+25}{4}\pmod9,
\qquad
\gcd(m,R)=1.
\]
With \(L_R=\operatorname{lcm}(R,9)\), the progression
\[
p_n=4sm(1+L_Rn)-R
\]
is primitive.  Every prime value \(p_n>R\) lies in the class
\(25\bmod36\) and has
\[
a_n=sm(1+L_Rn),
\qquad
u_n=s(1+L_Rn)^2\in\mathcal E_{R,a_n}.
\]
Dirichlet's theorem supplies infinitely many such prime values.

The maintained checker verifies representative primitive
constructions for
\[
R=27,31,35,39,55.
\]
This proves infinite supported prime families on every admissible
residual.  It leaves open the incidence of an arbitrary five-Finger
prime with the union of all carrier progressions.

## Residual-free carrier incidence

For a prime \(p\equiv1\pmod4\), the exterior channel is equivalent to
the existence of positive integers \(k,s,t,h\), with \(s\) squarefree,
such that
\[
kp+1=4sth,
\qquad
k\mid t+h,
\qquad
t<2h.
\]
The inverse map is
\[
m=\frac{t+h}{k},
\qquad
a=stm,
\qquad
R=4stm-p.
\]

The middle channel is equivalent to the existence of positive
integers \(\ell,s,t,m\), with \(s\) squarefree, such that
\[
(4\ell st-1)(4\ell sm-1)=4\ell^2sp+1,
\]
The inverse map is
\[
a=stm,
\qquad
R=4stm-p,
\qquad
t+m=\ell R.
\]
The exterior equations already give
\(R=(4st^2+1)/k>0\); the upper denominator bound is equivalent to
\(t<2h\).  The middle factor equation alone gives \(R>0\) and
\(R\le p\), hence \(p<4a\le2p\).  Thus neither channel requires a
separate interval hypothesis.

The exact prime windows are
\[
4st(m-t)-1\le p<4smt\le3p
\]
for the exterior channel and
\[
4smt-(t+m)\le p<4smt\le2p
\]
for the middle channel.

The maintained checker verifies all \(1504\) exterior coordinates and
all \(1366\) middle divisor coordinates occurring for primes through
\(1000\), plus converse examples in both channels.  The resulting
primewise problem is exact: at least one of the directed three-factor
system and the exchanged two-factor system must have a solution.

### Exterior divisor-carrier parametrization

The exterior channel has the equivalent divisor form
\[
k\mid4st^2+1,
\qquad
4st\mid kp+1,
\]
with \(s\) squarefree.  Put
\[
h=\frac{kp+1}{4st}.
\]
The shell condition is exactly \(t<2h\), and the inverse map is
\[
R=\frac{4st^2+1}{k},
\qquad
m=\frac{t+h}{k},
\qquad
a=stm.
\]
The two divisibilities imply
\[
4sth\equiv1\pmod k,
\qquad
4st(-t)\equiv1\pmod k.
\]
Since \(k\) is coprime to \(4st\), this gives \(h\equiv-t\pmod k\),
so \(m\) is integral.  The ordered denominator triple is
\[
\frac4p
=
\frac1{stm}
+
\frac1{psth}
+
\frac1{smh}.
\]
The maintained checker verifies the two divisor quotients, the inverse
coordinates, and this identity on all \(1504\) exterior coordinates
through prime \(1000\).

### One-leg factor-residue criterion

For every \(k\equiv3\pmod4\), put
\[
N_k(p)=\frac{kp+1}{4}.
\]
If \(N_k(p)\) has a squarefree divisor \(s\) satisfying
\[
k\mid4s+1,
\]
then
\[
h=\frac{N_k(p)}s,
\qquad
m=\frac{h+1}{k},
\qquad
R=\frac{4s+1}{k},
\qquad
a=sm
\]
are positive integers and
\[
s\in\mathcal E_{R,a},
\qquad
p<4a\le2p.
\]
The proof is the \(t=1\) specialization of the exterior incidence
theorem: \(4s\equiv-1\pmod k\) and \(4sh=kp+1\) give
\(h\equiv-1\pmod k\), while \(s\le N_k(p)\) gives \(R\le p\).
Thus a counterexample must avoid every such squarefree divisor for
every \(k\equiv3\pmod4\).

For the \(2374\) hard primes below \(100000\), the maintained checker
finds an exact one-leg certificate for \(2369\) using \(k\le255\).
The five bounded-search survivors are
\[
241,1249,6481,21169,43969.
\]

### Middle divisor-carrier parametrization

The middle channel has the equivalent divisor form
\[
q=4\ell st-1,
\qquad
q\mid p+4st^2,
\]
with \(s\) squarefree.  The inverse map is
\[
R=\frac{p+4st^2}{q},
\qquad
m=\ell R-t,
\qquad
a=stm.
\]
It gives the middle orbit \(\{st^2,sm^2\}\) and the exact identity
\[
\frac4p
=
\frac1{stm}
+
\frac1{p\ell st}
+
\frac1{p\ell sm}.
\]
Equivalently,
\[
q\mid\ell p+t,
\qquad
m=\frac{\ell p+t}{q}.
\]
The proof uses
\[
qR=p+4st^2,
\qquad
t+m=\ell R.
\]
The maintained checker verifies this divisor map on all \(1366\)
middle coordinates through prime \(1000\).

For \(t=1\), the five survivors of the bounded exterior one-leg scan
have data
\[
\begin{array}{c|rrrrrr}
p&\ell&q&s&m&R&a\\ \hline
241&1&11&3&22&23&66\\
1249&2&7&1&357&179&357\\
6481&1&7&2&926&927&1852\\
21169&5&39&2&2714&543&5428\\
43969&24&1631&17&647&27&10999.
\end{array}
\]
Thus the exterior and middle one-leg criteria together cover all
\(2374\) hard primes below \(100000\) within the recorded parameter
bounds.

### Integral determinant flags

The exterior divisor carrier is equivalent to the coupled pair
\[
E_p=
\begin{pmatrix}
4st&k\\ p&h
\end{pmatrix},
\qquad
E_R=
\begin{pmatrix}
k&4st\\ t&R
\end{pmatrix},
\qquad
\det E_p=\det E_R=1.
\]
The two determinant-one equations force
\[
h\equiv-t\pmod k,
\]
which is precisely the gluing needed for \(m=(t+h)/k\).

For the middle carrier, put \(q=4\ell st-1\) and
\(m=\ell R-t\).  Then
\[
M_1=
\begin{pmatrix}
4st&q\\1&\ell
\end{pmatrix},
\quad
M_p=
\begin{pmatrix}
q&4st\\t&R
\end{pmatrix},
\quad
M_t=
\begin{pmatrix}
q&\ell\\p&m
\end{pmatrix}
\]
satisfy
\[
\det M_1=1,
\qquad
\det M_p=p,
\qquad
\det M_t=t.
\]
Conversely, the first two determinant equations recover the complete
middle divisor carrier.  These statements are checked on all \(1504\)
exterior and \(1366\) middle coordinates through prime \(1000\).

### Determinant flags and ordered blade channels

For any invertible ordered carrier basis
\[
A=\begin{pmatrix}a&b\\c&d\end{pmatrix},
\]
the two raw blade channels transport as
\[
\mathscr N_{-+}(A)=AE_{21}A^{-1},
\qquad
\mathscr N_{+-}(A)=AE_{12}A^{-1}.
\]
They preserve the exact input/output signs and source/range corners
after conjugating \(J,E_{11},E_{22}\) by \(A\).

If \(A\) is integral with positive determinant
\(\Delta=ad-bc\), the integral channels are
\[
\mathscr B_{-+}(A)
=
\Delta AE_{21}A^{-1}
=
\begin{pmatrix}bd&-b^2\\d^2&-bd\end{pmatrix},
\]
\[
\mathscr B_{+-}(A)
=
\Delta AE_{12}A^{-1}
=
\begin{pmatrix}-ac&a^2\\-c^2&ac\end{pmatrix}.
\]
The first depends only on the second carrier column and the second
depends only on the first.

The exact carrier metric is
\[
G_A=(A^{-1})^{\mathsf T}A^{-1}.
\]
Relative to this metric the two channels are adjoints:
\[
\mathscr B_{-+}(A)^{\dagger_A}
=
\mathscr B_{+-}(A).
\]
Ordinary transposition identifies them exactly when
\[
A^{\mathsf T}A=|\det A|I_2.
\]
All five positive arithmetic determinant matrices fail this equality,
so the ordered arithmetic channels remain distinct.

Their orientation is forced by
\[
\frac db-\frac ca=\frac{\det A}{ab}>0.
\]
For the two exterior flags and three middle flags this yields,
respectively,
\[
\frac hk-\frac{p}{4st}=\frac1{4stk},
\qquad
\frac R{4st}-\frac tk=\frac1{4stk},
\]
\[
\frac\ell q-\frac1{4st}=\frac1{4stq},
\qquad
\frac R{4st}-\frac tq=\frac p{4stq},
\qquad
\frac m\ell-\frac pq=\frac t{q\ell}.
\]
The maintained checker verifies every sign, corner, action, adjoint,
transpose, and slope identity on all carrier coordinates through prime
\(1000\).

### Shared-column blade equality and the split reverse defect

For
\[
A_x=\begin{pmatrix}x&b\\c&d\end{pmatrix},
\qquad
A_y=\begin{pmatrix}y&b\\c&d\end{pmatrix},
\qquad
\delta=y-x,
\]
the shared second column forces
\[
\mathscr B_{-+}(A_x)=\mathscr B_{-+}(A_y).
\]
The reverse-channel difference is
\[
\mathscr D_{x,y}
=
\mathscr B_{+-}(A_y)-\mathscr B_{+-}(A_x)
=
\delta
\begin{pmatrix}
-c&x+y\\
0&c
\end{pmatrix}.
\]
It has the exact invariants
\[
\operatorname{tr}\mathscr D_{x,y}=0,
\qquad
\det\mathscr D_{x,y}=-\delta^2c^2,
\qquad
\mathscr D_{x,y}^2=\delta^2c^2I_2.
\]
For \(\delta\neq0\), the involution and its two spectral support
idempotents are
\[
\Theta_{x,y}
=
\frac{\mathscr D_{x,y}}{\delta c},
\qquad
\Pi_{\pm,x,y}
=
\frac12(I_2\pm\Theta_{x,y}).
\]
They satisfy
\[
\Theta_{x,y}^2=I_2,
\quad
\Pi_{\pm,x,y}^2=\Pi_{\pm,x,y},
\quad
\Pi_{-,x,y}\Pi_{+,x,y}
=
\Pi_{+,x,y}\Pi_{-,x,y}=0,
\quad
\Pi_{-,x,y}+\Pi_{+,x,y}=I_2.
\]
Thus the exact matrix route from the ordered blade difference to a
two-support system is
\[
(\mathscr B_{+-}(A_x),\mathscr B_{+-}(A_y))
\longmapsto
\mathscr D_{x,y}
\longmapsto
\Theta_{x,y}
\longmapsto
(\Pi_{-,x,y},\Pi_{+,x,y}).
\]

For a divisor coordinate lying in both the exterior and middle
carriers,
\[
E_R=\begin{pmatrix}k&4st\\t&R\end{pmatrix},
\qquad
M_p=\begin{pmatrix}q&4st\\t&R\end{pmatrix},
\qquad
q-k=\frac{p-1}{R}.
\]
The common directed blade is
\[
\mathscr B_{-+}(E_R)
=
\mathscr B_{-+}(M_p),
\]
while
\[
\mathscr B_{+-}(M_p)-\mathscr B_{+-}(E_R)
=
\frac{p-1}{R}
\begin{pmatrix}
-t&q+k\\
0&t
\end{pmatrix}.
\]
The overlap criterion is exact:
\[
R\mid4st^2+1
\quad\Longrightarrow\quad
\bigl(R\mid st^2+a\bigr)
\Longleftrightarrow
\bigl(R\mid p-1\bigr).
\]
The checker finds \(236\) such overlap coordinates through prime
\(1000\), and verifies the blade equality, split defect, eigenlines,
and support idempotents on every one.  The first is
\[
(p,a,R,s,t,m,k,q)=(13,4,3,2,1,2,3,7).
\]

The half-period comparison is exact.  On
\[
V_0=\operatorname{span}_{\mathbb R}\{\mathbf 1,g_0\},
\qquad
g_0=\mathbf 1_{[0,1/2)}-\mathbf 1_{[1/2,1)},
\]
the half-period translation \(T\) satisfies
\[
T\mathbf 1=\mathbf 1,
\qquad
Tg_0=-g_0.
\]
Define
\[
\Phi_{x,y,c}
\begin{pmatrix}z_1\\z_2\end{pmatrix}
=
\frac{z_2}{2c}\mathbf 1
+
\left(
z_1-\frac{x+y}{2c}z_2
\right)g_0.
\]
Then
\[
\Phi_{x,y,c}\Theta_{x,y}=T\Phi_{x,y,c},
\]
and
\[
\Phi_{x,y,c}\Pi_{-,x,y}
=
\frac12(I-T)\Phi_{x,y,c},
\qquad
\Phi_{x,y,c}\Pi_{+,x,y}
=
\frac12(I+T)\Phi_{x,y,c}.
\]
Thus the negative carrier support is carried to
\(\mathbb Rg_0\), while the positive carrier support is carried to
\(\mathbb R\mathbf 1\).

In matrix form,
\[
F_{x,y,c}
=
\begin{pmatrix}
0&\frac1{2c}\\
1&-\frac{x+y}{2c}
\end{pmatrix},
\qquad
F_{x,y,c}\Theta_{x,y}=JF_{x,y,c}.
\]
Composing with the maintained Hadamard map gives
\[
C_{x,y,c}=HF_{x,y,c},
\qquad
C_{x,y,c}\Theta_{x,y}=SC_{x,y,c},
\]
\[
C_{x,y,c}\Pi_{\pm,x,y}=P_\pm C_{x,y,c},
\qquad
C_{x,y,c}\mathscr D_{x,y}C_{x,y,c}^{-1}
=
\delta c\,S.
\]
This is the explicit intertwiner from the arithmetic reverse-blade
defect to the maintained half-period and mixer-support representation.

## Coupled packets: free two-sheet flag cover and exact three-orbit rank

For a coupled shell (R\mid p-1), the existing squarefree-coordinate
sets fit into the exact quotient
\[
\pi_{R,a}\colon
\mathcal S^{\mathrm{ext}}_{R,a}\longrightarrow\mathcal T_{R,a},
\qquad
(s,t,m)\longmapsto(s,\{t,m\}).
\]
Its deck involution is
\[
\iota(s,t,m)=(s,m,t),
\]
and it is free.  Indeed, a fixed point would give (t=m) and hence
(R\mid2t), which contradicts (R\ge3) and
(\gcd(R,t)=1).

Each ordered sheet (sigma=(s,t,m)) has the exact flag pair
\[
E_\sigma=
\begin{pmatrix}k_\sigma&4st\\t&R\end{pmatrix},
\qquad
M_\sigma=
\begin{pmatrix}q_\sigma&4st\\t&R\end{pmatrix},
\]
where
\[
k_\sigma=\frac{4st^2+1}{R},
\qquad
q_\sigma=\frac{p+4st^2}{R}.
\]
Its directed blades agree, and its reverse defect is
\[
\mathscr D_\sigma
=
\frac{p-1}{R}
\begin{pmatrix}
-t&q_\sigma+k_\sigma\\
0&t
\end{pmatrix}.
\]
The complementary sheet has the same formulas with (t) and (m)
exchanged.  Both sheets carry the exact half-period and mixer
intertwiners from the preceding section.

The quotient fiber contributes exactly
\[
\{(2,st^2),(0,sm^2)\},
\quad
\{(2,sm^2),(0,st^2)\},
\quad
\{(1,st^2),(1,sm^2)\}.
\]
Therefore
\[
|\mathcal S^{\mathrm{ext}}_{R,a}|
=|\mathcal E_{R,a}|
=c_{R,a}
=2|\mathcal T_{R,a}|,
\]
and
\[
q_{R,p}
=3|\mathcal T_{R,a}|
=\frac32|\mathcal S^{\mathrm{ext}}_{R,a}|.
\]
One nonempty shared-column packet hence forces (q_{R,p}\ge3),
(Q_p\ge3), and the Erdős--Strauss identity at (p).

The exact checker verifies this quotient and rank on all (35)
nonempty coupled shells through prime (1000); the first record is
\[
(p,a,R,|\mathcal S^{\mathrm{ext}}|,|\mathcal T|,q)
=(13,4,3,2,1,3).
\]

## Coupled packets carry both six-state laws

For a coupled packet \(P=(s,\{t,m\})\), put \(u=st^2\) and \(v=sm^2\).
Its three arithmetic complement orbits have union
\[
\mathcal X(P)=\{(j,u),(j,v):j\in\mathbb Z/3\mathbb Z\}.
\]
This is a two-sheet, three-origin arithmetic set.  Origin rotation
\(r(j,w)=(j+1,w)\), pure sheet exchange
\(\alpha(j,u)=(j,v)\), and arithmetic complement
\(\kappa(j,u)=(2-j,v)\) satisfy
\[
r^3=\alpha^2=\kappa^2=1,\qquad
\alpha r=r\alpha,\qquad
\kappa r\kappa=r^{-1}.
\]
Hence \(r\alpha\) gives a regular \(C_6\)-action and
\(\langle r,\kappa\rangle\) gives a regular \(D_3\)-action on the same
six cells.  In the ordered sheet basis,
\[
\mathbf R=\operatorname{diag}(R_3,R_3),\qquad
\mathbf A=\begin{pmatrix}0&I_3\\I_3&0\end{pmatrix},\qquad
\mathbf K=\begin{pmatrix}0&F_3\\F_3&0\end{pmatrix}.
\]
The same-origin sheet map \(A_\sigma\) intertwines the two \(C_3\)
rotations, and its block coupling obeys
\(\mathbf A=\mathbf A^\ast\), \(\mathbf A^2=I\succeq0\), and
\(\mathbf A\mathbf R=\mathbf R\mathbf A\).

Exact source: es_fable_c123_preprint.tex,
Theorem thm:coupled-packet-six-cell-laws.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
It verifies both regular actions on every packet in the 35 nonempty
coupled shells through prime 1000; the stored 37-line receipt agrees
line-for-line with a fresh run.

## Arithmetic exhaustion and spectral splitting of the packet couplings

Choose one ordered packet sheet \(\sigma\).  The exact carrier map is
\[
\Psi_\sigma(a,\epsilon)
=(a,u_{\iota^\epsilon\sigma})
\colon C_3\times C_2\longrightarrow\mathcal X(P).
\]
For \(x=(a,\epsilon)\), the two left regular laws become
\[
\Psi_\sigma(x\circ y)
=r^a\alpha^\epsilon\Psi_\sigma(y),
\qquad
\Psi_\sigma(x\star y)
=r^a(r\kappa)^\epsilon\Psi_\sigma(y).
\]
Thus the packet realizes both homomorphisms
\[
C_2\longrightarrow\operatorname{Aut}(C_3)\cong C_2,
\]
and these exhaust the semidirect couplings on this six-cell carrier.

The sheet-parity operators
\[
\mathbf P_\pm=\frac12(I\pm\mathbf A)
\]
are rank-three orthogonal projections commuting with both
\(\mathbf R\) and \(\mathbf K\).  For
\(\omega=e^{2\pi i/3}\) and \(\mathbf G=\mathbf R\mathbf A\),
\[
\operatorname{Spec}(\mathbf G)
=\{1,-1,\omega,-\omega,\omega^2,-\omega^2\},
\qquad
\det(XI_6-\mathbf G)=X^6-1.
\]
Under the reflected \(D_3\)-action,
\[
\mathscr H^+\cong\mathbf1\oplus V,
\qquad
\mathscr H^-\cong\operatorname{sgn}\oplus V,
\qquad
\mathscr H\cong
\mathbf1\oplus\operatorname{sgn}\oplus V^{\oplus2}.
\]
The sheet sum spans the trivial line; the sheet difference spans the
sign line.  The two orthogonal complements carry the
two-dimensional irreducible \(D_3\)-representation.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:coupled-packet-arithmetic-exhaustion-spectral-splitting.

The checker now verifies all 36 carrier products under both laws and
the exact six-by-six projection identities.  Its stored 37-line
receipt agrees line-for-line with a fresh run.

## Packet parity is the tensor lift of the ordered blade supports

For an ordered packet sheet \(\sigma\), the unitary
\[
\Upsilon_\sigma(\eta_\rho\otimes f_j)=e_{j,\rho}
\]
identifies
\[
\mathscr H_P\cong\mathscr S_P\otimes\mathscr O_3
\]
and gives the exact operator factorizations
\[
\Upsilon_\sigma^{-1}\mathbf A_P\Upsilon_\sigma=S\otimes I_3,
\qquad
\Upsilon_\sigma^{-1}\mathbf R_P\Upsilon_\sigma=I_2\otimes R_3,
\qquad
\Upsilon_\sigma^{-1}\mathbf K_P\Upsilon_\sigma=S\otimes F_3.
\]
The parity vectors
\[
\eta_\pm
=
\frac{\eta_\sigma\pm\eta_{\iota\sigma}}{\sqrt2}
\]
lift the ordered rank-one blades to
\[
\mathbb B_{P,-+}
=
\Upsilon_\sigma
\bigl((\eta_-\eta_+^\ast)\otimes I_3\bigr)
\Upsilon_\sigma^{-1},
\qquad
\mathbb B_{P,+-}
=
\Upsilon_\sigma
\bigl((\eta_+\eta_-^\ast)\otimes I_3\bigr)
\Upsilon_\sigma^{-1}.
\]
Their source and range projections are respectively
\[
\mathbf P_{P,+}\longrightarrow\mathbf P_{P,-},
\qquad
\mathbf P_{P,-}\longrightarrow\mathbf P_{P,+},
\]
and their ordered signs are
\[
\mathbf A_P\mathbb B_{P,-+}=-\mathbb B_{P,-+},
\qquad
\mathbb B_{P,-+}\mathbf A_P=\mathbb B_{P,-+},
\]
\[
\mathbf A_P\mathbb B_{P,+-}=\mathbb B_{P,+-},
\qquad
\mathbb B_{P,+-}\mathbf A_P=-\mathbb B_{P,+-}.
\]
Both commute with the arithmetic-origin rotation.

The flag-to-packet map
\[
\mathfrak C_\sigma
=
\Upsilon_\sigma
\circ
\bigl((U_\sigma C_\sigma)\otimes I_3\bigr)
\]
intertwines the flag involution and support projections with packet
parity and retains the complementary scales:
\[
\mathfrak C_\sigma
(\mathscr D_\sigma\otimes I_3)
\mathfrak C_\sigma^{-1}
=
\frac{(p-1)t}{R}\mathbf A_P,
\]
\[
\mathfrak C_{\iota\sigma}
(\mathscr D_{\iota\sigma}\otimes I_3)
\mathfrak C_{\iota\sigma}^{-1}
=
\frac{(p-1)m}{R}\mathbf A_P.
\]
Reversing the chosen sheet order fixes the parity projections and
changes the sign of each directed blade.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:packet-parity-tensor-lift-ordered-blade-supports.

The exact checker now includes the tensor-lifted blade identities.
Its stored 37-line receipt agrees line-for-line with a fresh run.

## Exact transition between the complementary packet flags

For \(\sigma=(s,t,m)\), \(\iota\sigma=(s,m,t)\), and
\[
h_P
=
(k_\sigma+q_\sigma)
+
(k_{\iota\sigma}+q_{\iota\sigma}),
\]
the flag-coordinate transition is
\[
\mathcal T_{\sigma\to\iota\sigma}
=
T_{\sigma\to\iota\sigma}\otimes I_3,
\qquad
T_{\sigma\to\iota\sigma}
=
\begin{pmatrix}
-1&h_P/(2t)\\
0&m/t
\end{pmatrix}.
\]
The reverse matrix is
\[
T_{\iota\sigma\to\sigma}
=
\begin{pmatrix}
-1&h_P/(2m)\\
0&t/m
\end{pmatrix}
=
T_{\sigma\to\iota\sigma}^{-1}.
\]
Consequently,
\[
\det T_{\sigma\to\iota\sigma}=-m/t,
\qquad
\operatorname{Spec}(T_{\sigma\to\iota\sigma})
=\{-1,m/t\},
\]
and the eigenlines are generated by
\[
(1,0)^{\mathsf T},
\qquad
\bigl(h_P/[2(t+m)],1\bigr)^{\mathsf T}.
\]
The six-dimensional lift repeats both eigenvalues three times and has
determinant \(-(m/t)^3\).

The transition intertwines the flag involutions and both ordered
support projections, while the reverse-channel defect retains its
exact arithmetic ratio:
\[
\mathcal T_{\sigma\to\iota\sigma}
(\mathscr D_\sigma\otimes I_3)
=
\frac tm
(\mathscr D_{\iota\sigma}\otimes I_3)
\mathcal T_{\sigma\to\iota\sigma}.
\]

On packet space, put
\[
r=t/m,\qquad d=h_\sigma-rh_{\iota\sigma}.
\]
The transport matrix in the ordered packet sheet basis is
\[
L_{\sigma\to\iota\sigma}
=
\frac12
\begin{pmatrix}
r-d-1&r-d+1\\
r+d+1&r+d-1
\end{pmatrix},
\]
with
\[
\det L_{\sigma\to\iota\sigma}=-t/m,
\qquad
\operatorname{Spec}(L_{\sigma\to\iota\sigma})
=\{-1,t/m\}.
\]
Thus both realizations contain one negative direction and one positive
arithmetic scale direction, with reciprocal scales.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:complementary-packet-exact-flag-transition.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
Its stored 37-line receipt agrees line-for-line with a fresh run.

## Canonical fixed line of an unordered arithmetic packet

For a coupled packet \(P=(s,\{t,m\})\), define
\[
\delta_P=\frac{p-1}{R},
\qquad
\ell_P=\frac{t+m}{R}.
\]
Its positive transition eigenline has the intrinsic coordinate
\[
\gamma_P
=
\frac{h_P}{2(t+m)}
=
4s\ell_P-\frac{\delta_P+2}{\ell_PR},
\qquad
0<\gamma_P<4s\ell_P.
\]
The vector \(w_P=(\gamma_P,1)^{\mathsf T}\) is multiplied by \(m/t\)
under the forward flag transition and by \(t/m\) under the reverse
transition.

For an ordered sheet \(\sigma=(s,t,m)\), put
\[
\mu_\sigma
=
\frac{(m-t)(\delta_P+2)}{t+m}.
\]
Order reversal sends \(\mu_\sigma\) to \(-\mu_\sigma\) and exchanges
the two sheet basis vectors.  Consequently,
\[
v_P
=
(1+\mu_\sigma)\eta_\sigma
+
(1-\mu_\sigma)\eta_{\iota\sigma}
\]
is unchanged.  The two flag charts map \(w_P\) to this same line:
\[
U_\sigma C_\sigma w_P
=
\frac{1}{2\sqrt2\,t}v_P,
\qquad
U_{\iota\sigma}C_{\iota\sigma}w_P
=
\frac{1}{2\sqrt2\,m}v_P.
\]

The rank-three lift of its line projection is
\[
\mathbb Q_P^{\mathrm{fix}}
=
\frac{1}{1+\mu_\sigma^2}
\left(
\mathbf P_{P,+}
+
\mu_\sigma
(\mathbb B_{P,-+}+\mathbb B_{P,+-})
+
\mu_\sigma^2\mathbf P_{P,-}
\right).
\]
This projection is independent of sheet order and commutes with the
arithmetic-origin rotation.  Its sheet-exchange commutator is
\[
[\mathbf A_P,\mathbb Q_P^{\mathrm{fix}}]
=
\frac{2\mu_\sigma}{1+\mu_\sigma^2}
(\mathbb B_{P,+-}-\mathbb B_{P,-+}).
\]
Since \(t\ne m\), this commutator is nonzero.  Thus the
order-independent packet line necessarily mixes the two parity
supports, and the ordered blade difference records its exact
off-diagonal component.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:unordered-packet-canonical-fixed-line.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
Its stored 37-line receipt agrees line-for-line with a fresh run.

## Square-discriminant reconstruction and the packet quarter

For a coupled shell, the map
\[
(s,\{t,m\})
\longmapsto
\left(s,\frac{t+m}{R}\right)
\]
is a bijection from \(\mathcal T_{R,a}\) onto the pairs
\((s,\ell)\) satisfying
\[
s\mid a,\qquad s\ \text{squarefree},\qquad
D_{s,\ell}:=\ell^2R^2-\frac{4a}{s}
\ \text{a positive square}.
\]
If \(d=\sqrt{D_{s,\ell}}\), the inverse is
\[
(s,\ell)
\longmapsto
\left(
s,
\left\{
\frac{\ell R-d}{2},
\frac{\ell R+d}{2}
\right\}
\right).
\]
Every such pair satisfies
\[
\ell R\le\frac as+1,
\]
so the packet count is an exact finite square-discriminant count.

For an ordered sheet \(\sigma=(s,t,m)\), put
\[
r_\sigma=\frac{t-m}{t+m},
\qquad
\zeta_P=-\frac{tm}{(t+m)^2}.
\]
Then
\[
D_{s,\ell_P}=(t-m)^2,
\qquad
r_\sigma^2=\frac{D_{s,\ell_P}}{\ell_P^2R^2},
\qquad
\mu_\sigma=-(\delta_P+2)r_\sigma.
\]
Consequently,
\[
\zeta_P+\frac14
=
\frac{D_{s,\ell_P}}{4\ell_P^2R^2}
=
\frac{\mu_\sigma^2}{4(\delta_P+2)^2},
\qquad
-\frac14<\zeta_P<0.
\]
Thus the unordered packet records the quarter gap, while the ordered
blade chart records its signed square root.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:unordered-packet-square-discriminant-quarter.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
The checker independently reconstructs the packet sets in all 35
nonempty coupled shells through prime 1000; its stored 37-line receipt
agrees line-for-line with a fresh run.

## Cartesian packet cover and Fable quarter endpoints

Let
\[
q\colon\mathbb A^1_y\longrightarrow\mathbb A^1_\zeta,
\qquad
q(y)=-\frac14+\frac{y^2}{4},
\]
and define, for an ordered packet sheet,
\[
y_{R,a}(\sigma)
=
\frac{\mu_\sigma}{\delta_{\pi_{R,a}(\sigma)}+2}
=
\frac{m-t}{m+t}.
\]
Writing the ordered and unordered packet sets as finite reduced
\(\mathbb Q\)-schemes \(\mathbf S_{R,a}\) and \(\mathbf T_{R,a}\), the
square
\[
\begin{array}{ccc}
\mathbf S_{R,a}&\xrightarrow{y_{R,a}}&\mathbb A^1_y\\
\pi_{R,a}\downarrow&&\downarrow q\\
\mathbf T_{R,a}&\xrightarrow{\zeta_{R,a}}&\mathbb A^1_\zeta
\end{array}
\]
is cartesian.  Over \(P=(s,\{t,m\})\), its coordinate algebra is
\[
\mathbb Q[Y]\big/\bigl(Y^2-(1+4\zeta_P)\bigr)
=
\mathbb Q[Y]\big/
\bigl((Y-y_\sigma)(Y+y_\sigma)\bigr)
\cong
\mathbb Q\oplus\mathbb Q.
\]
The two points are the two ordered packet sheets, and the deck
involution is \(y\mapsto-y\).  The arithmetic cover is unramified
because
\[
y_\sigma
=
\pm\frac{d_{s,\ell_P}}{\ell_PR}
\ne0.
\]

For the universal height
\[
h(y)=\frac{y^2}{4},
\]
every primitive coupled packet satisfies
\[
0<h(y_\sigma)<\frac14,
\qquad
\zeta_P=-\frac14+h(y_\sigma).
\]
On the complete Fable fibre,
\[
x(p_0)=0,\qquad x(p_+)=1,\qquad x(p_-)=-1,
\]
so
\[
h(x(p_0))=0,\qquad
h(x(p_+))=h(x(p_-))=\frac14,
\]
and
\[
q(x(p))-F_1(p)=h(x(p)).
\]
Thus the same height morphism places the fixed Fable point at the
zero-height endpoint, the transposed pair at the quarter-height
endpoint, and all primitive coupled arithmetic packets in the strict
interior.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:packet-cartesian-cover-fable-endpoints and
Figure fig:packet-fable-quarter-height.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
Its stored 40-line receipt agrees line-for-line with a fresh run.

## Blade coupling recovers the packet quarter height

For the fixed-line projection on the parity space, define
\[
E_\pm=\eta_\pm\eta_\pm^\ast,
\qquad
Q=Q_P^{\mathrm{fix}},
\qquad
S=E_+-E_-,
\qquad
a_\pm(P)=\operatorname{tr}(E_\pm Q).
\]
The exact parity weights are
\[
a_+(P)=\frac{1}{1+\mu_\sigma^2},
\qquad
a_-(P)=\frac{\mu_\sigma^2}{1+\mu_\sigma^2},
\]
and their coupling satisfies
\[
\lVert[S,Q]\rVert_{\mathrm{HS}}^2
=8a_+(P)a_-(P).
\]
Consequently,
\[
\zeta_P+\frac14
=
\frac{1}{4(\delta_P+2)^2}\frac{a_-(P)}{a_+(P)}
=
\frac{\lVert[S,Q]\rVert_{\mathrm{HS}}^2}
{32(\delta_P+2)^2a_+(P)^2}.
\]

The six-dimensional packet lift retains the origin multiplicity.  With
\[
A_\pm(P)=
\operatorname{tr}
\bigl(\mathbf P_{P,\pm}\mathbb Q_P^{\mathrm{fix}}\bigr),
\qquad
\mathcal C_P=
[\mathbf A_P,\mathbb Q_P^{\mathrm{fix}}],
\]
one has
\[
A_\pm(P)=3a_\pm(P),
\qquad
\lVert\mathcal C_P\rVert_{\mathrm{HS}}^2
=\frac83A_+(P)A_-(P),
\]
and
\[
\zeta_P+\frac14
=
\frac{1}{4(\delta_P+2)^2}\frac{A_-(P)}{A_+(P)}
=
\frac{3\lVert\mathcal C_P\rVert_{\mathrm{HS}}^2}
{32(\delta_P+2)^2A_+(P)^2}.
\]
Thus the strict positivity of the quarter height on an existing
arithmetic packet is exactly the nonzero coupling of its two ordered
blade channels.  The fibre \(\mu_\sigma=0\) has zero height, fixed-line
projection \(E_+\), and zero sheet-exchange commutator.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:packet-blade-coupling-quarter-height.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
Its stored 42-line receipt agrees line-for-line with a fresh run.

## Exact packet control complexity and interval volume

For equal-rank projections \(E,Q\), define their Hilbert--Schmidt
control complexity by
\[
\mathfrak C_{\mathrm{HS}}(E,Q)
=
\inf_U\int_0^1
\sqrt{\operatorname{tr}\bigl(H_U(t)^2\bigr)}\,dt,
\qquad
H_U(t)=i\dot U(t)U(t)^\ast,
\]
where \(U(0)=I\) and \(U(1)EU(1)^\ast=Q\).  For a packet, put
\[
\theta_\sigma=\arctan(\mu_\sigma).
\]
The exact two- and six-dimensional control costs are
\[
\mathfrak C_{\mathrm{HS}}^{(2)}(P)
=\sqrt2\,|\theta_\sigma|,
\qquad
\mathfrak C_{\mathrm{HS}}^{(6)}(P)
=\sqrt6\,|\theta_\sigma|
=\sqrt3\,\mathfrak C_{\mathrm{HS}}^{(2)}(P).
\]
The proof is intrinsic.  A unitary control path dominates the
Hilbert--Schmidt length of its projection path.  Sending a projection
\(Q(t)\) to the reflection \(2Q(t)-I\) doubles that length.  If the
principal angles are \(\theta_j\), the endpoint reflection product has
eigenphases \(\pm2\theta_j\); hence every control path has length at
least
\[
\sqrt{2\sum_j\theta_j^2}.
\]
The packet rotation paths attain this bound.

The quarter height is the following exact function of either control
cost:
\[
\zeta_P+\frac14
=
\frac{1}{4(\delta_P+2)^2}
\tan^2\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(2)}(P)}{\sqrt2}
\right)
=
\frac{1}{4(\delta_P+2)^2}
\tan^2\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(6)}(P)}{\sqrt6}
\right).
\]
For the packet interval
\[
I_P=
\left[0,\frac{|y_{R,a}(\sigma)|}{2}\right],
\qquad
\mathcal V_P=\operatorname{vol}_1(I_P),
\]
one has
\[
\mathcal V_P^2=\zeta_P+\frac14
\]
and
\[
\mathcal V_P
=
\frac{1}{2(\delta_P+2)}
\tan\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(2)}(P)}{\sqrt2}
\right)
=
\frac{1}{2(\delta_P+2)}
\tan\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(6)}(P)}{\sqrt6}
\right).
\]
This is an exact control-complexity/interval-volume carrier for every
existing arithmetic packet.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:packet-exact-control-complexity and
Corollary cor:packet-interval-volume-control-complexity.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
The finite certificate checks
\(\mathcal V_P^2=\zeta_P+\tfrac14\) on every packet in all 35 nonempty
coupled shells through prime 1000.

## Arithmetic reconstruction and the packet-volume lattice

Write
\[
L_P=t+m=\ell_PR,
\qquad
d_P=|m-t|.
\]
The packet interval volume recovers the integer gap:
\[
d_P
=
2L_P\mathcal V_P
=
\frac{L_P}{\delta_P+2}
\tan\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(2)}(P)}{\sqrt2}
\right)
=
\frac{L_P}{\delta_P+2}
\tan\left(
 \frac{\mathfrak C_{\mathrm{HS}}^{(6)}(P)}{\sqrt6}
\right).
\]
Consequently,
\[
\{t,m\}
=
\left\{
 \frac{L_P-d_P}{2},
 \frac{L_P+d_P}{2}
\right\}
=
\left\{
 L_P\left(\frac12-\mathcal V_P\right),
 L_P\left(\frac12+\mathcal V_P\right)
\right\}.
\]
The product and square discriminant are
\[
tm
=
L_P^2\left(\frac14-\mathcal V_P^2\right),
\qquad
D_{s,\ell_P}
=d_P^2
=4L_P^2\mathcal V_P^2.
\]
Thus
\[
2L_P\mathcal V_P\in\mathbb Z_{>0},
\qquad
2L_P\mathcal V_P\equiv L_P\pmod2,
\qquad
2L_P\mathcal V_P\le L_P-2,
\]
and
\[
\mathcal V_P
\in
\left\{
 \frac{d}{2L_P}:
 1\le d\le L_P-2,\ 
 d\equiv L_P\pmod2
\right\}.
\]
The lower lattice spacing is \(1/(2L_P)\) when \(L_P\) is odd and
\(1/L_P\) when \(L_P\) is even; the upper bound is
\(\tfrac12-\tfrac1{L_P}\).

Exact source: es_fable_c123_preprint.tex,
Corollary cor:packet-control-volume-arithmetic-reconstruction.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
It reconstructs the unordered pair, product, gap, discriminant, parity,
and lattice bounds on every packet in all 35 nonempty coupled shells
through prime 1000.

## Packet sum-gap polynomial and exact moments

For a coupled shell, define
\[
\mathscr G_{R,a}(X,Z)
=
\sum_{P\in\mathcal T_{R,a}}X^{L_P}Z^{d_P},
\qquad
L_P=t+m,
\qquad
d_P=|m-t|.
\]
The polynomial has only \(0\)-\(1\) coefficients.  For positive
integers \(L,d\), its coefficient at \(X^LZ^d\) is one exactly when
\[
L>d>0,
\qquad
L\equiv d\pmod2,
\]
\[
s_{L,d}:=\frac{4a}{L^2-d^2}
\]
is a positive squarefree integer and
\[
R\mid s_{L,d}(L-d)^2+1.
\]
Indeed, an occupied exponent pair reconstructs the entire packet:
\[
\{t,m\}
=
\left\{
\frac{L-d}{2},\frac{L+d}{2}
\right\},
\qquad
s=\frac{4a}{L^2-d^2}.
\]

The value at \((1,1)\) recovers the coupled-shell counts:
\[
\mathscr G_{R,a}(1,1)
=
|\mathcal T_{R,a}|
=
\frac12c_{R,a}
=
\frac12|\mathcal E_{R,a}|
=
\frac13q_{R,p}.
\]
With
\[
\mathcal D_X=X\partial_X,
\qquad
\mathcal D_Z=Z\partial_Z,
\]
all mixed moments satisfy
\[
\left.
\mathcal D_X^j\mathcal D_Z^k
\mathscr G_{R,a}
\right|_{(1,1)}
=
\sum_P L_P^j d_P^k
=
2^k\sum_P L_P^{j+k}\mathcal V_P^k.
\]
The first two gap moments are
\[
\left.\mathcal D_Z\mathscr G_{R,a}\right|_{(1,1)}
=
2\sum_PL_P\mathcal V_P,
\]
\[
\left.\mathcal D_Z^2\mathscr G_{R,a}\right|_{(1,1)}
=
\sum_PD_{s,\ell_P}
=
4\sum_PL_P^2\left(\zeta_P+\frac14\right).
\]
Thus the polynomial is a lossless finite encoding of the packet set,
and its Euler derivatives aggregate the exact control-volume and
quarter-height data.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:packet-sum-gap-polynomial.

Exact checker:
verification/verify_residual_free_carrier_incidence.py.
It verifies the coefficient criterion, coefficient uniqueness, count
recovery, and the first two moment identities on all 35 nonempty
coupled shells through prime 1000.

## Exact residual-three packet polynomial and divisor moments

For \(p\equiv1\pmod{12}\), put \(a=(p+3)/4\).  The later
multiplicative residual-three theorem already proves
\[
|\mathcal T(a)|
=
\frac{\mathrm d(a^2)-\mathrm d(a_+^2)}4,
\qquad
q_{3,p}
=
\frac34\left(\mathrm d(a^2)-\mathrm d(a_+^2)\right).
\]
The packet-polynomial refinement is
\[
\mathscr G_{3,a}(X,Z)
=
\sum_{\substack{s\mid a,\ s\ {\rm squarefree}\\s\equiv2\pmod3}}
\ \sum_{\substack{t\mid a/s\\t<\sqrt{a/s}}}
X^{t+a/(st)}Z^{a/(st)-t}.
\]
Indeed, \(a/s\equiv2\pmod3\), so \(a/s\) is not a square; its
unordered factor pairs are indexed exactly once by the displayed
strict divisor bound.

For
\[
A_r(a)=
\prod_{\ell^e\parallel a}
\left(\sigma_r(\ell^e)+\sigma_r(\ell^{e-1})\right),
\]
\[
B_r(a)=
\prod_{\ell^e\parallel a}
\left(
\sigma_r(\ell^e)+\chi_3(\ell)\sigma_r(\ell^{e-1})
\right),
\]
\[
H(a)=
\prod_{\ell^e\parallel a}
\left((e+1)\ell^e+e\ell^{e-1}\right),
\qquad
K(a)=
\prod_{\ell^e\parallel a}
\left((e+1)\ell^e+e\chi_3(\ell)\ell^{e-1}\right),
\]
the exact moments are
\[
\mathscr G_{3,a}(1,1)=\frac{A_0-B_0}{4},
\qquad
\left.\mathcal D_X\mathscr G_{3,a}\right|_{(1,1)}
=\frac{A_1-B_1}{2},
\]
\[
\left.\mathcal D_X^2\mathscr G_{3,a}\right|_{(1,1)}
=\frac{A_2-B_2+H-K}{2},
\]
\[
\left.\mathcal D_Z^2\mathscr G_{3,a}\right|_{(1,1)}
=\frac{A_2-B_2-H+K}{2}.
\]
Consequently the total residual-three discriminant and quarter-height
moment has the prime-local product expression
\[
\sum_{P\in\mathcal T_{3,a}}D_{s,\ell_P}
=
4\sum_{P\in\mathcal T_{3,a}}
L_P^2\left(\zeta_P+\frac14\right)
=
\frac{A_2-B_2-H+K}{2}.
\]

Exact source: es_fable_c123_preprint.tex,
Corollary cor:r3-packet-polynomial-divisor-moments.

Exact checker:
verification/verify_residual_three_packet_polynomial.py.
It checks all 159 primes \(p\equiv1\pmod{12}\) below 5000.  The 113
occupied shells contain 540 packets; the stored replay verifies the
polynomial support, coefficient uniqueness, multiplicative rank, and
all three displayed moments.

## Fixed-target residual-twenty-three ideal

For \(p\equiv1\pmod{12}\), put
\[
b=\frac{p+23}{12},
\qquad
a_{23}=3b.
\]
With the primitive logarithm
\[
\lambda_{23}:U_{23}\longrightarrow\mathbb Z/22\mathbb Z,
\qquad
\lambda_{23}(\overline5)=1,
\]
one has
\[
\lambda_{23}(\overline2)=2,\quad
\lambda_{23}(\overline3)=16,\quad
\lambda_{23}(\overline{-4^{-1}})=7,\quad
\lambda_{23}(\overline{-1})=11.
\]
Removing the forced factor \(3\) from the two reachability boxes gives
the fixed target triples
\[
E_{23}=\{7,13,19\},
\qquad
M_{23}=\{5,11,17\}.
\]
Thus, for the multiset \(M\) of nonzero factor logarithms of \(b\),
\[
q_{23,p}>0
\iff
\Sigma_{\mathrm E}^{23}(M)\cap E_{23}\ne\varnothing
\quad\text{or}\quad
\Sigma_{\mathrm M}^{23}(M)\cap M_{23}\ne\varnothing.
\]
The resulting reduced support ideal is
\[
J_{23}^{(3)}
=
(I_{23}^{\log}:X_{16}).
\]

The prior moving-target criterion is carried to this fixed form by a
specific translation.  If
\[
S=\{5,11,17\},
\qquad
\rho=\lambda_{23}(\overline p),
\]
then \(b\equiv2p\pmod{23}\) gives
\(\lambda_{23}(\overline b)=\rho+2\), and
\[
v\in S-\rho
\iff
v+\lambda_{23}(\overline b)\in S+2=E_{23}.
\]
Translation by the total factor logarithm maps the middle box
bijectively onto the exterior box.

The degree-one minimal rows are
\[
(5),(7),(11),(13),(17),(19),
\]
and there are exactly \(44\) degree-two minimal rows.  The full
low-degree list has SHA--256
3f9c363f28a56953fe396adb70d2fb17fdb03f70d0117c8e5bda6570bfe13bc2.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:R23-fixed-target-colon-ideal.

Exact checker:
verification/verify_residual_twenty_three_factor_classification.py.

## Forced-log classification of the prime-cofactor pullback

For the prime-cofactor family
\[
p=260\ell-19,\qquad
b_\ell=\frac{p+23}{12}=\frac{65\ell+1}{3},
\]
the condition \(p\equiv1\pmod{12}\) makes \(b_\ell\) an even integer.
Thus its fixed-target log monomial always contains \(X_2\).
On the two \(R=19\) blade classes
\[
\lambda_{19}(\ell)\in\{0,5\},
\]
one has
\[
\Xi_{19,a_{19}}=E_{21}
\]
and the \(R=23\) shell is empty exactly when
\[
\nu_k^{23}(b_\ell)=0
\quad\hbox{for every odd }k,
\]
or
\[
\mathfrak m_{23}^{\log}(b_\ell)
\in
\{X_1X_2,\ X_2X_{21},\ X_1X_2X_{21}\}.
\]
The first case says that every prime divisor of \(b_\ell\) is a
quadratic residue modulo \(23\).  The other cases are exactly
\[
b_\ell=2u q_5,\qquad
b_\ell=2u q_{14},\qquad
b_\ell=2u q_5q_{14},
\]
where every prime divisor of \(u\) is \(1\pmod{23}\),
\(q_5\equiv5\pmod{23}\), and \(q_{14}\equiv14\pmod{23}\).

The proof uses the forced logarithm \(2\) and the complete odd-bearing
down-set.  Its finite core is:

- the only safe odd partners of \(2\) are \(1\) and \(21\);
- the only safe extension of \((1,2)\) is \(21\);
- the only safe extension of \((2,21)\) is \(1\);
- \((1,2,21)\) has no nonzero safe extension.

For \(\ell\le10^7\), there are \(7328\) applicable prime pairs.
The \(5794\) occupied rows and \(1534\) empty rows split as
\[
\begin{array}{c|rrrr}
\text{empty type}
&\text{even logs}&(1,2)&(2,21)&(1,2,21)\\ \hline
\text{count}&1463&34&35&2.
\end{array}
\]

Exact source: es_fable_c123_preprint.tex,
Corollary cor:prime-cofactor-forced-log-R23-classification and
Computation comp:prime-cofactor-R23-pullback-census.

Exact checker and receipt:
verification/scan_prime_cofactor_r23_pullback.py and
verification/scan_prime_cofactor_r23_pullback_output.txt.

Lean certificate and receipt:
verification/OneSurplusQuarterBranchCertificate.lean and
verification/OneSurplusQuarterBranchCertificate_output.txt.

## Consecutive affine packet after \(R=23\)

Under the prime-cofactor conditions, reduction modulo \(12\) gives
\(\ell\equiv1\pmod6\).  Writing \(\ell=6m+1\) yields
\[
p=1560m+241,\qquad b_\ell=130m+22.
\]
For
\[
R_t=23+4t,\qquad a_t=\frac{p+R_t}{4},
\]
one has the exact coordinate formula
\[
a_t=390m+66+t=3b_\ell+t.
\]
Hence the shells \(R=23,27,\ldots,59\) form the ten-consecutive-integer
packet
\[
(a_0,\ldots,a_9)
=(390m+66,\ldots,390m+75).
\]
The forced divisor skeleton is
\[
(6,1,2,3,10,1,6,1,2,15),
\]
because
\[
\begin{aligned}
a_0&=6(65m+11),&
a_2&=2(195m+34),&
a_3&=3(130m+23),\\
a_4&=10(39m+7),&
a_6&=6(65m+12),&
a_8&=2(195m+37),\\
a_9&=15(26m+5).
\end{aligned}
\]
Moreover,
\[
a_t-a_s=t-s,
\qquad
\gcd(a_s,a_t)\mid|t-s|.
\]
Thus two coordinates in this ten-term packet can share no prime larger
than \(7\).  This supplies the exact affine and coprimality framework
for the post-\(R=23\) escape table.

## Degree-one colon triggers and minimal escape-certificate complexity

For the later residuals
\[
\mathcal R=\{27,31,35,39,43,47,51,55,59\},
\]
the affine packet has forced divisors
\[
(d_{27},d_{31},d_{35},d_{39},d_{43},d_{47},d_{51},d_{55},d_{59})
=(1,2,3,10,1,6,1,2,15).
\]
Let \(\boldsymbol\delta_R=\boldsymbol\nu_R(d_R)\), and define
\[
T_R^{(1)}=
\{u:\boldsymbol\delta_R+\mathbf e_u\in\mathscr U_R\}.
\]
Exact finite reachability gives
\[
\begin{aligned}
T_{27}^{(1)}&=\{20,26\},\\
T_{31}^{(1)}&=\{15,23,27,29,30\},\\
T_{35}^{(1)}&=\{23,26,32,34\},\\
T_{39}^{(1)}&=\{17,19,23,29,31,34,35,37,38\},\\
T_{43}^{(1)}&=\{32,42\},\\
T_{47}^{(1)}&=\{15,22,23,30,31,35,39,41,43,44,45,46\},\\
T_{51}^{(1)}&=\{38,50\},\\
T_{55}^{(1)}&=\{24,27,41,48,53,54\},\\
T_{59}^{(1)}&=\{18,23,39,44,47,54,55,56,58\}.
\end{aligned}
\]
If a prime divisor of the cofactor \(a_R/d_R\) lies in
\(T_R^{(1)}\), the shell is occupied.  Consequently, an empty shell
avoids every corresponding trigger class.  This implication is
universal on the affine packet.

For a first-occupied row in the bounded prime-cofactor census, let
\(\kappa_R(a_R)\) be the least degree of a cofactor residue submultiset
which, after adjoining \(\boldsymbol\delta_R\), belongs to the occupied
up-set \(\mathscr U_R\).  Across all \(1534\) rows with
\(\ell\le10^7\), the exact counts are
\[
\begin{array}{c|rrrr|r}
R&\kappa=1&\kappa=2&\kappa=3&\kappa=4&\text{total}\\ \hline
27&261&251&42&2&556\\
31&280&281&13&0&574\\
35&108&108&14&4&234\\
39&118&26&0&0&144\\
43&2&5&3&0&10\\
47&5&5&0&0&10\\
51&0&1&0&0&1\\
55&0&0&2&0&2\\
59&2&1&0&0&3\\ \hline
\text{total}&776&678&74&6&1534.
\end{array}
\]
The serialized minimal-certificate rows have SHA--256
`28f6c4432217a0df53d2f1c0b13433cdbff60d853f80407b00c3324b09f736fe`.

Exact source: `es_fable_c123_preprint.tex`, Proposition
`prop:prime-cofactor-affine-degree-one-trigger-sets` and Computation
`comp:prime-cofactor-escape-certificate-complexity`.

Exact checker and receipt:
`verification/analyze_prime_cofactor_escape_complexity.py` and
`verification/analyze_prime_cofactor_escape_complexity_output.txt`.

Exact source: es_fable_c123_preprint.tex,
Proposition prop:prime-cofactor-consecutive-affine-packet.

Lean certificate and receipt:
verification/PrimeCofactorAffinePacketCertificate.lean and
verification/PrimeCofactorAffinePacketCertificate_output.txt.

## First post-\(23\) escape in the bounded prime-cofactor family

Retain the prime-cofactor family
\[
p=260\ell-19
\]
and the \(1534\) rows with \(\ell\le10^7\) whose \(R=23\) shell is
empty.  Factoring \(a_R=(p+R)/4\), evaluating both multiplicative
reachability sets, and stopping at the first occupied residual
\(R>23\) gives
\[
\begin{array}{c|rrrrrrrrr}
R&27&31&35&39&43&47&51&55&59\\ \hline
\text{count}&556&574&234&144&10&10&1&2&3.
\end{array}
\]
Thus every one of the \(1534\) rows is occupied by \(R=59\).
The full factor-type split is
\[
\begin{array}{c|rrrrrrrrr}
\text{type}\backslash R&27&31&35&39&43&47&51&55&59\\ \hline
\text{even logs}&523&561&219&136&8&10&1&2&3\\
(1,2)&17&4&11&2&0&0&0&0&0\\
(2,21)&16&9&3&5&2&0&0&0&0\\
(1,2,21)&0&0&1&1&0&0&0&0&0.
\end{array}
\]
Consequently every nonresidue type escapes by \(R=43\), and only the
quadratic-residue type reaches \(R=47,51,55,59\).

Exactly three rows first occupy at \(R=59\):
\[
\begin{array}{r|r|r|l}
\ell&p&a_{59}&\operatorname{fac}(a_{59})\\ \hline
457&118801&29715&3\cdot5\cdot7\cdot283\\
163477&42504001&10626015&3\cdot5\cdot281\cdot2521\\
1945297&505777201&126444315&3\cdot5\cdot8429621.
\end{array}
\]
Each has \(\Xi_{59,a_{59}}=I_2+S\).  Their least exterior witnesses
give the exact certificates
\[
\frac4{118801}
=\frac1{29715}
 +\frac1{5077395546660}
 +\frac1{59834124},
\]
\[
\frac4{42504001}
=\frac1{10626015}
 +\frac1{1626852000211200354510}
 +\frac1{7655053462902},
\]
and
\[
\frac4{505777201}
=\frac1{126444315}
 +\frac1{8223506743037744477326560}
 +\frac1{1083943249686304}.
\]
The escape-row SHA--256 is
40ff82510a860198c07b31c5aaa898b87b679128de483d57851de543514afc70.
This is a bounded theorem for \(\ell\le10^7\); it is not a statement
of universal residual coverage.

Exact source: es_fable_c123_preprint.tex,
Computation comp:prime-cofactor-post-R23-escape-census.

Exact checker and receipt:
verification/scan_prime_cofactor_post23_escape.py and
verification/scan_prime_cofactor_post23_escape_output.txt.

## Complete target fibres in displacement quotients

Let
\[
B=A_1+\cdots+A_s\subset H,
\qquad
K=\operatorname{Stab}_H(B),
\qquad
Q=H/K,
\qquad
C=B/K,
\]
and suppose the target image is the two-point set
\[
U=\{u_0,u_1\}\subset Q.
\]
Put
\[
d=u_1-u_0,
\qquad
D=\langle d\rangle,
\qquad
Y=Q/D,
\]
and let \(\rho:Q\to Y\).  Write
\[
\widetilde A_i=\rho((A_i+K)/K),
\qquad
\widetilde C=\sum_i\widetilde A_i,
\qquad
\widetilde U=\rho(U),
\qquad
P=\operatorname{Stab}_Y(\widetilde C).
\]
The projected target surplus is
\[
\Sigma_D(P)
=
1+\sum_i\left(|(\widetilde A_i+P)/P|-1\right)
+|(\widetilde U+P)/P|-|Y/P|.
\]
Kneser's theorem gives
\[
\Sigma_D(P)>0
\Longrightarrow
\widetilde C\cap\widetilde U\ne\varnothing.
\]
If \(U+D=U\), this projected hit pulls back to
\(C\cap U\ne\varnothing\), and the defining property
\(K=\operatorname{Stab}_H(B)\) then gives \(B\cap T\ne\varnothing\).
For two distinct targets, the fibre condition is automatic when
\(|D|=2\), because
\[
U=u_0+D.
\]

The first new bounded arithmetic instance is
\[
(p,R,a)=(37,19,14).
\]
In multiplicative representatives,
\[
H=(\mathbb Z/19\mathbb Z)^\times,
\qquad
K=\{1,7,11\},
\qquad
Q=\{1,2,4,5,8,10\},
\]
and
\[
C=\{1,2,10\},
\qquad
U=D=\{1,8\}.
\]
The quotient \(Y=Q/D\) consists of
\[
\{1,8\},\qquad\{2,5\},\qquad\{4,10\}.
\]
The factor \(2\) projects onto all of \(Y\), while the factor \(7\)
projects to the identity:
\[
\rho(\overline A_2)=Y,
\qquad
\rho(\overline A_7)=\{D\}.
\]
Thus \(\widetilde C=Y\), \(P=Y\), and
\[
\Sigma_D(P)=1.
\]
The resulting divisor certificate reconstructs
\[
\frac4{37}
=
\frac1{14}+\frac1{28}+\frac1{1036}.
\]
This shell is not certified by the preceding uniform, nonstrict, or
support-boundary tests.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:displacement-quotient-target-fibre-forcing and
Theorem thm:p37-R19-displacement-quotient-certificate.

Exact checker and stored receipt:
verification/verify_displacement_quotient_target_forcing.py and
verification/verify_displacement_quotient_target_forcing_output.txt.
The checker passes \(1159599\) exhaustive cyclic assertions through
ambient order eight, including \(894371\) positive projected-surplus
cases, and independently recovers the \((13,7,5)\) and
\((37,19,14)\) arithmetic certificates.

Lean source and stored receipt:
verification/DisplacementQuotientTargetCertificate.lean and
verification/DisplacementQuotientTargetCertificate_output.txt.
The source proves the complete-target-fibre pullback step in Lean 4.32
without a proof placeholder or added axiom.

## Projected local intervals and the residual-nineteen prime-pair family

For a prime-power factor \(\ell_i^{e_i}\parallel a\), let
\[
y_i=\rho(\pi(\overline{\ell_i}))\in Y,
\qquad
n_i=\operatorname{ord}_Y(y_i).
\]
Its projected centered local support is the exact interval
\[
\widetilde A_i
=
\{k y_i:-e_i\le k\le e_i\},
\qquad
|\widetilde A_i|=\min(2e_i+1,n_i).
\]
It fills the displacement quotient precisely when
\[
\langle y_i\rangle=Y
\quad\text{and}\quad
2e_i+1\ge |Y|.
\]
If the target image is a complete \(D\)-fibre, one such filling factor
gives
\[
\widetilde C=Y,\qquad
P=Y,\qquad
\Sigma_D(P)=1,
\]
and therefore forces shell occupancy.

This criterion yields an exact residual-\(19\) family.  Let \(q\) be
prime with
\[
q\equiv7\ \text{or}\ 11\pmod{19},
\qquad
p=8q-19
\]
also prime, and put \(a=2q\).  Then \(4a-p=19\), and the corresponding
shell is occupied.  The proof uses
\[
K_0=\{1,7,11\}\le(\mathbb Z/19\mathbb Z)^\times,
\qquad
Q=(\mathbb Z/19\mathbb Z)^\times/K_0\cong C_6.
\]
The target displacement is the order-two class of
\[
\overline p=8K_0=(2K_0)^3.
\]
Thus \(Y=Q/\langle\overline p\rangle\cong C_3\), generated by the
image of \(2\).  Because \(e_2=1\), the projected local interval has
length
\[
2e_2+1=3=|Y|
\]
and fills \(Y\).

The resulting denominator identities are
\[
\frac4p
=
\frac1{2q}
+\frac1{2q(p+1)/19}
+\frac1{2pq(p+1)/19}
\qquad(q\equiv7\pmod{19})
\]
and
\[
\frac4p
=
\frac1{2q}
+\frac1{2(pq+1)/19}
+\frac1{2pq(pq+1)/19}
\qquad(q\equiv11\pmod{19}).
\]
These statements apply to every prime pair satisfying the displayed
conditions; no assertion about the infinitude of such pairs is used.

Exact source: es_fable_c123_preprint.tex,
Lemma lem:projected-local-exponent-interval,
Corollary cor:single-local-complete-fibre-forcing, and
Theorem thm:R19-complete-fibre-prime-pair-family.

Exact checker and stored receipt:
verification/verify_residual_nineteen_complete_fibre_family.py and
verification/verify_residual_nineteen_complete_fibre_family_output.txt.
The replay finds and checks all \(226\) prime pairs with
\(q\le200000\): \(115\) in the residue-\(7\) branch and \(111\) in
the residue-\(11\) branch.

Lean source and stored receipt:
verification/ResidualNineteenCompleteFibreFamilyCertificate.lean and
verification/ResidualNineteenCompleteFibreFamilyCertificate_output.txt.
The Lean 4.32 source proves both rational denominator identities and
the \(p=37\) instance without a proof placeholder or added axiom.

## Power-of-two complete-fibre ladder

Let \(e\ge1\), let \(R\) be an odd prime, and suppose
\[
\operatorname{ord}_R(2)=6e+12.
\]
Put
\[
m=2e+4,
\qquad
\omega=2^m\bmod R.
\]
Then \(\omega\) has order three.  Let \(q\) be prime with
\[
q\equiv\omega\quad\text{or}\quad\omega^2\pmod R,
\]
and suppose
\[
p=2^{e+2}q-R
\]
is prime.  For \(a=2^e q\), one has \(4a-p=R\), and the
residual-\(R\) shell is occupied.

The exact quotient mechanism is
\[
H=\langle\overline2\rangle,
\qquad
K_0=\langle\overline q\rangle
=\{1,\omega,\omega^2\},
\qquad
Q=H/K_0\cong C_{2e+4}.
\]
If \(g=\overline2K_0\), the projected \(2\)-factor is
\[
I=\{g^{-e},\ldots,g^e\},
\]
whose complement is
\[
\{g^{e+1},g^{e+2},g^{e+3}\}.
\]
The translation stabilizer of this three-point complement is trivial:
an order-three stabilizer would place the generator \(g\) in the
stabilizer and hence equal all of \(Q\).  Therefore the full support
stabilizer is exactly \(K_0\).

The target displacement satisfies
\[
\overline pK_0=g^{e+2}=g^{(2e+4)/2},
\]
the unique order-two point of \(Q\).  The two targets are consequently
one complete fibre of this order-two subgroup.  The displacement
quotient is cyclic of order \(e+2\), while the projected \(2\)-factor
contains \(2e+1\) consecutive powers.  Since
\[
2e+1\ge e+2,
\]
that one local factor fills the displacement quotient and the
complete-fibre theorem forces occupancy.

The two exact denominator branches are
\[
\frac4p
=
\frac1{2^e q}
+
\frac1{2^e q(p+1)/R}
+
\frac1{2^e p q(p+1)/R}
\qquad
(q\equiv\omega\pmod R)
\]
and
\[
\frac4p
=
\frac1{2^e q}
+
\frac1{2^e(pq+1)/R}
+
\frac1{2^e p q(pq+1)/R}
\qquad
(q\equiv\omega^2\pmod R).
\]

At \(e=1\), factorization of \(2^{18}-1\) and the exact orders of
\(2\) at its prime divisors force \(R=19\).  Thus the residual-nineteen
family above is the unique first rung.  At \(e=3\),
\[
(R,q,p,a)=(331,31,661,248)
\]
gives the compact certificate
\[
\frac4{661}
=
\frac1{248}+\frac1{496}+\frac1{327856}.
\]
No assertion about infinitely many prime pairs is used.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:power-two-complete-fibre-ladder and
Corollary cor:power-two-complete-fibre-first-rungs.

Exact checker and stored receipt:
verification/verify_power_two_complete_fibre_ladder.py and
verification/verify_power_two_complete_fibre_ladder_output.txt.
The replay checks \(1600\) abstract cyclic assertions, \(154\) exact
residual-group assertions, and \(36\) exact arithmetic certificates.
Through \(e=8\), it finds the eleven residual rungs
\[
19;\ 241;\ 331;\ 37,109;\ 5419;\ 97,673;\ 87211;\ 61,1321.
\]

Lean source and stored receipt:
verification/PowerTwoCompleteFibreLadderCertificate.lean and
verification/PowerTwoCompleteFibreLadderCertificate_output.txt.
The Lean 4.32 source proves both denominator schemas, the midpoint and
interval arithmetic, and the \(4/661\) identity without a proof
placeholder or added axiom.

### Cubic-total cofactor closure

The ladder persists under a strictly weaker cofactor condition.  Let
\(b\ge2\), require only the total residue
\[
b\in K_0=\{1,\omega,\omega^2\}\pmod R,
\]
and require one prime divisor \(\ell\mid b\) to satisfy
\[
\ell\equiv\omega\quad\hbox{or}\quad\omega^2\pmod R.
\]
All other prime divisors are unrestricted modulo \(R\).  The witness
prime-power has centered local support \(K_0\), while every other local
support contains its centered exponent zero.  The complete support of
\(a=2^e b\) therefore contains the embedded carrier
\[
B_0=A_2+K_0.
\]
This remains true when \(b\) is even: the complete local \(2\)-support
contains the \(2e+1\) powers contributed by the marked factor \(2^e\).

If
\[
p=2^{e+2}b-R
\]
is prime and \(a=2^e b\), the carrier \(B_0\) has stabilizer \(K_0\);
its complete target fibre and quotient-filling argument produce a
target representation inside the full support.  The certificate can
be written directly.  Choose
\[
u=
\begin{cases}
a,&b\equiv\omega,\\
2^e,&b\equiv\omega^2,\\
a/\ell,&b\equiv1,\ \ell\mid b,\ \ell\equiv\omega,\\
a\ell,&b\equiv1,\ \ell\mid b,\ \ell\equiv\omega^2.
\end{cases}
\]
In the identity branch, any nonidentity prime divisor may be used.
Then \(u\mid a^2\) and
\[
\frac ua\equiv-p\pmod R.
\]
Putting
\[
v=\frac{a^2p^2}{u}
\]
gives
\[
R\mid ap+u,
\qquad
R\mid ap+v,
\]
and therefore
\[
\frac4p
=
\frac1a
+
\frac1{(ap+u)/R}
+
\frac1{(ap+v)/R}.
\]

For \(R=19\), the three composite cofactors
\[
49=7^2,\qquad1141=7\cdot163,\qquad2629=11\cdot239
\]
represent the three total cubic classes \(11,1,7\), respectively, and
give
\[
\frac4{373}
=
\frac1{98}+\frac1{1924}+\frac1{35164948},
\]
\[
\frac4{9109}
=
\frac1{2282}+\frac1{1094056}+\frac1{69760292728},
\]
and
\[
\frac4{21013}
=
\frac1{5258}+\frac1{5815348}+\frac1{122197907524}.
\]

The total-residue criterion is witnessed in every cubic class by
\[
220=2^2\cdot5\cdot11,\qquad
286=2\cdot11\cdot13,\qquad
330=2\cdot3\cdot5\cdot11.
\]
Their total classes are \(11,1,7\pmod{19}\), respectively, although
several individual prime factors lie outside \(K_0\).  They give
\[
\frac4{1741}
=
\frac1{440}+\frac1{40318}+\frac1{15442600360},
\]
\[
\frac4{2269}
=
\frac1{572}+\frac1{68640}+\frac1{14158560},
\]
and
\[
\frac4{2621}
=
\frac1{660}+\frac1{91080}+\frac1{238720680}.
\]

Exact source: es_fable_c123_preprint.tex,
Theorem thm:power-two-cubic-cofactor-ladder and
Corollaries cor:R19-cubic-cofactor-three-class-certificates and
cor:R19-cubic-total-mixed-factor-certificates.

Exact checker and stored receipt:
verification/verify_power_two_cubic_cofactor_ladder.py and
verification/verify_power_two_cubic_cofactor_ladder_output.txt.
The replay checks \(400\) abstract support instances, all eleven rung
templates through \(e=8\), and \(19\) prime arithmetic certificates.
Six certificates contain prime factors outside \(K_0\), including
three with an additional \(2\)-factor.

Lean source and stored receipt:
verification/PowerTwoCubicCofactorCertificate.lean and
verification/PowerTwoCubicCofactorCertificate_output.txt.
The Lean 4.32 source proves the general divisor split, its exponent
arithmetic, ten rational certificates, and nine primality statements
without a proof placeholder or added axiom.

### Congruence scope of the power-of-two ladder

The order condition itself excludes one residue class.  If
\[
\operatorname{ord}_R(2)=6e+12
\]
with \(e\ge1\) and \(R\) prime, then
\[
R\bmod8\in\{1,3,5\}.
\]
Indeed, \(R\equiv7\pmod8\) would make \(2\) a quadratic residue modulo
\(R\).  Euler's criterion would then force the even integer
\(\operatorname{ord}_R(2)\) to divide the odd integer \((R-1)/2\).

For every integer \(b\),
\[
p=2^{e+2}b-R
\]
satisfies
\[
p\equiv-R\pmod8,
\qquad
p\bmod8\in\{7,5,3\}.
\]
Thus no ladder prime is \(1\pmod8\).  If \(p\) is \(3\) or \(7\pmod8\),
then \(p\equiv3\pmod4\).  If \(p\equiv5\pmod8\), primality leaves
\[
p\equiv5\quad\hbox{or}\quad13\pmod{24}.
\]
The first class is \(5\pmod{12}\), and the second has the previously
proved residual-\(3\) certificate.  Hence the ladder supplies new
support geometry and explicit divisor certificates inside already
covered congruence classes; it does not enlarge the prime congruence
coverage of the manuscript.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:power-two-ladder-congruence-exclusion and
Corollary cor:power-two-ladder-existing-congruence-coverage.

Literature source for the supplementary law:
Hardy and Wright, An Introduction to the Theory of Numbers, sixth
edition, Theorem 95.

The cubic-cofactor checker now verifies the congruence exclusion at
all eleven rung templates and all nineteen prime certificates.

## Target-averaged Fourier equality and strict contraction

Let \(Q=H/K\), let \(\nu=\overline\mu_K\), and let
\(d=\overline p_K\) be the displacement between the two target cosets.
Define
\[
S(\nu)=\sum_{\psi\ne1}|\widehat\nu(\psi)|,
\qquad
S_d(\nu)=
\sum_{\psi\ne1}
|\widehat\nu(\psi)|\frac{|1+\psi(d)|}{2}.
\]
The exact equality criterion is
\[
S_d(\nu)=S(\nu)
\quad\Longleftrightarrow\quad
\nu(x+d)=\nu(x)\quad(x\in Q).
\]
For the full support quotient
\[
K=\operatorname{Stab}_H(\operatorname{supp}\mu),
\]
the pushed support has trivial stabilizer.  Distinct target cosets give
\(d\ne0\), so
\[
S_d(\nu)<S(\nu).
\]
If the shell is empty, then
\[
M_{p,a}\le S_d(\nu)<S(\nu).
\]

Exact source: es_fable_c123_preprint.tex,
Corollary cor:target-averaged-Fourier-filter.

Formal source and receipt:
verification/StrictTargetAveragingCertificate.lean and
verification/StrictTargetAveragingCertificate_output.txt.

The bounded quotient scan through \(p\le150\), \(p\equiv1\pmod{12}\),
finds \(103\) two-target full-stabilizer quotients, and all \(103\) contract
strictly.  This is a finite implementation audit.

## Quantitative target-rotation gap

Let \(m=\operatorname{ord}_Q(d)\) and let
\[
(P_d\nu)(x)=\frac1m\sum_{j=0}^{m-1}\nu(x+jd).
\]
Then \(P_d\) is the Fourier projection onto the characters annihilating
\(d\):
\[
\widehat{P_d\nu}(\psi)
=
\begin{cases}
\widehat\nu(\psi),&\psi(d)=1,\\
0,&\psi(d)\ne1.
\end{cases}
\]
With
\[
W_{\mathrm{rot}}(\nu,d)
=
\sum_{\substack{\psi\ne1\\\psi(d)\ne1}}
|\widehat\nu(\psi)|
=
S(\nu)-S(P_d\nu),
\]
one has
\[
\boxed{
S_d(\nu)
\le
S(\nu)
-
\left(1-\cos\frac{\pi}{m}\right)
W_{\mathrm{rot}}(\nu,d).}
\]
On the full support quotient \(W_{\mathrm{rot}}(\nu,d)>0\).

Because the shell measure is integer-valued, a nonconstant \(d\)-orbit has
variance at least \((m-1)/m\).  Parseval and
\(\ell^1\ge\ell^2\) therefore give the uniform lower bound
\[
\boxed{
W_{\mathrm{rot}}(\nu,d)
\ge
\sqrt{|Q|\frac{m-1}{m}}.}
\]
Thus
\[
S_d(\nu)
\le
S(\nu)
-
\left(1-\cos\frac{\pi}{m}\right)
\sqrt{|Q|\frac{m-1}{m}},
\]
and the shell is occupied whenever
\[
S(\nu)
<
M_{p,a}
+
\left(1-\cos\frac{\pi}{m}\right)
\sqrt{|Q|\frac{m-1}{m}}.
\]

Exact source: es_fable_c123_preprint.tex,
Corollaries cor:quantitative-target-rotation-gap and
cor:integral-orbit-variance-target-gap.

Formal source and receipt:
verification/TargetRotationGapCertificate.lean and
verification/TargetRotationGapCertificate_output.txt.

## Support-boundary target gap

Let \(C=\operatorname{supp}\nu\), and let \(\mathcal O_d\) be the
translation orbits of \(d\), each of cardinality
\(m=\operatorname{ord}_Q(d)\).  For
\[
b_O=|C\cap O|,
\qquad
\mathcal B_d(C)
=
\frac1m\sum_{O\in\mathcal O_d}b_O(m-b_O),
\]
integer positivity on \(C\) gives
\[
\sum_{x\in Q}|\nu(x)-(P_d\nu)(x)|^2
\ge
\mathcal B_d(C).
\]
Parseval and the Fourier \(\ell^1/\ell^2\) inequality therefore give
\[
\boxed{
W_{\mathrm{rot}}(\nu,d)
\ge
\sqrt{|Q|\mathcal B_d(C)}.}
\]
Consequently
\[
\boxed{
S_d(\nu)
\le
S(\nu)
-
\left(1-\cos\frac{\pi}{m}\right)
\sqrt{|Q|\mathcal B_d(C)}.}
\]
The full support-stabilizer quotient satisfies
\(\mathcal B_d(C)\ge(m-1)/m\), recovering the preceding universal
orbit-variance bound.

If \(c=|C|\) and \(r_c\equiv c\pmod m\), concentration into whole
\(d\)-orbits gives the exact support-cardinality floor
\[
\mathcal B_d(C)\ge
\begin{cases}
r_c(m-r_c)/m,&r_c\ne0,\\
2(m-1)/m,&r_c=0\text{ and }C+d\ne C.
\end{cases}
\]
For an empty shell, Kneser's theorem and target disjointness give
\[
\kappa(K)\le c\le |Q|-|U|.
\]
Taking the minimum of the displayed floor over this integer interval
gives a support-boundary lower bound determined only by the local support
sizes, quotient size, target count, and displacement order.

For a one-prime-power shell \(a=\ell^e\), let
\[
n=|\langle\overline\ell\rangle|,
\qquad
L=2e+1<n,
\qquad
\overline p=\overline\ell^{\,r},
\qquad
g=\gcd(n,r),
\qquad
m=n/g.
\]
Write \(L=ug+v\), \(0\le v<g\).  The support is a proper cyclic interval.
Its \(d\)-orbits have \(u+1\) support points in \(v\) residue classes and
\(u\) support points in the remaining \(g-v\), so
\[
\boxed{
\mathcal B_d(C)
=
\frac{
v(u+1)(m-u-1)+(g-v)u(m-u)
}{m}.}
\]
The same interval has exact Fourier and target-filter coordinates
\[
\widehat\mu(\chi_j)
=
\frac{\sin(\pi Lj/n)}{\sin(\pi j/n)},
\qquad
|\mathcal A_U(\chi_j)|
=
\left|\cos\frac{\pi jr}{n}\right|
\quad(1\le j<n).
\]
This gives a closed support and Fourier calculation for every proper
one-factor shell.

Exact sources: es_fable_c123_preprint.tex,
Corollary cor:support-cardinality-boundary-floor and
Theorem thm:one-factor-cyclic-interval-boundary-formula.

Exact and formal checks:
verification/verify_one_factor_cyclic_interval_boundary.py,
verification/SupportBoundaryCardinalityCertificate.lean, and their
receipts.  The finite checker verifies \(679480\)
interval/displacement triples through cyclic order \(160\).

For the shell \((p,R,a)=(13,7,5)\),
\[
H=(\mathbb Z/7\mathbb Z)^\times=\langle3\rangle\cong C_6,
\qquad
\mu=(1,1,0,0,0,1)
\]
in generator order.  Exact reduction in
\(\mathbb Q[\zeta_6]/(\Phi_6)\) gives
\[
(\widehat\mu(\chi_0),\ldots,\widehat\mu(\chi_5))
=(3,2,0,-1,0,2).
\]
The two targets differ by the order-two element, so their character
filter is
\[
(1,0,1,0,1,0).
\]
Thus
\[
M=3,\qquad S=5,\qquad S_{\mathrm A}=0.
\]
All three displacement orbits contain one support point, giving
\[
\mathcal B_d(C)=\frac32,
\qquad
5-\sqrt{6\cdot\frac32}=2<3.
\]
This proves shell occupancy.  In the bounded scan through \(p\le150\),
the support-boundary criterion certifies three shells and adds this one
shell beyond both the quotient-size/order criterion and the nonstrict
unweighted criterion.

Exact sources: es_fable_c123_preprint.tex,
Corollary cor:support-boundary-target-gap and
Theorem thm:p13-R7-support-boundary-certificate.

Exact checker and receipt:
verification/verify_p13_R7_support_boundary_certificate.py and
verification/verify_p13_R7_support_boundary_certificate_output.txt.

## Exact \(C_{10}\) target-coupling certificate

For \((p,R,a)=(37,11,12)\), with \(H=C_{10}\),
\[
M=15,\qquad S=15,\qquad S_{\mathrm A}=3+4\sqrt5<15.
\]
The old strict test is inconclusive at equality, while the target-coupled
test proves occupancy.  The exact gap is
\[
M-S_{\mathrm A}=4(3-\sqrt5)>0.
\]

Exact source: es_fable_c123_preprint.tex,
Theorem thm:p37-R11-target-averaged-certificate.

Exact checker and formal certificate:
verification/verify_p37_R11_target_averaged_character_certificate.py,
verification/P37R11TargetAveragedCertificate.lean, and their receipts.

## Compaction-recovery workflow for archival provenance

Compaction is treated as loss of active state.  Before a long run, the
durable checkpoint records the objective, proved and open claims, exact
paths, artifact hashes, prohibited operations, pending proof attacks, and
the first next operation.  After compaction, the checkpoint, active theorem,
interrupted artifact, and receipt are reread before any edit or inference.
An interrupted write is treated as having unknown state until targeted
inspection determines whether it landed.  This workflow is recorded in
research_logbook.tex at L0331, L0333, and L0335 and has been handed to the
Zenodo-maintenance task for inclusion in the research-methods provenance.

## Support-boundary involution and discrete blade commutator

For one admissible residual shell, put \(T=T_{R,p}\), \(J=J_{R,a}\),
\(S=S_{R,a}\), and
\[
\partial_T^{\mathrm{out}}S=S\setminus T^{-1}(S),
\qquad
\partial_T^{\mathrm{in}}S=T^{-1}(S)\setminus S.
\]
The crossed reflection \(K=J\circ T\) is an involution and gives mutually
inverse bijections
\[
\partial_T^{\mathrm{out}}S
\xleftrightarrow[K]{K}
\partial_T^{\mathrm{in}}S.
\]
For
\[
b(r)=\mathbf1_S(r),
\qquad
C_T(r)=e_{b(Tr)}e_{b(r)}^{\mathsf T},
\qquad
\nabla_Tb(r)=b(Tr)-b(r),
\]
the four transitions are
\[
\begin{array}{c|c|c|c}
b(r)\to b(Tr)&\nabla_Tb(r)&C_T(r)&\text{status}\\ \hline
0\to0&0&E_{22}&\text{stationary}\\
0\to1&+1&E_{12}&\text{entry}\\
1\to0&-1&E_{21}&\text{exit}\\
1\to1&0&E_{11}&\text{stationary}.
\end{array}
\]
The blade cells therefore carry an exact discrete derivative:
\[
[J_{\mathrm B},C_T(r)]
=2\nabla_Tb(r)C_T(r),
\qquad
[D,C_T(r)]
=12\nabla_Tb(r)C_T(r),
\]
where \(D=3I_2+6J_{\mathrm B}=\operatorname{diag}(9,-3)\).
Thus \(E_{12}\) is the \(+12\) entry line and \(E_{21}\) is the
\(-12\) exit line.  For the first occupied \(R=107\) shell,
\[
\mathcal M(53)=2E_{21},
\qquad
r_0\in\partial_T^{\mathrm{out}}S_{107,2200869}.
\]

Exact source: es_fable_c123_preprint.tex,
Theorem thm:endpoint-support-boundary-commutator.

Exact checker and stored receipt:
verification/verify_endpoint_boundary_commutator.py and
verify_endpoint_boundary_commutator_output.txt.  The replay audits
67,810 admissible shells through \(p=2000\), finds 1,419,667 outgoing
and 1,419,667 incoming boundary sources, and verifies all labelled
endpoint transitions.

## Lorentz norm as support-boundary commutator cost

For the four raw blade cells, put
\[
\eta_+=1,
\qquad
\eta_-=0,
\qquad
\nabla_{\epsilon\lambda}=\eta_\epsilon-\eta_\lambda.
\]
On the two off-diagonal cells the Lorentz coordinate is
\[
W=-\nabla_{\epsilon\lambda}\frac{m^2+1}{2}.
\]
For all four cells the Lorentz norm is exactly
\[
\boxed{
\mathcal Q
=\frac14\lVert[J_{\mathrm B},N_{\epsilon\lambda}]\rVert_{\mathrm{HS}}^2
=\frac1{144}\lVert[D,N_{\epsilon\lambda}]\rVert_{\mathrm{HS}}^2.}
\]
The diagonal cells are stationary and null.  The entry and exit cells
have squared commutator cost \(m^2\), equal to their Lorentz norm.

This result has been carried through the dependency-bearing split-zero,
quarter, parity, first-shell, and modular statements.  In particular,
the split-zero coefficient remains supported when its endpoint state is
\(b=0\): the zero state records absence of the target divisor fibre.
It does not erase the supported matrix coefficient.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:four-blade-cell-Lorentz-table and equation
eq:four-cell-boundary-commutator-norm.

Propagation checker and stored receipt:
verification/verify_outgoing_edge_dependency_propagation.py and
verify_outgoing_edge_dependency_propagation_output.txt.

## Finite support-boundary Dirichlet energy

The complete unit-group energy is
\[
\mathscr E^\partial_{R,p}
:=
\frac14\sum_{r\in U_R}
\lVert[J_{\mathrm B},C_T(r)]\rVert_{\mathrm{HS}}^2.
\]
It has the exact forms
\[
\boxed{
\begin{aligned}
\mathscr E^\partial_{R,p}
&=
\frac1{144}\sum_{r\in U_R}
\lVert[D,C_T(r)]\rVert_{\mathrm{HS}}^2\\
&=
\sum_{r\in U_R}\bigl(\nabla_Tb(r)\bigr)^2\\
&=
\bigl|S\mathbin{\triangle}T^{-1}(S)\bigr|\\
&=
2\bigl|\partial_T^{\mathrm{out}}S\bigr|
=
2\bigl|\partial_T^{\mathrm{in}}S\bigr|.
\end{aligned}}
\]
It vanishes exactly when \(\overline p\in H_{R,a}\), equivalently when
multiplication by \(p\) preserves the complete support set.

For the unit-mass directed Gram carrier
\[
\mathfrak H_T(r)
=
C_T(r)^{\mathsf T}C_T(r)
-
e_{b(Tr)}e_{b(Tr)}^{\mathsf T},
\qquad
\mathcal N_T(r)=-\det\mathfrak H_T(r),
\]
one has
\[
\mathcal N_T(r)=\bigl(\nabla_Tb(r)\bigr)^2,
\qquad
\mathscr E^\partial_{R,p}
=
\sum_{r\in U_R}\mathcal N_T(r).
\]
Thus the finite Dirichlet energy is literally the sum of the Lorentz
norms of the unit endpoint cells.

The two labelled edges have energy
\[
\mathscr E^{\mathrm{lab}}_{R,p}
=
2(b_0-b_{-1})^2.
\]
It equals \(2\) for either one-sided pattern and \(0\) for the empty or
both-channel patterns.  For the first occupied \(R=107\) shell,
\[
\mathscr E^\partial_{107,8803369}=20,
\qquad
\mathscr E^{\mathrm{lab}}_{107,8803369}=2.
\]

The finite replay checks total energy \(2,839,334\), zero energy in
exactly \(771\) rotation-stable shells, and labelled energy \(3,912\)
across all \(67,810\) shells through \(p=2000\).

Exact source: es_fable_c123_preprint.tex,
Corollary cor:endpoint-support-boundary-Dirichlet-energy.

## Primewise directional-energy and complexity--volume bound

For
\[
\mathscr A_p^{\mathrm{one}}
=
\{a\in\mathscr A_p:\text{the shell is one-sided}\},
\qquad
\mathscr E^{\mathrm{lab}}_p
=
\sum_{a\in\mathscr A_p}\mathscr E^{\mathrm{lab}}_{R_a,p},
\]
one has
\[
\boxed{
\mathscr E^{\mathrm{lab}}_p
=
2|\mathscr A_p^{\mathrm{one}}|
\le
2Q_p
=
\frac{\log\operatorname{Vol}^{\det}_p}{3\log2}
=
\frac{2}{51}L_{H,p}^2
=
\frac{4}{75}L_{K,p}^2.}
\]
Equality holds exactly when every occupied shell is one-sided and every
such shell has \(q_{R_a,p}=1\).  Positive directional energy implies the
Erdős--Straus identity at \(p\).  The reverse implication need not hold,
because a both-channel shell has positive rank and zero labelled energy.

The finite replay verifies this inequality and its equality criterion for
all \(147\) primes \(p\equiv1\pmod4\) below \(2000\); none of those finite
primewise carriers is an equality case.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:primewise-directional-energy-bound.

## Squarefree rank--direction refinement

The two squarefree channel sets determine separate index sets
\[
\mathscr A_p^{\mathrm{ext}}
=
\{a\in\mathscr A_p:
\mathcal S^{\mathrm{ext}}_{R_a,a}\ne\varnothing\},
\qquad
\mathscr A_p^{\mathrm{mid}}
=
\{a\in\mathscr A_p:
\mathcal S^{\mathrm{mid}}_{R_a,a}\ne\varnothing\}.
\]
Define
\[
\Theta_p
=
\sum_{a\in\mathscr A_p}
\left(
|\mathcal S^{\mathrm{ext}}_{R_a,a}|
+
|\mathcal S^{\mathrm{mid}}_{R_a,a}|
\right),
\qquad
\Xi_p
=
\left|
\mathscr A_p^{\mathrm{ext}}
\mathbin{\triangle}
\mathscr A_p^{\mathrm{mid}}
\right|.
\]
The first coordinate is the total complement-orbit multiplicity, while
the second counts shells supported in exactly one of the two ordered
channels.  The exact relation is
\[
\boxed{
0\le\Xi_p\le\Theta_p=Q_p,
\qquad
\mathscr E^{\mathrm{lab}}_p=2\Xi_p.}
\]
Thus \((\Theta_p,\Xi_p)\) retains both occupied orbit mass and
one-sided directionality.  Equality \(\Xi_p=\Theta_p\) occurs exactly
when every occupied shell is one-sided and contains one complement
orbit.

For the arithmetic four-Time carrier,
\[
\boxed{
\mathscr E^{\mathrm{lab}}_p
=
2\Xi_p
\le
\frac12\dim_{\mathbb C}\mathscr V^{\mathrm{Time}}_p
=
\frac13\log_2\operatorname{Vol}^{\det}_p.}
\]
The same equality criterion applies.  This carries the directed
support information into the \(SU(4)\) multiplicity carrier while
retaining \(Q_p\) as its full arithmetic multiplicity.

The independent squarefree-coordinate replay checks all \(329\)
primewise inequalities through \(p=5000\).  Its aggregate values are
\[
\sum_p\Xi_p=6364,
\qquad
\sum_p\Theta_p=16229,
\]
and none of those finite primewise carriers is an equality case.

Exact sources: es_fable_c123_preprint.tex,
Corollary cor:squarefree-coordinate-complexity-volume,
Corollary cor:primewise-directional-energy-bound, and
Theorem thm:arithmetic-four-Time-multiplicity-carrier.

## Endpoint-selected amplitude propagation

For an occupied free shell, the endpoint bits select the actual
amplitude-retaining operator
\[
\mathcal N_{0+}^{p,a}
=
2H_{p,a}P_{p,a}\otimes\jmath(C_{0+}),
\qquad
C_{0+}=e_{b_1}e_{b_0}^{\mathsf T}.
\]
The exact status table is
\[
\begin{array}{c|c}
\text{status}&\mathcal N_{0+}^{p,a}\\ \hline
\text{exterior only}&\mathcal N_{12}^{p,a}\\
\text{middle only}&\mathcal N_{21}^{p,a}\\
\text{both}&2H_{p,a}P_{p,a}\otimes F_{22}.
\end{array}
\]
The empty shell is represented on the zero-dimensional space.

With
\[
\mathcal J_\partial^{p,a}
=
I_{\mathscr H_{p,a}}\otimes(F_{22}-F_{33}),
\]
one has
\[
[\mathcal J_\partial^{p,a},\mathcal N_{0+}^{p,a}]
=
2(b_1-b_0)\mathcal N_{0+}^{p,a},
\]
and therefore
\[
\boxed{
\mathscr E^{\mathrm{amp}}_{p,a}
=
\frac14
\lVert[\mathcal J_\partial^{p,a},\mathcal N_{0+}^{p,a}]\rVert_{\mathrm{HS}}^2
=
2\alpha^\Sigma_{p,a}\mathscr E^{\mathrm{lab}}_{R,p}.}
\]
This is the exact morphism from endpoint direction to the
amplitude-retaining polar carrier.  Its source and range are the
embedded projectors selected by \(b_0\) and \(b_1\).

Exact source: es_fable_c123_preprint.tex,
Corollary cor:endpoint-selected-amplitude-carrier.

Exact checker and stored receipt:
verification/verify_general_reduced_shell_polar_carrier.py and
verify_general_reduced_shell_polar_carrier_output.txt.

### Order-forced lift to the weighted \(C_1\)--\(C_2\)--\(C_3\) path

The endpoint-support order \(0<1\) and the divisor-sheet order
\[
x_O^-<x_O^+
\]
admit exactly one order isomorphism:
\[
0\longmapsto x_O^-,
\qquad
1\longmapsto x_O^+.
\]
It transports the arithmetic endpoint cell to the weighted path operator
\[
\mathcal W_{\partial,0+}^{p,a}
=
2\sum_{O,m}\sqrt{\alpha_O}\,
|e_{(m,x_O^{b_1})}\rangle
\langle e_{(m,x_O^{b_0})}|.
\]
The exact status table is
\[
\begin{array}{c|c}
\text{status}&\mathcal W_{\partial,0+}^{p,a}\\ \hline
\text{exterior only}&\mathcal W_{-,+}\\
\text{middle only}&\mathcal W_{+,-}\\
\text{both}&2\mathcal D_>^{1/2}.
\end{array}
\]
The empty shell is zero-dimensional.  The signed sheet grading gives
\[
[\mathcal J_{\partial,123}^{p,a},
 \mathcal W_{\partial,0+}^{p,a}]
=
2(b_1-b_0)\mathcal W_{\partial,0+}^{p,a}
\]
and
\[
\boxed{
\mathscr E^{\mathrm{amp},123}_{p,a}
=
3\alpha^\Sigma_{p,a}\mathscr E^{\mathrm{lab}}_{R,p}
=
\frac32\mathscr E^{\mathrm{amp}}_{p,a}.}
\]
The path/divisor multiplicities are exact:
\[
2\,\operatorname{rank}\mathcal W_{\partial,0+}
=3\,\operatorname{rank}\mathcal N_{0+},
\quad
2\|\mathcal W_{\partial,0+}\|_{\mathrm{HS}}^2
=3\|\mathcal N_{0+}\|_{\mathrm{HS}}^2,
\quad
2\mathscr E^{\mathrm{amp},123}
=3\mathscr E^{\mathrm{amp}}.
\]
For a one-sided shell the same energy is joined to the weighted
determinant volume and control lengths by
\[
6q
\left(\operatorname{Vol}^{\det,\alpha}_{p,a}\right)^{1/(6q)}
\leq
\mathscr E^{\mathrm{amp},123}_{p,a}
\leq
\frac{12\sqrt q}{\sqrt{51}}L_{H,\alpha}
=
12\sqrt{\frac{2q}{75}}L_{K,\alpha}.
\]
Both bounds are attained together exactly when all orbit amplitudes are
equal.

On every occupied shell, the same selected carrier has source and range
moduli
\[
\mathcal D_{\partial,0}^{\circ}
=\frac14W^*W\big|_{\mathscr H_{\partial,0}^{\mathrm{path}}},
\qquad
\mathcal D_{\partial,1}^{\circ}
=\frac14WW^*\big|_{\mathscr H_{\partial,1}^{\mathrm{path}}}.
\]
Both act by the same orbit amplitudes:
\[
\mathcal D_{\partial,j}^{\circ}e_{(m,x_O^{b_j})}
=\alpha_Oe_{(m,x_O^{b_j})}.
\]
For each selected sheet, the order-determined stable tensor flip gives
\[
\mathcal D_{\partial,j}^{\circ}\otimes I_2
\cong
D_{p,a}\otimes I_3,
\]
hence
\[
2\mu_{\partial,j}^{\mathrm{path}}=3\mu^{\mathrm{div}},
\qquad
\det(tI-\mathcal D_{\partial,j}^{\circ})^2
=\det(tI-D_{p,a})^3.
\]
The polar partial isometry
\[
V_{\partial,0+}
=\frac12W(\mathcal D_{\partial,0}^{\circ})^{-1/2}
\]
transports source modulus to range modulus and satisfies
\[
[\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}]
=2(b_1-b_0)V_{\partial,0+}.
\]
Thus the positive spectra agree on the two selected sheets, while the
ordered endpoint direction remains in the polar carrier.
Its amplitude-free Hilbert--Schmidt energy is
\[
\boxed{
\mathscr E^{\mathrm{pol},123}_{p,a}
=\frac14\lVert[\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}]
\rVert_{\mathrm{HS}}^2
=3q_{R,p}(b_1-b_0)^2
=\frac{3q_{R,p}}2\mathscr E^{\mathrm{lab}}_{R,p}.}
\]
Writing \(\rho^{\mathrm{path}}_{p,a}=3q_{R,p}\), the pair
\[
(\rho^{\mathrm{path}}_{p,a},
 \mathscr E^{\mathrm{pol},123}_{p,a})
\]
is \((0,0)\) for an empty shell, \((3q,3q)\) for either one-sided
status, and \((3q,0)\) for a both-channel shell.  It therefore recovers
the endpoint status without the orbit amplitudes.  Primewise,
\[
\frac32\mathscr E_p^{\mathrm{lab}}
=3\Xi_p
\leq\mathscr E_p^{\mathrm{pol},123}
\leq3Q_p
=\frac{1}{2\log2}\log\operatorname{Vol}^{\det}_p
=\frac1{17}L_{H,p}^2
=\frac2{25}L_{K,p}^2.
\]
Let
\[
\mathsf G_{p,a}
=
\begin{pmatrix}
\lambda_+&\lambda_-\\
\lambda_-&\lambda_+
\end{pmatrix},
\qquad
r_{p,a}=\operatorname{rank}\mathsf G_{p,a}.
\]
The target-character Lorentz theorem and the polar rank table give
\[
\boxed{
\mathscr E^{\mathrm{pol},123}_{p,a}
=3q_{R,p}r_{p,a}(2-r_{p,a}).}
\]
Therefore this energy is positive exactly on the nonzero null boundary
of the target-character future cone.  On that boundary,
\[
b_1-b_0=\frac{\lambda_-}{\lambda_+},
\qquad
[\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}]
=2\frac{\lambda_-}{\lambda_+}V_{\partial,0+}.
\]
The exterior-only channel is the positive null ray
\(\lambda_-=\lambda_+>0\); the middle-only channel is the negative null
ray \(\lambda_-=-\lambda_+<0\).
If a spectral function \(\varphi\) is strictly positive on every occupied
orbit amplitude, then
\[
\operatorname{rank}\mathsf G_\varphi
=\operatorname{rank}\mathsf G_{p,a}
\]
and on a one-sided shell
\[
b_1-b_0
=\frac{\lambda_{\varphi,-}}{\lambda_{\varphi,+}}.
\]
The moment, heat, and real resolvent functions used in the paper satisfy
this positivity condition.  Consequently
\[
\frac{M_{02,k}-M_{11,k}}{M_{02,k}+M_{11,k}}
=
\frac{\Theta_{02}(\beta)-\Theta_{11}(\beta)}
     {\Theta_{02}(\beta)+\Theta_{11}(\beta)}
=
\frac{R_{02}(z)-R_{11}(z)}
     {R_{02}(z)+R_{11}(z)}
=b_1-b_0
\]
on a one-sided shell.  Equivalently, the signed resolvent character obeys
\[
\Xi(z)=(b_1-b_0)\Pi(z).
\]
Thus the strictly positive spectral calculus carries the direction
faithfully but does not change the shellwise support test.  A stronger
test must use a spectral function with zeros or sign changes, or additional
signed data.
Writing \(\beta_1,\beta_2\) for the middle and exterior split-zero support
bits, respectively, gives the exact ordered-channel identification
\[
(b_0,b_1)=(\beta_1,\beta_2),
\qquad
b_1-b_0=\beta_2-\beta_1.
\]
The grading anticommutator supplies the conjunction coordinate:
\[
\mathscr E^{\mathrm{tim},123}_{p,a}
=
\frac14
\left\|
\{\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}\}
\right\|_{\mathrm{HS}}^2
=3q_{R,p}\beta_1\beta_2.
\]
Together with the commutator square, it exhausts the selected path rank:
\[
\boxed{
\frac14
\left(
\left\|[\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}]\right\|_{\mathrm{HS}}^2
+
\left\|\{\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}\}\right\|_{\mathrm{HS}}^2
\right)
=
\|V_{\partial,0+}\|_{\mathrm{HS}}^2
=3q_{R,p}
=\rho^{\mathrm{path}}_{p,a}.}
\]
Thus the commutator square is the Boolean exclusive-or part and the
anticommutator square is the conjunction part:
\[
\rho^{\mathrm{path}}_{p,a}
=\mathscr E^{\mathrm{pol},123}_{p,a}
 +\mathscr E^{\mathrm{tim},123}_{p,a}.
\]
Summing gives the exact complexity--volume split
\[
\mathscr E_p^{\mathrm{pol},123}
 +\mathscr E_p^{\mathrm{tim},123}
=3Q_p
=\frac34\dim_{\mathbb C}\mathscr V_p^{\mathrm{Time}}
=\frac12\log_2\operatorname{Vol}^{\det}_p.
\]
This proves entry by entry that the two split-zero mixer supports are the
ordered endpoint bits of the \((-,+)\), \((+,-)\), and diagonal path
channels.
The same transfer holds typewise for the (02) and (11) orbit classes,
so every nonnegative spectral function, moment, heat trace, and resolvent
reconstructs the same Lorentz-cone masses from either selected sheet.  The
aggregate target coefficient and target-null vector also obey
\[
2\Delta_{\partial,j}^{\mathrm{path}}
=3\Delta^{\mathrm{div}},
\qquad
2\nu_{\partial,j}^{\mathrm{path}}
=3\nu^{\mathrm{div}}
\]
for both (j=0,1).

Exact source: es_fable_c123_preprint.tex,
Corollaries cor:endpoint-selected-weighted-123-carrier and
cor:endpoint-energy-volume-control, and
cor:endpoint-selected-stable-spectral-transfer,
cor:endpoint-selected-polar-rank-direction, and
cor:primewise-polar-rank-direction, and
cor:polar-direction-target-Lorentz-boundary,
cor:positive-spectral-polar-null-direction, and
cor:moment-heat-resolvent-Lorentz-families; Theorem
thm:signed-resolvent-character-blade-circle; Corollary
cor:split-zero-polar-timelike-rank-decomposition.

Exact checker and stored receipt:
verification/verify_endpoint_selected_weighted_123_carrier.py and
verify_endpoint_selected_weighted_123_carrier_output.txt.

## Pre-certificate convolution to modular and polar support

For the exact nonnegative divisor convolution
\[
\mu=\mu_1*\cdots*\mu_s
\]
on the finite residue group \(H\), define
\[
\mathfrak T_{p,a}(f)
=
\binom{\widetilde f(T_2(p))}
      {\widetilde f(T_1(p))/2}.
\]
Its value on the arithmetic convolution is
\[
\boxed{
\mathfrak T_{p,a}(\mu)
=
\binom{q_{02}}{q_{11}},
\qquad
q_{R,p}=q_{02}+q_{11}.}
\]
The support of the two entries recovers the complete ordered endpoint
pair:
\[
b_0=\beta_1=\mathbf 1_{\{q_{11}>0\}},
\qquad
b_1=\beta_2=\mathbf 1_{\{q_{02}>0\}}.
\]

Let \(u_{\mathrm{mod}}=(0,E_{11})\) span the shellwise modular unit line.
For \(j=0,1\), the partial isometry
\[
\mathscr U_{\partial,j}^{p,a}
\bigl((e_O\otimes u_{\mathrm{mod}})\otimes g_m\bigr)
=e_{(m,x_O^{b_j})}
\]
identifies its \(C_3\)-amplification with the selected endpoint sheet.
The selected polar map is exactly
\[
\boxed{
V_{\partial,0+}
=
\mathscr U_{\partial,1}^{p,a}
(\mathscr U_{\partial,0}^{p,a})^*.}
\]
Therefore
\[
\operatorname{rank}V_{\partial,0+}
=3\operatorname{rank}P^{\mathrm{mod}}_{R,p}
=3(q_{02}+q_{11}),
\]
and the commutator and anticommutator energies are functions of the same
two extracted coefficients.

The full convolution itself never vanishes:
\[
\sum_{h\in H}\mu(h)=\prod_i(2e_i+1)>0.
\]
The exact shell question is whether this nonzero vector survives target
extraction:
\[
\mu\notin\ker\mathfrak T_{p,a}
\iff
P^{\mathrm{mod}}_{R,p}\ne0
\iff
V_{\partial,0+}\ne0.
\]
For \(p\equiv1\pmod4\), the counterexample condition is consequently
\[
\boxed{
\neg\mathrm{ES}(p)
\iff
\forall a\in\mathscr A_p:\quad
\mu_{p,a}\in\ker\mathfrak T_{p,a}.}
\]
Equivalently,
\[
\mathrm{ES}
\iff
\forall p\equiv1\pmod{12}\ \exists a\in\mathscr A_p:
\mu_{p,a}\notin\ker\mathfrak T_{p,a}
\iff
\inf_{p\equiv1\ (12)}
\operatorname{rank}\mathcal V_p^\partial\ge3.
\]
This identifies the precise upstream arithmetic locus: the modular and
polar carriers are exact images of the target extraction, while universal
coverage is the assertion that the finite family of nonzero convolution
vectors cannot all lie in their respective two-target kernels.

Fourier inversion resolves the target extraction before any certificate is
chosen.  With
\[
D_i(\chi)
=
\sum_{\beta=-e_i}^{e_i}
\overline{\chi(\overline\ell_i)}^{\,\beta},
\qquad
\mathbf v_{p,a}(\chi)
=
\binom{\operatorname{ev}_{H,T_2(p)}(\chi)}
      {\operatorname{ev}_{H,T_1(p)}(\chi)/2},
\]
where the extended evaluation is zero for a target outside \(H\), one has
\[
\boxed{
\mathfrak T_{p,a}(\mu)
=
\frac1{|H|}
\sum_{\chi\in\widehat H}
\left(\prod_iD_i(\chi)\right)\mathbf v_{p,a}(\chi).}
\]
Every local factor and every \(\widehat\mu(\chi)\) is real.  If
\[
M_{p,a}=\widehat\mu(1)=\prod_i(2e_i+1),
\]
then a target already lying in \(H\) is missed exactly when
\[
\sum_{\chi\ne1}
\widehat\mu(\chi)\chi(T_j(p))
=-M_{p,a}.
\]
Thus each target obstruction is either subgroup exclusion or exact
nonprincipal cancellation of the positive principal mass.

Each local factor has the cyclotomic form
\[
D_i(\chi)
=
\begin{cases}
2e_i+1,&z_i(\chi)=1,\\
z_i(\chi)^{-e_i}
\dfrac{z_i(\chi)^{2e_i+1}-1}{z_i(\chi)-1},
&z_i(\chi)\ne1,
\end{cases}
\]
where \(z_i(\chi)=\overline{\chi(\overline\ell_i)}\).  Hence it vanishes
exactly when \(z_i(\chi)\) is a nontrivial root whose order divides the odd
integer \(2e_i+1\).  Every \(2\)-primary character therefore survives.

If the only survivors are the principal character and the binary character
\(\eta\), then
\[
\mu(h)=\frac{M_{p,a}+A_{p,a}\eta(h)}{|H|},
\qquad
\frac{|A_{p,a}|}{M_{p,a}}
=
\prod_{\eta(\overline\ell_i)=-1}\frac1{2e_i+1}
\le\frac13.
\]
Thus both binary sheets are strictly positive.  For the \(12289\) shell,
\[
\widehat\mu=(45,0,0,0,0,-15,0,0,0,0),
\qquad
\mu(h)=\frac{45-15(-1)^h}{10}\in\{3,6\}.
\]
The retained \(C_2\) mode changes multiplicity and does not create an
unsupported residue.

More generally, let \(\Gamma\) be the \(2\)-primary subgroup of
\(\widehat H\) and put \(K=\Gamma^\perp\).  If every character outside
\(\Gamma\) is killed, the convolution is constant on the cosets of \(K\)
and descends to \(H/K\), whose dual is exactly \(\Gamma\).  The principal
and binary cases are both strictly positive.  Hence a missing coefficient
under complete odd-mode annihilation forces
\[
|H/K|=|\Gamma|\ge4.
\]
This identifies the first possible purely \(2\)-primary obstruction.

Every elementary-abelian quotient is excluded in every rank.  If
\[
P=H/K\cong C_2^d
\]
and \(\nu=\pi_*\mu\), choose local residue directions \(q_i\) forming a
basis of \(P\).  The corresponding binary local measures have coefficient
pair \(\{e_i,e_i+1\}\).  Their convolution has a unique basis expansion at
every class, and convolution with all remaining nonnegative local measures
gives
\[
\boxed{
\nu(x)\ge\frac{M_{p,a}}{3^d}>0,
\qquad
\mu(h)\ge\frac{2^dM_{p,a}}{3^d|H|}>0.}
\]
Consequently an elementary-abelian \(2\)-primary quotient cannot support a
missing coefficient.

The order-four quotient is completely classified.  For
\(P=H/K\cong C_2\times C_2\), two independent residue directions give
\[
\nu(x)\ge\frac{M_{p,a}}9,
\qquad
\mu(h)\ge\frac{4M_{p,a}}{9|H|},
\]
so every class is supported.  For \(P\cong C_4\), put
\[
L_{\rm odd}=\prod_{q_i\in\{1,3\}}m_i,
\qquad
L_2=\prod_{q_i=2}m_i.
\]
The three nonprincipal amplitude ratios are
\[
\frac1{L_{\rm odd}L_2},
\qquad
\frac1{L_{\rm odd}},
\qquad
\frac1{L_{\rm odd}L_2}.
\]
Their sum is at most one.  Equality holds exactly when
\(L_{\rm odd}=3\) and \(L_2=1\), in which case
\[
\pi_*\mu
=
\frac{M_{p,a}}3(\delta_{-q}+\delta_0+\delta_q)
\]
and the sole missing class is \(2q\).  Therefore a purely \(2\)-primary
missing coefficient either has a non-elementary quotient of order at least
eight or is this exact cyclic order-four antipodal configuration.

The cyclic extremum has an explicit Fable morphism.  On
\(C_4=\{0,q,2q,-q\}\), let \(\rho_q\) cycle
\(0,q,-q\) and fix \(2q\), and let \(\sigma_q(x)=-x\).  The bijection
\[
2q\mapsto v_\ast,\qquad
0\mapsto v_0,\qquad
q\mapsto v_+,\qquad
-q\mapsto v_-
\]
intertwines \(\rho_q,\sigma_q\) with
\(\mathfrak R_\square,\mathfrak J_\square\).  It pushes the arithmetic
measure to
\[
\frac{M_{p,a}}3
(\delta_{v_0}+\delta_{v_+}+\delta_{v_-})
\]
and sends its missing antipode to the unique negative-quarter apex
\(v_\ast\).  If \(b_\nu=(v_0+v_++v_-)/3\), then the existing
raw-cell--Lorentz map gives
\[
\pi_{\rm sp}\Phi_\triangle(b_\nu)
-
\pi_{\rm sp}\Phi_\triangle(v_\ast)
=
\left(0,\frac14,0\right).
\]
Thus the exceptional arithmetic quotient and the Fable tetrahedron are
joined by a coordinate-level \(D_3\)-equivariant map.

The order-eight \(2\)-primary support monoid is completely classified.
For \(C_8=\langle q\rangle\), every generating nonfull support is, after
choosing a generator,
\[
\begin{aligned}
A_3(q)&=\{0,\pm q\},\\
A_5(q)&=\{0,\pm q,\pm2q\},\\
A_6(q)&=C_8\setminus\{\pm2q\},\\
A_7(q)&=C_8\setminus\{4q\}.
\end{aligned}
\]
For \(C_4\times C_2\), with \(q\) of order four and
\(r\notin\langle q\rangle\) of order two, the complete list is
\[
\begin{aligned}
B_6(q,r)
&=
\{0,\pm q,r,r\pm q\}
=P\setminus\{2q,2q+r\},\\
B_7(q,r)
&=P\setminus\{2q\}.
\end{aligned}
\]
Every type occurs in the finite monoid generated by the local interval
supports.  The elementary-abelian theorem excludes \(C_2^3\).  The
order-sixteen continuation is recorded below.

These sets have an exact inherited eight-cell map.  In both the cyclic
and product cases,
\[
P=
\coprod_{\epsilon\in C_2}
\left(\epsilon r+\{0,q,2q,-q\}\right),
\]
where \(r=4q\) in \(C_8\).  Map the apex \(\epsilon r+2q\) to
\(e_\epsilon\otimes f\), and map
\(\epsilon r-q,\epsilon r+q,\epsilon r\) to
\(e_\epsilon\otimes g_0,e_\epsilon\otimes g_1,
e_\epsilon\otimes g_2\), respectively.  This bijection intertwines the
sheetwise face cycle with \(U_\Delta\), the diagonal reflection with
\(\widehat R_8\), and the crossed reflection with \(J_8\).

The supports \(A_6\) and \(B_6\) are exactly the crossed six-path orbit
\[
\mathscr O_0\cup\mathscr O_1
=
\mathbb C^2_{\rm sh}\otimes
\{g_0,g_1,g_2\}
\]
at the level of basis cells; their missing pair is the fixed two-cell
factor.  Every corresponding local-interval measure factors as
\[
\nu
=
c(b_0\delta_0+b_1\delta_r)
*
(\delta_{-q}+\delta_0+\delta_q),
\qquad c,b_0,b_1>0,
\]
so its coefficient vector maps to
\[
c\sqrt3(b_0e_0+b_1e_1)\otimes v_0
\in\ker K_{\rm ph}.
\]
The other inherited placements are exact as well:
\(A_3\) is one diagonal face orbit; \(A_5\) is that face together with
both fixed apices; \(B_7\) is the seven-cell diagonal carrier with one
fixed apex absent.  The support \(A_7\) misses a face cell and is not
preserved by the inherited phase cycle.  This is the exact boundary of
the existing eight-cell action.

The order-sixteen \(2\)-primary support monoids are also completely
classified.  For
\[
C_{16},\quad C_8\times C_2,\quad C_4\times C_4,\quad
C_4\times C_2^2,\quad C_2^4,
\]
the numbers of distinct local interval supports are
\[
35,\quad19,\quad15,\quad15,\quad15,
\]
and the full support-monoid cardinalities are
\[
63,\quad64,\quad54,\quad60,\quad67.
\]
Filtering for generating nonfull supports leaves respectively
\[
51,\quad36,\quad24,\quad11,\quad0
\]
labeled supports.  Exact automorphism closure partitions them into
\[
\boxed{17,\quad12,\quad4,\quad3,\quad0}
\]
orbits.  The four nonzero entries therefore give \(36\) complete structural
types; \(C_2^4\) is everywhere positive.

Writing an order-sixteen group as
\[
P\cong
\prod_{j=1}^{a}C_{2^{\lambda_j}}\times C_2^b,
\qquad \lambda_j\ge2,
\]
the least cardinality of a generating support in the local-interval monoid is
\[
\boxed{m(P)=3^a2^b.}
\]
There is one automorphism orbit at the minimum, represented by the direct
interval box
\[
\sum_{j=1}^{a}I_1(q_j)+\sum_{k=1}^{b}\{0,r_k\}.
\]
Consequently the five minimum support volumes are
\[
3,\quad6,\quad9,\quad12,\quad16.
\]

The four non-elementary groups have one exact sixteen-point carrier as a
four-sheet set with four cyclic cells:
\[
\Theta_P:S_P\times C_4\longrightarrow P,
\qquad
\Theta_P(u,j)=\sigma_P(u)+ja_P.
\]
For \(C_{16}\) and \(C_4\times C_4\), the sheet group is \(C_4\); for
\(C_8\times C_2\) and \(C_4\times C_2^2\), it is \(C_2^2\).  The transported
law is
\[
(u,j)\boxplus_P(v,k)
=
\bigl(u+v,j+k+\kappa_P(u,v)\bigr).
\]
The exact carries are
\[
\kappa_{C_{16}}(t,t')
=
\left\lfloor\frac{\widetilde t+\widetilde t'}4\right\rfloor,
\qquad
\kappa_{C_8\times C_2}
\bigl((\epsilon,\delta),(\epsilon',\delta')\bigr)
=
\epsilon\epsilon',
\]
and zero for \(C_4\times C_4\) and \(C_4\times C_2^2\).  The first two
cocycles are not coboundaries: \(C_{16}\) has no order-four complement to
\(\langle4q\rangle\), while every binary order-four subgroup of
\(C_8\times C_2\) meets \(\langle2q\rangle\) in \(\langle4q\rangle\).
The latter two carriers split through \(\langle r\rangle\) and
\(\langle r,s\rangle\).

The four minimum supports have carrier sizes, sheet-projection sizes,
cell-projection sizes, and correlation deficits
\[
\begin{array}{c|cccc}
P&C_{16}&C_8\times C_2&C_4\times C_4&C_4\times C_2^2\\ \hline
|X_P|&3&6&9&12\\
|\operatorname{pr}_{S_P}X_P|&3&4&3&4\\
|\operatorname{pr}_{C_4}X_P|&2&2&3&3\\
d_P&3&2&0&0.
\end{array}
\]
Thus
\[
|\operatorname{pr}_{S_P}X_P|\,
|\operatorname{pr}_{C_4}X_P|
=m(P)+d_P.
\]
This is an exact finite complexity--volume identity: the split carriers
fill their marginal sheet--cell rectangles, while the two non-split carries
remove exactly three and two correlated coordinate pairs.

Group inversion transports through the carrier by the exact formula
\[
\iota_P(u,j)
=
\bigl(-u,-j-\kappa_P(u,-u)\bigr).
\]
Thus the two nonzero carry classes remain visible as cell displacements.
On the full sixteen-point carriers, the positive and negative inversion
ranks are
\[
\begin{array}{c|cccc}
P&C_{16}&C_8\times C_2&C_4\times C_4&C_4\times C_2^2\\ \hline
\dim\mathscr K_{P,+}&9&10&10&12\\
\dim\mathscr K_{P,-}&7&6&6&4.
\end{array}
\]
The minimum supports are inversion invariant.  Their fixed-point counts are
\[
1,\quad2,\quad1,\quad4,
\]
and their negative ranks, equivalently their numbers \(b_P\) of two-point
inversion orbits, are
\[
b_P=(1,2,4,4).
\]
On every such orbit, inversion has the exchange matrix
\[
S=\begin{pmatrix}0&1\\1&0\end{pmatrix}.
\]
Its half-projectors are exactly the mixer projectors
\(\tfrac12(I\pm S)\), and the two one-dimensional spectral corner spaces
are the ordered blade lines generated by \(B_{-+}\) and \(B_{+-}\).
Reversing the point order negates the generators and fixes both lines.
Combining the blade-block counts with the sheet--cell deficits gives
\[
\boxed{d_P+b_P=4}
\]
in all four rows.  The product-coordinate volume missing from the support
and the antisymmetric mixer--blade modes therefore sum to the four cyclic
carrier cells.

Cell translation
\[
\mathsf R_P(u,j)=(u,j+1)
\]
and carrier inversion generate a faithful action of
\[
\mathsf D_8
=
\langle r,s:r^4=s^2=1,\ srs=r^{-1}\rangle.
\]
The dihedral orbit sizes on the full carriers are
\[
\begin{array}{c|cccc}
P&C_{16}&C_8\times C_2&C_4\times C_4&C_4\times C_2^2\\ \hline
\text{orbit sizes}&(4,4,8)&(4,4,4,4)&(4,4,8)&(4,4,4,4).
\end{array}
\]
For
\[
v_{u,k}=\sum_{j=0}^{3}\mathbf i^{-kj}\delta_{(u,j)},
\]
the exact actions are
\[
\mathsf R_Pv_{u,k}=\mathbf i^kv_{u,k},
\qquad
U_Pv_{u,k}
=
\mathbf i^{k\kappa_P(u,-u)}v_{-u,-k}.
\]
Hence the four cell-Fourier projectors
\[
\mathsf Q_{P,k}
=
\frac14\sum_{m=0}^{3}\mathbf i^{-km}\mathsf R_P^m
\]
all have complex rank four and satisfy
\[
U_P\mathsf Q_{P,k}U_P=\mathsf Q_{P,-k}.
\]
The self-conjugate second sector has sheet sign
\[
(-1)^{\kappa_P(u,-u)}.
\]
In the stated sheet orders, its four rows are
\[
\begin{array}{c|cccc}
P&C_{16}&C_8\times C_2&C_4\times C_4&C_4\times C_2^2\\ \hline
k=2\text{ signs}&
(1,-1,-1,-1)&
(1,1,-1,-1)&
(1,1,1,1)&
(1,1,1,1).
\end{array}
\]
The nonzero carry values are therefore visible as negative phases in an
intrinsic self-conjugate Fourier sector.

Let \(\chi_{\alpha\beta}\) be the one-dimensional dihedral character with
\(r\mapsto\alpha\) and \(s\mapsto\beta\), and let \(\rho\) be the
two-dimensional irreducible representation.  Put
\[
V_0=\chi_{++}\oplus\chi_{-+}\oplus\rho,
\qquad
V_1=\chi_{++}\oplus\chi_{--}\oplus\rho.
\]
The exact orbit-module decompositions are
\[
\begin{array}{c|c}
P&\mathscr K_P^{\mathbb C}\\ \hline
C_{16}&V_0\oplus V_1\oplus\mathbb C[\mathsf D_8]\\
C_8\times C_2&2V_0\oplus2V_1\\
C_4\times C_4&2V_0\oplus\mathbb C[\mathsf D_8]\\
C_4\times C_2^2&4V_0.
\end{array}
\]
In the irreducible order
\[
(m_{++},m_{+-},m_{-+},m_{--},m_\rho),
\]
the multiplicity rows are
\[
\begin{array}{c|ccccc}
C_{16}&3&1&2&2&4\\
C_8\times C_2&4&0&2&2&4\\
C_4\times C_4&3&1&3&1&4\\
C_4\times C_2^2&4&0&4&0&4.
\end{array}
\]
The rotated-reflection trace gives
\[
\frac12\operatorname{tr}(\mathsf R_PU_P)
=
m_{--}(P)-m_{+-}(P)
=
(1,2,0,0).
\]
For these four carrier laws,
\[
\boxed{
\kappa_P\text{ is not a coboundary}
\iff
\operatorname{tr}(\mathsf R_PU_P)>0
\iff
m_{--}(P)>m_{+-}(P).}
\]
Thus the full multiplicity row distinguishes the four selected marked
extension classes, while the displayed imbalance detects exactly the two
non-coboundary selected rows.

The spectrum admits a finer intrinsic description on the two-torsion sheet
subgroup.  For every finite abelian sheet group \(S\) and symmetric
\(C_4\)-valued carrier cocycle \(\kappa\), put
\[
q_\kappa:S[2]\longrightarrow C_2,
\qquad
q_\kappa(u)=\kappa(u,u)\pmod2.
\]
The cocycle identity makes \(q_\kappa\) additive, and changing the section
adds \(2f(u)\) to the diagonal on \(S[2]\), so the character is intrinsic to
the marked extension.  Its Hamming weight is the irreducible spectral defect:
\[
\boxed{
m_{--}-m_{+-}
=
\frac12\operatorname{tr}(\mathsf R U)
=
\bigl|\{u\in S[2]:q_\kappa(u)=1\}\bigr|.}
\]
If \(q_\kappa\ne0\), translation by any element in its one-fiber exchanges
the zero and one fibers.  Therefore
\[
\bigl|\{q_\kappa=1\}\bigr|=\frac{|S[2]|}{2},
\]
and the extension is non-split.  In the four order-sixteen carriers the
characters have weights
\[
(1,2,0,0);
\]
the first two are the nonzero characters on two- and four-element
two-torsion sheet groups, while the last two vanish.

The exact detection kernel is now known.  If
\[
S_{(2)}
\cong
\prod_{i=1}^{a}C_{2^{\lambda_i}}\times C_2^b,
\qquad
\lambda_i\ge2,
\]
then the marked abelian \(C_4\)-extension classes and their two-torsion
characters fit into
\[
\boxed{
0\longrightarrow(2C_4)^a
\longrightarrow C_4^a\times C_2^b
\xrightarrow{\ Q_S\ }C_2^{a+b}
\longrightarrow0.}
\]
Thus every character has \(2^a\) marked extension classes above it, and it
determines the marked extension exactly when \(S_{(2)}\) is elementary
abelian.  At order four the cyclic quotient classes \(0,1,2,3\) yield
\[
C_4\times C_4,\quad C_{16},\quad C_8\times C_2,\quad C_{16}
\]
with character weights \(0,1,0,1\), while the \(C_2^2\) quotient yields
\(C_4\times C_2^2\) in its zero class and \(C_8\times C_2\) in each nonzero
class, with weights \(0,2,2,2\).  In particular, the same abstract group
\(C_8\times C_2\) admits a selected binary-sheet carrier of weight two and a
non-split cyclic-sheet carrier of weight zero.  The spectral defect therefore
belongs to the marked carrier and is not an invariant of the abstract group
alone.

The kernel has an exact visible/hidden bit law.  In the displayed
invariant-factor coordinates, write every \(C_4\) extension coordinate
uniquely as
\[
c=q+2h,\qquad q,h\in C_2.
\]
Then Baer addition is
\[
\boxed{
(q,h;\epsilon)\star(q',h';\epsilon')
=
(q+q',h+h'+q\odot q';\epsilon+\epsilon').}
\]
The detection map forgets \(h\):
\[
Q_S(q,h;\epsilon)=(q;\epsilon),
\qquad
\ker Q_S=\{(0,h;0)\}.
\]
The exact sequence has a group-homomorphic section precisely when \(a=0\).
Thus the bit chart is a bijection of underlying sets for every \(a\), while
the quadratic carry \(q\odot q'\) prevents it from being an additive product
chart whenever a long cyclic sheet is present.  For \(S=C_4\), the four
classes have bit coordinates
\[
0\leftrightarrow(0,0),\quad
1\leftrightarrow(1,0),\quad
2\leftrightarrow(0,1),\quad
3\leftrightarrow(1,1).
\]
The class \(2\) is the unique nonzero invisible kernel class and has total
group \(C_8\times C_2\).

The split-zero operator construction realizes this visible/hidden law
exactly.  For the marked support section
\[
\iota_+(0)=0,\qquad \iota_+(1)=1
\]
and endpoint bits \(\beta_1,\beta_2\), put
\[
\ell=\beta_1+\beta_2\pmod2,\qquad
h=\beta_1\beta_2,\qquad
c=\iota_+(\beta_1)+\iota_+(\beta_2).
\]
Then
\[
\boxed{c=\ell+2h=\beta_1+\beta_2,}
\qquad
(\beta_1,0)\star(\beta_2,0)=(\ell,h).
\]
On every occupied shell,
\[
\mathscr E_{p,a}^{\mathrm{pol},123}=3q_{R,p}\ell,
\qquad
\mathscr E_{p,a}^{\mathrm{tim},123}=3q_{R,p}h.
\]
Thus the polar XOR energy is the visible digit and the timelike AND energy
is the hidden carry.  The energy pair identifies the two one-sided states.
Their order is retained by
\[
d=\beta_2-\beta_1,\qquad
[\mathcal J_{\partial,123}^{p,a},V_{\partial,0+}]=2dV_{\partial,0+},
\]
and the pair \((c,d)\) recovers
\[
\beta_1=\frac{c-d}{2},\qquad
\beta_2=\frac{c+d}{2}.
\]
One endpoint pair has marked class in \(\{0,1,2\}\); class \(3\) is absent
locally and occurs in the generated Baer closure through \(1+2=3\).

The same local table has an exact Lorentz-rank interpretation.  Let
\[
\widehat c_{p,a}:=\ell+2h\in\{0,1,2\}\subset\mathbb Z
\]
be the local integer lift of the marked class.  Then
\[
\boxed{
\widehat c_{p,a}
=
\operatorname{rank}\mathsf G_{p,a},}
\qquad
\boxed{
3q_{R,p}\widehat c_{p,a}
=
\mathscr E_{p,a}^{\mathrm{pol},123}
+2\mathscr E_{p,a}^{\mathrm{tim},123}.}
\]
Thus classes \(0,1,2\) are precisely the zero, future-null, and
future-timelike Lorentz strata.  Locally,
\[
\Omega_R(p)>0
\iff
\widehat c_{p,a}>0
\iff
c_{p,a}\ne0
\iff
\operatorname{rank}\mathsf G_{p,a}>0,
\]
while
\[
\det\mathsf G_{p,a}>0
\iff
\widehat c_{p,a}=2.
\]
The primewise marked-rank coordinate is
\[
\boxed{
\mathscr C_p^{C_4}
:=
\sum_{a\in\mathscr A_p}3q_{R,p}\widehat c_{p,a}
=
\mathscr E_p^{\mathrm{pol},123}
+2\mathscr E_p^{\mathrm{tim},123}
=
3\sum_{a\in\mathscr A_p}
q_{R,p}\operatorname{rank}\mathsf G_{p,a}.}
\]
Under the primewise shell reduction,
\[
\boxed{
\mathrm{ES}(p)
\iff
\mathscr C_p^{C_4}>0
\iff
\exists a\in\mathscr A_p:\ c_{p,a}\ne0.}
\]

Exact source: es_fable_c123_preprint.tex,
Corollary cor:split-zero-C4-rank-support-criterion.

Exact finite and Lean certificates:
verification/verify_split_zero_C4_rank_support.py,
verification/verify_split_zero_C4_rank_support_output.txt,
verification/SplitZeroC4RankSupportCertificate.lean, and
verification/SplitZeroC4RankSupportCertificate_output.txt.

The marked coordinate reconstructs the primewise one-sided and timelike
multiplicities.  Define
\[
\mathsf N_p^\partial
=
\sum_{a\in\mathscr A_p}q_{R_a,p}\ell_{p,a},
\qquad
\mathsf T_p^\partial
=
\sum_{a\in\mathscr A_p}q_{R_a,p}h_{p,a}.
\]
Then
\[
\boxed{
Q_p=\mathsf N_p^\partial+\mathsf T_p^\partial,
\qquad
\frac{\mathscr C_p^{C_4}}3
=
\mathsf N_p^\partial+2\mathsf T_p^\partial.}
\]
The inverse formulas are
\[
\mathsf N_p^\partial
=
2Q_p-\frac{\mathscr C_p^{C_4}}3,
\qquad
\mathsf T_p^\partial
=
\frac{\mathscr C_p^{C_4}}3-Q_p.
\]
Consequently,
\[
\boxed{
3Q_p\le\mathscr C_p^{C_4}\le6Q_p,
\qquad
\mathscr C_p^{C_4}
\le
\log_2\operatorname{Vol}^{\det}_p
\le
2\mathscr C_p^{C_4}.}
\]
The lower rank equality means that no occupied shell is timelike; the upper
rank equality means that no occupied shell is one-sided.  For \(Q_p>0\),
\[
\frac{\mathscr C_p^{C_4}}{3Q_p}
=
1+\frac{\mathsf T_p^\partial}{Q_p}
\in[1,2].
\]
Under the primewise shell reduction,
\[
\boxed{
\mathrm{ES}
\iff
\inf_{p\in\mathbb P_{1,12}}\mathscr C_p^{C_4}\ge3.}
\]

Exact source: es_fable_c123_preprint.tex,
Corollary cor:marked-C4-primewise-rank-volume.

Exact finite and Lean certificates:
verification/verify_marked_C4_primewise_rank_volume.py,
verification/verify_marked_C4_primewise_rank_volume_output.txt,
verification/MarkedC4PrimewiseRankVolumeCertificate.lean, and
verification/MarkedC4PrimewiseRankVolumeCertificate_output.txt.

Let
\[
d_P=(3,2,0,0),\qquad
b_P=(1,2,4,4)
\]
be the minimum sheet--cell correlation deficit and the minimum
mixer--blade block count, respectively.  Let
\[
\delta_P
:=
m_{--}(P)-m_{+-}(P)
=
\frac12\operatorname{tr}(\mathsf R_PU_P)
=(1,2,0,0),
\]
and let \(e_P=(1,1,0,0)\) be the indicator that the carrier cocycle is
not a coboundary.  The four carrier rows obey the exact balance laws
\[
\boxed{
d_P+\delta_P=4e_P,
\qquad
b_P-\delta_P=4(1-e_P).}
\]
Equivalently,
\[
\delta_P=e_Pb_P,\qquad
d_P=e_P(4-b_P),\qquad
b_P=\delta_P+4(1-e_P).
\]
Thus either non-split selected minimum carrier allocates the four-cell volume
between the correlation and irreducible spectral defects, while either split
selected minimum carrier places all four cells in the mixer--blade sector.

The next unclassified purely \(2\)-primary order is \(32\).

An empty shell admits a sharper finite quotient certificate.  Put
\[
K=\operatorname{Stab}(B),\qquad Q=H/K,\qquad
C=B/K,\qquad U=(T+K)/K.
\]
Then
\[
\delta_K=|Q|-|C|-|U|\ge0,\qquad
\epsilon_K=|C|-\kappa(K)\ge0,
\]
and
\[
\boxed{-\Sigma_T(K)=\delta_K+\epsilon_K.}
\]
For every \(u\in U\),
\[
\boxed{
\sum_{\substack{\psi\in\widehat Q\\\psi\ne1}}
\widehat\mu(q^\vee\psi)\psi(u)
=-M_{p,a}.}
\]
Thus target failure forces principal-mass cancellation using only the
characters in \(K^\perp\).  If \(T\ne\varnothing\) and every subgroup with
nonpositive surplus satisfies
\[
\sum_{\psi\ne1}
\prod_i|D_i(q^\vee\psi)|<M_{p,a},
\]
the shell is occupied.  The exact Parseval criterion
\[
(|Q|-1)
\left(
|Q|\sum_{\bar h\in Q}(\pi_{K*}\mu(\bar h))^2-M_{p,a}^2
\right)
<M_{p,a}^2
\]
implies the same conclusion.

The finite algebraic core is also certified in Lean~4.32.  The certificate
proves the defect identity with both summands nonnegative, the finite
principal/nonprincipal sum decomposition, the induced principal-mass square
bound, and the contradiction between exact cancellation and strict
Cauchy--Schwarz/Parseval domination.  It also proves the one-third
binary-sheet positivity gap, the elementary-abelian local and finite-product
bounds, preservation of a uniform gap under nonnegative convolution, and
the power-of-two order gap after the trivial and binary cases.  The
separate order-eight Lean certificate proves the face cycle, both
reflections, both \(D_3\) relations, and preservation of the six-cell face
locus.  The finite-group quotient and Fourier
identifications supplying those algebraic inputs are replayed independently
by the exact Python checker.

For the \(12289\) shell,
\[
\frac1{10}
\left[
45\binom{1}{1/2}
-15\binom{1}{-1/2}
\right]
=\binom33.
\]

The same map sharpens two earlier arithmetic results.  Every endpoint
divisor orbit counted by \(\nu_a(p)+\nu_p(p)\) survives the target map, so
\[
\operatorname{rank}\mathcal V_p^\partial
=
\mathscr E_p^{\mathrm{pol},123}
+
\mathscr E_p^{\mathrm{tim},123}
\ge3(\nu_a(p)+\nu_p(p)).
\]
The coupled-shell decomposition becomes
\[
\operatorname{rank}\mathcal V_p^\partial
=
3Q_p^{\mathrm{rem}}+\frac92C_p^{\mathrm{coup}},
\]
and a counterexample requires every remainder convolution to lie in its
target kernel together with the vanishing of every coupled group-ring
coefficient.

Exact source: es_fable_c123_preprint.tex,
Theorems thm:convolution-modular-polar-factorization and
thm:two-target-Fourier-kernel-factorization; Theorem
thm:cyclotomic-survivor-binary-sheet-positivity; Theorem
cor:first-purely-two-primary-obstruction; Theorem
thm:elementary-abelian-two-primary-full-support; Theorem
thm:order-four-two-primary-obstruction-classification; Corollary
cor:purely-two-primary-obstruction-dichotomy; Theorem
thm:exceptional-C4-Fable-tetrahedron-intertwiner; Theorem
thm:order-eight-two-primary-support-classification; Corollary
cor:purely-two-primary-obstruction-through-order-eight; Theorem
thm:order-eight-support-eight-cell-intertwiner; Computation
comp:order-eight-two-primary-support-check; Theorems
thm:order-sixteen-two-primary-support-classification and
thm:order-sixteen-four-sheet-carrier; Theorems
thm:order-sixteen-carrier-inversion-mixer-blade,
thm:order-sixteen-carrier-dihedral-fourier, and
thm:order-sixteen-dihedral-irreducible-carry-criterion; Theorem
thm:C4-carrier-two-torsion-carry-character; Theorem
thm:C4-extension-detection-exact-sequence; Corollary
cor:C4-extension-visible-hidden-bit-coupling; Corollary
cor:split-zero-C4-full-adder-bridge; Corollaries
cor:order-sixteen-spectral-support-balance,
cor:order-sixteen-minimum-support-volume,
cor:order-sixteen-minimum-support-carrier-location, and
cor:purely-two-primary-obstruction-through-order-sixteen; Computation
comp:order-sixteen-carrier-inversion-blade-certificates; Computation
comp:order-sixteen-carrier-dihedral-fourier-certificates; Computation
comp:order-sixteen-dihedral-irreducible-certificates; Computation
comp:order-sixteen-two-torsion-carry-character-certificates; Computation
comp:marked-C4-extension-detection-certificates; Computation
comp:C4-extension-visible-hidden-bit-certificates; Computation
comp:split-zero-C4-full-adder-certificates; Computation
comp:order-sixteen-spectral-support-balance-certificates; Computation
comp:order-sixteen-two-primary-support-check; Theorem
thm:stabilizer-quotient-character-obstruction; Theorem
thm:endpoint-divisor-orbit-lower-bound; Corollary
cor:primewise-coupled-coefficient-decomposition.

Exact checkers and stored receipts:
verification/verify_endpoint_selected_weighted_123_carrier.py,
verify_endpoint_selected_weighted_123_carrier_output.txt,
verification/verify_two_target_fourier_factorization.py,
verify_two_target_fourier_factorization_output.txt,
verification/verify_cyclotomic_two_sheet_positivity.py,
verify_cyclotomic_two_sheet_positivity_output.txt,
verification/verify_order_four_two_primary.py,
verify_order_four_two_primary_output.txt,
verification/verify_exceptional_c4_fable_bridge.py,
verify_exceptional_c4_fable_bridge_output.txt,
verification/verify_order_eight_two_primary_support.py,
verify_order_eight_two_primary_support_output.txt,
verification/verify_order_eight_eight_cell_bridge.py,
verify_order_eight_eight_cell_bridge_output.txt,
verification/OrderEightCarrierCertificate.lean,
OrderEightCarrierCertificate_output.txt,
verification/verify_order_sixteen_two_primary_support.py,
verify_order_sixteen_two_primary_support_output.txt,
verification/OrderSixteenSupportCertificate.lean,
OrderSixteenSupportCertificate_output.txt,
verification/verify_order_sixteen_four_sheet_carrier.py,
verify_order_sixteen_four_sheet_carrier_output.txt,
verification/OrderSixteenFourSheetCarrierCertificate.lean,
OrderSixteenFourSheetCarrierCertificate_output.txt,
verification/verify_order_sixteen_carrier_inversion_blade.py,
verify_order_sixteen_carrier_inversion_blade_output.txt,
verification/OrderSixteenCarrierInversionBladeCertificate.lean,
OrderSixteenCarrierInversionBladeCertificate_output.txt,
verification/verify_order_sixteen_carrier_dihedral_fourier.py,
verify_order_sixteen_carrier_dihedral_fourier_output.txt,
verification/OrderSixteenCarrierDihedralFourierCertificate.lean,
OrderSixteenCarrierDihedralFourierCertificate_output.txt,
verification/verify_order_sixteen_carrier_dihedral_irreducibles.py,
verify_order_sixteen_carrier_dihedral_irreducibles_output.txt,
verification/OrderSixteenCarrierDihedralIrreducibleCertificate.lean,
OrderSixteenCarrierDihedralIrreducibleCertificate_output.txt,
verification/verify_order_sixteen_two_torsion_carry_character.py,
verify_order_sixteen_two_torsion_carry_character_output.txt,
verification/OrderSixteenTwoTorsionCarryCharacterCertificate.lean,
OrderSixteenTwoTorsionCarryCharacterCertificate_output.txt,
verification/verify_marked_C4_extension_detection.py,
verify_marked_C4_extension_detection_output.txt,
verification/MarkedC4ExtensionDetectionCertificate.lean,
MarkedC4ExtensionDetectionCertificate_output.txt,
verification/verify_marked_C4_visible_hidden_bits.py,
verify_marked_C4_visible_hidden_bits_output.txt,
verification/MarkedC4VisibleHiddenBitsCertificate.lean,
MarkedC4VisibleHiddenBitsCertificate_output.txt,
verification/verify_split_zero_C4_full_adder_bridge.py,
verify_split_zero_C4_full_adder_bridge_output.txt,
verification/SplitZeroC4FullAdderBridgeCertificate.lean,
SplitZeroC4FullAdderBridgeCertificate_output.txt,
verification/verify_order_sixteen_spectral_support_balance.py,
verify_order_sixteen_spectral_support_balance_output.txt,
verification/OrderSixteenSpectralSupportBalanceCertificate.lean,
OrderSixteenSpectralSupportBalanceCertificate_output.txt,
verification/TwoTargetQuotientCertificate.lean,
TwoTargetQuotientCertificate_output.txt,
verification/verify_endpoint_divisor_orbit_families.py,
verify_endpoint_divisor_orbit_families_output.txt,
verification/verify_primewise_coupled_coefficient_decomposition.py,
verify_primewise_coupled_coefficient_decomposition_output.txt,
verification/verify_outgoing_edge_dependency_propagation.py, and
verify_outgoing_edge_dependency_propagation_output.txt.

## Endpoint-fibre displacement and the boundary of coupled coverage

For every shell with
\[
p=4a-R,
\]
let
\[
\rho_{R,a}:\{u>0:u\mid a^2\}\longrightarrow\mathbb Z/R\mathbb Z
\]
be residue reduction.  The two complete endpoint sections are fibres
of the same finite divisor-residue map:
\[
\mathcal E_{R,a}
=
\rho_{R,a}^{-1}(-4^{-1}),
\qquad
\mathcal M_{R,a}
=
\rho_{R,a}^{-1}(-4^{-1}+\delta_{R,p}),
\]
where the exact endpoint displacement is
\[
\delta_{R,p}
=
4^{-1}-a
=
-(p-1)4^{-1}
\pmod R.
\]
Thus the affine translation by \(\delta_{R,p}\) carries the exterior
target to the middle target, and
\[
\delta_{R,p}=0
\iff
R\mid p-1.
\]
The earlier equality
\[
\mathcal E_{R,a}=\mathcal M_{R,a}
\]
is the zero-displacement specialization.

The first relevant prime with no occupied coupled shell is \(p=73\).
Its only coupled residual is \(R=3\), with \(a=19\), and both endpoint
sections are empty.  The first occupied shell is the noncoupled
\(R=7\) shell with \(a=20\):
\[
\mathcal E_{7,20}=\{5,40\},
\qquad
\mathcal M_{7,20}=\{1,8,50,400\},
\qquad
q_{7,73}=4.
\]
Here \(\delta_{7,73}=3\), carrying the exterior residue \(5\) to the
middle residue \(1\).

An exact divisor scan through \(p\le10^6\) finds \(19564\) relevant
primes.  Of these, \(16757\) have an occupied coupled shell and \(2807\)
have none.  Every coupled failure has an occupied general shell whose
first residual is at most \(59\).  At that shell, \(2750\) cases meet
both endpoint fibres, \(36\) are exterior-only, and \(21\) are
middle-only.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:endpoint-divisor-fibre-displacement and
Corollary cor:first-coupled-shell-coverage-failure.

Exact checker and stored receipt:
verification/scan_coupled_shell_coverage.py and
verification/scan_coupled_shell_coverage_output.txt.

## Dihedral endpoint orbit and exact \(C_6=C_2\times C_3\) carrier

For each shell, define
\[
T(r)=pr,\qquad J(r)=a^2r^{-1}
\]
on \(U_R\).  Then
\[
J^2=1,\qquad JTJ=T^{-1}.
\]
With middle target \(r_0=-a\) and \(r_j=p^jr_0\), the three labelled
endpoint targets are
\[
r_{-1}=-4^{-1}\quad\hbox{(exterior)},\qquad
r_0=-a\quad\hbox{(middle)},\qquad
r_1=-pa\quad\hbox{(opposite exterior)}.
\]
Divisor complement \(u\mapsto a^2/u\) induces
\[
\mathcal F_{R,a}(r_j)\cong\mathcal F_{R,a}(r_{-j}),
\]
so it fixes the middle target and exchanges the two exterior targets.
The shell rank is exactly the three-labelled-fibre count
\[
2q_{R,p}
=
|\mathcal F_{R,a}(r_{-1})|
+
|\mathcal F_{R,a}(r_0)|
+
|\mathcal F_{R,a}(r_1)|.
\]
If \(n=\operatorname{ord}_{U_R}(p)\ge3\), \(T\) and \(J\) act
faithfully as the dihedral group of order \(2n\) on the target orbit.

At \(p=73,R=7,a=20\), the rotation has order six:
\[
(r_0,r_1,r_2,r_3,r_4,r_5)=(1,3,2,6,4,5).
\]
Under the canonical sheet/phase map
\[
\Phi_7:U_7\cong C_2\times C_3,
\]
this becomes
\[
((1,1),(-1,4),(1,2),(-1,1),(1,4),(-1,2)).
\]
Each rotation step flips the \(C_2\) sheet and rotates the \(C_3\)
phase.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:endpoint-dihedral-orbit and
Corollary cor:R7-p73-c6-carrier.

Exact checker and stored receipt:
verification/verify_endpoint_dihedral_orbit.py and
verification/verify_endpoint_dihedral_orbit_output.txt.
The replay covers 67810 admissible shells through \(p=2000\) and
1666950 divisors with multiplicity.

## Endpoint support-orbit classification

Let
\[
S_{R,a}
=
\{r\in U_R:\mathcal F_{R,a}(r)\ne\varnothing\}
\]
be the support of the complete divisor-residue section and let
\[
H_{R,a}
=
\{h\in U_R:hS_{R,a}=S_{R,a}\}.
\]
Divisor complementation proves
\[
J(S_{R,a})=S_{R,a},
\]
and \(H_{R,a}\) is a subgroup of \(U_R\).  Hence the two reflected
exterior targets always have the same support status.  The four
possible endpoint patterns are exactly:
\[
\begin{array}{c|c}
\text{empty}&r_{-1},r_0,r_1\notin S_{R,a}\\
\text{exterior only}&r_{-1},r_1\in S_{R,a},\ r_0\notin S_{R,a}\\
\text{middle only}&r_0\in S_{R,a},\ r_{-1},r_1\notin S_{R,a}\\
\text{both}&r_{-1},r_0,r_1\in S_{R,a}.
\end{array}
\]
Consequently,
\[
q_{R,p}>0
\iff
S_{R,a}\cap\{r_{-1},r_0,r_1\}\ne\varnothing.
\]

If \(p\in H_{R,a}\), support membership is constant on the entire
target rotation orbit.  Therefore every one-sided shell breaks
rotation-stability:
\[
\text{exterior only or middle only}
\Longrightarrow
p\notin H_{R,a}.
\]
The converse fails.  At \((p,R,a)=(73,11,21)\),
\[
S_{11,21}=\{1,3,4,5,7,8,9,10\},
\qquad
(r_{-1},r_0,r_1)=(8,1,7),
\]
so both channels are occupied, while multiplication by
\(p\equiv7\pmod{11}\) does not preserve the support.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:endpoint-support-orbit-classification.

Exact checker and stored receipt:
verification/verify_endpoint_support_stabilizers.py and
verification/verify_endpoint_support_stabilizers_output.txt.
Across 67810 admissible shells through \(p=2000\), the occupancy
counts are 65253 empty, 1642 exterior-only, 314 middle-only, and 601
both-channel.  No one-sided support is preserved by multiplication by
\(p\).

## Complete Boolean endpoint-to-blade cell bridge

For the three target-support bits
\[
b_j=\mathbf1_{S_{R,a}}(r_j),
\]
reflection gives \(b_{-1}=b_1\).  In the Boolean-status basis
\[
e_1=e_+,\qquad e_0=e_-,
\]
the first and second directed target edges are
\[
C_{-0}=e_{b_0}e_{b_{-1}}^{\mathsf T},
\qquad
C_{0+}=e_{b_1}e_{b_0}^{\mathsf T}=C_{-0}^{\mathsf T}.
\]
Their complete table is
\[
\begin{array}{c|c|c|c|c}
\text{status}&(b_{-1},b_0,b_1)&
(b_0-b_{-1},b_1-b_0)&C_{-0}&C_{0+}\\
\hline
\text{empty}&000&(0,0)&E_{22}&E_{22}\\
\text{exterior only}&101&(-1,+1)&E_{21}&E_{12}\\
\text{middle only}&010&(+1,-1)&E_{12}&E_{21}\\
\text{both}&111&(0,0)&E_{11}&E_{11}.
\end{array}
\]
The Hadamard images of the ordered edge pair are
\[
\begin{array}{c|c}
\text{empty}&(P_-,P_-)\\
\text{exterior only}&(B_{-+},B_{+-})\\
\text{middle only}&(B_{+-},B_{-+})\\
\text{both}&(P_+,P_+).
\end{array}
\]
Thus each one-sided pattern contains both off-diagonal cells, in
opposite edge order.  The matrix signs satisfy
\[
J_{\mathrm B}C_{-0}=(2b_0-1)C_{-0},
\qquad
C_{-0}J_{\mathrm B}=(2b_{-1}-1)C_{-0}.
\]
The bridge determines the Boolean cell; fibre populations remain in
the three-fibre rank identity.

The \(R=107\) shell fixes the directed selection.  It is middle-only
with \(q=1\), so
\[
C_{-0}=E_{12},\qquad C_{0+}=E_{21},
\]
and
\[
2qC_{0+}=2E_{21}=\mathcal M(53).
\]
The coefficient of the incoming transposed cell \(E_{12}\) at residue
\(53\) is zero.  Hence the proved blade coefficient selects the
outgoing edge \(r_0\to r_1\).

Exact source: es_fable_c123_preprint.tex,
Theorem thm:endpoint-Boolean-blade-cell-bridge and
Corollary cor:R107-outgoing-Boolean-blade-selection.

Exact checker and stored receipt:
verification/verify_endpoint_Boolean_blade_bridge.py and
verification/verify_endpoint_Boolean_blade_bridge_output.txt.

### Dependency propagation of the outgoing-edge correction

The directional result is carried through every statement whose content
depends on the \(107\)-shell coefficient:

- the abstract records the support word \(010\), outgoing \(E_{21}\), and
  incoming \(E_{12}\) with zero residue-\(53\) coefficient;
- the root proposition for \(\mathcal M(53)\) identifies its nonzero entry
  as \(C_{0+}\);
- the Hadamard mixer and quarter-inversion theorems retain the outgoing
  direction;
- the champion orbit and branch-scale statements identify
  \(2q_{107,p_\ast}C_{0+}=2E_{21}\);
- the parity-sheet and first-\(107\)-shell calculations display both
  directed cells;
- the later history crosswalk uses the outgoing line while retaining its
  stated ambient-multiplication limitation.

Exact dependency checker and stored receipt:
verification/verify_outgoing_edge_dependency_propagation.py and
verification/verify_outgoing_edge_dependency_propagation_output.txt.

## Safe-residual parity-sheet reduction

Let
\[
R=2q+1
\]
with \(R\) and the odd integer \(q\) prime.  For a primitive
logarithm
\[
\lambda_R:U_R\longrightarrow\mathbb Z/(2q)\mathbb Z,
\qquad
r_R=\lambda_R(2),
\]
the two unshifted shell targets are
\[
\lambda_R(-1)=q,
\qquad
\lambda_R(-4^{-1})=q-2r_R.
\]
Both are odd.  After repeating the prime factors of \(a\) according
to valuation, every middle representation uses coefficients in
\(\{-1,0,1\}\), every exterior representation uses coefficients in
\(\{0,1,2\}\), and each target representation has an odd number of
odd-log occurrences carrying odd coefficients.  An all-even
factor-log profile therefore has an empty shell.

The same theorem has a primitive-root-free form.  If \(Q_R\) is the
quadratic-residue subgroup and \(\chi_R\) is the quadratic character,
then
\[
\Phi_R(u)=\bigl(\chi_R(u),\chi_R(u)u\bigr)
\]
is a canonical isomorphism
\[
U_R\cong\{\pm1\}\times Q_R.
\]
It sends the shell targets to
\[
-1\longmapsto(-1,1),
\qquad
-4^{-1}\longmapsto(-1,4^{-1}).
\]
Thus both targets live on the nonresidue sheet, while their second
coordinates live in the odd-order group \(Q_R\).  For \(R=7\),
\[
Q_7=\{1,2,4\}=\langle2\rangle\cong C_3
\]
and
\[
U_7\cong C_2\times C_3,\qquad
s_7\mapsto(-1,1),\qquad
t_7\mapsto(-1,2).
\]
This is the exact arithmetic binary-sheet/three-phase carrier.  The
Boolean coordinate \(\mathbf1_{\{q_{7,p}>0\}}\) records target
support.

If \(k\) is the unique odd factor-log occurrence and the remaining
logs are \(2h_i\), put
\[
\mathscr A_R^{\mathrm M}
=
\left\{\sum_i\delta_i h_i:\delta_i\in\{-1,0,1\}\right\},
\qquad
\mathscr A_R^{\mathrm E}
=
\left\{\sum_i\epsilon_i h_i:\epsilon_i\in\{0,1,2\}\right\}.
\]
Then the exact quotient criterion in \(\mathbb Z/q\mathbb Z\) is
\[
q_{R,p}>0
\iff
\frac{q-k}{2}\in\mathscr A_R^{\mathrm M}
\quad\text{or}\quad
\frac{q+k}{2}\in\mathscr A_R^{\mathrm M}
\quad\text{or}\quad
\frac{q-2r_R-k}{2}\in\mathscr A_R^{\mathrm E}.
\]

For the \(R=107\) Busy-Beaver carrier,
\[
q=53,\qquad r_{107}=1,\qquad k=\lambda_{107}(43)=59,
\]
and the even half-log multiset is
\[
(35,35,11,11,33).
\]
The reduced targets are \(50,3,49\).  The first two have the unique
aggregate representatives
\[
(2,0,1),\qquad(-2,0,-1),
\]
and \(49\) has no exterior representative.  These lift to the two
centered vectors
\[
(-2,0,-1,-1),\qquad(2,0,1,1).
\]
The unshifted exterior target is \(51\), while
\[
\lambda_{107}(a_\ast)=97,\qquad51-97=60\pmod{106},
\]
which proves the exact transport to the centered exterior coordinate
already used by the champion theorem.

Exact source: es_fable_c123_preprint.tex,
Theorem thm:safe-residual-parity-sheet-reduction and
Corollary cor:safe-residual-Legendre-sheet-form and
Corollary cor:R107-exact-parity-sheets.

Exact checker and stored receipt:
verification/verify_safe_residual_parity_bridge.py and
verify_safe_residual_parity_bridge_output.txt.  The replay checks the
canonical sheet isomorphism and target images for all safe residual
primes through \(1000\), the exact \(R=7\) carrier, \(255837\)
one-odd profiles through \(R=107\), the two unique middle vectors, the
empty exterior fibre, and the centered target transport.

## Coupled-shell equality of complete divisor sections

For a coupled shell \(R\mid p-1\), the affine relation
\[
p=4a-R
\]
gives
\[
4a\equiv1\pmod R,
\qquad
a\equiv4^{-1}\pmod R.
\]
Consequently, for every divisor \(u\mid a^2\),
\[
R\mid4u+1
\iff
u\equiv-4^{-1}
\iff
u\equiv-a
\iff
R\mid u+a.
\]
The complete endpoint divisor sections are therefore literally equal:
\[
\boxed{\mathcal E_{R,a}=\mathcal M_{R,a}}.
\]
This strengthens the earlier equality of channel counts.  The common
section is complement-stable, has no complement fixed point, and
satisfies
\[
q_{R,p}
=
\frac32|\mathcal E_{R,a}|
=
\frac32|\mathcal M_{R,a}|.
\]
Thus a coupled shell is occupied exactly when this one common divisor
section is nonempty.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:coupled-shell-divisor-section-equality.

Exact checker and stored receipt:
verification/verify_coupled_shell_three_orbit_balance.py and
verify_coupled_shell_three_orbit_balance_output.txt.  The fresh replay
checks literal divisor-set equality in all \(625\) coupled shells
through \(p=5000\), together with the packet and three-orbit
identities.

## Complete odd-bearing residual-twenty-three down-set

Omit factors whose logarithm is \(0\).  Let \(O(b)\) be the multiset
of odd factor logarithms of \(b\), and let \(V(b)\) be the multiset of
nonzero even factor logarithms.  The empty \(R=23\) profiles have the
complete form
\[
q_{23,p}=0
\iff
O(b)=\varnothing
\quad\text{or}\quad
(O(b),V(b))\preccurlyeq(O_i,V_i)
\]
for one of \(25\) explicit maximal pairs.  Here
\(\preccurlyeq\) denotes the componentwise submultiset order.

The \(25\) maximal pairs are
\[
\begin{array}{c|c}
O_i&V_i\\ \hline
15^2&16\\
15^2&8^2\\
15^4&8\\
15^6&\varnothing\\
9,15&\varnothing\\
9^2&6\\
3,21&\varnothing\\
3,15&6\\
3,9&12\\
3,9&6^2\\
3^2&18\\
3^2&6,12\\
3^2&6^3\\
3^2,9^2&\varnothing\\
3^3,15&\varnothing\\
3^3,9&6\\
3^4&12\\
3^4&6^2\\
3^5,9&\varnothing\\
3^6&6\\
3^8&\varnothing\\
1,21&2\\
1,15&8\\
1,15^3&\varnothing\\
1^3,21&\varnothing
\end{array}
\]
and there are exactly \(82\) odd-bearing safe profiles.  Their
canonical row hash is
c854a92934205485e9ff4ff440ff2cb107f1fc0666ded9d8a554fead9e3393a8.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:R23-complete-odd-bearing-downset.

Exact checker and stored receipt:
verification/verify_residual_twenty_three_factor_classification.py
and verify_residual_twenty_three_factor_classification_output.txt.
It compares the fixed and moving criteria and the original divisor
definitions on 2870 reduced coordinates and 555 prime shells.

## Unrestricted first-six survivor criterion

For
\[
c=\frac{p+11}{12},
\]
the first six reduced coordinates are
\[
(3c-2,3c-1,c,3c+1,3c+2,c+1).
\]
All shells through \(R=23\) are empty exactly when the exact first-four
conditions hold and
\[
\mathfrak m_{19}^{\log}(3c+2)\notin I_{19}^{\log},
\qquad
\mathfrak m_{23}^{\log}(c+1)\notin J_{23}^{(3)}.
\]
The Euclidean algorithm proves that different reduced coordinates can
share no prime factor except \(2\) or \(5\).

Exact source: es_fable_c123_preprint.tex,
Corollary cor:exact-unrestricted-first-six-survivor-criterion.

## Parity-split residual-twenty-three survivor bounds

For an empty \(R=23\) shell, write
\[
\alpha_k=\nu_k^{23}(b).
\]
The degree-one carriers force
\[
\alpha_5=\alpha_7=\alpha_{11}
=\alpha_{13}=\alpha_{17}=\alpha_{19}=0.
\]
In the coordinate order
\[
(\alpha_1,\alpha_3,\alpha_9,\alpha_{15},\alpha_{21}),
\]
the odd sector is contained in the coordinatewise down-set generated
by
\[
\begin{aligned}
\{&(0,0,0,6,0),(0,0,1,1,0),(0,1,0,0,1),
(0,2,2,0,0),\\
 &(0,3,0,1,0),(0,5,1,0,0),(0,8,0,0,0),
(1,0,0,3,0),(3,0,0,0,1)\}.
\end{aligned}
\]
There are exactly \(39\) safe odd-sector vectors.  The pure-class
first-occupation multiplicities for \(k=1,3,9,15,21\) are
\[
4,9,3,7,2.
\]

Let
\[
\eta_{23}(b)=\sum_{j=1}^{10}\nu_{2j}^{23}(b).
\]
If one of the odd classes \(1,9,15,21\) occurs, an empty shell has
\(\eta_{23}(b)\le2\).  If the odd sector is supported only at class
\(3\), an empty shell has \(\eta_{23}(b)\le3\).  If every nonzero
factor logarithm is even, the shell is empty.

The coupling bounds follow in \(\mathbb Z/11\mathbb Z\).  The even-log
middle sumset has cardinality at least
\[
\min(2\eta_{23}(b)+1,11)
\]
by Cauchy--Davenport.  The target-difference sets attached to the five
safe odd classes have cardinalities
\[
6,4,6,6,6.
\]
Disjointness from the even-log sumset gives the two bounds above.

Exact source: es_fable_c123_preprint.tex,
Corollary cor:R23-parity-split-survivor-bounds.

Exact checker:
verification/verify_residual_twenty_three_factor_classification.py.

# Fable–Erdős–Strauss higher-dimensional carrier

## Active question

The coordinate bounds and residual variables in the Erdős–Strauss programme
are to be compared with the Fable/JGPTech marked-factor construction as
analogous mathematics.  The operative issue is whether a fractional or
piecewise coordinate downstairs is the projection of a regular coordinate on
an affine carrier with one additional direction of freedom.

## Exact cubic step

For the Fable construction, a marked linear–quadratic factorization has five
coefficients:

\[
L=aU+bV,
\qquad
Q=cU^2+dUV+eV^2.
\]

The resultant-one locus has dimension four.  Fixing the visible coefficient
\(ad+bc=1\) gives the three-dimensional affine chart that reconstructs the
Fable map.  Its residual coordinates

\[
y=\frac{b-1}{a},
\qquad
z=\frac{c-1+\frac32ay}{a^2}
\]

are regular on the lifted incidence carrier.  Their fractional appearance is
created by eliminating the factor coordinates.

## Exact quartic Erdős–Strauss step

Let

\[
L=aU+bV,
\qquad
Q_3=cU^3+dU^2V+eUV^2+fV^3.
\]

On \(ac\ne0\), write

\[
p=-\frac ba,
\qquad
\frac{Q_3}{c}=(U-xV)(U-yV)(U-zV).
\]

Then

\[
\frac4p=\frac1x+\frac1y+\frac1z
\quad\Longleftrightarrow\quad
4af-be=0.
\]

The equation is gauge invariant under

\[
(L,Q_3)\longmapsto(\lambda L,\lambda^{-1}Q_3)
\]

and has the determinant form

\[
4af-be
=
\det
\begin{pmatrix}
2a&b\\
e&2f
\end{pmatrix}.
\]

Therefore the Erdős–Strauss relation is a rank-one determinantal carrier
inside the marked linear–cubic factor space.

The quartic resultant is

\[
R_4=-b^3c+ab^2d-a^2be+a^3f.
\]

The locus \(Y_4=\{R_4=1\}\subset\mathbb C^6\) is five-dimensional.  The
Erdős–Strauss locus

\[
X_{\mathrm{ES}}=\{R_4=1,\ 4af-be=0\}
\]

is a smooth fourfold.  Indeed, \(b=0\) would imply both \(a^3f=1\) and
\(4af=0\), which is impossible.  The \((c,e)\)-minor of the two defining
differentials is \(b^4\), hence has no zero on this locus.

This is the exact four-dimensional layer inside a five-dimensional upstairs
carrier anticipated in the research discussion.

## Adjacent-simplex coordinate

For a centered regular simplex with \(r\) vertices, the Gram matrix is

\[
G_r=
\frac r{r-1}
\left(I-\frac1r\mathbf1\mathbf1^{\mathsf T}\right),
\qquad
\operatorname{rank}G_r=r-1.
\]

The four-dimensional layer has the five-vertex Gram coefficient \(-1/4\).
The five-dimensional layer has the six-vertex Gram coefficient \(-1/5\).
The established adjacent-simplex projection theorem gives the shared
four-to-five-dimensional reciprocal \(-1/5\): it is the normalized
face-centroid coordinate in the lower four-simplex and the common hidden
displacement of the upper five-simplex facet.

The dimension statement and the determinant carrier are proved.  The active
proof problem is to construct the metric/frame intertwiner that sends the
natural tangent and normal data of \(X_{\mathrm{ES}}\subset Y_4\) to this
adjacent-simplex pair.  That intertwiner would make the \(-1/5\) coordinate a
property of the Erdős–Strauss carrier itself.

## Exact source locations

- Maintained theorem source:
  `reader/erdos_straus_project_reader.tex`
- Maintained research log:
  `provenance/research_logbook.tex`
- JGPTech marked-factor proof:
  `supporting_sources/JGPTech_Fun/Jacobian/Local_Fidelity_Global_Alias_Pipeline_Proof.tex`
- JGPTech audit:
  `verification/JGPTECH_PIPELINE_AUDIT.md`
- Verbatim historical discussion:
  `private historical discussion omitted from the public archive`
- Exact checker added for this step:
  `verification/verify_es_quartic_marked_factor_lift.py`

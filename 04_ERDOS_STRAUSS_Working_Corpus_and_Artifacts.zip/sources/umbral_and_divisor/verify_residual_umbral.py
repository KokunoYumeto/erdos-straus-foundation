#!/usr/bin/env python3
"""
Finite symbolic checks for the residual-umbral completion preprint.
No external packages are required.  All computations are exact integer or
rational arithmetic.
"""
from fractions import Fraction
from itertools import product, permutations
from collections import Counter, defaultdict
import math


def egcd(a, b):
    if b == 0:
        return (abs(a), 1 if a > 0 else -1, 0)
    g, x1, y1 = egcd(b, a % b)
    return (g, y1, x1 - (a // b) * y1)


def inv_mod(a, m):
    a %= m
    g, x, _ = egcd(a, m)
    if g != 1:
        raise ValueError(f"{a} is not a unit modulo {m}")
    return x % m


def factorint(n):
    out = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def legendre_symbol(a, p):
    a %= p
    if a == 0:
        return 0
    r = pow(a, (p - 1) // 2, p)
    return 1 if r == 1 else -1


def units_mod(n):
    return {a for a in range(n) if math.gcd(a, n) == 1}


def qA5(k):
    k %= 6
    return Fraction(5 * k * k, 6)  # equivalent mod 2Z to k(6-k)/6


def muA5(k):
    k %= 6
    return Fraction(k * (6 - k), 6)


def qD4(e, f):
    return Fraction(0) if (e, f) == (0, 0) else Fraction(1)


def muD4(e, f):
    return qD4(e, f)


def add_disc(x, y):
    return tuple([(x[i] + y[i]) % 6 for i in range(4)] + [x[4] ^ y[4], x[5] ^ y[5]])


def mul_disc(n, x):
    r = (0, 0, 0, 0, 0, 0)
    for _ in range(n):
        r = add_disc(r, x)
    return r


def q_disc(x):
    return sum(qA5(k) for k in x[:4]) + qD4(x[4], x[5])


def mu_disc(x):
    return sum(muA5(k) for k in x[:4]) + muD4(x[4], x[5])


def mod2_zero(fr):
    return fr.denominator == 1 and fr.numerator % 2 == 0


def subgroup_generated(gens, mod_ranges=(6, 6, 6)):
    H = set()
    for coeffs in product(*[range(m) for m in mod_ranges]):
        v = (0, 0, 0, 0, 0, 0)
        for c, g in zip(coeffs, gens):
            v = add_disc(v, mul_disc(c, g))
        H.add(v)
    return H


def gl2_f2():
    mats = []
    for a, b, c, d in product([0, 1], repeat=4):
        if (a * d - b * c) % 2 == 1:
            mats.append((a, b, c, d))
    return mats


def d_apply(M, e, f):
    a, b, c, d = M
    return ((a * e + b * f) % 2, (c * e + d * f) % 2)


def act_ambient(elem, x):
    signs, perm, M = elem
    ys = [(signs[i] * x[perm[i]]) % 6 for i in range(4)]
    e, f = d_apply(M, x[4], x[5])
    return tuple(ys + [e, f])


def order_action(elem):
    gens = [(1,0,0,0,0,0),(0,1,0,0,0,0),(0,0,1,0,0,0),
            (0,0,0,1,0,0),(0,0,0,0,1,0),(0,0,0,0,0,1)]
    curr = gens[:]
    for n in range(1, 200):
        curr = [act_ambient(elem, y) for y in curr]
        if curr == gens:
            return n
    return None


def perm_order(perm):
    seen = [False] * len(perm)
    lcm = 1
    for i in range(len(perm)):
        if not seen[i]:
            j = i; c = 0
            while not seen[j]:
                seen[j] = True; c += 1; j = perm[j]
            lcm = math.lcm(lcm, c)
    return lcm


def gl2_f3():
    mats = []
    for a, b, c, d in product(range(3), repeat=4):
        if (a * d - b * c) % 3 != 0:
            mats.append((a, b, c, d))
    return mats


def mat_vec_f3(M, v):
    a,b,c,d = M
    x,y = v
    return ((a*x+b*y)%3, (c*x+d*y)%3)


def proj_point(v):
    x,y = v
    if x % 3 != 0:
        inv = inv_mod(x, 3)
        return (1, (y*inv)%3)
    inv = inv_mod(y, 3)
    return (0, 1)


def eta_recip_coeffs(maxq=6):
    # 1/eta_pi = q^{-1} prod_{n>=1} (1-q^n)^5 (1-q^{2n})^{-1}
    #                         * (1-q^{3n}) (1-q^{6n})^{-5}
    factors = [(1, 5), (2, -1), (3, 1), (6, -5)]
    coeff = [0]*(maxq+1); coeff[0]=1
    def mul_series(a,b):
        out=[0]*(maxq+1)
        for i,ai in enumerate(a):
            if ai==0: continue
            for j,bj in enumerate(b):
                if bj and i+j <= maxq:
                    out[i+j] += ai*bj
        return out
    for n, exp in factors:
        m = 1
        while n*m <= maxq:
            N=n*m
            f=[0]*(maxq+1)
            if exp >= 0:
                # (1-q^N)^exp finite
                for k in range(exp+1):
                    deg=N*k
                    if deg<=maxq:
                        f[deg] = math.comb(exp,k)*((-1)**k)
            else:
                a=-exp
                # (1-q^N)^(-a)=sum_{k>=0} binom(a+k-1,k) q^{Nk}
                for k in range(0, maxq//N + 1):
                    f[N*k] = math.comb(a+k-1,k)
            coeff=mul_series(coeff,f)
            m += 1
    return coeff


def signed_support_hits(modulus, fac):
    qs=list(fac.keys()); es=[fac[q] for q in qs]
    values=[]
    for beta in product(*[range(-e,e+1) for e in es]):
        val=1
        for q,b in zip(qs,beta):
            val=(val*pow(q,b,modulus))%modulus
        values.append((beta,val))
    return qs,es,values


def main():
    lines=[]
    def ok(name, value):
        lines.append(f"[OK] {name}: {value}")

    # 1. Modulo-840 fibration.
    U = units_mod(840)
    V = {r for r in U if r % 24 == 1}
    S = {r for r in V if legendre_symbol(r,5)==1 and legendre_symbol(r,7)==1}
    expected_S = {1,121,169,289,361,529}
    fibers=defaultdict(list)
    for r in V:
        fibers[(legendre_symbol(r,5), legendre_symbol(r,7))].append(r)
    assert len(V)==24
    assert S==expected_S
    assert sorted(len(v) for v in fibers.values()) == [6,6,6,6]
    powers=[pow(289,j,840) for j in range(6)]
    assert powers==[1,289,361,169,121,529]
    assert pow(289,6,840)==1
    ok("|V_840|", len(V))
    ok("fiber sizes for (chi_5,chi_7)", sorted(len(v) for v in fibers.values()))
    ok("<289> in S_840", powers)

    # 2. Discriminant glue.
    h1=(1,3,1,1,0,0); h2=(1,4,2,3,1,1); h3=(3,0,3,0,0,1)
    H = subgroup_generated([h1,h2,h3])
    assert len(H)==72
    assert all(mod2_zero(q_disc(x)) for x in H)
    ambient_size = 6**4*4
    assert ambient_size == 72**2
    nonzero=[x for x in H if x!=(0,0,0,0,0,0)]
    dist=Counter(mu_disc(x)*6 for x in nonzero)
    assert min(mu_disc(x) for x in nonzero) == 4
    assert dist == Counter({Fraction(24):46, Fraction(36):25})
    ok("|H_ES|", len(H))
    ok("ambient discriminant size", ambient_size)
    ok("all glue elements isotropic", True)
    ok("6*minimum norm distribution on H_ES\\{0}", dict(dist))

    # 3. Glue automorphism group.
    GL2 = gl2_f2()
    pres=[]
    perms=list(permutations(range(4)))
    for signs in product([1,-1], repeat=4):
        for perm in perms:
            for M in GL2:
                elem=(signs,perm,M)
                if {act_ambient(elem,x) for x in H} == H:
                    pres.append(elem)
    byperm=defaultdict(list)
    for e in pres:
        byperm[e[1]].append(e)
    order_counts=Counter(order_action(e) for e in pres)
    assert len(pres)==48
    assert len(byperm)==24
    assert Counter(len(v) for v in byperm.values()) == Counter({2:24})
    assert all(all(order_action(e)==8 for e in v) for perm,v in byperm.items() if perm_order(perm)==4)
    ok("glue automorphism count", len(pres))
    ok("projection to S4 and lifts per permutation", f"{len(byperm)} permutations, {Counter(len(v) for v in byperm.values())}")
    ok("orders in glue symmetry", dict(order_counts))
    ok("all lifts over 4-cycles have order", 8)

    # 4. GL2(3) quotient check.
    G3=gl2_f3()
    P1=[(1,0),(1,1),(1,2),(0,1)]
    perms_seen=set(); kernel=[]
    for M in G3:
        image=tuple(P1.index(proj_point(mat_vec_f3(M,p))) for p in P1)
        perms_seen.add(image)
        if image == (0,1,2,3):
            kernel.append(M)
    assert len(G3)==48
    assert len(perms_seen)==24
    assert len(kernel)==2
    ok("|GL_2(F_3)|", len(G3))
    ok("PGL_2(F_3) action on P^1(F_3)", f"{len(perms_seen)} permutations, kernel size {len(kernel)}")

    # 5. Coxeter frame/eta product.
    frame={1:-5,2:1,3:-1,6:5}
    assert sum(n*k for n,k in frame.items())==24
    coeff=eta_recip_coeffs(6)
    # Reciprocal eta product is q^{-1}*(coeff[0]+coeff[1]q+...)
    assert coeff[0]==1 and coeff[1]==-5
    ok("Coxeter frame shape", frame)
    ok("sum n*k_n", sum(n*k for n,k in frame.items()))
    ok("1/eta_pi expansion coefficients after q^{-1}", coeff[:7])

    # 6. E8 square-exponent calibration.
    E8=[1,7,11,13,17,19,23,29]
    squares=sorted({(e*e)%30 for e in E8})
    image=sorted({r%30 for r in expected_S})
    kernel=[r for r in expected_S if r%30==1]
    assert squares==[1,19]
    assert image==[1,19]
    assert len(kernel)==3
    ok("E8 exponent squares mod 30", squares)
    ok("S840 image mod 30", image)
    ok("kernel size of S840 -> {1,19}", len(kernel))

    # 7. Champion certificate R=107.
    p=8803369; R=107; a=(p+R)//4
    assert p%840==169
    fac=factorint(a)
    assert fac=={3:2,11:2,43:1,47:1}
    qs,es,values=signed_support_hits(R, fac)
    target1=(-1)%R; target2=(-inv_mod(p,R))%R
    hits=[(beta,val) for beta,val in values if val in (target1,target2)]
    assert hits==[((-2,0,-1,-1),106),((2,0,1,1),106)]
    beta=hits[0][0]
    u=1
    for q,e,beta_j in zip(qs, es, beta):
        u *= q**(e+beta_j)
    N=p*a; d=p*u; ecomp=N*N//d
    bden=(N+d)//R; cden=(N+ecomp)//R
    assert d%R == (-N)%R
    assert 4*bden*cden == p*(bden+cden) + (p*bden*cden)//a  # equivalent after multiplying? check separately below
    # Direct integer equality: 4/p = 1/a + 1/b + 1/c -> multiply by pabc.
    assert 4*a*bden*cden == p*bden*cden + p*a*cden + p*a*bden
    ok("champion p mod 840", p%840)
    ok("R=107 a factorization", fac)
    ok("R=107 two-channel hits", hits)
    ok("R=107 certificate u,d,b,c", (u,d,bden,cden))

    # 8. Bounded exponent obstruction example at R=43.
    p=8803369; R=43; a=(p+R)//4
    fac=factorint(a)
    assert fac=={379:1,5807:1}
    qs,es,values=signed_support_hits(R, fac)
    t1=(-1)%R; t2=(-inv_mod(p,R))%R
    hits43=[(beta,val) for beta,val in values if val in (t1,t2)]
    saturated=(pow(379,2,R)*5807)%R
    assert hits43==[]
    assert saturated==t1
    ok("R=43 a factorization", fac)
    ok("R=43 bounded-box hits for {-1,-p^-1}", hits43)
    ok("R=43 saturated witness 379^2*5807 mod 43", saturated)

    report="\n".join(lines)+"\n"
    print(report)

if __name__ == "__main__":
    main()

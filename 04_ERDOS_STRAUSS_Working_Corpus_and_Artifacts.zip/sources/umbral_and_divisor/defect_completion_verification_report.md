# Defect-completed residual verification report

- **V840_size**: `24`
- **S840_sorted**: `[1, 121, 169, 289, 361, 529]`
- **powers_289**: `[1, 289, 361, 169, 121, 529]`
- **H2_order**: `8`
- **H3_order**: `9`
- **H3_nonzero_weights**: `[3]`
- **glue_order**: `72`
- **glue_isotropic_all**: `True`
- **glue_nonzero_min_norms**: `['4', '6']`
- **GL2F3_order**: `48`
- **GL2F3_center_order**: `2`
- **PGL2F3_image_order_on_P1**: `24`
- **PGL2F3_kernel_order**: `2`
- **eta_reciprocal_coefficients_excluding_q_minus_1**: `[1, -5, 6, 4, -3, -12, -8, 12, 30]`
- **C3_positive_inverse_ok**: `True`
- **C3_supported_zero_inverse_ok**: `True`
- **C4_positive_matrix**: `[[1, 1, 1, 1], [1, 0, 1, 0], [1, 1, 0, 1], [1, 0, 1, 0]]`
- **C4_kernel_e2_minus_e4_image**: `[0, 0, 0, 0]`
- **pair_zeta_character_mismatches**: `[]`

## Champion shell p=8803369, R=107

- **p**: `8803369`
- **R**: `107`
- **a**: `2200869`
- **X**: `1`
- **Y**: `18189`
- **Z**: `121`
- **X_plus_Y**: `18190`
- **pair_certificate_ok**: `True`
- **reduced_b**: `20570`
- **reduced_c**: `374147730`
- **p_mod_840**: `169`
- **kappa**: `3`

## Failed finite-capacity shell p=8803369, R=43

- **p**: `8803369`
- **R**: `43`
- **a**: `2200853`
- **factors**: `[(379, 1), (5807, 1)]`
- **379_squared_times_5807_mod_43**: `42`
- **equals_minus_one**: `True`
- **finite_signed_support**: `[1, 2, 8, 16, 22, 27, 32, 35, 39]`
- **finite_two_channel_certificate**: `False`
- **p_mod_840**: `169`
- **kappa**: `3`

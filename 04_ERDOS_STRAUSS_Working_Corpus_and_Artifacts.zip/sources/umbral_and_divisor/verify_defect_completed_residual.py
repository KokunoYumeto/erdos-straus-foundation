#!/usr/bin/env python3
from __future__ import annotations
import itertools, json, math, cmath
from fractions import Fraction
from pathlib import Path

# ---------- elementary utilities ----------

def inv_mod(a:int,m:int)->int:
    a%=m
    if math.gcd(a,m)!=1:
        raise ValueError((a,m))
    return pow(a,-1,m)

def units_mod(n:int):
    return [r for r in range(n) if math.gcd(r,n)==1]

def legendre_prime(a:int,p:int):
    a%=p
    if a==0: return 0
    v=pow(a,(p-1)//2,p)
    return 1 if v==1 else -1

def factor(n:int):
    out=[]
    d=2
    while d*d<=n:
        if n%d==0:
            e=0
            while n%d==0:
                n//=d; e+=1
            out.append((d,e))
        d += 1 if d==2 else 2
    if n>1: out.append((n,1))
    return out

# ---------- 840 data ----------
V840=[r for r in units_mod(840) if r%24==1]
S840=[r for r in V840 if legendre_prime(r,5)==1 and legendre_prime(r,7)==1]
powers289=[pow(289,j,840) for j in range(6)]
kappa={pow(289,j,840):j for j in range(6)}
fibers={}
for r in V840:
    chi=(legendre_prime(r,5),legendre_prime(r,7))
    fibers.setdefault(str(chi),[]).append(r)

# ---------- duad/tetracode glue ----------
H2=[
    ((0,0,0,0),0), ((1,1,1,1),0),
    ((1,1,0,0),1), ((0,0,1,1),1),
    ((1,0,1,0),2), ((0,1,0,1),2),
    ((1,0,0,1),3), ((0,1,1,0),3),
]
TGEN=[(1,1,1,0),(1,2,0,1)]
H3=[]
for a,b in itertools.product(range(3), repeat=2):
    H3.append(tuple((a*TGEN[0][i]+b*TGEN[1][i])%3 for i in range(4)))
H3=sorted(set(H3))

def qA5(k:int)->Fraction:
    k%=6
    return Fraction(5*k*k,6)

def minA5(k:int)->Fraction:
    k%=6
    return Fraction(k*(6-k),6)

def qD(y:int)->Fraction:
    return Fraction(0) if y==0 else Fraction(1)

def even_mod_2(q:Fraction)->bool:
    return q.denominator==1 and q.numerator%2==0

H_glue=[]
for u,y in H2:
    for v in H3:
        k=tuple((3*u[i]+2*v[i])%6 for i in range(4))
        H_glue.append((k,y,u,v))
H_glue_set=set((k,y) for k,y,_,_ in H_glue)
glue_isotropic=[]
min_norms=[]
for k,y,u,v in H_glue:
    q=sum(qA5(ki) for ki in k)+qD(y)
    glue_isotropic.append(even_mod_2(q))
    mn=sum(minA5(ki) for ki in k)+(Fraction(0) if y==0 else Fraction(1))
    if k!=(0,0,0,0) or y!=0:
        min_norms.append(mn)

# ---------- GL(2,3) action on P1 ----------
def matmul(A,B):
    return tuple(tuple(sum(A[i][k]*B[k][j] for k in range(2))%3 for j in range(2)) for i in range(2))
def det(A): return (A[0][0]*A[1][1]-A[0][1]*A[1][0])%3
GL23=[]
for entries in itertools.product(range(3), repeat=4):
    A=((entries[0],entries[1]),(entries[2],entries[3]))
    if det(A)!=0: GL23.append(A)
center=[A for A in GL23 if all(matmul(A,B)==matmul(B,A) for B in GL23)]
P1=[(1,0),(0,1),(1,1),(1,2)]
def normalize_vec(v):
    a,b=v[0]%3,v[1]%3
    if a!=0:
        z=inv_mod(a,3); return ((a*z)%3,(b*z)%3)
    z=inv_mod(b,3); return ((a*z)%3,(b*z)%3)
def act(A,v):
    return normalize_vec((A[0][0]*v[0]+A[0][1]*v[1], A[1][0]*v[0]+A[1][1]*v[1]))
perms=[]
for A in GL23:
    perms.append(tuple(P1.index(act(A,v)) for v in P1))
image=set(perms)
kernel=[A for A,perm in zip(GL23,perms) if perm==(0,1,2,3)]

# ---------- eta product reciprocal q^{-1} factor ----------
def poly_mul(a,b,maxdeg):
    c=[0]*(maxdeg+1)
    for i,x in enumerate(a):
        if x==0: continue
        for j,y in enumerate(b):
            if y==0 or i+j>maxdeg: continue
            c[i+j]+=x*y
    return c

def factor_series(step, exponent, maxdeg):
    coeff=[0]*(maxdeg+1); coeff[0]=1
    if exponent>=0:
        for k in range(exponent+1):
            if step*k<=maxdeg:
                coeff[step*k]=((-1)**k)*math.comb(exponent,k)
    else:
        m=-exponent
        k=0
        while step*k<=maxdeg:
            coeff[step*k]=math.comb(m+k-1,k)
            k+=1
    return coeff

def eta_recip(maxdeg=8):
    # reciprocal of eta_pi: eta^5 eta(3)/(eta(2) eta(6)^5), excluding q^-1
    poly=[0]*(maxdeg+1); poly[0]=1
    for n in range(1,maxdeg+1):
        for step,exp in [(n,5),(3*n,1),(2*n,-1),(6*n,-5)]:
            if step<=maxdeg:
                poly=poly_mul(poly,factor_series(step,exp,maxdeg),maxdeg)
    return poly
eta_coeffs=eta_recip(8)

# ---------- boundary matrices ----------
def matmul_int(A,B):
    n=len(A); m=len(B[0]); k=len(B)
    return [[sum(A[i][t]*B[t][j] for t in range(k)) for j in range(m)] for i in range(n)]
C3p=[[1,1,1],[1,0,1],[1,1,0]]
C3p_inv=[[-1,1,1],[1,-1,0],[1,0,-1]]
C3z=[[0,1,0,0],[1,1,1,1],[0,1,0,1],[0,1,1,0]]
C3z_inv=[[1,1,-1,-1],[1,0,0,0],[-1,0,0,1],[-1,0,1,0]]
C4p=[[1 if math.gcd(i,j)==1 else 0 for j in range(1,5)] for i in range(1,5)]
ker_C4=[C4p[i][1]-C4p[i][3] for i in range(4)]

# ---------- pair-cover zeta coefficient brute force vs character formula ----------
def A_R_n(R,n):
    count=0
    triples=[]
    for X in range(1,n+1):
        if n%X: continue
        for Y in range(1,n//X+1):
            if (n//X)%Y: continue
            Z=n//(X*Y)
            if math.gcd(X,Y)==1 and (X+Y)%R==0 and math.gcd(n,R)==1:
                count+=1; triples.append((X,Y,Z))
    return count, triples
# Verify for small R,n by enumerating indicator formula with characters manually for cyclic mod prime R=5.
def chars_mod_prime(p):
    # primitive generator
    units=[u for u in range(1,p) if math.gcd(u,p)==1]
    g=None
    for cand in units:
        if len({pow(cand,k,p) for k in range(1,p)})==p-1:
            g=cand; break
    log={pow(g,k,p):k for k in range(p-1)}
    def chi(k,a):
        if math.gcd(a,p)!=1: return 0
        return cmath.exp(2j*math.pi*k*log[a%p]/(p-1))
    return [lambda a,k=k: chi(k,a) for k in range(p-1)]
def A_R_n_character(R,n):
    if R not in [3,5,7]:
        return None
    chars=chars_mod_prime(R)
    total=0+0j
    for X in range(1,n+1):
        if n%X: continue
        for Y in range(1,n//X+1):
            if (n//X)%Y: continue
            Z=n//(X*Y)
            if math.gcd(X,Y)!=1 or math.gcd(n,R)!=1: continue
            indicator=sum(ch((-1)%R)*ch(X)*complex(ch(Y)).conjugate() for ch in chars)/(R-1)
            total += indicator
    return round(total.real)
small_pair_tests=[]
for R in [3,5,7]:
    for n in range(1,80):
        if math.gcd(n,R)==1:
            brute,_=A_R_n(R,n)
            char=A_R_n_character(R,n)
            if brute!=char:
                small_pair_tests.append((R,n,brute,char))
                break

# ---------- champion and failed shell ----------
champ_p=8803369; champ_R=107
champ_a=(champ_p+champ_R)//4
champ_X=1; champ_Y=3**2*43*47; champ_Z=11**2
champ_ok=(champ_a==champ_X*champ_Y*champ_Z and (champ_X+champ_Y)%champ_R==0)
champ_b=champ_X*champ_Z*(champ_X+champ_Y)//champ_R
champ_c=champ_Y*champ_Z*(champ_X+champ_Y)//champ_R
# These are reduced R/N denominators; for original fixed a with N=pa, central branch has p factor.

fail_p=8803369; fail_R=43; fail_a=(fail_p+fail_R)//4
fail_factors=factor(fail_a)
rad_relation=(pow(379,2,fail_R)*5807)%fail_R
# signed support of a for coprime two-channel
def signed_support(factors,mod):
    vals=[]
    for beta in itertools.product(*[range(-e,e+1) for q,e in factors]):
        x=1
        for (q,e),b in zip(factors,beta):
            if b>=0: x=(x*pow(q,b,mod))%mod
            else: x=(x*pow(inv_mod(q,mod),-b,mod))%mod
        vals.append((beta,x))
    return vals
fail_Q=set(x for beta,x in signed_support(fail_factors,fail_R))
fail_cert=((fail_R-1) in fail_Q) or ((-inv_mod(fail_p,fail_R))%fail_R in fail_Q)

# ---------- report ----------
report={
    "V840_size": len(V840),
    "S840_sorted": sorted(S840),
    "powers_289": powers289,
    "fibers": {k: sorted(v) for k,v in fibers.items()},
    "kappa": {str(k):v for k,v in sorted(kappa.items())},
    "H2_order": len(H2),
    "H3_order": len(H3),
    "H3_nonzero_weights": sorted(set(sum(x!=0 for x in v) for v in H3 if v!=(0,0,0,0))),
    "glue_order": len(H_glue_set),
    "glue_isotropic_all": all(glue_isotropic),
    "glue_nonzero_min_norms": sorted({str(x) for x in min_norms}),
    "GL2F3_order": len(GL23),
    "GL2F3_center_order": len(center),
    "PGL2F3_image_order_on_P1": len(image),
    "PGL2F3_kernel_order": len(kernel),
    "eta_reciprocal_coefficients_excluding_q_minus_1": eta_coeffs,
    "C3_positive_inverse_ok": matmul_int(C3p,C3p_inv)==[[1,0,0],[0,1,0],[0,0,1]],
    "C3_supported_zero_inverse_ok": matmul_int(C3z,C3z_inv)==[[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]],
    "C4_positive_matrix": C4p,
    "C4_kernel_e2_minus_e4_image": ker_C4,
    "pair_zeta_character_mismatches": small_pair_tests,
    "champion": {
        "p": champ_p, "R": champ_R, "a": champ_a,
        "X": champ_X, "Y": champ_Y, "Z": champ_Z,
        "X_plus_Y": champ_X+champ_Y,
        "pair_certificate_ok": champ_ok,
        "reduced_b": champ_b,
        "reduced_c": champ_c,
        "p_mod_840": champ_p%840, "kappa": kappa[champ_p%840]
    },
    "failed_43": {
        "p": fail_p, "R": fail_R, "a": fail_a, "factors": fail_factors,
        "379_squared_times_5807_mod_43": rad_relation,
        "equals_minus_one": rad_relation==fail_R-1,
        "finite_signed_support": sorted(fail_Q),
        "finite_two_channel_certificate": fail_cert,
        "p_mod_840": fail_p%840, "kappa": kappa[fail_p%840]
    }
}

out=Path(__file__).resolve().parent
(out/"verification_report.json").write_text(json.dumps(report,indent=2,sort_keys=True))
md=["# Defect-completed residual verification report\n"]
for k,v in report.items():
    if k in ["fibers","kappa","champion","failed_43"]: continue
    md.append(f"- **{k}**: `{v}`")
md.append("\n## Champion shell p=8803369, R=107\n")
for k,v in report["champion"].items(): md.append(f"- **{k}**: `{v}`")
md.append("\n## Failed finite-capacity shell p=8803369, R=43\n")
for k,v in report["failed_43"].items(): md.append(f"- **{k}**: `{v}`")
(out/"verification_report.md").write_text("\n".join(md)+"\n")
print(json.dumps(report,indent=2,sort_keys=True))


#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction
from itertools import product, permutations
from collections import Counter, defaultdict
import math


def inv_mod(a: int, m: int) -> int:
    a %= m
    if math.gcd(a, m) != 1:
        raise ValueError((a, m))
    return pow(a, -1, m)


def legendre(a: int, p: int) -> int:
    a %= p
    if a == 0:
        return 0
    v = pow(a, (p - 1) // 2, p)
    return 1 if v == 1 else -1


def units_mod(n: int):
    return [r for r in range(n) if math.gcd(r, n) == 1]


def factor(n: int):
    out = []
    d = 2
    while d * d <= n:
        e = 0
        while n % d == 0:
            n //= d
            e += 1
        if e:
            out.append((d, e))
        d += 1 if d == 2 else 2
    if n > 1:
        out.append((n, 1))
    return out


def ok(label, value):
    print(f"[OK] {label}: {value}")

# 1. Modulo 840 fibration.
V840 = [r for r in units_mod(840) if r % 24 == 1]
fibers = defaultdict(list)
for r in V840:
    fibers[(legendre(r, 5), legendre(r, 7))].append(r)
S840 = sorted(fibers[(1, 1)])
powers_289 = [pow(289, j, 840) for j in range(6)]

assert len(V840) == 24
assert sorted(len(v) for v in fibers.values()) == [6, 6, 6, 6]
assert sorted(powers_289) == S840
assert powers_289 == [1, 289, 361, 169, 121, 529]
ok("|V_840|", len(V840))
ok("fiber sizes", sorted(len(v) for v in fibers.values()))
ok("<289>", powers_289)

# 2. Coprimality boundary matrices.
def C(n):
    return [[1 if math.gcd(i, j) == 1 else 0 for j in range(1, n + 1)] for i in range(1, n + 1)]

def matmul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]

C3 = C(3)
C3inv = [[-1, 1, 1], [1, -1, 0], [1, 0, -1]]
assert matmul(C3, C3inv) == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
C4 = C(4)
ker = [C4[i][1] - C4[i][3] for i in range(4)]
assert ker == [0, 0, 0, 0]
ok("C3 inverse", C3inv)
ok("C4(e2-e4)", ker)

# 3. Glue subgroup.
def qA(k: int) -> Fraction:
    k %= 6
    return Fraction(5 * k * k, 6)


def muA(k: int) -> Fraction:
    k %= 6
    return Fraction(k * (6 - k), 6)


def qD(y):
    return Fraction(0) if y == (0, 0) else Fraction(1)


def even_mod_2(x: Fraction) -> bool:
    return x.denominator == 1 and x.numerator % 2 == 0

# H2 table with D4 classes as F2^2.
H2 = [
    ((0, 0, 0, 0), (0, 0)),
    ((1, 1, 1, 1), (0, 0)),
    ((1, 1, 0, 0), (1, 0)),
    ((0, 0, 1, 1), (1, 0)),
    ((1, 0, 1, 0), (0, 1)),
    ((0, 1, 0, 1), (0, 1)),
    ((1, 0, 0, 1), (1, 1)),
    ((0, 1, 1, 0), (1, 1)),
]
H3gens = [(1, 1, 1, 0), (1, 2, 0, 1)]
H3 = sorted(set(tuple((a * H3gens[0][i] + b * H3gens[1][i]) % 3 for i in range(4)) for a, b in product(range(3), repeat=2)))
assert len(H3) == 9
assert sorted(set(sum(1 for x in v if x) for v in H3 if v != (0, 0, 0, 0))) == [3]
H = []
for u, y in H2:
    for v in H3:
        k = tuple((3 * u[i] + 2 * v[i]) % 6 for i in range(4))
        H.append((k, y))
H = sorted(set(H))
assert len(H) == 72
isotropic = []
mins = []
for k, y in H:
    q = sum(qA(x) for x in k) + qD(y)
    isotropic.append(even_mod_2(q))
    if k != (0, 0, 0, 0) or y != (0, 0):
        mins.append(sum(muA(x) for x in k) + (Fraction(0) if y == (0, 0) else Fraction(1)))
assert all(isotropic)
assert sorted(set(mins)) == [Fraction(4), Fraction(6)]
ok("|H_ES|", len(H))
ok("H_ES isotropic", all(isotropic))
ok("nonzero glue coset minima", sorted(set(str(m) for m in mins)))

# Generator equivalence.  These five generators are the binary duad and ternary tetracode generators.
gens = [
    ((3, 3, 3, 3), (0, 0)),
    ((3, 3, 0, 0), (1, 0)),
    ((3, 0, 3, 0), (0, 1)),
    ((2, 2, 2, 0), (0, 0)),
    ((2, 4, 0, 2), (0, 0)),
]
Hg = set()
for coeff in product(range(6), repeat=len(gens)):
    k = tuple(sum(coeff[j] * gens[j][0][i] for j in range(len(gens))) % 6 for i in range(4))
    y = (sum(coeff[j] * gens[j][1][0] for j in range(len(gens))) % 2,
         sum(coeff[j] * gens[j][1][1] for j in range(len(gens))) % 2)
    Hg.add((k, y))
assert Hg == set(H)
ok("generator presentation", "matches H2/H3 construction")

# 4. Glue symmetry enumeration.
def sign_action(x, signs):
    return tuple((signs[i] * x[i]) % 6 for i in range(4))

def perm_action(x, perm):
    # New coordinate i receives old coordinate perm[i].
    return tuple(x[perm[i]] for i in range(4))

# all GL2(F2) matrices.
GL22 = []
for a, b, c, d in product(range(2), repeat=4):
    det = (a*d - b*c) % 2
    if det:
        GL22.append(((a, b), (c, d)))

def gl2_act(A, y):
    return ((A[0][0] * y[0] + A[0][1] * y[1]) % 2,
            (A[1][0] * y[0] + A[1][1] * y[1]) % 2)

Hset = set(H)
preservers = []
for signs in product([1, -1], repeat=4):
    for perm in permutations(range(4)):
        for A in GL22:
            image = set()
            for k, y in Hset:
                kk = sign_action(perm_action(k, perm), signs)
                yy = gl2_act(A, y)
                image.add((kk, yy))
            if image == Hset:
                preservers.append((signs, perm, A))
assert len(preservers) == 48
proj = defaultdict(int)
for signs, perm, A in preservers:
    proj[perm] += 1
assert len(proj) == 24 and set(proj.values()) == {2}

def compose_pres(g, h):
    # transform h then g; only needed to compute orders by applying to all discriminant elements
    pass

# Compute order of a transformation on the finite discriminant group.
def apply_trans(tr, elem):
    signs, perm, A = tr
    k, y = elem
    return (sign_action(perm_action(k, perm), signs), gl2_act(A, y))

all_disc = [(k, y) for k in product(range(6), repeat=4) for y in product(range(2), repeat=2)]

def order_trans(tr):
    current = {e: e for e in all_disc}
    # iterate a sample element map by repeated application to all elements
    image = list(all_disc)
    for n in range(1, 100):
        image = [apply_trans(tr, e) for e in image]
        if image == all_disc:
            # This checks only if list order preserved because all_disc sorted and apply all.
            # Need identity pointwise.
            if all(image[i] == all_disc[i] for i in range(len(all_disc))):
                return n
    raise RuntimeError("order too large")

def perm_order(perm):
    seen = [False] * 4
    l = 1
    for i in range(4):
        if not seen[i]:
            j = i; c = 0
            while not seen[j]:
                seen[j] = True
                c += 1
                j = perm[j]
            if c:
                l = math.lcm(l, c)
    return l

lift_orders_4cycles = [order_trans(tr) for tr in preservers if perm_order(tr[1]) == 4]
assert set(lift_orders_4cycles) == {8}
ok("glue symmetry order", len(preservers))
ok("projection to S4", f"{len(proj)} permutations, lift sizes {Counter(proj.values())}")
ok("orders over 4-cycles", sorted(set(lift_orders_4cycles)))

# 5. GL2(F3) and PGL action on P1(F3).
def matmul2(A, B, mod):
    return tuple(tuple(sum(A[i][t] * B[t][j] for t in range(2)) % mod for j in range(2)) for i in range(2))

def det2(A, mod):
    return (A[0][0]*A[1][1] - A[0][1]*A[1][0]) % mod

GL23 = []
for entries in product(range(3), repeat=4):
    A = ((entries[0], entries[1]), (entries[2], entries[3]))
    if det2(A, 3):
        GL23.append(A)
center = [A for A in GL23 if all(matmul2(A, B, 3) == matmul2(B, A, 3) for B in GL23)]
P1 = [(1,0), (0,1), (1,1), (1,2)]
def norm_vec(v):
    a,b = v[0] % 3, v[1] % 3
    if a:
        z = inv_mod(a,3); return ((a*z)%3, (b*z)%3)
    z = inv_mod(b,3); return ((a*z)%3, (b*z)%3)
def act_p1(A, v):
    return norm_vec((A[0][0]*v[0]+A[0][1]*v[1], A[1][0]*v[0]+A[1][1]*v[1]))
perms = []
for A in GL23:
    perms.append(tuple(P1.index(act_p1(A, v)) for v in P1))
assert len(GL23) == 48
assert len(center) == 2
assert len(set(perms)) == 24
assert sum(1 for p in perms if p == (0,1,2,3)) == 2
ok("|GL2(F3)|", len(GL23))
ok("center GL2(F3)", len(center))
ok("PGL2(F3) image on P1", len(set(perms)))

# 6. Eta product expansion excluding q^-1.
def poly_mul(a, b, maxdeg):
    out = [0] * (maxdeg + 1)
    for i, x in enumerate(a):
        if not x: continue
        for j, y in enumerate(b):
            if not y or i + j > maxdeg: continue
            out[i+j] += x*y
    return out

def factor_series(step, exponent, maxdeg):
    out = [0] * (maxdeg + 1)
    out[0] = 1
    if exponent >= 0:
        for k in range(exponent + 1):
            if step * k <= maxdeg:
                out[step*k] = (-1)**k * math.comb(exponent, k)
    else:
        m = -exponent
        k = 0
        while step * k <= maxdeg:
            out[step*k] = math.comb(m+k-1, k)
            k += 1
    return out

def eta_recip(maxdeg=8):
    # q^-1 prod (1-q^n)^5(1-q^3n)(1-q^2n)^-1(1-q^6n)^-5
    p = [0] * (maxdeg + 1); p[0] = 1
    for n in range(1, maxdeg + 1):
        for step, exp in [(n, 5), (3*n, 1), (2*n, -1), (6*n, -5)]:
            if step <= maxdeg:
                p = poly_mul(p, factor_series(step, exp, maxdeg), maxdeg)
    return p
eta = eta_recip(8)
assert eta[:7] == [1, -5, 6, 4, -3, -12, -8]
ok("eta reciprocal coefficients", eta[:9])

# 7. E8 calibration.
E8 = [1,7,11,13,17,19,23,29]
sq = sorted(set((e*e) % 30 for e in E8))
img = sorted(set(x % 30 for x in S840))
assert sq == [1,19]
assert img == [1,19]
assert [x % 30 for x in powers_289] == [1,19,1,19,1,19]
ok("E8 square exponents mod 30", sq)
ok("S840 image mod 30", img)

# 8. Arithmetic examples.
p = 8803369
R = 43
a = (p + R)//4
assert a == 379 * 5807
values = set()
for b1 in [-1,0,1]:
    for b2 in [-1,0,1]:
        x = (pow(379, b1, R) if b1 >= 0 else pow(inv_mod(379, R), -b1, R))
        y = (pow(5807, b2, R) if b2 >= 0 else pow(inv_mod(5807, R), -b2, R))
        values.add((x*y) % R)
targets = {(-1) % R, (-inv_mod(p, R)) % R}
assert targets == {42,41}
assert values.isdisjoint(targets)
assert (pow(379, 2, R) * 5807) % R == 42
ok("R=43 bounded capacity targets", sorted(targets))
ok("R=43 central box misses", sorted(values))
ok("R=43 saturated hit", "379^2*5807 == -1 mod 43")

R = 107
a = (p + R)//4
assert factor(a) == [(3,2),(11,2),(43,1),(47,1)]
val = (pow(inv_mod(3, R), 2, R) * inv_mod(43, R) * inv_mod(47, R)) % R
assert val == R - 1
b = 181085300330
c = 3293760527702370
# Verify equality by cross multiplication.
left_num = 4 * a * b * c
right_num = p * (b*c + a*c + a*b)
assert left_num == right_num
ok("R=107 factorization", factor(a))
ok("R=107 beta=(-2,0,-1,-1)", val)
ok("R=107 denominator identity", "verified")

print("All finite symbolic checks passed.")

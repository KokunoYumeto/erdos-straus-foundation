# Superseded source lineage

The principal reader controls theorem status. Exact duplicate aliases are recorded in `../MANIFEST.csv` or the root `MANIFEST.csv`.

## `z3_center_symmetry/`

- `lineage/z3_center_symmetry/zenodo_16936041_v3.pdf` — historical or exploratory source

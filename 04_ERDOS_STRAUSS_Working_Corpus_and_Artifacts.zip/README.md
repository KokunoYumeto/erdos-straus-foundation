# Erdős–Straus working corpus and supporting artifacts

This archive collects the project sources behind the current reader. It contains LaTeX manuscripts, short notes, verification scripts, data tables, computation reports, and a small set of figures. The material was drawn from bounded project directories and immutable release snapshots, then arranged under descriptive roots.

The current reader is the authority for theorem status. Many files here record intermediate reductions, test cases, abandoned routes, or speculative bridges. They preserve provenance and avenues for further work. The full Erdős–Straus conjecture remains open. In particular, the arithmetic three-cycle sought in several older constructions remains an additional hypothesis unless the current reader supplies the required invariance argument.

## Where to begin

- `sources/umbral_and_divisor/erdos_straus_split_zero_divisor_pair_reconstruction.tex` develops the divisor-shell reconstruction used by the reader.
- `sources/umbral_and_divisor/references.bib` is the byte-exact bibliography recovered from the packaged source ZIP for `es_pre_niemeier.tex`; its external credits and draft-note labels are unchanged.
- `sources/residual_and_computational/8/star_kneser_defect_theorem.tex` and the adjacent verification files contain the Star–Kneser computation.
- `sources/residual_and_computational/3/bb107_full_note.tex` and the top-level `bb107_*` files record the mod-107 calculations and rigidity tables.
- `sources/residual_and_computational/16/lorentz_apollonian_hidden_fiber.tex` gives the Lorentz and circle-packing bridge, with its checker in `16/scripts/`.
- `sources/target_lineage/erdos_straus_residual_cubic_support_algebra.tex` and `sources/target_lineage/extensions/erdos_straus_cubic_phase_residue_lifts.tex` are the sources attached to the preceding Zenodo version. The compiled cubic-phase paper is retained beside its source. Its seven CivQ17 notebook images were recovered pixel-for-pixel from the compiled PDF and now occupy the `phase_ext_figs/` paths expected by the LaTeX source; the recovery manifest preserves page, object, dimension, hash, and attribution data.
- `sources/current_reader_verification/` contains the checkers and archived outputs frozen with the current reader, including the Lorentz–Kocik, orbit-trace, operator-volume, support–glue–Fricke, tetrahedral, and sixfold-parameter calculations.
- `sources/reader_cited_sources/earlier_snapshot/cited/` preserves the bounded Niemeier, umbral, and globalization notes captured with an earlier immutable reader snapshot.
- `sources/cited_project_sources/globalization/` contains all twenty-two TeX sources in the bounded globalization corpus used by the current logbook. The neighboring `split_zero_projective_monads_surcomplex/` and `ES-Fable-C123-support/` directories contain the foundational monad source and the two source maps that identify this material.
- `sources/cited_project_sources/` also contains the additional support-complete, split-zero, and supersignum sources cited by the public logbook. Exact duplicate pairs appear once and are cross-referenced through `MANIFEST.csv`.
- `sources/residual_and_computational/further_results/combined_live_theorem_package.tex` is accompanied by the eight exact PDFs named by its `\includepdf` commands. They were recovered from the bounded companion bundle, safety-checked, and retain their original package hashes.
- `supporting_sources/JGPTech_Fun/Jacobian/` contains the exact `Jacobian/` source tree from JGPTech/Fun commit `2fe1901840ef3aa28232930e1aec8d8bbb61281a`, including the Python, Julia, and Wolfram implementations, manifests, data, paper source, and compiled proof.
- `supporting_sources/sectorial_modular_data/` contains the three sectorial source notes cited in the reader.
- `supporting_sources/qsm_entropy/43.5.7.tex` is the bounded original QSM source cited in the research logbook and globalization source map.
- `lineage/z3_center_symmetry/zenodo_16936041_v3.pdf` preserves the current PDF from the superseded Zenodo record `10.5281/zenodo.16936041`. Its exact TeX is deduplicated to `supporting_sources/sectorial_modular_data/3.tex`; `MANIFEST.csv` records the alias.
- `supporting_sources/arithmetic_time_cpt/` contains the integrated arithmetic-time and CPT source cited by the present reader.

## Directory map

- `sources/residual_and_computational/` corresponds to `Documents/Papors/Chatnotes/BEAVERSHINE/`.
- `sources/umbral_and_divisor/` corresponds to `Documents/Papors/Chatnotes/E-S umbrl/`.
- `sources/target_lineage/` corresponds to `Documents/Papors/Chatnotes/mock/`.
- `sources/current_reader_verification/` comes from the immutable maintained-reader checkpoint for this release.
- `sources/reader_cited_sources/earlier_snapshot/` is the preceding bounded cited-artifact snapshot retained for provenance.
- `sources/cited_project_sources/` contains exact, bounded project files needed to resolve later logbook citations.
- `supporting_sources/sectorial_modular_data/` comes from the three bounded local sectorial notes cited by the reader.
- `supporting_sources/qsm_entropy/` contains the single bounded QSM source cited by the current logbook.
- `lineage/z3_center_symmetry/` comes from the public files of Zenodo record `16936041`.
- `supporting_sources/arithmetic_time_cpt/` comes from the bounded `Soc` source cited by the reader.
- `supporting_sources/JGPTech_Fun/Jacobian/` is the pinned external source tree credited to Jon Poplett / u/JGPTech.

`MANIFEST.csv` maps every reviewed local source to its public path and records both SHA-256 digests. Public paths use descriptive directory names; the manifest retains the original project-relative location for provenance. Exact duplicates are represented once and listed as aliases in the manifest. `CHECKSUMS.sha256` covers every public member other than the checksum file itself.

`INDEX.md` is the quickest file-by-file navigation aid. It groups canonical members by public directory and records the review status assigned during assembly. Shorter directory-level listings are available at `sources/INDEX.md`, `supporting_sources/INDEX.md`, and `lineage/INDEX.md`.

The JGPTech subtree is reproduced byte-for-byte from the pinned public commit and retains Jon Poplett / u/JGPTech's authorship. No license file applies at the repository root or inside `Jacobian/` at that commit. The files therefore remain subject to the upstream author's copyright and any permission separately granted by the upstream project; their presence here does not create a broader reuse license.

## Editorial and privacy treatment

Local project manuscripts are credited to **The Clankers**. The public copies use that byline consistently; the manifest records whether a byline was retained, replaced, or inserted, without reproducing a discarded local name. External source notes retain their published author credits. A few old references to the software used during calculation were changed to neutral descriptions of the computation. No mathematical formula, dataset, or program logic was altered by this editorial pass.

Raw research transcripts, internal task notes, profile paths, copied literature, build logs, cache files, shortcuts, nested archives, and redundant compiled PDFs are omitted. Public papers and posts used by the project are cited in the reader; copies are absent from this archive.

The archive was built deterministically. Member names are relative, path-safe, and sorted; all entries use the same ZIP timestamp. The release verification bundle contains the independently replayed checkers and the Lean development used for the principal identities.

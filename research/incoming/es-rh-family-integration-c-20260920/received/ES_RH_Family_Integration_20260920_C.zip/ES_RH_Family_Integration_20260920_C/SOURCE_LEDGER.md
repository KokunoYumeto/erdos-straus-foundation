# Source ledger and integration boundaries

## Supplied basis (GF)

Title: *General-family control: multiplicities, collisions, source sections, and all mixed minima*. Date in the source: 20 September 2026. Author not separately identified in the supplied attachment. Original file: `Pasted markdown(7).md`, file ID `file_0000000099a88210bbb9a328a59c4a71`, 979 lines, 30,064 bytes. Entire text read through Files and preserved unchanged as `sources/GENERAL_FAMILY_INPUT.md`.

Uses: GF(3)–(18), complete constructed tensor/jet metric and variance; GF(19)–(35), the aggregate and actual source-section realization; GF(36)–(39), complete cross Gram and joint minimum; GF(49)–(54), the two-centre evaluation and its weighted-minor problem; GF(55)–(60), the constructed-family heat scale. The directly implemented finite interfaces were independently checked. This is not a claim to have retrieved the standalone `Programme_General_Families_20260920.zip` or the additional linked complete proof and verification files. Library search returned the supplied note but not that separate package.

## Current connected repositories

RH: `KokunoYumeto/zeta-function-research-reader`, head read as `b1f3e2e1879c40f411eb263dde171589cb5f9390`, commit timestamp 2026-09-20 18:43:31 UTC. Its README records a new finite-theta certificate; only the update's status was read for this integration. That certificate is not a premise of a new theorem here.

Native Gaussian provider: `workbenches/splitzero-tandem/continuations/20260920-gaussian-arithmetic-return/NATIVE_GAUSSIAN_TRANSFER.tex` at that commit. Git blob `6122e3b4f165df907a46ddcbc739f4dc159d65c6`. Current directly read range 365–462, NG16–NG22. Uses: the original native selfadjoint compression law NG20, its no-atom-at-zero density, the actual rank-one comparison NG21, and the distinction from the observed minimum NG22. The full provider was examined in prior conversation turns. Its varying-weight asymptotic proof was not independently rebuilt or numerically tested in this integration. MR7–MR14 and JS15 explicitly inherit it as a theorem input.

Pinned source: https://github.com/KokunoYumeto/zeta-function-research-reader/blob/b1f3e2e1879c40f411eb263dde171589cb5f9390/workbenches/splitzero-tandem/continuations/20260920-gaussian-arithmetic-return/NATIVE_GAUSSIAN_TRANSFER.tex

ES: `KokunoYumeto/erdos-straus-foundation`, head read as `34e45e06694c66650ddb4550bbf48c60ce75d8f9`, timestamp 2026-09-20 16:53:19 UTC. The already retained original equation, marking, and integral hard-prime root distinctness are used in ER11–ER14. No new ES occupancy theorem, rational/integral zero of the receiving divisor, or finite-prime model of a transcendental physical metric is claimed.

Repository writes: none. The new results are local artifacts for review and integration. Connector search for the new general-family title returned no match; that search is not treated as proof that integration has not occurred under another filename.

## Preserved prior material

`prior/ES_RH_Multi_20260920.zip` is the exactly available predecessor archive, copied unchanged. `prior/B_supplied_notes/` contains the four supplied continuation-B Markdown/JSON artifacts found in the active runtime. The complete B ZIP and its checker sources were not mounted in this continuation and are not represented as present or replayed. No previous check count is added to the fresh 4-suite count.

## Primary external references

Higham, N. J. (2020, October 13). *What is the singular value decomposition?* https://nhigham.com/2020/10/13/what-is-the-singular-value-decomposition/ . Author's exposition read for SVD, norm and singular-space conventions. The exterior identities actually needed here are proved directly.

National Institute of Standards and Technology. (n.d.). *DLMF*, §26.3. https://dlmf.nist.gov/26.3 . Binomial definitions and generating functions checked; all problem-specific determinant and weight identities are proved here. No mathematical claim is based on a search-result snippet from an unrelated source.

A direct raw-source download was attempted but did not succeed. No complete byte copy of the new GitHub provider is claimed. The received general-family text and predecessor archive, in contrast, have exact local bytes and are hashed in the manifest.

## Verification boundary

The exact Python/SymPy scripts use explicit exceptions, not `assert`, so optimized Python does not remove their comparisons. The external tool time limit interrupted the all-suites orchestration; the remaining optimized metric suite was run separately to completion. The final collection checked every complete normal/optimized stdout and JSON pair for byte equality. The completed receipts, not the interrupted orchestration attempts, determine the verification summary.

Tests are exact finite algebra, with deliberately labelled synthetic positive-metric matrices and bounded combinatorial cases. They do not evaluate unknown original xi packets, approximate a zeta zero, or constitute Lean verification. All asymptotic source uses and finite test boundaries are separately stated in the manuscript.

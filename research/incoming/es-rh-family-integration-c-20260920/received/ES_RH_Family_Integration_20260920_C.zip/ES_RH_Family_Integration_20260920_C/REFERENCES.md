

\newpage
# References and continuation boundary

*General-family control: Multiplicities, collisions, source sections, and all mixed minima*. (2026, September 20). [User-supplied programme continuation; original author unspecified in the supplied text]. File `Pasted markdown(7).md`. The entire supplied 979-line text is preserved. Source equations GF(1)–GF(60) retain their original numbering and attribution status.

Higham, N. J. (2020, October 13). *What is the singular value decomposition?* Author's mathematical exposition. https://nhigham.com/2020/10/13/what-is-the-singular-value-decomposition/ . Read for the standard SVD, norm, and singular-space conventions. The finite exterior inequalities in this continuation are proved directly and are not attributed as a new SVD theorem.

National Institute of Standards and Technology. (n.d.). *NIST Digital Library of Mathematical Functions*, §26.3, Lattice paths: Binomial coefficients. https://dlmf.nist.gov/26.3 . Definitions and generating-function conventions checked. The multinomial, Vandermonde, and minor identities required above are proved at their uses.

Split-Zero research programme. (2026, September 20). *Gaussian spectral actions through the original arithmetic quotient* [Research manuscript, NG1–NG27]. Zeta-function research reader, commit `b1f3e2e1879c40f411eb263dde171589cb5f9390`, file `workbenches/splitzero-tandem/continuations/20260920-gaussian-arithmetic-return/NATIVE_GAUSSIAN_TRANSFER.tex`. The directly read current passage is lines 365–462, NG16–NG22, with exact native compression law NG20 and rank-one relation NG21. Its full theorem provenance is preserved in the preceding conversation's source reading; this integration does not claim a fresh proof of the upstream varying-measure asymptotic.

The Clankers. (2026, September 20). *Erdős–Straus Foundation* [Repository and integrated defining-prime source edition]. Commit `34e45e06694c66650ddb4550bbf48c60ce75d8f9`. The original ES equation and literal-root marking are retained. No global occupancy or integral singularity claim is inferred from the jet thickening in Section 3.

**What remains to evaluate.** The supplied finite source entries, the complete cross Gram `C_X`, its value map `F`, and its spectral orientation relative to the actual observation kernel remain native arithmetic inputs. JS6 splits their determinant cost exactly but does not supply their values. The enlarged ES/RH representation has the explicit value space ER5; returning it to a smaller original observation requires the stated additional quotient rather than an assumed identification. The canonical comparison MR7–MR14 remains conditional on the pinned source's actual spectral-transfer theorem, with its stated fixed-packet and cutoff limits. Its lack of an effective convergence threshold is not replaced by the exact small-matrix tests.

# ES–RH general-family integration C

Complete proof notes and fresh exact tests integrating the supplied general-family construction with the canonical arithmetic metric, the original full source minimum, and the ES-labelled tensor action.

Read `RESEARCH_CONTINUATION.md` or `MANUSCRIPT.pdf`. The four standalone proof files are in `proofs/`; the received text is preserved unchanged in `sources/`. `SOURCE_LEDGER.md` identifies every inherited theorem and the reading boundary. `CODEX_HANDOFF.md` lists the exact continuing calculations without assigning uncomputed native values.

Fresh verification: 4 suites, 1,275 exact checks and 20 negative-control executions per interpreter mode; normal and optimized receipts are identical. See `results/VERIFICATION_SUMMARY.json`. Run `python checks/run_validation.py` to replay. Python 3 with SymPy is required; no network is used by the checks. The tests are not Lean proofs or numerical native-moment evaluations.

The prior Multi archive and the supplied B notes are included with their original content. This is not represented as a complete copy of an unmounted B archive or the separate general-family proof package linked inside the received text. No repository files were changed.

Rebuild the typeset manuscript with `python build_manuscript.py` (requires Pandoc and pdfLaTeX). The source-note bytes are not changed by that script. `CLAIM_REGISTER.json` distinguishes finite proofs from asymptotic consequences of the pinned upstream theorem.

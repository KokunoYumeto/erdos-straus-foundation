# Historical drafts and corrections

This archive records the development of the Erdős–Straus project through the first three versions of concept DOI `10.5281/zenodo.20401937`. The files are preserved for provenance. The current project reader gives the statements and proofs that the release adopts.

## How to read the archive

The directory `public_versions/` contains the files published in records `20401938`, `20408579`, and `20449975`. The first record also carried a RAR of working drafts; its original bytes appear in `original_record_20401938/`.

The v3 cubic-phase TeX cites seven CivQ17 notebook images whose standalone
files were absent from the bounded project shelves. The original v3 TeX and
PDF remain byte-identical to their archived copies. For source rebuilds,
`public_versions/v3_record_20449975/phase_ext_figs/` adds PNGs recovered
pixel-for-pixel from the compiled PDF, together with page, object, dimension,
hash, method, and attribution records.

For convenience, the RAR members have been arranged by mathematical status:

- `bounded_predecessor/` contains finite reductions, divisor-shell algebra, and Lorentz or projective calculations.
- `bounded_diagnostic/` contains modular and mixed-mock calculations that record a surviving obstruction.
- `corrective_note/` contains the later analysis of the projective step.
- `historical_overstatement/` contains five draft families that claimed terminal annihilation and the full conjecture.

## The superseded terminal claim

The five affected draft families are:

- `constructive_terminal_algebra_preprint.*`
- `erdos_straus_centered_sign_integrated_preprint.*`
- `erdos_straus_projective_completion_shell_fixed.*`
- `erdos_straus_projective_completion_sign_corrected.*`
- `erdos_straus_projective_completion_tobley_revised.*`

Their projective construction removes a formal endpoint-orientation line. The desired arithmetic conclusion also requires the residual chamber-count vector to have zero projective-even component. The drafts leave that condition open. Their terminal-annihilation theorem and global conclusion are superseded.

The file `projective_springborn_terminal_transport_corrected.*` gives the corrected conditional statement and identifies the missing arithmetic input.

## Using individual results

The archive contains many valid algebraic identities and finite calculations. Each such result enters the current reader only after an independent proof or computational replay. The manifests record file identity and historical classification. Theorem-level review remains separate.

## Manifests

- `manifests/ZENODO_VERSION_HISTORY.csv` records the three published versions and their public hashes.
- `manifests/ORIGINAL_RAR_MEMBER_STATUS.csv` records the 25 original RAR members, CRCs, and status classes.
- `MANIFEST.csv` records every accessible member of this ZIP with its size and SHA-256.
- `SHA256SUMS.txt` provides a plain checksum list for all files except itself.

Project synthesis and archive preparation: **The Clankers**.
